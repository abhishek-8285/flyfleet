--
-- PostgreSQL database dump
--

\restrict I7iXoMSizNePegjCLMmfwu2TZ8LSOrndMfnUYC5i56XVNnLjbFhHvoJdJX3TcEN

-- Dumped from database version 15.15
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: governance_request_status; Type: TYPE; Schema: public; Owner: fleet_user
--

CREATE TYPE public.governance_request_status AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED',
    'EXPIRED',
    'COMPLETED'
);


ALTER TYPE public.governance_request_status OWNER TO fleet_user;

--
-- Name: governance_request_type; Type: TYPE; Schema: public; Owner: fleet_user
--

CREATE TYPE public.governance_request_type AS ENUM (
    'EXPORT',
    'DELETION',
    'ACCESS_REVIEW'
);


ALTER TYPE public.governance_request_type OWNER TO fleet_user;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO fleet_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_review_items; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.access_review_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    review_id uuid,
    user_id uuid,
    status character varying(50) DEFAULT 'pending'::character varying,
    reviewer_id uuid,
    notes text,
    reviewed_at timestamp with time zone
);


ALTER TABLE public.access_review_items OWNER TO fleet_user;

--
-- Name: access_reviews; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.access_reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    title character varying(255),
    status character varying(50) DEFAULT 'pending'::character varying,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.access_reviews OWNER TO fleet_user;

--
-- Name: alert_rules; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.alert_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    description text,
    severity character varying(20) DEFAULT 'warning'::character varying,
    conditions jsonb NOT NULL,
    actions jsonb,
    vehicles jsonb,
    driver_ids jsonb,
    enabled boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.alert_rules OWNER TO fleet_user;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.alerts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    rule_id uuid,
    type character varying(50) NOT NULL,
    severity character varying(20) DEFAULT 'warning'::character varying,
    vehicle_id uuid,
    driver_id uuid,
    "timestamp" timestamp with time zone DEFAULT now(),
    location jsonb,
    details jsonb,
    status character varying(20) DEFAULT 'new'::character varying,
    notes text,
    acknowledged_by uuid,
    acknowledged_at timestamp with time zone,
    resolved_by uuid,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.alerts OWNER TO fleet_user;

--
-- Name: analytics_jobs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.analytics_jobs (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(100) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    job_type character varying(100) NOT NULL,
    parameters jsonb DEFAULT '{}'::jsonb NOT NULL,
    input_source character varying(255) NOT NULL,
    output_destination character varying(255) NOT NULL,
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    progress numeric(5,2) DEFAULT 0,
    error_details text,
    organization_id uuid NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT analytics_jobs_progress_check CHECK (((progress >= (0)::numeric) AND (progress <= (100)::numeric)))
);


ALTER TABLE public.analytics_jobs OWNER TO fleet_user;

--
-- Name: api_clients; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.api_clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    client_id character varying(100) NOT NULL,
    client_secret_hash text NOT NULL,
    name character varying(255) NOT NULL,
    scopes text[] DEFAULT '{}'::text[],
    expiry timestamp with time zone,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.api_clients OWNER TO fleet_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    resource character varying(100) NOT NULL,
    details jsonb,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    severity character varying(20) DEFAULT 'info'::character varying,
    status character varying(20) DEFAULT 'success'::character varying,
    org_id uuid,
    module character varying(100),
    entity_id character varying(100),
    before_state jsonb,
    after_state jsonb,
    metadata jsonb
);


ALTER TABLE public.audit_logs OWNER TO fleet_user;

--
-- Name: audit_policies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.audit_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    retention_years integer DEFAULT 7,
    archive_policy character varying(100) DEFAULT 'MOVE_TO_COLD_STORAGE_1Y'::character varying,
    masking_rules jsonb DEFAULT '["credit_card", "ssn", "phone", "email"]'::jsonb,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_policies OWNER TO fleet_user;

--
-- Name: audit_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.audit_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    retention_days_online integer DEFAULT 90,
    retention_days_archival integer DEFAULT 2555,
    masking_rules jsonb DEFAULT '["password", "secret", "token", "phone", "email_local"]'::jsonb,
    tracked_event_types jsonb DEFAULT '["MFA_POLICY_UPDATE", "MFA_EXCEPTION_GRANT", "MFA_OVERRIDE_TOGGLE", "LOGIN_SUCCESS", "LOGIN_FAILED"]'::jsonb,
    alert_on_critical boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_settings OWNER TO fleet_user;

--
-- Name: auth_tokens; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.auth_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    access_token text NOT NULL,
    refresh_token text NOT NULL,
    device_id character varying(255),
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    ip_address character varying(45),
    user_agent text,
    last_active timestamp with time zone DEFAULT now(),
    is_active boolean DEFAULT true
);


ALTER TABLE public.auth_tokens OWNER TO fleet_user;

--
-- Name: backups; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.backups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    s3_key character varying(255) NOT NULL,
    size_bytes bigint DEFAULT 0 NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.backups OWNER TO fleet_user;

--
-- Name: billing_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_settings (
    org_id uuid NOT NULL,
    default_tax_rate numeric(5,2) DEFAULT 0.00 NOT NULL,
    base_currency text DEFAULT 'USD'::text NOT NULL,
    grace_period_days integer DEFAULT 14 NOT NULL,
    auto_invoicing_enabled boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_settings OWNER TO fleet_user;

--
-- Name: bulk_config; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.bulk_config (
    organization_id uuid NOT NULL,
    max_records_per_file integer DEFAULT 5000,
    concurrent_threads integer DEFAULT 4,
    retention_months integer DEFAULT 6,
    mandatory_fields jsonb DEFAULT '["vin", "registration_no", "make", "model_year"]'::jsonb,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.bulk_config OWNER TO fleet_user;

--
-- Name: bulk_job_records; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.bulk_job_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id uuid NOT NULL,
    row_number integer NOT NULL,
    record_data jsonb,
    status character varying(50) NOT NULL,
    error_message text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT bulk_job_records_status_check CHECK (((status)::text = ANY ((ARRAY['success'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.bulk_job_records OWNER TO fleet_user;

--
-- Name: bulk_jobs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.bulk_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    file_name character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    total_records integer DEFAULT 0,
    success_count integer DEFAULT 0,
    failed_count integer DEFAULT 0,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    retry_count integer DEFAULT 0,
    CONSTRAINT bulk_jobs_status_check CHECK (((status)::text = ANY ((ARRAY['processing'::character varying, 'completed'::character varying, 'failed'::character varying, 'partial_success'::character varying])::text[])))
);


ALTER TABLE public.bulk_jobs OWNER TO fleet_user;

--
-- Name: device_commands; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_id uuid,
    org_id uuid,
    command character varying(100) NOT NULL,
    category character varying(50),
    params jsonb,
    status character varying(20) DEFAULT 'pending'::character varying,
    result jsonb,
    error_message text,
    created_by uuid,
    sent_at timestamp with time zone,
    executed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.device_commands OWNER TO fleet_user;

--
-- Name: device_diagnostics_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_diagnostics_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_id uuid,
    org_id uuid,
    log_type character varying(50),
    source character varying(50),
    message text,
    metadata jsonb,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.device_diagnostics_logs OWNER TO fleet_user;

--
-- Name: device_firmware_status; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_firmware_status (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_id uuid,
    rollout_id uuid,
    status character varying(20) DEFAULT 'pending'::character varying,
    progress integer DEFAULT 0,
    error_message text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.device_firmware_status OWNER TO fleet_user;

--
-- Name: device_telemetry; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_telemetry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_id uuid,
    org_id uuid,
    payload jsonb NOT NULL,
    packet_type character varying(50),
    raw_hex text,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.device_telemetry OWNER TO fleet_user;

--
-- Name: devices; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    vehicle_id uuid,
    serial_number character varying(100) NOT NULL,
    type character varying(50) DEFAULT 'gps'::character varying,
    status character varying(20) DEFAULT 'active'::character varying,
    last_ping_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    firmware_version character varying(50),
    battery_level integer,
    signal_strength integer,
    hardware_revision character varying(20),
    last_heartbeat timestamp with time zone,
    model character varying(50),
    manufacturer character varying(50)
);


ALTER TABLE public.devices OWNER TO fleet_user;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    doc_number character varying(100) NOT NULL,
    issue_date date NOT NULL,
    expiry_date date NOT NULL,
    file_url text,
    status character varying(20) DEFAULT 'pending'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.documents OWNER TO fleet_user;

--
-- Name: TABLE documents; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.documents IS 'Stores compliance documents associated with vehicles';


--
-- Name: COLUMN documents.metadata; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.documents.metadata IS 'Flexible JSON storage for document-specific attributes';


--
-- Name: driver_behavior; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_behavior (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    driver_id uuid NOT NULL,
    org_id uuid NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    score double precision,
    safety_score double precision,
    efficiency_score double precision,
    compliance_score double precision,
    harsh_accelerations integer DEFAULT 0,
    harsh_brakings integer DEFAULT 0,
    harsh_cornerings integer DEFAULT 0,
    speeding_incidents integer DEFAULT 0,
    phone_usage integer DEFAULT 0,
    seatbelt_violations integer DEFAULT 0,
    fuel_consumption double precision DEFAULT 0,
    distance_driven double precision DEFAULT 0,
    idle_time integer DEFAULT 0,
    eco_driving_score double precision,
    hours_of_service double precision,
    rest_periods integer,
    document_compliance boolean DEFAULT true,
    maintenance_adherence boolean DEFAULT true,
    night_driving_hours double precision DEFAULT 0,
    highway_percentage double precision DEFAULT 0,
    city_driving_percentage double precision DEFAULT 0,
    risk_level character varying(20),
    risk_factors jsonb,
    improvement_areas jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_behavior OWNER TO fleet_user;

--
-- Name: driver_behavior_analytics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_behavior_analytics (
    id character varying(36) NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    analysis_period_start date NOT NULL,
    analysis_period_end date NOT NULL,
    total_driving_hours numeric(8,2) DEFAULT 0 NOT NULL,
    aggressive_acceleration_count integer DEFAULT 0 NOT NULL,
    hard_braking_count integer DEFAULT 0 NOT NULL,
    sharp_turn_count integer DEFAULT 0 NOT NULL,
    over_speeding_count integer DEFAULT 0 NOT NULL,
    idling_time numeric(8,2) DEFAULT 0 NOT NULL,
    average_speed numeric(8,2) DEFAULT 0 NOT NULL,
    max_speed numeric(8,2) DEFAULT 0 NOT NULL,
    fuel_efficiency numeric(8,2) DEFAULT 0 NOT NULL,
    safety_score numeric(5,2) DEFAULT 0 NOT NULL,
    efficiency_score numeric(5,2) DEFAULT 0 NOT NULL,
    comfort_score numeric(5,2) DEFAULT 0 NOT NULL,
    ranking integer,
    improvement_suggestions jsonb DEFAULT '[]'::jsonb NOT NULL,
    behavior_trend character varying(20) DEFAULT 'stable'::character varying NOT NULL,
    generated_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT driver_behavior_analytics_comfort_score_check CHECK (((comfort_score >= (0)::numeric) AND (comfort_score <= (100)::numeric))),
    CONSTRAINT driver_behavior_analytics_efficiency_score_check CHECK (((efficiency_score >= (0)::numeric) AND (efficiency_score <= (100)::numeric))),
    CONSTRAINT driver_behavior_analytics_safety_score_check CHECK (((safety_score >= (0)::numeric) AND (safety_score <= (100)::numeric)))
);


ALTER TABLE public.driver_behavior_analytics OWNER TO fleet_user;

--
-- Name: driver_incidents; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_incidents (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    driver_id uuid NOT NULL,
    org_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    location jsonb,
    speed double precision,
    details jsonb,
    resolved boolean DEFAULT false,
    resolution_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_incidents OWNER TO fleet_user;

--
-- Name: driver_verifications; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_verifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    license_number character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    verification_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    name character varying(100) NOT NULL,
    father_name character varying(100),
    date_of_birth date,
    gender character varying(10),
    address text,
    city character varying(50),
    district character varying(50),
    state character varying(50),
    pin character varying(10),
    license_class jsonb,
    issue_date date,
    validity_from date,
    validity_to date,
    last_transaction character varying(100),
    enrollment_number character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT driver_verifications_status_check CHECK (((status)::text = ANY ((ARRAY['verified'::character varying, 'pending'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.driver_verifications OWNER TO fleet_user;

--
-- Name: drivers; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.drivers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    full_name character varying(100) GENERATED ALWAYS AS ((((first_name)::text || ' '::text) || (last_name)::text)) STORED,
    email character varying(100) NOT NULL,
    phone character varying(20) NOT NULL,
    license_number character varying(50) NOT NULL,
    license_type character varying(20),
    license_expiry timestamp with time zone,
    license_authority character varying(100),
    date_of_birth timestamp with time zone,
    address jsonb,
    emergency_contact jsonb,
    status character varying(20) DEFAULT 'active'::character varying,
    current_vehicle_id uuid,
    current_trip_id uuid,
    joining_date timestamp with time zone DEFAULT now(),
    resignation_date timestamp with time zone,
    experience_years integer DEFAULT 0,
    rating double precision DEFAULT 5.0,
    total_trips integer DEFAULT 0,
    total_distance_km double precision DEFAULT 0,
    total_hours_driven double precision DEFAULT 0,
    behavior_score integer DEFAULT 100,
    documents jsonb,
    attendance_records jsonb,
    schedules jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


ALTER TABLE public.drivers OWNER TO fleet_user;

--
-- Name: e_way_bills; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.e_way_bills (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    eway_bill_number character varying(50) NOT NULL,
    eway_bill_date timestamp with time zone NOT NULL,
    eway_bill_valid_till timestamp with time zone NOT NULL,
    document_number character varying(50) NOT NULL,
    document_date date NOT NULL,
    document_type character varying(20) NOT NULL,
    goods_description text,
    goods_value numeric(12,2) NOT NULL,
    goods_tax_rate numeric(5,2),
    goods_unit character varying(20),
    goods_quantity numeric(10,2),
    from_place character varying(100) NOT NULL,
    from_pincode character varying(10) NOT NULL,
    from_state_code integer NOT NULL,
    to_place character varying(100) NOT NULL,
    to_pincode character varying(10) NOT NULL,
    to_state_code integer NOT NULL,
    transporter_id character varying(50),
    transporter_name character varying(100),
    transport_mode character varying(20),
    transport_document_number character varying(50),
    transport_document_date character varying(20),
    transit_type character varying(20),
    vehicle_number character varying(20),
    vehicle_type character varying(20),
    remaining_distance numeric(8,2),
    user_gstin character varying(15),
    recipient_gstin character varying(15),
    generated_by character varying(100),
    generated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    cancelled boolean DEFAULT false,
    cancelled_by character varying(100),
    cancelled_on timestamp with time zone,
    cancelled_reason character varying(200),
    updated_by character varying(100),
    updated_at timestamp with time zone,
    CONSTRAINT e_way_bills_document_type_check CHECK (((document_type)::text = ANY ((ARRAY['INV'::character varying, 'CHL'::character varying, 'WBILL'::character varying, 'OTH'::character varying])::text[]))),
    CONSTRAINT e_way_bills_transit_type_check CHECK (((transit_type)::text = ANY ((ARRAY['own'::character varying, 'hired'::character varying, 'railways'::character varying])::text[]))),
    CONSTRAINT e_way_bills_transport_mode_check CHECK (((transport_mode)::text = ANY ((ARRAY['road'::character varying, 'rail'::character varying, 'air'::character varying, 'ship'::character varying])::text[]))),
    CONSTRAINT e_way_bills_vehicle_type_check CHECK (((vehicle_type)::text = ANY ((ARRAY['reg'::character varying, 'lr'::character varying, 'cn'::character varying])::text[])))
);


ALTER TABLE public.e_way_bills OWNER TO fleet_user;

--
-- Name: entity_audit_history; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.entity_audit_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(100) NOT NULL,
    change_data jsonb NOT NULL,
    actor uuid,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.entity_audit_history OWNER TO fleet_user;

--
-- Name: evidence_exports; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.evidence_exports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    module character varying(50) NOT NULL,
    date_range_start timestamp with time zone,
    date_range_end timestamp with time zone,
    format character varying(20) DEFAULT 'pdf'::character varying,
    status character varying(20) DEFAULT 'processing'::character varying,
    requested_by uuid,
    file_url text,
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.evidence_exports OWNER TO fleet_user;

--
-- Name: fastag_transactions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.fastag_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tag_number character varying(50) NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    transaction_id character varying(100) NOT NULL,
    transaction_type character varying(20) NOT NULL,
    amount numeric(10,2) NOT NULL,
    toll_plaza character varying(100) NOT NULL,
    toll_plaza_id character varying(50) NOT NULL,
    lane_id character varying(20) NOT NULL,
    transaction_time timestamp with time zone NOT NULL,
    transaction_date date NOT NULL,
    settlement_date date,
    status character varying(20) NOT NULL,
    error_code character varying(20),
    error_description text,
    reconciled boolean DEFAULT false,
    reconciliation_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fastag_transactions_status_check CHECK (((status)::text = ANY ((ARRAY['success'::character varying, 'failed'::character varying, 'pending'::character varying])::text[]))),
    CONSTRAINT fastag_transactions_transaction_type_check CHECK (((transaction_type)::text = ANY ((ARRAY['debit'::character varying, 'credit'::character varying])::text[])))
);


ALTER TABLE public.fastag_transactions OWNER TO fleet_user;

--
-- Name: firmware_packages; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.firmware_packages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    version character varying(50) NOT NULL,
    hardware_target character varying(50) NOT NULL,
    file_url text NOT NULL,
    file_size integer,
    checksum character varying(64),
    release_notes text,
    status character varying(20) DEFAULT 'draft'::character varying,
    is_critical boolean DEFAULT false,
    released_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.firmware_packages OWNER TO fleet_user;

--
-- Name: firmware_rollouts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.firmware_rollouts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    firmware_id uuid,
    org_id uuid,
    name character varying(100),
    device_group character varying(100),
    target_filter jsonb,
    total_devices integer DEFAULT 0,
    completed_devices integer DEFAULT 0,
    failed_devices integer DEFAULT 0,
    status character varying(20) DEFAULT 'scheduled'::character varying,
    rollout_strategy character varying(20) DEFAULT 'gradual'::character varying,
    max_concurrent integer DEFAULT 10,
    created_by uuid,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.firmware_rollouts OWNER TO fleet_user;

--
-- Name: fleet_analytics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.fleet_analytics (
    id character varying(36) NOT NULL,
    organization_id uuid NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    total_vehicles integer DEFAULT 0 NOT NULL,
    active_vehicles integer DEFAULT 0 NOT NULL,
    total_distance numeric(12,2) DEFAULT 0 NOT NULL,
    average_speed numeric(8,2) DEFAULT 0 NOT NULL,
    total_fuel_consumption numeric(12,2) DEFAULT 0 NOT NULL,
    average_fuel_efficiency numeric(8,2) DEFAULT 0 NOT NULL,
    total_trips integer DEFAULT 0 NOT NULL,
    completed_trips integer DEFAULT 0 NOT NULL,
    cancelled_trips integer DEFAULT 0 NOT NULL,
    average_trip_duration numeric(8,2) DEFAULT 0 NOT NULL,
    idle_time_percentage numeric(5,2) DEFAULT 0 NOT NULL,
    routing_efficiency numeric(5,2) DEFAULT 0 NOT NULL,
    fuel_cost numeric(12,2) DEFAULT 0 NOT NULL,
    maintenance_cost numeric(12,2) DEFAULT 0 NOT NULL,
    revenue numeric(15,2) DEFAULT 0 NOT NULL,
    profit_margin numeric(5,2) DEFAULT 0 NOT NULL,
    safety_score numeric(5,2) DEFAULT 0 NOT NULL,
    accidents_count integer DEFAULT 0 NOT NULL,
    incidents_count integer DEFAULT 0 NOT NULL,
    emergency_stops integer DEFAULT 0 NOT NULL,
    geofence_violations integer DEFAULT 0 NOT NULL,
    alerts_triggered integer DEFAULT 0 NOT NULL,
    data_points_collected bigint DEFAULT 0 NOT NULL,
    processing_time numeric(10,3) DEFAULT 0 NOT NULL,
    generated_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT fleet_analytics_idle_time_percentage_check CHECK (((idle_time_percentage >= (0)::numeric) AND (idle_time_percentage <= (100)::numeric))),
    CONSTRAINT fleet_analytics_routing_efficiency_check CHECK (((routing_efficiency >= (0)::numeric) AND (routing_efficiency <= (100)::numeric))),
    CONSTRAINT fleet_analytics_safety_score_check CHECK (((safety_score >= (0)::numeric) AND (safety_score <= (100)::numeric)))
);


ALTER TABLE public.fleet_analytics OWNER TO fleet_user;

--
-- Name: geofences; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.geofences (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(20) NOT NULL,
    center jsonb,
    radius_meters integer,
    coordinates jsonb,
    route_polyline text,
    buffer_meters integer,
    entry_alert boolean DEFAULT true,
    exit_alert boolean DEFAULT true,
    speed_limit integer,
    vehicles jsonb,
    enabled boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.geofences OWNER TO fleet_user;

--
-- Name: governance_audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.governance_audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    action text NOT NULL,
    module text NOT NULL,
    change_detail text,
    ip_address text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.governance_audit_logs OWNER TO fleet_user;

--
-- Name: governance_requests; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.governance_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    requester_id uuid NOT NULL,
    request_type public.governance_request_type NOT NULL,
    data_scope text NOT NULL,
    purpose text NOT NULL,
    format text DEFAULT 'CSV'::text NOT NULL,
    delivery_method text DEFAULT 'DIRECT'::text NOT NULL,
    status public.governance_request_status DEFAULT 'PENDING'::public.governance_request_status NOT NULL,
    expiry_date timestamp with time zone,
    comments text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.governance_requests OWNER TO fleet_user;

--
-- Name: governance_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.governance_settings (
    organization_id uuid NOT NULL,
    retention_policies jsonb DEFAULT '{}'::jsonb NOT NULL,
    masking_rules jsonb DEFAULT '{}'::jsonb NOT NULL,
    auto_expiry_enabled boolean DEFAULT true NOT NULL,
    download_ttl_hours integer DEFAULT 48 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.governance_settings OWNER TO fleet_user;

--
-- Name: gst_compliances; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.gst_compliances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    gstin character varying(15) NOT NULL,
    status character varying(20) NOT NULL,
    legal_name character varying(200) NOT NULL,
    trade_name character varying(200),
    address text,
    centre_jurisdiction character varying(100),
    state_jurisdiction character varying(100),
    date_of_registration date,
    date_of_cancellation date,
    last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    return_filing_frequency character varying(20),
    return_filing_status character varying(20),
    payment_status character varying(20),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT gst_compliances_payment_status_check CHECK (((payment_status)::text = ANY ((ARRAY['compliant'::character varying, 'non_compliant'::character varying])::text[]))),
    CONSTRAINT gst_compliances_return_filing_frequency_check CHECK (((return_filing_frequency)::text = ANY ((ARRAY['monthly'::character varying, 'quarterly'::character varying, 'annually'::character varying])::text[]))),
    CONSTRAINT gst_compliances_return_filing_status_check CHECK (((return_filing_status)::text = ANY ((ARRAY['compliant'::character varying, 'non_compliant'::character varying])::text[]))),
    CONSTRAINT gst_compliances_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'cancelled'::character varying, 'suspended'::character varying])::text[])))
);


ALTER TABLE public.gst_compliances OWNER TO fleet_user;

--
-- Name: incident_comments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.incident_comments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ticket_id uuid NOT NULL,
    author_id uuid,
    author_name character varying(100),
    comment_type character varying(20) DEFAULT 'INTERNAL'::character varying,
    content text NOT NULL,
    is_private boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.incident_comments OWNER TO fleet_user;

--
-- Name: TABLE incident_comments; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.incident_comments IS 'Comments and history for support tickets';


--
-- Name: integration_configs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.integration_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    service_type character varying(50) NOT NULL,
    api_endpoint text NOT NULL,
    api_key character varying(200),
    username character varying(100),
    password character varying(200),
    client_id character varying(100),
    client_secret character varying(200),
    environment character varying(20) DEFAULT 'production'::character varying,
    active boolean DEFAULT true,
    last_sync_at timestamp with time zone,
    next_sync_at timestamp with time zone,
    sync_interval integer DEFAULT 60,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT integration_configs_environment_check CHECK (((environment)::text = ANY ((ARRAY['production'::character varying, 'staging'::character varying, 'sandbox'::character varying])::text[]))),
    CONSTRAINT integration_configs_service_type_check CHECK (((service_type)::text = ANY ((ARRAY['fastag'::character varying, 'ewaybill'::character varying, 'vahan'::character varying, 'sarathi'::character varying, 'gst'::character varying])::text[])))
);


ALTER TABLE public.integration_configs OWNER TO fleet_user;

--
-- Name: integration_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.integration_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    integration_id uuid,
    method character varying(10) NOT NULL,
    endpoint text NOT NULL,
    request_body jsonb,
    response_body jsonb,
    status_code integer,
    status character varying(20),
    duration_ms integer,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.integration_logs OWNER TO fleet_user;

--
-- Name: integrations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.integrations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(50) NOT NULL,
    provider character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    config jsonb DEFAULT '{}'::jsonb,
    last_sync timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.integrations OWNER TO fleet_user;

--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.invoice_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid NOT NULL,
    description text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(15,2) DEFAULT 0.00 NOT NULL,
    tax_percent numeric(5,2) DEFAULT 0.00 NOT NULL,
    total numeric(15,2) DEFAULT 0.00 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.invoice_items OWNER TO fleet_user;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    customer_name text NOT NULL,
    invoice_date date NOT NULL,
    due_date date NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    total_amount numeric(15,2) DEFAULT 0.00 NOT NULL,
    amount_paid numeric(15,2) DEFAULT 0.00 NOT NULL,
    balance_due numeric(15,2) DEFAULT 0.00 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.invoices OWNER TO fleet_user;

--
-- Name: ip_rules; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.ip_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    cidr character varying(50) NOT NULL,
    action character varying(20) NOT NULL,
    added_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    description text
);


ALTER TABLE public.ip_rules OWNER TO fleet_user;

--
-- Name: local_permits; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.local_permits (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    permit_number character varying(50) NOT NULL,
    permit_type character varying(50) NOT NULL,
    permit_category character varying(50) NOT NULL,
    permit_sub_category character varying(50),
    valid_from date NOT NULL,
    valid_to date NOT NULL,
    issuing_authority character varying(100),
    jurisdiction character varying(100),
    route_details text,
    number_of_trips integer,
    max_load_capacity numeric(10,2),
    number_of_seats integer,
    fare numeric(10,2),
    status character varying(20) NOT NULL,
    remarks text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT local_permits_permit_category_check CHECK (((permit_category)::text = ANY ((ARRAY['ordinary'::character varying, 'tourist'::character varying, 'educational'::character varying])::text[]))),
    CONSTRAINT local_permits_permit_sub_category_check CHECK (((permit_sub_category)::text = ANY ((ARRAY['public'::character varying, 'private'::character varying])::text[]))),
    CONSTRAINT local_permits_permit_type_check CHECK (((permit_type)::text = ANY ((ARRAY['stage_carriage'::character varying, 'contract_carriage'::character varying, 'goods_vehicle'::character varying])::text[]))),
    CONSTRAINT local_permits_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'expired'::character varying, 'cancelled'::character varying, 'suspended'::character varying])::text[])))
);


ALTER TABLE public.local_permits OWNER TO fleet_user;

--
-- Name: login_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.login_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    user_id uuid,
    ip_address character varying(100),
    status character varying(50),
    os text,
    browser text,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    email character varying(255),
    device text,
    location character varying(100),
    risk_level character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.login_events OWNER TO fleet_user;

--
-- Name: maintenance_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.maintenance_logs (
    id character varying(36) NOT NULL,
    org_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    schedule_id character varying(36),
    type character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone NOT NULL,
    duration_minutes integer NOT NULL,
    performed_by uuid NOT NULL,
    cost numeric(10,2) DEFAULT 0 NOT NULL,
    odometer integer NOT NULL,
    engine_hours numeric(10,2),
    parts_used jsonb DEFAULT '[]'::jsonb,
    service_items jsonb DEFAULT '[]'::jsonb,
    notes text,
    documents text[],
    status character varying(20) DEFAULT 'completed'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT maintenance_logs_status_check CHECK (((status)::text = ANY ((ARRAY['completed'::character varying, 'partially_completed'::character varying])::text[]))),
    CONSTRAINT maintenance_logs_type_check CHECK (((type)::text = ANY ((ARRAY['routine'::character varying, 'preventive'::character varying, 'corrective'::character varying, 'emergency'::character varying])::text[])))
);


ALTER TABLE public.maintenance_logs OWNER TO fleet_user;

--
-- Name: maintenance_schedules; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.maintenance_schedules (
    id character varying(36) NOT NULL,
    org_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    type character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    due_date timestamp with time zone NOT NULL,
    due_odometer integer,
    due_engine_hours numeric(10,2),
    assigned_to uuid,
    priority character varying(10) DEFAULT 'medium'::character varying NOT NULL,
    status character varying(15) DEFAULT 'scheduled'::character varying NOT NULL,
    estimated_cost numeric(10,2),
    actual_cost numeric(10,2),
    parts_required jsonb DEFAULT '[]'::jsonb,
    service_items jsonb DEFAULT '[]'::jsonb,
    notes text,
    reminders jsonb DEFAULT '[]'::jsonb,
    recurring jsonb,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    completed_by uuid,
    CONSTRAINT maintenance_schedules_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT maintenance_schedules_status_check CHECK (((status)::text = ANY ((ARRAY['scheduled'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[]))),
    CONSTRAINT maintenance_schedules_type_check CHECK (((type)::text = ANY ((ARRAY['routine'::character varying, 'preventive'::character varying, 'corrective'::character varying, 'emergency'::character varying])::text[])))
);


ALTER TABLE public.maintenance_schedules OWNER TO fleet_user;

--
-- Name: mfa_codes; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    code character varying(10) NOT NULL,
    method character varying(50) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_codes OWNER TO fleet_user;

--
-- Name: mfa_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    event_type character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    method character varying(20),
    ip_address character varying(45),
    user_agent text,
    location character varying(255),
    details jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_events OWNER TO fleet_user;

--
-- Name: mfa_exceptions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_exceptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    reason text NOT NULL,
    granted_by uuid,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    start_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_exceptions OWNER TO fleet_user;

--
-- Name: mfa_failures; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_failures (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    method character varying(20),
    failure_reason text,
    ip_address character varying(45),
    location character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_failures OWNER TO fleet_user;

--
-- Name: mfa_lockouts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_lockouts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    reason character varying(255),
    locked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    unlocked_at timestamp with time zone,
    unlocked_by uuid
);


ALTER TABLE public.mfa_lockouts OWNER TO fleet_user;

--
-- Name: mfa_org_overrides; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_org_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    enabled boolean DEFAULT true,
    allowed_methods jsonb DEFAULT '["totp", "sms"]'::jsonb,
    max_attempts integer DEFAULT 5,
    lockout_minutes integer DEFAULT 30,
    remember_device_days integer DEFAULT 30,
    grace_period_days integer DEFAULT 7,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_org_overrides OWNER TO fleet_user;

--
-- Name: mfa_policies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    require_mfa boolean DEFAULT false,
    allowed_methods jsonb DEFAULT '["totp", "sms"]'::jsonb,
    max_attempts integer DEFAULT 5,
    lockout_minutes integer DEFAULT 30,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    grace_period_days integer DEFAULT 7,
    remember_device_days integer DEFAULT 30,
    enforce_at_login boolean DEFAULT true,
    admin_only_mode boolean DEFAULT false,
    remember_device_allowed boolean DEFAULT true,
    mfa_challenge_timeout integer DEFAULT 60,
    version integer DEFAULT 1
);


ALTER TABLE public.mfa_policies OWNER TO fleet_user;

--
-- Name: mfa_policy_history; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_policy_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    policy_id uuid,
    org_id uuid,
    snapshot jsonb NOT NULL,
    changed_by uuid,
    change_reason text,
    version integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_policy_history OWNER TO fleet_user;

--
-- Name: mfa_users; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_users (
    user_id uuid NOT NULL,
    org_id uuid,
    status character varying(20) DEFAULT 'DISABLED'::character varying,
    method character varying(50),
    trusted_devices_count integer DEFAULT 0,
    last_reset timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.mfa_users OWNER TO fleet_user;

--
-- Name: org_support_metrics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.org_support_metrics (
    org_id uuid NOT NULL,
    open_tickets integer DEFAULT 0,
    resolved_tickets integer DEFAULT 0,
    avg_resolution_time interval,
    sla_breaches integer DEFAULT 0,
    critical_issues integer DEFAULT 0,
    last_calculated timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.org_support_metrics OWNER TO fleet_user;

--
-- Name: TABLE org_support_metrics; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.org_support_metrics IS 'Pre-calculated organization support metrics';


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    domain character varying(255),
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    default_theme character varying(20) DEFAULT 'light'::character varying,
    is_deleted boolean DEFAULT false,
    contact_email character varying(255),
    plan character varying(50) DEFAULT 'enterprise'::character varying,
    CONSTRAINT organizations_default_theme_check CHECK (((default_theme)::text = ANY ((ARRAY['light'::character varying, 'dark'::character varying, 'system'::character varying])::text[])))
);


ALTER TABLE public.organizations OWNER TO fleet_user;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    role_id uuid,
    resource character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.permissions OWNER TO fleet_user;

--
-- Name: prediction_results; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.prediction_results (
    id character varying(36) NOT NULL,
    model_id character varying(36) NOT NULL,
    prediction_input jsonb NOT NULL,
    predicted_value jsonb,
    confidence_score numeric(5,4) NOT NULL,
    probability_scores jsonb,
    feature_importance jsonb,
    anomaly_detected boolean DEFAULT false NOT NULL,
    anomaly_score numeric(5,4),
    explanation text,
    organization_id uuid NOT NULL,
    request_id character varying(36) NOT NULL,
    predicted_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT prediction_results_anomaly_score_check CHECK (((anomaly_score >= (0)::numeric) AND (anomaly_score <= (1)::numeric))),
    CONSTRAINT prediction_results_confidence_score_check CHECK (((confidence_score >= (0)::numeric) AND (confidence_score <= (1)::numeric)))
);


ALTER TABLE public.prediction_results OWNER TO fleet_user;

--
-- Name: predictive_maintenance_analytics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.predictive_maintenance_analytics (
    id character varying(36) NOT NULL,
    vehicle_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    analysis_date date NOT NULL,
    next_service_due date NOT NULL,
    service_priority character varying(20) NOT NULL,
    component_risks jsonb DEFAULT '{}'::jsonb NOT NULL,
    failure_prediction jsonb,
    maintenance_schedule jsonb DEFAULT '[]'::jsonb NOT NULL,
    parts_needed jsonb DEFAULT '[]'::jsonb NOT NULL,
    cost_estimation numeric(12,2) DEFAULT 0 NOT NULL,
    uptime_prediction numeric(5,2) DEFAULT 0 NOT NULL,
    reliability_score numeric(5,2) DEFAULT 0 NOT NULL,
    recommendations jsonb DEFAULT '[]'::jsonb NOT NULL,
    generated_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT predictive_maintenance_analytics_reliability_score_check CHECK (((reliability_score >= (0)::numeric) AND (reliability_score <= (100)::numeric))),
    CONSTRAINT predictive_maintenance_analytics_uptime_prediction_check CHECK (((uptime_prediction >= (0)::numeric) AND (uptime_prediction <= (100)::numeric)))
);


ALTER TABLE public.predictive_maintenance_analytics OWNER TO fleet_user;

--
-- Name: predictive_models; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.predictive_models (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    version character varying(50) NOT NULL,
    model_type character varying(100) NOT NULL,
    description text,
    algorithm character varying(100) NOT NULL,
    input_features jsonb DEFAULT '[]'::jsonb NOT NULL,
    output_variable character varying(255),
    training_data_start timestamp with time zone NOT NULL,
    training_data_end timestamp with time zone NOT NULL,
    accuracy numeric(5,4),
    "precision" numeric(5,4),
    recall numeric(5,4),
    f1_score numeric(5,4),
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    trained_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT predictive_models_accuracy_check CHECK (((accuracy >= (0)::numeric) AND (accuracy <= (1)::numeric))),
    CONSTRAINT predictive_models_f1_score_check CHECK (((f1_score >= (0)::numeric) AND (f1_score <= (1)::numeric))),
    CONSTRAINT predictive_models_precision_check CHECK ((("precision" >= (0)::numeric) AND ("precision" <= (1)::numeric))),
    CONSTRAINT predictive_models_recall_check CHECK (((recall >= (0)::numeric) AND (recall <= (1)::numeric)))
);


ALTER TABLE public.predictive_models OWNER TO fleet_user;

--
-- Name: report_executions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.report_executions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    report_id uuid,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    duration_seconds integer,
    status character varying(20),
    error_message text,
    file_url text,
    file_size bigint,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.report_executions OWNER TO fleet_user;

--
-- Name: report_global_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.report_global_settings (
    id integer NOT NULL,
    max_concurrent_jobs integer DEFAULT 50,
    max_retry_attempts integer DEFAULT 3,
    retention_days integer DEFAULT 90,
    smtp_host character varying(255),
    smtp_port integer,
    smtp_user character varying(255),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.report_global_settings OWNER TO fleet_user;

--
-- Name: report_global_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: fleet_user
--

CREATE SEQUENCE public.report_global_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.report_global_settings_id_seq OWNER TO fleet_user;

--
-- Name: report_global_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleet_user
--

ALTER SEQUENCE public.report_global_settings_id_seq OWNED BY public.report_global_settings.id;


--
-- Name: report_recipients; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.report_recipients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    report_id uuid,
    email character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.report_recipients OWNER TO fleet_user;

--
-- Name: restore_jobs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.restore_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    backup_id uuid NOT NULL,
    status character varying(50) NOT NULL,
    target_environment character varying(50) NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    performed_by uuid NOT NULL,
    logs text
);


ALTER TABLE public.restore_jobs OWNER TO fleet_user;

--
-- Name: review_items; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.review_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    review_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid,
    current_status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    reviewer_id uuid,
    reviewed_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT review_items_current_status_check CHECK (((current_status)::text = ANY ((ARRAY['PENDING'::character varying, 'APPROVED'::character varying, 'REVOKED'::character varying])::text[])))
);


ALTER TABLE public.review_items OWNER TO fleet_user;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    is_system boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    organization_id uuid
);


ALTER TABLE public.roles OWNER TO fleet_user;

--
-- Name: route_optimization_jobs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.route_optimization_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_id uuid NOT NULL,
    status character varying(50) DEFAULT 'queued'::character varying NOT NULL,
    worker_id character varying(100),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.route_optimization_jobs OWNER TO fleet_user;

--
-- Name: route_optimization_requests; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.route_optimization_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    constraints jsonb DEFAULT '{}'::jsonb,
    stops jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.route_optimization_requests OWNER TO fleet_user;

--
-- Name: route_optimization_results; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.route_optimization_results (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_id uuid NOT NULL,
    routes jsonb DEFAULT '[]'::jsonb NOT NULL,
    total_distance numeric(10,2) DEFAULT 0,
    total_duration numeric(10,2) DEFAULT 0,
    total_cost numeric(10,2) DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.route_optimization_results OWNER TO fleet_user;

--
-- Name: scheduled_reports; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.scheduled_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    report_type character varying(100) NOT NULL,
    format character varying(20) NOT NULL,
    frequency character varying(50) NOT NULL,
    cron_expression character varying(100) NOT NULL,
    delivery_time time without time zone NOT NULL,
    timezone character varying(50) NOT NULL,
    filters jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_by uuid NOT NULL,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.scheduled_reports OWNER TO fleet_user;

--
-- Name: security_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.security_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    event_type character varying(100) NOT NULL,
    ip_address character varying(45),
    user_agent text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.security_events OWNER TO fleet_user;

--
-- Name: support_audit_log; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.support_audit_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ticket_id uuid,
    user_id uuid,
    action character varying(100) NOT NULL,
    old_value jsonb,
    new_value jsonb,
    details text,
    created_at timestamp with time zone DEFAULT now(),
    ip_address character varying(45)
);


ALTER TABLE public.support_audit_log OWNER TO fleet_user;

--
-- Name: TABLE support_audit_log; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.support_audit_log IS 'Audit trail for all support operations';


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.support_tickets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ticket_id character varying(50) NOT NULL,
    org_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'OPEN'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'MEDIUM'::character varying NOT NULL,
    category character varying(100),
    assigned_to uuid,
    reporter_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone,
    sla_deadline timestamp with time zone,
    tags jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.support_tickets OWNER TO fleet_user;

--
-- Name: TABLE support_tickets; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.support_tickets IS 'Core support ticket records';


--
-- Name: telemetry; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    trip_id uuid,
    latitude numeric(10,8),
    longitude numeric(11,8),
    speed numeric(6,2),
    heading numeric(5,2),
    event_type character varying(50),
    event_time timestamp without time zone DEFAULT now()
);


ALTER TABLE public.telemetry OWNER TO fleet_user;

--
-- Name: telemetry_analytics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_analytics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    analysis_type character varying(100) NOT NULL,
    data jsonb NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    confidence numeric(3,2) NOT NULL,
    CONSTRAINT telemetry_analytics_confidence_check CHECK (((confidence >= (0)::numeric) AND (confidence <= (1)::numeric)))
);


ALTER TABLE public.telemetry_analytics OWNER TO fleet_user;

--
-- Name: TABLE telemetry_analytics; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.telemetry_analytics IS 'Stores advanced analytics results for vehicle telemetry data';


--
-- Name: COLUMN telemetry_analytics.analysis_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.telemetry_analytics.analysis_type IS 'Type of analysis performed (e.g., speed_analysis, fuel_efficiency)';


--
-- Name: COLUMN telemetry_analytics.confidence; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.telemetry_analytics.confidence IS 'Confidence score for the analysis results (0-1)';


--
-- Name: telemetry_anomalies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_anomalies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    anomaly_type character varying(100) NOT NULL,
    data jsonb NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    confidence numeric(3,2) NOT NULL,
    anomaly_score numeric(5,2) NOT NULL,
    recommendation text,
    CONSTRAINT telemetry_anomalies_confidence_check CHECK (((confidence >= (0)::numeric) AND (confidence <= (1)::numeric)))
);


ALTER TABLE public.telemetry_anomalies OWNER TO fleet_user;

--
-- Name: TABLE telemetry_anomalies; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.telemetry_anomalies IS 'Stores detected anomalies in vehicle telemetry data';


--
-- Name: COLUMN telemetry_anomalies.anomaly_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.telemetry_anomalies.anomaly_type IS 'Type of anomaly detected (e.g., unusual_speed, fuel_theft)';


--
-- Name: COLUMN telemetry_anomalies.anomaly_score; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.telemetry_anomalies.anomaly_score IS 'Numerical score representing severity of the anomaly';


--
-- Name: COLUMN telemetry_anomalies.recommendation; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.telemetry_anomalies.recommendation IS 'Suggested action for addressing the anomaly';


--
-- Name: threat_alerts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.threat_alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    type character varying(50),
    severity character varying(20),
    description text,
    status character varying(20) DEFAULT 'open'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    resolved_at timestamp with time zone
);


ALTER TABLE public.threat_alerts OWNER TO fleet_user;

--
-- Name: trip_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.trip_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    retention_period integer DEFAULT 36,
    policies jsonb DEFAULT '{}'::jsonb,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.trip_settings OWNER TO fleet_user;

--
-- Name: trips; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.trips (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    vehicle_id uuid,
    driver_id uuid,
    status character varying(50) DEFAULT 'planned'::character varying NOT NULL,
    title character varying(255),
    description text,
    planned_route jsonb,
    actual_route jsonb,
    waypoints jsonb,
    start_location jsonb,
    end_location jsonb,
    estimated_distance_km numeric(10,2),
    actual_distance_km numeric(10,2),
    estimated_duration_min integer,
    actual_duration_min integer,
    fuel_consumed_liters numeric(10,2) DEFAULT 0,
    idling_time_minutes integer DEFAULT 0,
    cargo_details jsonb,
    pod_documents jsonb,
    scheduled_start timestamp with time zone,
    started_at timestamp with time zone,
    ended_at timestamp with time zone,
    customer_name character varying(255),
    customer_phone character varying(50),
    customer_email character varying(255),
    cancellation_reason text,
    events jsonb,
    is_deleted boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.trips OWNER TO fleet_user;

--
-- Name: user_organizations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.user_organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    role character varying(50) DEFAULT 'member'::character varying,
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_organizations OWNER TO fleet_user;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    session_id character varying(100) NOT NULL,
    ip_address character varying(45),
    user_agent text,
    device_info jsonb,
    login_time timestamp with time zone DEFAULT now(),
    last_activity timestamp with time zone DEFAULT now(),
    logout_time timestamp with time zone,
    is_active boolean DEFAULT true,
    location jsonb
);


ALTER TABLE public.user_sessions OWNER TO fleet_user;

--
-- Name: TABLE user_sessions; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.user_sessions IS 'User session tracking for support investigations';


--
-- Name: users; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255),
    role character varying(50) DEFAULT 'user'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    failed_logins integer DEFAULT 0,
    locked_until timestamp with time zone,
    mfa_enabled boolean DEFAULT false,
    mfa_secret character varying(255),
    theme character varying(50) DEFAULT 'light'::character varying,
    theme_updated_at timestamp with time zone,
    phone character varying(50),
    status character varying(50) DEFAULT 'active'::character varying,
    is_deleted boolean DEFAULT false,
    role_id uuid,
    verified boolean DEFAULT true
);


ALTER TABLE public.users OWNER TO fleet_user;

--
-- Name: vehicle_assignments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicle_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid,
    driver_id uuid,
    device_id uuid,
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    ended_at timestamp with time zone,
    is_active boolean DEFAULT true
);


ALTER TABLE public.vehicle_assignments OWNER TO fleet_user;

--
-- Name: vehicle_locations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicle_locations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    latitude numeric(10,8) NOT NULL,
    longitude numeric(11,8) NOT NULL,
    speed numeric(5,2) DEFAULT 0,
    heading numeric(5,2) DEFAULT 0,
    accuracy numeric(6,2) DEFAULT 0,
    "timestamp" timestamp with time zone DEFAULT now()
);


ALTER TABLE public.vehicle_locations OWNER TO fleet_user;

--
-- Name: vehicle_verifications; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicle_verifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    registration_number character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    verification_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    chassis_number character varying(30),
    engine_number character varying(30),
    model character varying(50),
    manufacturer character varying(100),
    fuel_type character varying(20),
    body_type character varying(50),
    cubic_capacity integer,
    seating_capacity integer,
    color character varying(30),
    manufacturing_year integer,
    owner_name character varying(100),
    owner_address text,
    owner_city character varying(50),
    owner_district character varying(50),
    owner_state character varying(50),
    owner_pin character varying(10),
    rc_status character varying(20),
    insurance_company character varying(100),
    insurance_policy character varying(50),
    insurance_expiry date,
    puc_number character varying(50),
    puc_expiry date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT vehicle_verifications_rc_status_check CHECK (((rc_status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'suspended'::character varying])::text[]))),
    CONSTRAINT vehicle_verifications_status_check CHECK (((status)::text = ANY ((ARRAY['verified'::character varying, 'pending'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.vehicle_verifications OWNER TO fleet_user;

--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    license_plate character varying(20) NOT NULL,
    model character varying(50) NOT NULL,
    make character varying(50) NOT NULL,
    year integer NOT NULL,
    color character varying(30),
    status character varying(20) DEFAULT 'active'::character varying,
    capacity integer DEFAULT 1,
    fuel_type character varying(20),
    vin character varying(50),
    registration character varying(50),
    insurance character varying(50),
    odometer bigint DEFAULT 0,
    last_service timestamp with time zone,
    current_driver_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    vehicle_no character varying(50),
    service_due timestamp with time zone,
    notes text
);


ALTER TABLE public.vehicles OWNER TO fleet_user;

--
-- Name: video_analytics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.video_analytics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    recording_id uuid NOT NULL,
    stream_id uuid,
    objects_detected jsonb DEFAULT '[]'::jsonb NOT NULL,
    behavior_events jsonb DEFAULT '[]'::jsonb NOT NULL,
    traffic_signs jsonb DEFAULT '[]'::jsonb NOT NULL,
    incidents jsonb DEFAULT '[]'::jsonb NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    confidence numeric(3,2) NOT NULL,
    processed_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT video_analytics_confidence_check CHECK (((confidence >= (0)::numeric) AND (confidence <= (1)::numeric)))
);


ALTER TABLE public.video_analytics OWNER TO fleet_user;

--
-- Name: TABLE video_analytics; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.video_analytics IS 'Stores AI-powered insights extracted from video analysis';


--
-- Name: COLUMN video_analytics.objects_detected; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_analytics.objects_detected IS 'List of objects detected in the video';


--
-- Name: COLUMN video_analytics.behavior_events; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_analytics.behavior_events IS 'List of behavioral events detected in the video';


--
-- Name: COLUMN video_analytics.incidents; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_analytics.incidents IS 'List of incidents detected in the video';


--
-- Name: COLUMN video_analytics.confidence; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_analytics.confidence IS 'Confidence score for the analytics results (0-1)';


--
-- Name: video_recordings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.video_recordings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    stream_id uuid NOT NULL,
    camera_id character varying(255) NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    filename character varying(500) NOT NULL,
    filepath text NOT NULL,
    file_size bigint NOT NULL,
    duration integer NOT NULL,
    resolution character varying(20),
    framerate integer,
    bitrate integer,
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone NOT NULL,
    location_start jsonb NOT NULL,
    location_end jsonb NOT NULL,
    status character varying(50) DEFAULT 'processing'::character varying NOT NULL,
    thumbnail_path text,
    tags jsonb DEFAULT '[]'::jsonb,
    event_type character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.video_recordings OWNER TO fleet_user;

--
-- Name: TABLE video_recordings; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.video_recordings IS 'Stores information about recorded video clips';


--
-- Name: COLUMN video_recordings.status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_recordings.status IS 'Status of the video recording (recorded, processing, available, archived, deleted)';


--
-- Name: COLUMN video_recordings.event_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_recordings.event_type IS 'Type of event that triggered the recording (sudden_stop, harsh_acceleration, etc.)';


--
-- Name: video_retention_policies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.video_retention_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    event_type character varying(100),
    retention_period integer NOT NULL,
    auto_archive boolean DEFAULT false,
    auto_delete boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.video_retention_policies OWNER TO fleet_user;

--
-- Name: TABLE video_retention_policies; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.video_retention_policies IS 'Stores retention policies for video data';


--
-- Name: COLUMN video_retention_policies.retention_period; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_retention_policies.retention_period IS 'Number of days to retain videos before archiving/deletion';


--
-- Name: COLUMN video_retention_policies.auto_archive; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_retention_policies.auto_archive IS 'Flag to automatically archive videos after retention period';


--
-- Name: COLUMN video_retention_policies.auto_delete; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_retention_policies.auto_delete IS 'Flag to automatically delete videos after retention period';


--
-- Name: video_streams; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.video_streams (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    camera_id character varying(255) NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    url text NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    resolution character varying(20),
    framerate integer,
    bitrate integer,
    protocol character varying(20),
    location jsonb NOT NULL,
    started_at timestamp with time zone NOT NULL,
    ended_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    analytics_enabled boolean DEFAULT false
);


ALTER TABLE public.video_streams OWNER TO fleet_user;

--
-- Name: TABLE video_streams; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.video_streams IS 'Stores information about live video streams from vehicles';


--
-- Name: COLUMN video_streams.status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_streams.status IS 'Status of the video stream (active, inactive, error)';


--
-- Name: COLUMN video_streams.analytics_enabled; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_streams.analytics_enabled IS 'Flag to enable AI-powered analytics on this stream';


--
-- Name: video_thumbnails; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.video_thumbnails (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    recording_id uuid NOT NULL,
    image_path text NOT NULL,
    image_url text NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.video_thumbnails OWNER TO fleet_user;

--
-- Name: TABLE video_thumbnails; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.video_thumbnails IS 'Stores thumbnail images for video recordings';


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    url text NOT NULL,
    events text[] DEFAULT '{}'::text[],
    secret character varying(255),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.webhooks OWNER TO fleet_user;

--
-- Name: report_global_settings id; Type: DEFAULT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.report_global_settings ALTER COLUMN id SET DEFAULT nextval('public.report_global_settings_id_seq'::regclass);


--
-- Data for Name: access_review_items; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.access_review_items (id, review_id, user_id, status, reviewer_id, notes, reviewed_at) FROM stdin;
\.


--
-- Data for Name: access_reviews; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.access_reviews (id, org_id, title, status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alert_rules; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.alert_rules (id, org_id, name, type, description, severity, conditions, actions, vehicles, driver_ids, enabled, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.alerts (id, org_id, rule_id, type, severity, vehicle_id, driver_id, "timestamp", location, details, status, notes, acknowledged_by, acknowledged_at, resolved_by, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: analytics_jobs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.analytics_jobs (id, name, type, description, status, job_type, parameters, input_source, output_destination, start_time, end_time, progress, error_details, organization_id, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_clients; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.api_clients (id, org_id, client_id, client_secret_hash, name, scopes, expiry, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.audit_logs (id, user_id, action, resource, details, ip_address, user_agent, created_at, severity, status, org_id, module, entity_id, before_state, after_state, metadata) FROM stdin;
\.


--
-- Data for Name: audit_policies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.audit_policies (id, org_id, retention_years, archive_policy, masking_rules, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.audit_settings (id, org_id, retention_days_online, retention_days_archival, masking_rules, tracked_event_types, alert_on_critical, updated_at) FROM stdin;
\.


--
-- Data for Name: auth_tokens; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.auth_tokens (id, user_id, access_token, refresh_token, device_id, expires_at, created_at, ip_address, user_agent, last_active, is_active) FROM stdin;
140ccb4a-a9e9-4b9e-a713-f9af830d5cbc	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwODU3ODIsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.IWV6Bgav1NxqFpBZONfzuahMkxHxQmQ8JDP-p4Ec2EY	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2ODk2ODIsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.x1okk_bwFSrzWTdwPPwE4txFFArkGeINvFVi_ZPN2tU	\N	2026-02-21 16:01:22.106661+00	2026-02-14 16:01:22.106964+00	\N	\N	2026-02-14 16:01:22.106964+00	t
82290903-a8d6-4071-9a4b-799d74609050	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwODU4NDUsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.kCW5Iy3_9M_Tt-RyX4OqdxynChoHjkiujAeqThdLtOo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2ODk3NDUsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.z1m0XY1Ms6HAASbpzKAvkWoP1qJZEOI9dDO-LcsiDuM	\N	2026-02-21 16:02:25.327665+00	2026-02-14 16:02:25.327959+00	\N	\N	2026-02-14 16:02:25.327959+00	t
5573b6be-4e33-4b34-a04b-448f25012cf2	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwODU5NDgsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.BDyY62CH5tXiiNvPgKI1QkcAJhEgKBk0Zi7KWL8du-E	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2ODk4NDgsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.QhbZzl3S_2cnEtntrz1Bm_OLOEUFQ5PqUkuRdHn407c	\N	2026-02-21 16:04:08.441891+00	2026-02-14 16:04:08.441948+00	\N	\N	2026-02-14 16:04:08.441948+00	t
913328b9-d302-423c-9bb5-e2f7b7e213c0	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwODYwNzUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.KIV6OLoZ_zhV_rZXz0_V2o6DGG-2SYXP9EIafRmJE-4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2ODk5NzUsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.Tss-Fn-IyoDIkLeL_09BpJWksk-rNE9TcElwS5wUzK4	\N	2026-02-21 16:06:15.770438+00	2026-02-14 16:06:15.770734+00	\N	\N	2026-02-14 16:06:15.770734+00	t
fb3bfe4a-0793-4103-afb9-047123ff59bb	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwODYxNDUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.tbTTfddUtblCYPFxU_I6u5ujefUphgilP8uYnOxnPtg	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2OTAwNDUsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.O8IyWJRQmsR0esN5GAqWJzhxEi8wdk6slEPqhKDHOUg	\N	2026-02-21 16:07:25.485055+00	2026-02-14 16:07:25.485303+00	\N	\N	2026-02-14 16:07:25.485303+00	t
63899fb2-42c3-403f-9faf-68287dbec3f4	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwODYzNDQsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.o1BG_PPtLlY-vjC9DvOrLb3sVKqAoGtHWUaITQ_yWok	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2OTAyNDQsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.oMKKYtiDO1wzXL1sClB2-IIE-ejEeAUcWoa7DrGJ8FU	\N	2026-02-21 16:10:44.551321+00	2026-02-14 16:10:44.551611+00	\N	\N	2026-02-14 16:10:44.551611+00	t
336969f2-9d94-4bb2-bef7-e459674de94d	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwODY3MDYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.6ETQzzv6kDmUZY28XbUU7ktq_koJc7ooelnece2_BMI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2OTA2MDYsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.wA3yR7j8Jf4ZWKEnvz1W3rwnhLpTeJ3-purt92bjkXI	\N	2026-02-21 16:16:46.355883+00	2026-02-14 16:16:46.35663+00	\N	\N	2026-02-14 16:16:46.35663+00	t
dbbfcf95-782d-48c8-81c4-25c409e0c3e9	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwODcxMjMsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.tW99a08RnpUbd4_u9FXAV31i65zFd6cSngEZK9qs2_c	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2OTEwMjMsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.M9XCsY1O7uFLkiUHcjhS2UC2w5bkCOpgXlr9xNkFeaE	\N	2026-02-21 16:23:43.861113+00	2026-02-14 16:23:43.861463+00	\N	\N	2026-02-14 16:23:43.861463+00	t
af904fbf-0595-4f21-a78e-e4e851345fb0	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwOTAyMTUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.kLQZs2KYaqWAVnQAQgALBQ3yJyXxxf1SKCtV3ny4_ps	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2OTQxMTUsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.0eFOpOGjdOrlkznbiS7YzakUo6gkbmqfSxgmSrsbN1A	\N	2026-02-21 17:15:15.806679+00	2026-02-14 17:15:15.806737+00	\N	\N	2026-02-14 17:15:15.806737+00	t
2869d76a-7b1e-4b6c-9b59-4b57fcf1f582	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwOTA5NTYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.Xii8SiLhrduDqzDnVzZ2fesJslNygJGbsCxLq-ytmzM	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2OTQ4NTYsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.IWQ3unhloOnNpkXaalQrz3gETBmAe1IuAD7GLV2_cag	\N	2026-02-21 17:27:36.570629+00	2026-02-14 17:27:36.57096+00	\N	\N	2026-02-14 17:27:36.57096+00	t
163277df-31ac-4346-9f48-80da8d5f874a	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwOTEwMTgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.AbZjwxtvBLdsQlNyRVonDz6YCa7NOkhihCM8Ye1PQxY	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2OTQ5MTgsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.HiiKnJk11Uot2uliok_CDCR2ZKHvMSPwT9D-9Tl2TaQ	\N	2026-02-21 17:28:38.508168+00	2026-02-14 17:28:38.508458+00	\N	\N	2026-02-14 17:28:38.508458+00	t
ae6d54b7-e75f-4d20-9479-a5d17f1a1bd4	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwOTI2NDEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.t-fiz617V8MmYhaW44H2Q9lTLtMVEA9aNmb2TglWBOw	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2OTY1NDEsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.wRfPd4YBAWE6vAzbYpodycPf0QMFaxg_2kk0vO4BX2U	\N	2026-02-21 17:55:41.752091+00	2026-02-14 17:55:41.752139+00	\N	\N	2026-02-14 17:55:41.752139+00	t
061e9eff-28c9-442b-85d5-adddb77cdb4d	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwOTQ0MDcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.7fQheFAihJUdZ9pC5ty6c7KLQkvVmpQUJP5fn9cZnB0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2OTgzMDcsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.E4SlS7TT5LDKvQtkhb3yW2u-5swn81nWOaEXzNMnF_0	\N	2026-02-21 18:25:07.641244+00	2026-02-14 18:25:07.641499+00	\N	\N	2026-02-14 18:25:07.641499+00	t
8e3b851e-ef08-4265-8ca2-564bde57a8c7	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzExMDM2MTYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.R40UOg1V8tA5jaeTbELkKxBlE8_bC6Jxqeq-WAD99f8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE3MDc1MTYsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.1IEYmRZoYgMMNzyVwx7AeAMyvVp2d0N1lGiBJ7HSEr8	\N	2026-02-21 20:58:36.494366+00	2026-02-14 20:58:36.494746+00	\N	\N	2026-02-14 20:58:36.494746+00	t
66a49c39-d034-4c72-a95d-33cb69ff6268	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzExMDM4OTcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.VZXtf1jlRGogXbrlJlpKdDAb7xJoO7N8ivoO4a9B8Ok	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE3MDc3OTcsInVzZXJfaWQiOiIxNmJjMjFkYy1jMTQzLTRmZTktOTRjMS0wZDcwYWQxYmQ3MDUifQ.PqPBRz3vvcp8FDogcMeR8ms_DkY2uzInF1MKdBoIzFA	\N	2026-02-21 21:03:17.847444+00	2026-02-14 21:03:17.847493+00	\N	\N	2026-02-14 21:03:17.847493+00	t
\.


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.backups (id, type, status, s3_key, size_bytes, created_by, created_at, completed_at, metadata) FROM stdin;
\.


--
-- Data for Name: billing_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_settings (org_id, default_tax_rate, base_currency, grace_period_days, auto_invoicing_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bulk_config; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.bulk_config (organization_id, max_records_per_file, concurrent_threads, retention_months, mandatory_fields, updated_at) FROM stdin;
\.


--
-- Data for Name: bulk_job_records; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.bulk_job_records (id, job_id, row_number, record_data, status, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: bulk_jobs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.bulk_jobs (id, organization_id, file_name, status, total_records, success_count, failed_count, created_by, created_at, updated_at, retry_count) FROM stdin;
\.


--
-- Data for Name: device_commands; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_commands (id, device_id, org_id, command, category, params, status, result, error_message, created_by, sent_at, executed_at, created_at) FROM stdin;
\.


--
-- Data for Name: device_diagnostics_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_diagnostics_logs (id, device_id, org_id, log_type, source, message, metadata, "timestamp") FROM stdin;
\.


--
-- Data for Name: device_firmware_status; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_firmware_status (id, device_id, rollout_id, status, progress, error_message, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: device_telemetry; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_telemetry (id, device_id, org_id, payload, packet_type, raw_hex, "timestamp") FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.devices (id, org_id, vehicle_id, serial_number, type, status, last_ping_at, is_deleted, created_at, updated_at, firmware_version, battery_level, signal_strength, hardware_revision, last_heartbeat, model, manufacturer) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.documents (id, vehicle_id, type, doc_number, issue_date, expiry_date, file_url, status, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_behavior; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_behavior (id, driver_id, org_id, period_start, period_end, score, safety_score, efficiency_score, compliance_score, harsh_accelerations, harsh_brakings, harsh_cornerings, speeding_incidents, phone_usage, seatbelt_violations, fuel_consumption, distance_driven, idle_time, eco_driving_score, hours_of_service, rest_periods, document_compliance, maintenance_adherence, night_driving_hours, highway_percentage, city_driving_percentage, risk_level, risk_factors, improvement_areas, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_behavior_analytics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_behavior_analytics (id, driver_id, organization_id, analysis_period_start, analysis_period_end, total_driving_hours, aggressive_acceleration_count, hard_braking_count, sharp_turn_count, over_speeding_count, idling_time, average_speed, max_speed, fuel_efficiency, safety_score, efficiency_score, comfort_score, ranking, improvement_suggestions, behavior_trend, generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_incidents; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_incidents (id, driver_id, org_id, type, severity, "timestamp", location, speed, details, resolved, resolution_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_verifications; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_verifications (id, driver_id, organization_id, license_number, status, verification_date, name, father_name, date_of_birth, gender, address, city, district, state, pin, license_class, issue_date, validity_from, validity_to, last_transaction, enrollment_number, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.drivers (id, org_id, first_name, last_name, email, phone, license_number, license_type, license_expiry, license_authority, date_of_birth, address, emergency_contact, status, current_vehicle_id, current_trip_id, joining_date, resignation_date, experience_years, rating, total_trips, total_distance_km, total_hours_driven, behavior_score, documents, attendance_records, schedules, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: e_way_bills; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.e_way_bills (id, eway_bill_number, eway_bill_date, eway_bill_valid_till, document_number, document_date, document_type, goods_description, goods_value, goods_tax_rate, goods_unit, goods_quantity, from_place, from_pincode, from_state_code, to_place, to_pincode, to_state_code, transporter_id, transporter_name, transport_mode, transport_document_number, transport_document_date, transit_type, vehicle_number, vehicle_type, remaining_distance, user_gstin, recipient_gstin, generated_by, generated_at, cancelled, cancelled_by, cancelled_on, cancelled_reason, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: entity_audit_history; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.entity_audit_history (id, entity_type, entity_id, change_data, actor, "timestamp") FROM stdin;
\.


--
-- Data for Name: evidence_exports; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.evidence_exports (id, org_id, module, date_range_start, date_range_end, format, status, requested_by, file_url, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: fastag_transactions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.fastag_transactions (id, tag_number, vehicle_id, driver_id, organization_id, transaction_id, transaction_type, amount, toll_plaza, toll_plaza_id, lane_id, transaction_time, transaction_date, settlement_date, status, error_code, error_description, reconciled, reconciliation_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: firmware_packages; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.firmware_packages (id, version, hardware_target, file_url, file_size, checksum, release_notes, status, is_critical, released_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: firmware_rollouts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.firmware_rollouts (id, firmware_id, org_id, name, device_group, target_filter, total_devices, completed_devices, failed_devices, status, rollout_strategy, max_concurrent, created_by, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: fleet_analytics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.fleet_analytics (id, organization_id, start_date, end_date, total_vehicles, active_vehicles, total_distance, average_speed, total_fuel_consumption, average_fuel_efficiency, total_trips, completed_trips, cancelled_trips, average_trip_duration, idle_time_percentage, routing_efficiency, fuel_cost, maintenance_cost, revenue, profit_margin, safety_score, accidents_count, incidents_count, emergency_stops, geofence_violations, alerts_triggered, data_points_collected, processing_time, generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: geofences; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.geofences (id, org_id, name, type, center, radius_meters, coordinates, route_polyline, buffer_meters, entry_alert, exit_alert, speed_limit, vehicles, enabled, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: governance_audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.governance_audit_logs (id, organization_id, user_id, action, module, change_detail, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: governance_requests; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.governance_requests (id, organization_id, requester_id, request_type, data_scope, purpose, format, delivery_method, status, expiry_date, comments, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: governance_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.governance_settings (organization_id, retention_policies, masking_rules, auto_expiry_enabled, download_ttl_hours, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gst_compliances; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.gst_compliances (id, organization_id, gstin, status, legal_name, trade_name, address, centre_jurisdiction, state_jurisdiction, date_of_registration, date_of_cancellation, last_updated, return_filing_frequency, return_filing_status, payment_status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: incident_comments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.incident_comments (id, ticket_id, author_id, author_name, comment_type, content, is_private, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: integration_configs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.integration_configs (id, organization_id, service_type, api_endpoint, api_key, username, password, client_id, client_secret, environment, active, last_sync_at, next_sync_at, sync_interval, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: integration_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.integration_logs (id, org_id, integration_id, method, endpoint, request_body, response_body, status_code, status, duration_ms, "timestamp") FROM stdin;
\.


--
-- Data for Name: integrations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.integrations (id, org_id, name, type, provider, status, config, last_sync, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.invoice_items (id, invoice_id, description, quantity, unit_price, tax_percent, total, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.invoices (id, org_id, customer_name, invoice_date, due_date, status, currency, total_amount, amount_paid, balance_due, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ip_rules; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.ip_rules (id, org_id, cidr, action, added_by, created_at, updated_at, description) FROM stdin;
\.


--
-- Data for Name: local_permits; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.local_permits (id, vehicle_id, driver_id, organization_id, permit_number, permit_type, permit_category, permit_sub_category, valid_from, valid_to, issuing_authority, jurisdiction, route_details, number_of_trips, max_load_capacity, number_of_seats, fare, status, remarks, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: login_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.login_events (id, org_id, user_id, ip_address, status, os, browser, "timestamp", email, device, location, risk_level, created_at) FROM stdin;
630ec277-5543-4a1c-8f91-aafcc8d27773	00000000-0000-0000-0000-000000000000	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	172.18.0.1:38204	SUCCESS	\N	curl/8.5.0	2026-02-14 16:04:08.438588+00	admin@flyfleet.com	Unknown		low	2026-02-14 16:04:08.438273+00
4aa04711-3911-4fa8-adf9-01f65636174c	00000000-0000-0000-0000-000000000001	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	172.18.0.1:53990	SUCCESS	\N	curl/8.5.0	2026-02-14 16:06:15.766879+00	admin@flyfleet.com	Unknown		low	2026-02-14 16:06:15.766574+00
b39846e8-19b3-44c9-b568-87aafcffa492	00000000-0000-0000-0000-000000000001	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	172.18.0.1:48546	SUCCESS	\N	curl/8.5.0	2026-02-14 16:10:44.544599+00	admin@flyfleet.com	Unknown		low	2026-02-14 16:10:44.544225+00
08f6fc5f-1fc3-402e-ae39-40ac2bd694b5	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	172.18.0.12:59130	FAILED	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Windsurf/1.107.0 Chrome/142.0.7444.175 Electron/39.2.3 Safari/537.36	2026-02-14 16:16:32.25187+00		Unknown		low	2026-02-14 16:16:32.249761+00
4066be40-7d83-4303-8e3c-b0576e033ee5	00000000-0000-0000-0000-000000000001	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	172.18.0.12:54822	SUCCESS	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Windsurf/1.107.0 Chrome/142.0.7444.175 Electron/39.2.3 Safari/537.36	2026-02-14 16:16:46.350687+00	admin@flyfleet.com	Unknown		low	2026-02-14 16:16:46.350605+00
52d5399e-f0b3-4887-8d6f-973356f60336	00000000-0000-0000-0000-000000000001	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	172.18.0.12:42720	SUCCESS	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Windsurf/1.107.0 Chrome/142.0.7444.175 Electron/39.2.3 Safari/537.36	2026-02-14 16:23:43.854715+00	admin@flyfleet.com	Unknown		low	2026-02-14 16:23:43.854377+00
1f736489-5fc9-4446-9f65-32839384b6a8	00000000-0000-0000-0000-000000000001	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	172.18.0.12:44820	SUCCESS	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Windsurf/1.107.0 Chrome/142.0.7444.175 Electron/39.2.3 Safari/537.36	2026-02-14 17:15:15.801606+00	admin@flyfleet.com	Unknown		low	2026-02-14 17:15:15.801531+00
37ef6d59-3f9a-49c4-8715-8cd9c9962f8a	00000000-0000-0000-0000-000000000001	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	172.18.0.12:48430	FAILED	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Windsurf/1.107.0 Chrome/142.0.7444.175 Electron/39.2.3 Safari/537.36	2026-02-14 17:26:47.511418+00	admin@flyfleet.com	Unknown		low	2026-02-14 17:26:47.511036+00
cad1bac5-7867-4172-b1ee-13a34295936b	00000000-0000-0000-0000-000000000001	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	172.18.0.12:34764	SUCCESS	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-14 17:27:36.564705+00	admin@flyfleet.com	Unknown		low	2026-02-14 17:27:36.564377+00
eb5f1a2e-0057-48c9-9376-900f37c95590	00000000-0000-0000-0000-000000000001	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	172.18.0.12:48712	SUCCESS	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Windsurf/1.107.0 Chrome/142.0.7444.175 Electron/39.2.3 Safari/537.36	2026-02-14 17:28:38.503264+00	admin@flyfleet.com	Unknown		low	2026-02-14 17:28:38.503191+00
e7dad465-f9c3-456e-bda5-c7fe5cf994a9	00000000-0000-0000-0000-000000000001	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	172.18.0.12:39980	SUCCESS	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Windsurf/1.107.0 Chrome/142.0.7444.175 Electron/39.2.3 Safari/537.36	2026-02-14 17:55:41.747371+00	admin@flyfleet.com	Unknown		low	2026-02-14 17:55:41.747302+00
335f8a30-60ae-4a2e-aca0-b68b90e9eaba	00000000-0000-0000-0000-000000000001	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	172.18.0.1:60672	SUCCESS	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-14 18:25:07.635575+00	admin@flyfleet.com	Unknown		low	2026-02-14 18:25:07.635245+00
cef3ca2a-c99f-41f3-9a94-3f12f7cbd95c	00000000-0000-0000-0000-000000000001	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	172.18.0.1:32956	SUCCESS	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Windsurf/1.107.0 Chrome/142.0.7444.175 Electron/39.2.3 Safari/537.36	2026-02-14 20:58:36.488116+00	admin@flyfleet.com	Unknown		low	2026-02-14 20:58:36.487666+00
b2775a85-029d-4211-862b-8b26b9669bb7	00000000-0000-0000-0000-000000000001	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	172.18.0.1:54754	FAILED	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-14 21:03:07.681251+00	admin@flyfleet.com	Unknown		low	2026-02-14 21:03:07.68119+00
dd3539c9-ea57-4821-b0d1-09c91a4a7e6d	00000000-0000-0000-0000-000000000001	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	172.18.0.1:38436	SUCCESS	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-14 21:03:17.842593+00	admin@flyfleet.com	Unknown		low	2026-02-14 21:03:17.842531+00
\.


--
-- Data for Name: maintenance_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.maintenance_logs (id, org_id, vehicle_id, schedule_id, type, name, description, start_date, end_date, duration_minutes, performed_by, cost, odometer, engine_hours, parts_used, service_items, notes, documents, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: maintenance_schedules; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.maintenance_schedules (id, org_id, vehicle_id, type, name, description, due_date, due_odometer, due_engine_hours, assigned_to, priority, status, estimated_cost, actual_cost, parts_required, service_items, notes, reminders, recurring, created_by, created_at, updated_at, completed_at, completed_by) FROM stdin;
\.


--
-- Data for Name: mfa_codes; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_codes (id, user_id, code, method, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_events (id, user_id, org_id, event_type, status, method, ip_address, user_agent, location, details, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_exceptions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_exceptions (id, user_id, org_id, reason, granted_by, expires_at, created_at, start_date) FROM stdin;
\.


--
-- Data for Name: mfa_failures; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_failures (id, user_id, org_id, method, failure_reason, ip_address, location, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_lockouts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_lockouts (id, user_id, org_id, reason, locked_at, expires_at, unlocked_at, unlocked_by) FROM stdin;
\.


--
-- Data for Name: mfa_org_overrides; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_org_overrides (id, org_id, enabled, allowed_methods, max_attempts, lockout_minutes, remember_device_days, grace_period_days, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_policies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_policies (id, org_id, require_mfa, allowed_methods, max_attempts, lockout_minutes, created_at, updated_at, grace_period_days, remember_device_days, enforce_at_login, admin_only_mode, remember_device_allowed, mfa_challenge_timeout, version) FROM stdin;
\.


--
-- Data for Name: mfa_policy_history; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_policy_history (id, policy_id, org_id, snapshot, changed_by, change_reason, version, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_users; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_users (user_id, org_id, status, method, trusted_devices_count, last_reset, updated_at) FROM stdin;
\.


--
-- Data for Name: org_support_metrics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.org_support_metrics (org_id, open_tickets, resolved_tickets, avg_resolution_time, sla_breaches, critical_issues, last_calculated, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	0	0	\N	0	0	2026-02-14 15:38:44.337497+00	2026-02-14 15:38:44.337497+00
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.organizations (id, name, domain, status, created_at, updated_at, default_theme, is_deleted, contact_email, plan) FROM stdin;
00000000-0000-0000-0000-000000000001	FlyFleet Global	test.com	active	2026-02-14 15:38:32.937474+00	2026-02-14 15:38:32.937476+00	light	f	\N	enterprise
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.permissions (id, role_id, resource, action, created_at) FROM stdin;
\.


--
-- Data for Name: prediction_results; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.prediction_results (id, model_id, prediction_input, predicted_value, confidence_score, probability_scores, feature_importance, anomaly_detected, anomaly_score, explanation, organization_id, request_id, predicted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: predictive_maintenance_analytics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.predictive_maintenance_analytics (id, vehicle_id, organization_id, analysis_date, next_service_due, service_priority, component_risks, failure_prediction, maintenance_schedule, parts_needed, cost_estimation, uptime_prediction, reliability_score, recommendations, generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: predictive_models; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.predictive_models (id, name, version, model_type, description, algorithm, input_features, output_variable, training_data_start, training_data_end, accuracy, "precision", recall, f1_score, status, trained_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: report_executions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.report_executions (id, report_id, started_at, finished_at, duration_seconds, status, error_message, file_url, file_size, created_at) FROM stdin;
\.


--
-- Data for Name: report_global_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.report_global_settings (id, max_concurrent_jobs, max_retry_attempts, retention_days, smtp_host, smtp_port, smtp_user, updated_at) FROM stdin;
1	50	3	90	\N	\N	\N	2026-02-14 18:50:24.80725+00
\.


--
-- Data for Name: report_recipients; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.report_recipients (id, report_id, email, created_at) FROM stdin;
\.


--
-- Data for Name: restore_jobs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.restore_jobs (id, backup_id, status, target_environment, started_at, completed_at, performed_by, logs) FROM stdin;
\.


--
-- Data for Name: review_items; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.review_items (id, review_id, user_id, role_id, current_status, reviewer_id, reviewed_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.roles (id, name, description, is_system, created_at, updated_at, organization_id) FROM stdin;
b4f4650e-fac9-4202-90df-c1fd7d19485d	super_admin	Full platform access	t	2026-02-14 14:49:59.995454+00	2026-02-14 14:49:59.995454+00	\N
28818a98-f04f-4441-aaba-f3e923c54d9d	org_admin	Organization level administrator	t	2026-02-14 14:49:59.995454+00	2026-02-14 14:49:59.995454+00	\N
e761da6d-cfb5-4478-b40c-b5a7deb62a88	fleet_manager	Manages vehicles and drivers	t	2026-02-14 14:49:59.995454+00	2026-02-14 14:49:59.995454+00	\N
b245f18d-f32c-4757-a135-7d7be318c5fb	driver	Driver app access only	t	2026-02-14 14:49:59.995454+00	2026-02-14 14:49:59.995454+00	\N
14ff1cdb-9065-4b64-bcef-146e7195e5fb	Super Admin	Full access to the entire system	t	2026-02-14 16:10:34.34227+00	2026-02-14 16:10:34.342273+00	\N
dcb43c9b-ee57-497f-9756-b2efbed139e5	Org Admin	Full access to organization resources	t	2026-02-14 16:10:34.352489+00	2026-02-14 16:10:34.352491+00	\N
c614ec57-c747-4008-96a5-5c5f98718f28	Member	Standard member access	t	2026-02-14 16:10:34.356187+00	2026-02-14 16:10:34.356189+00	\N
be8e5858-99e5-45d4-9ecb-1f7aedcaaf25	Viewer	Read-only access	t	2026-02-14 16:10:34.359476+00	2026-02-14 16:10:34.359479+00	\N
\.


--
-- Data for Name: route_optimization_jobs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.route_optimization_jobs (id, request_id, status, worker_id, started_at, completed_at, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: route_optimization_requests; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.route_optimization_requests (id, organization_id, status, constraints, stops, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: route_optimization_results; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.route_optimization_results (id, request_id, routes, total_distance, total_duration, total_cost, created_at) FROM stdin;
\.


--
-- Data for Name: scheduled_reports; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.scheduled_reports (id, organization_id, name, report_type, format, frequency, cron_expression, delivery_time, timezone, filters, status, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: security_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.security_events (id, user_id, event_type, ip_address, user_agent, metadata, created_at) FROM stdin;
f2c5af2a-dd50-4446-b64d-00880e8f75b3	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	LOGIN_SUCCESS	172.18.0.1:48546	curl/8.5.0	{}	2026-02-14 16:10:44.547579+00
653815b0-fc69-407e-b021-520218a9089c	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	LOGIN_SUCCESS	172.18.0.12:54822	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Windsurf/1.107.0 Chrome/142.0.7444.175 Electron/39.2.3 Safari/537.36	{}	2026-02-14 16:16:46.352923+00
373b2eab-27e6-481d-b9d9-6c32debb06dd	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	LOGIN_SUCCESS	172.18.0.12:42720	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Windsurf/1.107.0 Chrome/142.0.7444.175 Electron/39.2.3 Safari/537.36	{}	2026-02-14 16:23:43.857669+00
da71c66a-7140-44ce-9a19-778712142b41	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	LOGIN_SUCCESS	172.18.0.12:44820	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Windsurf/1.107.0 Chrome/142.0.7444.175 Electron/39.2.3 Safari/537.36	{}	2026-02-14 17:15:15.803792+00
9234d362-d8a3-4add-9636-f3ca614376cf	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	LOGIN_FAILED	172.18.0.12:48430	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Windsurf/1.107.0 Chrome/142.0.7444.175 Electron/39.2.3 Safari/537.36	{}	2026-02-14 17:26:47.51421+00
3d98dc90-6062-4773-86ac-9ce39d3922ac	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	LOGIN_SUCCESS	172.18.0.12:34764	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{}	2026-02-14 17:27:36.567426+00
fec37fbe-6641-4c4b-8e5a-b5ac0521b31d	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	LOGIN_SUCCESS	172.18.0.12:48712	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Windsurf/1.107.0 Chrome/142.0.7444.175 Electron/39.2.3 Safari/537.36	{}	2026-02-14 17:28:38.505371+00
6bd1ec2a-cf2b-4498-bb7d-bd9ccec2c299	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	LOGIN_SUCCESS	172.18.0.12:39980	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Windsurf/1.107.0 Chrome/142.0.7444.175 Electron/39.2.3 Safari/537.36	{}	2026-02-14 17:55:41.749427+00
24bfad53-4487-47a6-a8fd-94b5d173aa1c	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	LOGIN_SUCCESS	172.18.0.1:60672	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{}	2026-02-14 18:25:07.638249+00
9758f855-4949-4c3e-9a07-20a67a7f7e65	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	LOGIN_SUCCESS	172.18.0.1:32956	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Windsurf/1.107.0 Chrome/142.0.7444.175 Electron/39.2.3 Safari/537.36	{}	2026-02-14 20:58:36.490942+00
fefa2c68-1aba-439a-8bfb-6023b177937f	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	LOGIN_FAILED	172.18.0.1:54754	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{}	2026-02-14 21:03:07.683342+00
0458c5fd-b998-4866-8fda-3c6a61692852	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	LOGIN_SUCCESS	172.18.0.1:38436	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{}	2026-02-14 21:03:17.844756+00
\.


--
-- Data for Name: support_audit_log; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.support_audit_log (id, ticket_id, user_id, action, old_value, new_value, details, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.support_tickets (id, ticket_id, org_id, title, description, status, priority, category, assigned_to, reporter_id, created_at, updated_at, resolved_at, sla_deadline, tags, metadata) FROM stdin;
\.


--
-- Data for Name: telemetry; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry (id, trip_id, latitude, longitude, speed, heading, event_type, event_time) FROM stdin;
\.


--
-- Data for Name: telemetry_analytics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_analytics (id, vehicle_id, analysis_type, data, "timestamp", confidence) FROM stdin;
\.


--
-- Data for Name: telemetry_anomalies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_anomalies (id, vehicle_id, anomaly_type, data, "timestamp", confidence, anomaly_score, recommendation) FROM stdin;
\.


--
-- Data for Name: threat_alerts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.threat_alerts (id, org_id, type, severity, description, status, created_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: trip_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.trip_settings (id, organization_id, retention_period, policies, updated_at) FROM stdin;
\.


--
-- Data for Name: trips; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.trips (id, org_id, vehicle_id, driver_id, status, title, description, planned_route, actual_route, waypoints, start_location, end_location, estimated_distance_km, actual_distance_km, estimated_duration_min, actual_duration_min, fuel_consumed_liters, idling_time_minutes, cargo_details, pod_documents, scheduled_start, started_at, ended_at, customer_name, customer_phone, customer_email, cancellation_reason, events, is_deleted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_organizations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.user_organizations (id, user_id, org_id, role, status, created_at) FROM stdin;
34af9f8b-57d8-4b96-aced-98e053548f35	16bc21dc-c143-4fe9-94c1-0d70ad1bd705	00000000-0000-0000-0000-000000000001	super_admin	active	2026-02-14 16:05:51.422149+00
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.user_sessions (id, user_id, session_id, ip_address, user_agent, device_info, login_time, last_activity, logout_time, is_active, location) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.users (id, email, password_hash, name, role, is_active, created_at, updated_at, failed_logins, locked_until, mfa_enabled, mfa_secret, theme, theme_updated_at, phone, status, is_deleted, role_id, verified) FROM stdin;
16bc21dc-c143-4fe9-94c1-0d70ad1bd705	admin@flyfleet.com	$2b$12$k2EpictQdcdbr7tR9N8LdeuosO8ZTzDwir2K3cOc7esxoKS5aFFzm	System Admin	admin	t	2026-02-14 12:49:48.832135+00	2026-02-14 21:03:17.83848+00	0	\N	f	\N	light	\N	\N	active	f	\N	t
\.


--
-- Data for Name: vehicle_assignments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicle_assignments (id, vehicle_id, driver_id, device_id, started_at, ended_at, is_active) FROM stdin;
\.


--
-- Data for Name: vehicle_locations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicle_locations (id, vehicle_id, latitude, longitude, speed, heading, accuracy, "timestamp") FROM stdin;
\.


--
-- Data for Name: vehicle_verifications; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicle_verifications (id, vehicle_id, organization_id, registration_number, status, verification_date, chassis_number, engine_number, model, manufacturer, fuel_type, body_type, cubic_capacity, seating_capacity, color, manufacturing_year, owner_name, owner_address, owner_city, owner_district, owner_state, owner_pin, rc_status, insurance_company, insurance_policy, insurance_expiry, puc_number, puc_expiry, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicles (id, org_id, license_plate, model, make, year, color, status, capacity, fuel_type, vin, registration, insurance, odometer, last_service, current_driver_id, created_at, updated_at, deleted_at, vehicle_no, service_due, notes) FROM stdin;
\.


--
-- Data for Name: video_analytics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.video_analytics (id, recording_id, stream_id, objects_detected, behavior_events, traffic_signs, incidents, "timestamp", confidence, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: video_recordings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.video_recordings (id, stream_id, camera_id, vehicle_id, driver_id, organization_id, filename, filepath, file_size, duration, resolution, framerate, bitrate, start_time, end_time, location_start, location_end, status, thumbnail_path, tags, event_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: video_retention_policies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.video_retention_policies (id, organization_id, name, description, event_type, retention_period, auto_archive, auto_delete, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: video_streams; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.video_streams (id, camera_id, vehicle_id, driver_id, organization_id, url, status, resolution, framerate, bitrate, protocol, location, started_at, ended_at, created_at, updated_at, analytics_enabled) FROM stdin;
\.


--
-- Data for Name: video_thumbnails; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.video_thumbnails (id, recording_id, image_path, image_url, "timestamp", created_at) FROM stdin;
\.


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.webhooks (id, org_id, url, events, secret, status, created_at, updated_at) FROM stdin;
\.


--
-- Name: report_global_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fleet_user
--

SELECT pg_catalog.setval('public.report_global_settings_id_seq', 1, false);


--
-- Name: access_review_items access_review_items_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.access_review_items
    ADD CONSTRAINT access_review_items_pkey PRIMARY KEY (id);


--
-- Name: access_reviews access_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.access_reviews
    ADD CONSTRAINT access_reviews_pkey PRIMARY KEY (id);


--
-- Name: alert_rules alert_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alert_rules
    ADD CONSTRAINT alert_rules_pkey PRIMARY KEY (id);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: analytics_jobs analytics_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.analytics_jobs
    ADD CONSTRAINT analytics_jobs_pkey PRIMARY KEY (id);


--
-- Name: api_clients api_clients_client_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT api_clients_client_id_key UNIQUE (client_id);


--
-- Name: api_clients api_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT api_clients_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: audit_policies audit_policies_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_org_id_key UNIQUE (org_id);


--
-- Name: audit_policies audit_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_pkey PRIMARY KEY (id);


--
-- Name: audit_settings audit_settings_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_settings
    ADD CONSTRAINT audit_settings_org_id_key UNIQUE (org_id);


--
-- Name: audit_settings audit_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_settings
    ADD CONSTRAINT audit_settings_pkey PRIMARY KEY (id);


--
-- Name: auth_tokens auth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_pkey PRIMARY KEY (id);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: billing_settings billing_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_settings
    ADD CONSTRAINT billing_settings_pkey PRIMARY KEY (org_id);


--
-- Name: bulk_config bulk_config_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_config
    ADD CONSTRAINT bulk_config_pkey PRIMARY KEY (organization_id);


--
-- Name: bulk_job_records bulk_job_records_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_job_records
    ADD CONSTRAINT bulk_job_records_pkey PRIMARY KEY (id);


--
-- Name: bulk_jobs bulk_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_jobs
    ADD CONSTRAINT bulk_jobs_pkey PRIMARY KEY (id);


--
-- Name: device_commands device_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_commands
    ADD CONSTRAINT device_commands_pkey PRIMARY KEY (id);


--
-- Name: device_diagnostics_logs device_diagnostics_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_diagnostics_logs
    ADD CONSTRAINT device_diagnostics_logs_pkey PRIMARY KEY (id);


--
-- Name: device_firmware_status device_firmware_status_device_id_rollout_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_firmware_status
    ADD CONSTRAINT device_firmware_status_device_id_rollout_id_key UNIQUE (device_id, rollout_id);


--
-- Name: device_firmware_status device_firmware_status_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_firmware_status
    ADD CONSTRAINT device_firmware_status_pkey PRIMARY KEY (id);


--
-- Name: device_telemetry device_telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_telemetry
    ADD CONSTRAINT device_telemetry_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: devices devices_serial_number_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_serial_number_key UNIQUE (serial_number);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: driver_behavior_analytics driver_behavior_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_behavior_analytics
    ADD CONSTRAINT driver_behavior_analytics_pkey PRIMARY KEY (id);


--
-- Name: driver_behavior driver_behavior_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_behavior
    ADD CONSTRAINT driver_behavior_pkey PRIMARY KEY (id);


--
-- Name: driver_incidents driver_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_incidents
    ADD CONSTRAINT driver_incidents_pkey PRIMARY KEY (id);


--
-- Name: driver_verifications driver_verifications_license_number_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_verifications
    ADD CONSTRAINT driver_verifications_license_number_key UNIQUE (license_number);


--
-- Name: driver_verifications driver_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_verifications
    ADD CONSTRAINT driver_verifications_pkey PRIMARY KEY (id);


--
-- Name: drivers drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pkey PRIMARY KEY (id);


--
-- Name: e_way_bills e_way_bills_eway_bill_number_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.e_way_bills
    ADD CONSTRAINT e_way_bills_eway_bill_number_key UNIQUE (eway_bill_number);


--
-- Name: e_way_bills e_way_bills_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.e_way_bills
    ADD CONSTRAINT e_way_bills_pkey PRIMARY KEY (id);


--
-- Name: entity_audit_history entity_audit_history_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.entity_audit_history
    ADD CONSTRAINT entity_audit_history_pkey PRIMARY KEY (id);


--
-- Name: evidence_exports evidence_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.evidence_exports
    ADD CONSTRAINT evidence_exports_pkey PRIMARY KEY (id);


--
-- Name: fastag_transactions fastag_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fastag_transactions
    ADD CONSTRAINT fastag_transactions_pkey PRIMARY KEY (id);


--
-- Name: fastag_transactions fastag_transactions_transaction_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fastag_transactions
    ADD CONSTRAINT fastag_transactions_transaction_id_key UNIQUE (transaction_id);


--
-- Name: firmware_packages firmware_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_packages
    ADD CONSTRAINT firmware_packages_pkey PRIMARY KEY (id);


--
-- Name: firmware_rollouts firmware_rollouts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_pkey PRIMARY KEY (id);


--
-- Name: fleet_analytics fleet_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fleet_analytics
    ADD CONSTRAINT fleet_analytics_pkey PRIMARY KEY (id);


--
-- Name: geofences geofences_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofences
    ADD CONSTRAINT geofences_pkey PRIMARY KEY (id);


--
-- Name: governance_audit_logs governance_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_audit_logs
    ADD CONSTRAINT governance_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: governance_requests governance_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_requests
    ADD CONSTRAINT governance_requests_pkey PRIMARY KEY (id);


--
-- Name: governance_settings governance_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_settings
    ADD CONSTRAINT governance_settings_pkey PRIMARY KEY (organization_id);


--
-- Name: gst_compliances gst_compliances_gstin_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.gst_compliances
    ADD CONSTRAINT gst_compliances_gstin_key UNIQUE (gstin);


--
-- Name: gst_compliances gst_compliances_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.gst_compliances
    ADD CONSTRAINT gst_compliances_pkey PRIMARY KEY (id);


--
-- Name: incident_comments incident_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_comments
    ADD CONSTRAINT incident_comments_pkey PRIMARY KEY (id);


--
-- Name: integration_configs integration_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integration_configs
    ADD CONSTRAINT integration_configs_pkey PRIMARY KEY (id);


--
-- Name: integration_logs integration_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: ip_rules ip_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.ip_rules
    ADD CONSTRAINT ip_rules_pkey PRIMARY KEY (id);


--
-- Name: local_permits local_permits_permit_number_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.local_permits
    ADD CONSTRAINT local_permits_permit_number_key UNIQUE (permit_number);


--
-- Name: local_permits local_permits_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.local_permits
    ADD CONSTRAINT local_permits_pkey PRIMARY KEY (id);


--
-- Name: login_events login_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.login_events
    ADD CONSTRAINT login_events_pkey PRIMARY KEY (id);


--
-- Name: maintenance_logs maintenance_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.maintenance_logs
    ADD CONSTRAINT maintenance_logs_pkey PRIMARY KEY (id);


--
-- Name: maintenance_schedules maintenance_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.maintenance_schedules
    ADD CONSTRAINT maintenance_schedules_pkey PRIMARY KEY (id);


--
-- Name: mfa_codes mfa_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_codes
    ADD CONSTRAINT mfa_codes_pkey PRIMARY KEY (id);


--
-- Name: mfa_events mfa_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_events
    ADD CONSTRAINT mfa_events_pkey PRIMARY KEY (id);


--
-- Name: mfa_exceptions mfa_exceptions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_pkey PRIMARY KEY (id);


--
-- Name: mfa_failures mfa_failures_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_failures
    ADD CONSTRAINT mfa_failures_pkey PRIMARY KEY (id);


--
-- Name: mfa_lockouts mfa_lockouts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_pkey PRIMARY KEY (id);


--
-- Name: mfa_org_overrides mfa_org_overrides_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_org_overrides
    ADD CONSTRAINT mfa_org_overrides_org_id_key UNIQUE (org_id);


--
-- Name: mfa_org_overrides mfa_org_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_org_overrides
    ADD CONSTRAINT mfa_org_overrides_pkey PRIMARY KEY (id);


--
-- Name: mfa_policies mfa_policies_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policies
    ADD CONSTRAINT mfa_policies_org_id_key UNIQUE (org_id);


--
-- Name: mfa_policies mfa_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policies
    ADD CONSTRAINT mfa_policies_pkey PRIMARY KEY (id);


--
-- Name: mfa_policy_history mfa_policy_history_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policy_history
    ADD CONSTRAINT mfa_policy_history_pkey PRIMARY KEY (id);


--
-- Name: mfa_users mfa_users_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_users
    ADD CONSTRAINT mfa_users_pkey PRIMARY KEY (user_id);


--
-- Name: org_support_metrics org_support_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.org_support_metrics
    ADD CONSTRAINT org_support_metrics_pkey PRIMARY KEY (org_id);


--
-- Name: organizations organizations_domain_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_domain_key UNIQUE (domain);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_role_id_resource_action_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_role_id_resource_action_key UNIQUE (role_id, resource, action);


--
-- Name: prediction_results prediction_results_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.prediction_results
    ADD CONSTRAINT prediction_results_pkey PRIMARY KEY (id);


--
-- Name: predictive_maintenance_analytics predictive_maintenance_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.predictive_maintenance_analytics
    ADD CONSTRAINT predictive_maintenance_analytics_pkey PRIMARY KEY (id);


--
-- Name: predictive_models predictive_models_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.predictive_models
    ADD CONSTRAINT predictive_models_pkey PRIMARY KEY (id);


--
-- Name: report_executions report_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.report_executions
    ADD CONSTRAINT report_executions_pkey PRIMARY KEY (id);


--
-- Name: report_global_settings report_global_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.report_global_settings
    ADD CONSTRAINT report_global_settings_pkey PRIMARY KEY (id);


--
-- Name: report_recipients report_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.report_recipients
    ADD CONSTRAINT report_recipients_pkey PRIMARY KEY (id);


--
-- Name: restore_jobs restore_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.restore_jobs
    ADD CONSTRAINT restore_jobs_pkey PRIMARY KEY (id);


--
-- Name: review_items review_items_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: route_optimization_jobs route_optimization_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_jobs
    ADD CONSTRAINT route_optimization_jobs_pkey PRIMARY KEY (id);


--
-- Name: route_optimization_requests route_optimization_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_requests
    ADD CONSTRAINT route_optimization_requests_pkey PRIMARY KEY (id);


--
-- Name: route_optimization_results route_optimization_results_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_results
    ADD CONSTRAINT route_optimization_results_pkey PRIMARY KEY (id);


--
-- Name: scheduled_reports scheduled_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.scheduled_reports
    ADD CONSTRAINT scheduled_reports_pkey PRIMARY KEY (id);


--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);


--
-- Name: support_audit_log support_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_audit_log
    ADD CONSTRAINT support_audit_log_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_ticket_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_ticket_id_key UNIQUE (ticket_id);


--
-- Name: telemetry_analytics telemetry_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_analytics
    ADD CONSTRAINT telemetry_analytics_pkey PRIMARY KEY (id);


--
-- Name: telemetry_anomalies telemetry_anomalies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_anomalies
    ADD CONSTRAINT telemetry_anomalies_pkey PRIMARY KEY (id);


--
-- Name: telemetry telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry
    ADD CONSTRAINT telemetry_pkey PRIMARY KEY (id);


--
-- Name: threat_alerts threat_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.threat_alerts
    ADD CONSTRAINT threat_alerts_pkey PRIMARY KEY (id);


--
-- Name: trip_settings trip_settings_organization_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trip_settings
    ADD CONSTRAINT trip_settings_organization_id_key UNIQUE (organization_id);


--
-- Name: trip_settings trip_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trip_settings
    ADD CONSTRAINT trip_settings_pkey PRIMARY KEY (id);


--
-- Name: trips trips_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_pkey PRIMARY KEY (id);


--
-- Name: user_organizations user_organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_pkey PRIMARY KEY (id);


--
-- Name: user_organizations user_organizations_user_id_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_user_id_org_id_key UNIQUE (user_id, org_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_session_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_session_id_key UNIQUE (session_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vehicle_assignments vehicle_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_assignments
    ADD CONSTRAINT vehicle_assignments_pkey PRIMARY KEY (id);


--
-- Name: vehicle_locations vehicle_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_locations
    ADD CONSTRAINT vehicle_locations_pkey PRIMARY KEY (id);


--
-- Name: vehicle_verifications vehicle_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_verifications
    ADD CONSTRAINT vehicle_verifications_pkey PRIMARY KEY (id);


--
-- Name: vehicle_verifications vehicle_verifications_registration_number_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_verifications
    ADD CONSTRAINT vehicle_verifications_registration_number_key UNIQUE (registration_number);


--
-- Name: vehicles vehicles_license_plate_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_license_plate_key UNIQUE (license_plate);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_vehicle_no_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_vehicle_no_key UNIQUE (vehicle_no);


--
-- Name: video_analytics video_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_analytics
    ADD CONSTRAINT video_analytics_pkey PRIMARY KEY (id);


--
-- Name: video_recordings video_recordings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_recordings
    ADD CONSTRAINT video_recordings_pkey PRIMARY KEY (id);


--
-- Name: video_retention_policies video_retention_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_retention_policies
    ADD CONSTRAINT video_retention_policies_pkey PRIMARY KEY (id);


--
-- Name: video_streams video_streams_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_streams
    ADD CONSTRAINT video_streams_pkey PRIMARY KEY (id);


--
-- Name: video_thumbnails video_thumbnails_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_thumbnails
    ADD CONSTRAINT video_thumbnails_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: idx_access_reviews_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_access_reviews_org ON public.access_reviews USING btree (org_id);


--
-- Name: idx_access_reviews_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_access_reviews_status ON public.access_reviews USING btree (org_id, status);


--
-- Name: idx_alerts_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_org_id ON public.alerts USING btree (org_id);


--
-- Name: idx_alerts_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_status ON public.alerts USING btree (status);


--
-- Name: idx_alerts_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_timestamp ON public.alerts USING btree ("timestamp");


--
-- Name: idx_alerts_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_vehicle_id ON public.alerts USING btree (vehicle_id);


--
-- Name: idx_analytics_jobs_org_status_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_analytics_jobs_org_status_type ON public.analytics_jobs USING btree (organization_id, status, job_type);


--
-- Name: idx_api_clients_client_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_api_clients_client_id ON public.api_clients USING btree (client_id);


--
-- Name: idx_api_clients_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_api_clients_org ON public.api_clients USING btree (org_id);


--
-- Name: idx_api_clients_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_api_clients_org_id ON public.api_clients USING btree (org_id);


--
-- Name: idx_api_clients_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_api_clients_status ON public.api_clients USING btree (status);


--
-- Name: idx_assignments_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_assignments_vehicle ON public.vehicle_assignments USING btree (vehicle_id);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: idx_audit_logs_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_org_id ON public.audit_logs USING btree (org_id);


--
-- Name: idx_audit_logs_severity; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_severity ON public.audit_logs USING btree (severity);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_auth_tokens_refresh_token; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_auth_tokens_refresh_token ON public.auth_tokens USING btree (refresh_token);


--
-- Name: idx_auth_tokens_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_auth_tokens_user_id ON public.auth_tokens USING btree (user_id);


--
-- Name: idx_backups_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_backups_created_at ON public.backups USING btree (created_at);


--
-- Name: idx_backups_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_backups_status ON public.backups USING btree (status);


--
-- Name: idx_behavior_driver_period; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_behavior_driver_period ON public.driver_behavior USING btree (driver_id, period_start);


--
-- Name: idx_bulk_job_records_job_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_bulk_job_records_job_id ON public.bulk_job_records USING btree (job_id);


--
-- Name: idx_bulk_jobs_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_bulk_jobs_org ON public.bulk_jobs USING btree (organization_id);


--
-- Name: idx_bulk_jobs_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_bulk_jobs_status ON public.bulk_jobs USING btree (status);


--
-- Name: idx_device_commands_device; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_commands_device ON public.device_commands USING btree (device_id);


--
-- Name: idx_device_commands_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_commands_status ON public.device_commands USING btree (status);


--
-- Name: idx_device_diagnostics_logs_device; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_diagnostics_logs_device ON public.device_diagnostics_logs USING btree (device_id);


--
-- Name: idx_device_diagnostics_logs_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_diagnostics_logs_timestamp ON public.device_diagnostics_logs USING btree ("timestamp" DESC);


--
-- Name: idx_device_firmware_status_rollout; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_firmware_status_rollout ON public.device_firmware_status USING btree (rollout_id);


--
-- Name: idx_device_telemetry_device; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_telemetry_device ON public.device_telemetry USING btree (device_id);


--
-- Name: idx_device_telemetry_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_telemetry_timestamp ON public.device_telemetry USING btree ("timestamp" DESC);


--
-- Name: idx_devices_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_devices_org ON public.devices USING btree (org_id);


--
-- Name: idx_documents_expiry_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_expiry_date ON public.documents USING btree (expiry_date);


--
-- Name: idx_documents_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_status ON public.documents USING btree (status);


--
-- Name: idx_documents_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_type ON public.documents USING btree (type);


--
-- Name: idx_documents_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_vehicle_id ON public.documents USING btree (vehicle_id);


--
-- Name: idx_driver_behavior_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_behavior_driver ON public.driver_behavior_analytics USING btree (driver_id, analysis_period_start, analysis_period_end);


--
-- Name: idx_driver_behavior_org_dates; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_behavior_org_dates ON public.driver_behavior_analytics USING btree (organization_id, analysis_period_start, analysis_period_end);


--
-- Name: idx_driver_verifications_driver_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_verifications_driver_id ON public.driver_verifications USING btree (driver_id);


--
-- Name: idx_driver_verifications_license_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_verifications_license_number ON public.driver_verifications USING btree (license_number);


--
-- Name: idx_driver_verifications_organization_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_verifications_organization_id ON public.driver_verifications USING btree (organization_id);


--
-- Name: idx_driver_verifications_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_verifications_status ON public.driver_verifications USING btree (status);


--
-- Name: idx_drivers_current_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_current_vehicle_id ON public.drivers USING btree (current_vehicle_id);


--
-- Name: idx_drivers_email; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_email ON public.drivers USING btree (email);


--
-- Name: idx_drivers_license_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_license_number ON public.drivers USING btree (license_number);


--
-- Name: idx_drivers_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_org_id ON public.drivers USING btree (org_id);


--
-- Name: idx_drivers_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_status ON public.drivers USING btree (status);


--
-- Name: idx_drivers_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_vehicle ON public.drivers USING btree (current_vehicle_id);


--
-- Name: idx_e_way_bills_cancelled; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_e_way_bills_cancelled ON public.e_way_bills USING btree (cancelled);


--
-- Name: idx_e_way_bills_document_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_e_way_bills_document_number ON public.e_way_bills USING btree (document_number);


--
-- Name: idx_e_way_bills_eway_bill_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_e_way_bills_eway_bill_number ON public.e_way_bills USING btree (eway_bill_number);


--
-- Name: idx_e_way_bills_generated_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_e_way_bills_generated_at ON public.e_way_bills USING btree (generated_at);


--
-- Name: idx_e_way_bills_transporter_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_e_way_bills_transporter_id ON public.e_way_bills USING btree (transporter_id);


--
-- Name: idx_e_way_bills_vehicle_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_e_way_bills_vehicle_number ON public.e_way_bills USING btree (vehicle_number);


--
-- Name: idx_entity_history_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_entity_history_id ON public.entity_audit_history USING btree (entity_id);


--
-- Name: idx_entity_history_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_entity_history_type ON public.entity_audit_history USING btree (entity_type);


--
-- Name: idx_fastag_transactions_organization_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fastag_transactions_organization_id ON public.fastag_transactions USING btree (organization_id);


--
-- Name: idx_fastag_transactions_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fastag_transactions_status ON public.fastag_transactions USING btree (status);


--
-- Name: idx_fastag_transactions_tag_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fastag_transactions_tag_number ON public.fastag_transactions USING btree (tag_number);


--
-- Name: idx_fastag_transactions_transaction_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fastag_transactions_transaction_date ON public.fastag_transactions USING btree (transaction_date);


--
-- Name: idx_fastag_transactions_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fastag_transactions_vehicle_id ON public.fastag_transactions USING btree (vehicle_id);


--
-- Name: idx_firmware_rollouts_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_firmware_rollouts_org ON public.firmware_rollouts USING btree (org_id);


--
-- Name: idx_firmware_rollouts_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_firmware_rollouts_status ON public.firmware_rollouts USING btree (status);


--
-- Name: idx_fleet_analytics_org_dates; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fleet_analytics_org_dates ON public.fleet_analytics USING btree (organization_id, start_date, end_date);


--
-- Name: idx_gov_audit_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gov_audit_org ON public.governance_audit_logs USING btree (organization_id);


--
-- Name: idx_gov_req_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gov_req_org ON public.governance_requests USING btree (organization_id);


--
-- Name: idx_gov_req_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gov_req_status ON public.governance_requests USING btree (status);


--
-- Name: idx_gst_compliances_gstin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gst_compliances_gstin ON public.gst_compliances USING btree (gstin);


--
-- Name: idx_gst_compliances_organization_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gst_compliances_organization_id ON public.gst_compliances USING btree (organization_id);


--
-- Name: idx_gst_compliances_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gst_compliances_status ON public.gst_compliances USING btree (status);


--
-- Name: idx_incident_comments_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_incident_comments_created_at ON public.incident_comments USING btree (created_at);


--
-- Name: idx_incident_comments_ticket_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_incident_comments_ticket_id ON public.incident_comments USING btree (ticket_id);


--
-- Name: idx_incidents_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_incidents_driver ON public.driver_incidents USING btree (driver_id);


--
-- Name: idx_integration_configs_active; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_configs_active ON public.integration_configs USING btree (active);


--
-- Name: idx_integration_configs_org_service; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_configs_org_service ON public.integration_configs USING btree (organization_id, service_type);


--
-- Name: idx_integration_configs_service_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_configs_service_type ON public.integration_configs USING btree (service_type);


--
-- Name: idx_integration_logs_integration; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_logs_integration ON public.integration_logs USING btree (integration_id);


--
-- Name: idx_integration_logs_integration_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_logs_integration_id ON public.integration_logs USING btree (integration_id);


--
-- Name: idx_integration_logs_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_logs_org ON public.integration_logs USING btree (org_id);


--
-- Name: idx_integration_logs_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_logs_org_id ON public.integration_logs USING btree (org_id);


--
-- Name: idx_integration_logs_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_logs_timestamp ON public.integration_logs USING btree ("timestamp" DESC);


--
-- Name: idx_integrations_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integrations_org ON public.integrations USING btree (org_id);


--
-- Name: idx_integrations_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integrations_org_id ON public.integrations USING btree (org_id);


--
-- Name: idx_integrations_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integrations_status ON public.integrations USING btree (status);


--
-- Name: idx_integrations_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integrations_type ON public.integrations USING btree (type);


--
-- Name: idx_invoice_items_invoice_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_items_invoice_id ON public.invoice_items USING btree (invoice_id);


--
-- Name: idx_invoices_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoices_org_id ON public.invoices USING btree (org_id);


--
-- Name: idx_ip_rules_action; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_ip_rules_action ON public.ip_rules USING btree (org_id, action);


--
-- Name: idx_ip_rules_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_ip_rules_org ON public.ip_rules USING btree (org_id);


--
-- Name: idx_local_permits_driver_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_local_permits_driver_id ON public.local_permits USING btree (driver_id);


--
-- Name: idx_local_permits_organization_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_local_permits_organization_id ON public.local_permits USING btree (organization_id);


--
-- Name: idx_local_permits_permit_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_local_permits_permit_number ON public.local_permits USING btree (permit_number);


--
-- Name: idx_local_permits_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_local_permits_status ON public.local_permits USING btree (status);


--
-- Name: idx_local_permits_valid_from_to; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_local_permits_valid_from_to ON public.local_permits USING btree (valid_from, valid_to);


--
-- Name: idx_local_permits_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_local_permits_vehicle_id ON public.local_permits USING btree (vehicle_id);


--
-- Name: idx_login_events_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_login_events_org_id ON public.login_events USING btree (org_id);


--
-- Name: idx_login_events_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_login_events_status ON public.login_events USING btree (status);


--
-- Name: idx_login_events_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_login_events_user_id ON public.login_events USING btree (user_id);


--
-- Name: idx_maintenance_logs_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_maintenance_logs_org_id ON public.maintenance_logs USING btree (org_id);


--
-- Name: idx_maintenance_logs_performed_by; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_maintenance_logs_performed_by ON public.maintenance_logs USING btree (performed_by);


--
-- Name: idx_maintenance_logs_start_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_maintenance_logs_start_date ON public.maintenance_logs USING btree (start_date);


--
-- Name: idx_maintenance_logs_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_maintenance_logs_vehicle_id ON public.maintenance_logs USING btree (vehicle_id);


--
-- Name: idx_maintenance_schedules_due_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_maintenance_schedules_due_date ON public.maintenance_schedules USING btree (due_date);


--
-- Name: idx_maintenance_schedules_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_maintenance_schedules_org_id ON public.maintenance_schedules USING btree (org_id);


--
-- Name: idx_maintenance_schedules_priority; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_maintenance_schedules_priority ON public.maintenance_schedules USING btree (priority);


--
-- Name: idx_maintenance_schedules_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_maintenance_schedules_status ON public.maintenance_schedules USING btree (status);


--
-- Name: idx_maintenance_schedules_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_maintenance_schedules_vehicle_id ON public.maintenance_schedules USING btree (vehicle_id);


--
-- Name: idx_mfa_codes_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_codes_user_id ON public.mfa_codes USING btree (user_id);


--
-- Name: idx_mfa_events_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_events_created_at ON public.mfa_events USING btree (created_at);


--
-- Name: idx_mfa_events_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_events_org_id ON public.mfa_events USING btree (org_id);


--
-- Name: idx_mfa_events_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_events_user_id ON public.mfa_events USING btree (user_id);


--
-- Name: idx_mfa_exceptions_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_exceptions_user_id ON public.mfa_exceptions USING btree (user_id);


--
-- Name: idx_mfa_failures_location; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_failures_location ON public.mfa_failures USING btree (location);


--
-- Name: idx_mfa_failures_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_failures_user_id ON public.mfa_failures USING btree (user_id);


--
-- Name: idx_mfa_lockouts_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_lockouts_user_id ON public.mfa_lockouts USING btree (user_id);


--
-- Name: idx_mfa_org_overrides_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_org_overrides_org_id ON public.mfa_org_overrides USING btree (org_id);


--
-- Name: idx_mfa_policy_history_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_policy_history_org_id ON public.mfa_policy_history USING btree (org_id);


--
-- Name: idx_permissions_role_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_permissions_role_id ON public.permissions USING btree (role_id);


--
-- Name: idx_pred_maint_analysis_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_pred_maint_analysis_date ON public.predictive_maintenance_analytics USING btree (analysis_date);


--
-- Name: idx_pred_maint_org_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_pred_maint_org_vehicle ON public.predictive_maintenance_analytics USING btree (organization_id, vehicle_id);


--
-- Name: idx_prediction_results_anomaly; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_prediction_results_anomaly ON public.prediction_results USING btree (anomaly_detected, created_at);


--
-- Name: idx_prediction_results_model_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_prediction_results_model_created ON public.prediction_results USING btree (model_id, created_at);


--
-- Name: idx_prediction_results_org_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_prediction_results_org_created ON public.prediction_results USING btree (organization_id, created_at);


--
-- Name: idx_restore_jobs_backup_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_restore_jobs_backup_id ON public.restore_jobs USING btree (backup_id);


--
-- Name: idx_restore_jobs_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_restore_jobs_status ON public.restore_jobs USING btree (status);


--
-- Name: idx_review_items_review; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_review_items_review ON public.review_items USING btree (review_id);


--
-- Name: idx_review_items_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_review_items_status ON public.review_items USING btree (review_id, current_status);


--
-- Name: idx_review_items_user; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_review_items_user ON public.review_items USING btree (user_id);


--
-- Name: idx_route_opt_jobs_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_opt_jobs_status ON public.route_optimization_jobs USING btree (status);


--
-- Name: idx_route_opt_req_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_opt_req_org ON public.route_optimization_requests USING btree (organization_id);


--
-- Name: idx_route_opt_req_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_opt_req_status ON public.route_optimization_requests USING btree (status);


--
-- Name: idx_route_opt_res_req; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_opt_res_req ON public.route_optimization_results USING btree (request_id);


--
-- Name: idx_support_audit_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_audit_created_at ON public.support_audit_log USING btree (created_at);


--
-- Name: idx_support_audit_ticket_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_audit_ticket_id ON public.support_audit_log USING btree (ticket_id);


--
-- Name: idx_support_tickets_assigned_to; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_assigned_to ON public.support_tickets USING btree (assigned_to);


--
-- Name: idx_support_tickets_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_created_at ON public.support_tickets USING btree (created_at);


--
-- Name: idx_support_tickets_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_org_id ON public.support_tickets USING btree (org_id);


--
-- Name: idx_support_tickets_priority; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_priority ON public.support_tickets USING btree (priority);


--
-- Name: idx_support_tickets_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_status ON public.support_tickets USING btree (status);


--
-- Name: idx_telemetry_analytics_composite; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_analytics_composite ON public.telemetry_analytics USING btree (vehicle_id, analysis_type, "timestamp" DESC);


--
-- Name: idx_telemetry_analytics_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_analytics_timestamp ON public.telemetry_analytics USING btree ("timestamp");


--
-- Name: idx_telemetry_analytics_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_analytics_type ON public.telemetry_analytics USING btree (analysis_type);


--
-- Name: idx_telemetry_analytics_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_analytics_vehicle_id ON public.telemetry_analytics USING btree (vehicle_id);


--
-- Name: idx_telemetry_anomalies_composite; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_anomalies_composite ON public.telemetry_anomalies USING btree (vehicle_id, anomaly_type, "timestamp" DESC);


--
-- Name: idx_telemetry_anomalies_score; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_anomalies_score ON public.telemetry_anomalies USING btree (anomaly_score DESC);


--
-- Name: idx_telemetry_anomalies_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_anomalies_timestamp ON public.telemetry_anomalies USING btree ("timestamp");


--
-- Name: idx_telemetry_anomalies_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_anomalies_type ON public.telemetry_anomalies USING btree (anomaly_type);


--
-- Name: idx_telemetry_anomalies_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_anomalies_vehicle_id ON public.telemetry_anomalies USING btree (vehicle_id);


--
-- Name: idx_telemetry_event_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_event_time ON public.telemetry USING btree (event_time);


--
-- Name: idx_telemetry_trip_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_trip_id ON public.telemetry USING btree (trip_id);


--
-- Name: idx_threat_alerts_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_threat_alerts_org_id ON public.threat_alerts USING btree (org_id);


--
-- Name: idx_threat_alerts_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_threat_alerts_status ON public.threat_alerts USING btree (status);


--
-- Name: idx_trips_driver_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_driver_id ON public.trips USING btree (driver_id);


--
-- Name: idx_trips_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_org_id ON public.trips USING btree (org_id);


--
-- Name: idx_trips_scheduled_start; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_scheduled_start ON public.trips USING btree (scheduled_start);


--
-- Name: idx_trips_started_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_started_at ON public.trips USING btree (started_at);


--
-- Name: idx_trips_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_status ON public.trips USING btree (status);


--
-- Name: idx_trips_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_vehicle_id ON public.trips USING btree (vehicle_id);


--
-- Name: idx_user_org_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_org_org_id ON public.user_organizations USING btree (org_id);


--
-- Name: idx_user_org_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_org_user_id ON public.user_organizations USING btree (user_id);


--
-- Name: idx_user_sessions_is_active; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_sessions_is_active ON public.user_sessions USING btree (is_active);


--
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: idx_users_role_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_users_role_id ON public.users USING btree (role_id);


--
-- Name: idx_vehicle_locations_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_locations_timestamp ON public.vehicle_locations USING btree ("timestamp" DESC);


--
-- Name: idx_vehicle_locations_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_locations_vehicle_id ON public.vehicle_locations USING btree (vehicle_id);


--
-- Name: idx_vehicle_verifications_organization_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_verifications_organization_id ON public.vehicle_verifications USING btree (organization_id);


--
-- Name: idx_vehicle_verifications_reg_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_verifications_reg_number ON public.vehicle_verifications USING btree (registration_number);


--
-- Name: idx_vehicle_verifications_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_verifications_status ON public.vehicle_verifications USING btree (status);


--
-- Name: idx_vehicle_verifications_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_verifications_vehicle_id ON public.vehicle_verifications USING btree (vehicle_id);


--
-- Name: idx_vehicles_license; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_license ON public.vehicles USING btree (license_plate);


--
-- Name: idx_vehicles_license_plate; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_license_plate ON public.vehicles USING btree (license_plate);


--
-- Name: idx_vehicles_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_org_id ON public.vehicles USING btree (org_id);


--
-- Name: idx_vehicles_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_status ON public.vehicles USING btree (status);


--
-- Name: idx_vehicles_vehicle_no; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_vehicle_no ON public.vehicles USING btree (vehicle_no);


--
-- Name: idx_vehicles_vin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_vin ON public.vehicles USING btree (vin);


--
-- Name: idx_video_analytics_recording_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_analytics_recording_id ON public.video_analytics USING btree (recording_id);


--
-- Name: idx_video_analytics_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_analytics_timestamp ON public.video_analytics USING btree ("timestamp");


--
-- Name: idx_video_recordings_start_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_start_time ON public.video_recordings USING btree (start_time);


--
-- Name: idx_video_recordings_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_status ON public.video_recordings USING btree (status);


--
-- Name: idx_video_recordings_stream_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_stream_id ON public.video_recordings USING btree (stream_id);


--
-- Name: idx_video_recordings_stream_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_stream_status ON public.video_recordings USING btree (stream_id, status);


--
-- Name: idx_video_recordings_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_vehicle_id ON public.video_recordings USING btree (vehicle_id);


--
-- Name: idx_video_recordings_vehicle_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_vehicle_time ON public.video_recordings USING btree (vehicle_id, start_time);


--
-- Name: idx_video_retention_policies_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_retention_policies_org_id ON public.video_retention_policies USING btree (organization_id);


--
-- Name: idx_video_streams_started_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_streams_started_at ON public.video_streams USING btree (started_at);


--
-- Name: idx_video_streams_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_streams_status ON public.video_streams USING btree (status);


--
-- Name: idx_video_streams_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_streams_vehicle_id ON public.video_streams USING btree (vehicle_id);


--
-- Name: idx_video_streams_vehicle_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_streams_vehicle_status ON public.video_streams USING btree (vehicle_id, status);


--
-- Name: idx_video_thumbnails_recording_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_thumbnails_recording_id ON public.video_thumbnails USING btree (recording_id);


--
-- Name: idx_webhooks_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_webhooks_org ON public.webhooks USING btree (org_id);


--
-- Name: idx_webhooks_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_webhooks_org_id ON public.webhooks USING btree (org_id);


--
-- Name: idx_webhooks_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_webhooks_status ON public.webhooks USING btree (status);


--
-- Name: analytics_jobs update_analytics_jobs_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_analytics_jobs_updated_at BEFORE UPDATE ON public.analytics_jobs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: api_clients update_api_clients_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_api_clients_updated_at BEFORE UPDATE ON public.api_clients FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: driver_behavior_analytics update_driver_behavior_analytics_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_driver_behavior_analytics_updated_at BEFORE UPDATE ON public.driver_behavior_analytics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: driver_verifications update_driver_verifications_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_driver_verifications_updated_at BEFORE UPDATE ON public.driver_verifications FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: drivers update_drivers_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_drivers_updated_at BEFORE UPDATE ON public.drivers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: e_way_bills update_e_way_bills_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_e_way_bills_updated_at BEFORE UPDATE ON public.e_way_bills FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: fastag_transactions update_fastag_transactions_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_fastag_transactions_updated_at BEFORE UPDATE ON public.fastag_transactions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: fleet_analytics update_fleet_analytics_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_fleet_analytics_updated_at BEFORE UPDATE ON public.fleet_analytics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: governance_requests update_governance_requests_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_governance_requests_updated_at BEFORE UPDATE ON public.governance_requests FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: gst_compliances update_gst_compliances_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_gst_compliances_updated_at BEFORE UPDATE ON public.gst_compliances FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: incident_comments update_incident_comments_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_incident_comments_updated_at BEFORE UPDATE ON public.incident_comments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: integration_configs update_integration_configs_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_integration_configs_updated_at BEFORE UPDATE ON public.integration_configs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: integrations update_integrations_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_integrations_updated_at BEFORE UPDATE ON public.integrations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: local_permits update_local_permits_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_local_permits_updated_at BEFORE UPDATE ON public.local_permits FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: maintenance_logs update_maintenance_logs_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_maintenance_logs_updated_at BEFORE UPDATE ON public.maintenance_logs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: maintenance_schedules update_maintenance_schedules_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_maintenance_schedules_updated_at BEFORE UPDATE ON public.maintenance_schedules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: org_support_metrics update_org_support_metrics_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_org_support_metrics_updated_at BEFORE UPDATE ON public.org_support_metrics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: prediction_results update_prediction_results_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_prediction_results_updated_at BEFORE UPDATE ON public.prediction_results FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: predictive_maintenance_analytics update_predictive_maintenance_analytics_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_predictive_maintenance_analytics_updated_at BEFORE UPDATE ON public.predictive_maintenance_analytics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: predictive_models update_predictive_models_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_predictive_models_updated_at BEFORE UPDATE ON public.predictive_models FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: support_tickets update_support_tickets_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_support_tickets_updated_at BEFORE UPDATE ON public.support_tickets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: trips update_trips_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_trips_updated_at BEFORE UPDATE ON public.trips FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: vehicle_verifications update_vehicle_verifications_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_vehicle_verifications_updated_at BEFORE UPDATE ON public.vehicle_verifications FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: vehicles update_vehicles_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_vehicles_updated_at BEFORE UPDATE ON public.vehicles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: webhooks update_webhooks_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_webhooks_updated_at BEFORE UPDATE ON public.webhooks FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: access_review_items access_review_items_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.access_review_items
    ADD CONSTRAINT access_review_items_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.access_reviews(id) ON DELETE CASCADE;


--
-- Name: alert_rules alert_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alert_rules
    ADD CONSTRAINT alert_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: alert_rules alert_rules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alert_rules
    ADD CONSTRAINT alert_rules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: alerts alerts_acknowledged_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_acknowledged_by_fkey FOREIGN KEY (acknowledged_by) REFERENCES public.users(id);


--
-- Name: alerts alerts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: alerts alerts_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: alerts alerts_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.alert_rules(id);


--
-- Name: api_clients api_clients_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT api_clients_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: audit_logs audit_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_policies audit_policies_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_policies audit_policies_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_settings audit_settings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_settings
    ADD CONSTRAINT audit_settings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: auth_tokens auth_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bulk_job_records bulk_job_records_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_job_records
    ADD CONSTRAINT bulk_job_records_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.bulk_jobs(id) ON DELETE CASCADE;


--
-- Name: device_commands device_commands_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_commands
    ADD CONSTRAINT device_commands_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: device_commands device_commands_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_commands
    ADD CONSTRAINT device_commands_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: device_commands device_commands_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_commands
    ADD CONSTRAINT device_commands_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: device_diagnostics_logs device_diagnostics_logs_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_diagnostics_logs
    ADD CONSTRAINT device_diagnostics_logs_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: device_diagnostics_logs device_diagnostics_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_diagnostics_logs
    ADD CONSTRAINT device_diagnostics_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: device_firmware_status device_firmware_status_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_firmware_status
    ADD CONSTRAINT device_firmware_status_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: device_firmware_status device_firmware_status_rollout_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_firmware_status
    ADD CONSTRAINT device_firmware_status_rollout_id_fkey FOREIGN KEY (rollout_id) REFERENCES public.firmware_rollouts(id) ON DELETE CASCADE;


--
-- Name: device_telemetry device_telemetry_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_telemetry
    ADD CONSTRAINT device_telemetry_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: device_telemetry device_telemetry_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_telemetry
    ADD CONSTRAINT device_telemetry_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: devices devices_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: drivers drivers_current_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_current_vehicle_id_fkey FOREIGN KEY (current_vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: entity_audit_history entity_audit_history_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.entity_audit_history
    ADD CONSTRAINT entity_audit_history_actor_fkey FOREIGN KEY (actor) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: evidence_exports evidence_exports_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.evidence_exports
    ADD CONSTRAINT evidence_exports_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: evidence_exports evidence_exports_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.evidence_exports
    ADD CONSTRAINT evidence_exports_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: firmware_rollouts firmware_rollouts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: firmware_rollouts firmware_rollouts_firmware_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_firmware_id_fkey FOREIGN KEY (firmware_id) REFERENCES public.firmware_packages(id) ON DELETE CASCADE;


--
-- Name: firmware_rollouts firmware_rollouts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: video_analytics fk_video_analytics_recording; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_analytics
    ADD CONSTRAINT fk_video_analytics_recording FOREIGN KEY (recording_id) REFERENCES public.video_recordings(id);


--
-- Name: video_analytics fk_video_analytics_stream; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_analytics
    ADD CONSTRAINT fk_video_analytics_stream FOREIGN KEY (stream_id) REFERENCES public.video_streams(id);


--
-- Name: video_recordings fk_video_recordings_organization; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_recordings
    ADD CONSTRAINT fk_video_recordings_organization FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: video_recordings fk_video_recordings_stream; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_recordings
    ADD CONSTRAINT fk_video_recordings_stream FOREIGN KEY (stream_id) REFERENCES public.video_streams(id);


--
-- Name: video_retention_policies fk_video_retention_policies_org; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_retention_policies
    ADD CONSTRAINT fk_video_retention_policies_org FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: video_streams fk_video_streams_organization; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_streams
    ADD CONSTRAINT fk_video_streams_organization FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: video_thumbnails fk_video_thumbnails_recording; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_thumbnails
    ADD CONSTRAINT fk_video_thumbnails_recording FOREIGN KEY (recording_id) REFERENCES public.video_recordings(id);


--
-- Name: geofences geofences_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofences
    ADD CONSTRAINT geofences_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: geofences geofences_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofences
    ADD CONSTRAINT geofences_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: incident_comments incident_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_comments
    ADD CONSTRAINT incident_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: incident_comments incident_comments_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_comments
    ADD CONSTRAINT incident_comments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: integration_logs integration_logs_integration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_integration_id_fkey FOREIGN KEY (integration_id) REFERENCES public.integrations(id) ON DELETE SET NULL;


--
-- Name: integration_logs integration_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: integrations integrations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: invoice_items invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: mfa_codes mfa_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_codes
    ADD CONSTRAINT mfa_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_events mfa_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_events
    ADD CONSTRAINT mfa_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_events mfa_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_events
    ADD CONSTRAINT mfa_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_exceptions mfa_exceptions_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.users(id);


--
-- Name: mfa_exceptions mfa_exceptions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_exceptions mfa_exceptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_failures mfa_failures_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_failures
    ADD CONSTRAINT mfa_failures_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_failures mfa_failures_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_failures
    ADD CONSTRAINT mfa_failures_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_lockouts mfa_lockouts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_lockouts mfa_lockouts_unlocked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_unlocked_by_fkey FOREIGN KEY (unlocked_by) REFERENCES public.users(id);


--
-- Name: mfa_lockouts mfa_lockouts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_org_overrides mfa_org_overrides_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_org_overrides
    ADD CONSTRAINT mfa_org_overrides_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_policies mfa_policies_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policies
    ADD CONSTRAINT mfa_policies_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_policy_history mfa_policy_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policy_history
    ADD CONSTRAINT mfa_policy_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: mfa_policy_history mfa_policy_history_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policy_history
    ADD CONSTRAINT mfa_policy_history_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_users mfa_users_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_users
    ADD CONSTRAINT mfa_users_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: mfa_users mfa_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_users
    ADD CONSTRAINT mfa_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: org_support_metrics org_support_metrics_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.org_support_metrics
    ADD CONSTRAINT org_support_metrics_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: permissions permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: prediction_results prediction_results_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.prediction_results
    ADD CONSTRAINT prediction_results_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.predictive_models(id) ON DELETE CASCADE;


--
-- Name: report_executions report_executions_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.report_executions
    ADD CONSTRAINT report_executions_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.scheduled_reports(id);


--
-- Name: report_recipients report_recipients_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.report_recipients
    ADD CONSTRAINT report_recipients_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.scheduled_reports(id) ON DELETE CASCADE;


--
-- Name: restore_jobs restore_jobs_backup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.restore_jobs
    ADD CONSTRAINT restore_jobs_backup_id_fkey FOREIGN KEY (backup_id) REFERENCES public.backups(id);


--
-- Name: review_items review_items_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.access_reviews(id) ON DELETE CASCADE;


--
-- Name: review_items review_items_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id);


--
-- Name: review_items review_items_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: review_items review_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: route_optimization_jobs route_optimization_jobs_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_jobs
    ADD CONSTRAINT route_optimization_jobs_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.route_optimization_requests(id) ON DELETE CASCADE;


--
-- Name: route_optimization_requests route_optimization_requests_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_requests
    ADD CONSTRAINT route_optimization_requests_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: route_optimization_results route_optimization_results_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_results
    ADD CONSTRAINT route_optimization_results_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.route_optimization_requests(id) ON DELETE CASCADE;


--
-- Name: security_events security_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: support_audit_log support_audit_log_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_audit_log
    ADD CONSTRAINT support_audit_log_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id);


--
-- Name: support_audit_log support_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_audit_log
    ADD CONSTRAINT support_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: support_tickets support_tickets_reporter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_reporter_id_fkey FOREIGN KEY (reporter_id) REFERENCES public.users(id);


--
-- Name: telemetry telemetry_trip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry
    ADD CONSTRAINT telemetry_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES public.trips(id) ON DELETE CASCADE;


--
-- Name: trips trips_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: user_organizations user_organizations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: user_organizations user_organizations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: vehicle_assignments vehicle_assignments_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_assignments
    ADD CONSTRAINT vehicle_assignments_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE SET NULL;


--
-- Name: vehicle_locations vehicle_locations_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_locations
    ADD CONSTRAINT vehicle_locations_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: webhooks webhooks_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- PostgreSQL database dump complete
--

\unrestrict I7iXoMSizNePegjCLMmfwu2TZ8LSOrndMfnUYC5i56XVNnLjbFhHvoJdJX3TcEN

