--
-- PostgreSQL database dump
--

\restrict RwehVIg9fSwnsBKzLC2i4auLjJTgh1KJDohM1Wzh2qWoU7ByyokZaz5sbN8Jz93

-- Dumped from database version 15.17 (Ubuntu 15.17-1.pgdg22.04+1)
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: timescaledb; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION timescaledb IS 'Enables scalable inserts and complex queries for time-series data (Community Edition)';


--
-- Name: timescaledb_toolkit; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb_toolkit WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb_toolkit; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION timescaledb_toolkit IS 'Library of analytical hyperfunctions, time-series pipelining, and other SQL utilities';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: cleanup_expired_reset_tokens(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.cleanup_expired_reset_tokens() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM password_reset_tokens WHERE expires_at < NOW() - INTERVAL '24 hours';
    DELETE FROM refresh_tokens WHERE expires_at < NOW() - INTERVAL '30 days';
END;
$$;


ALTER FUNCTION public.cleanup_expired_reset_tokens() OWNER TO fleet_user;

--
-- Name: cleanup_expired_tokens(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.cleanup_expired_tokens() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM refresh_tokens WHERE expires_at < NOW() - INTERVAL '30 days';
END;
$$;


ALTER FUNCTION public.cleanup_expired_tokens() OWNER TO fleet_user;

--
-- Name: get_current_org_id(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.get_current_org_id() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
    SELECT current_setting('app.current_org_id', true)::uuid;
$$;


ALTER FUNCTION public.get_current_org_id() OWNER TO fleet_user;

--
-- Name: refresh_vehicle_status(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.refresh_vehicle_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY vehicle_status;
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.refresh_vehicle_status() OWNER TO fleet_user;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO fleet_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_reviews; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.access_reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    due_date timestamp with time zone,
    total_users integer DEFAULT 0,
    reviewed_users integer DEFAULT 0,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT access_reviews_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'IN_PROGRESS'::character varying, 'COMPLETED'::character varying])::text[])))
);


ALTER TABLE public.access_reviews OWNER TO fleet_user;

--
-- Name: alert_rules; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.alert_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    description text,
    severity character varying(20) DEFAULT 'warning'::character varying,
    conditions jsonb NOT NULL,
    actions jsonb,
    vehicles jsonb,
    driver_ids jsonb,
    enabled boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.alert_rules OWNER TO fleet_user;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.alerts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    rule_id uuid,
    type character varying(50) NOT NULL,
    severity character varying(20) DEFAULT 'warning'::character varying,
    vehicle_id uuid,
    driver_id uuid,
    "timestamp" timestamp with time zone DEFAULT now(),
    location jsonb,
    details jsonb,
    status character varying(20) DEFAULT 'new'::character varying,
    notes text,
    acknowledged_by uuid,
    acknowledged_at timestamp with time zone,
    resolved_by uuid,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    dedup_key text,
    escalation_level integer DEFAULT 0,
    last_escalated_at timestamp with time zone,
    escalated_to uuid[],
    sla_deadline timestamp with time zone
);


ALTER TABLE public.alerts OWNER TO fleet_user;

--
-- Name: analytics_jobs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.analytics_jobs (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(100) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    job_type character varying(100) NOT NULL,
    parameters jsonb DEFAULT '{}'::jsonb NOT NULL,
    input_source character varying(255) NOT NULL,
    output_destination character varying(255) NOT NULL,
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    progress numeric(5,2) DEFAULT 0,
    error_details text,
    organization_id uuid NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT analytics_jobs_progress_check CHECK (((progress >= (0)::numeric) AND (progress <= (100)::numeric)))
);


ALTER TABLE public.analytics_jobs OWNER TO fleet_user;

--
-- Name: api_clients; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.api_clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    client_id character varying(100) NOT NULL,
    client_secret_hash text NOT NULL,
    name character varying(255) NOT NULL,
    scopes text[] DEFAULT '{}'::text[],
    expiry timestamp with time zone,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.api_clients OWNER TO fleet_user;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    name text NOT NULL,
    prefix text NOT NULL,
    secret_hash text NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    revoked boolean DEFAULT false
);


ALTER TABLE public.api_keys OWNER TO fleet_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    resource character varying(100) NOT NULL,
    details jsonb,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    severity character varying(20) DEFAULT 'info'::character varying,
    status character varying(20) DEFAULT 'success'::character varying,
    org_id uuid,
    module character varying(100),
    entity_id character varying(100),
    before_state jsonb,
    after_state jsonb,
    metadata jsonb
);


ALTER TABLE public.audit_logs OWNER TO fleet_user;

--
-- Name: audit_policies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.audit_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    retention_years integer DEFAULT 7,
    archive_policy character varying(100) DEFAULT 'MOVE_TO_COLD_STORAGE_1Y'::character varying,
    masking_rules jsonb DEFAULT '["credit_card", "ssn", "phone", "email"]'::jsonb,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_policies OWNER TO fleet_user;

--
-- Name: audit_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.audit_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    retention_days_online integer DEFAULT 90,
    retention_days_archival integer DEFAULT 2555,
    masking_rules jsonb DEFAULT '["password", "secret", "token", "phone", "email_local"]'::jsonb,
    tracked_event_types jsonb DEFAULT '["MFA_POLICY_UPDATE", "MFA_EXCEPTION_GRANT", "MFA_OVERRIDE_TOGGLE", "LOGIN_SUCCESS", "LOGIN_FAILED"]'::jsonb,
    alert_on_critical boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_settings OWNER TO fleet_user;

--
-- Name: auth_audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.auth_audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_id uuid NOT NULL,
    actor_type text NOT NULL,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text NOT NULL,
    org_id uuid,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.auth_audit_logs OWNER TO fleet_user;

--
-- Name: auth_tokens; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.auth_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    access_token text NOT NULL,
    refresh_token text NOT NULL,
    device_id character varying(255),
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    ip_address character varying(45),
    user_agent text,
    last_active timestamp with time zone DEFAULT now(),
    is_active boolean DEFAULT true
);


ALTER TABLE public.auth_tokens OWNER TO fleet_user;

--
-- Name: backup_verifications; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.backup_verifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    backup_id uuid NOT NULL,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    checksum character varying(128),
    verified_at timestamp with time zone,
    verified_by uuid,
    error_message text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.backup_verifications OWNER TO fleet_user;

--
-- Name: backups; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.backups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    s3_key character varying(255) NOT NULL,
    size_bytes bigint DEFAULT 0 NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.backups OWNER TO fleet_user;

--
-- Name: billing_accounting_exports; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_accounting_exports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    external_system character varying(50) NOT NULL,
    export_type character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    file_key text,
    records_count integer DEFAULT 0 NOT NULL,
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp with time zone,
    created_by uuid
);


ALTER TABLE public.billing_accounting_exports OWNER TO fleet_user;

--
-- Name: billing_coupons; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_coupons (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    discount_type character varying(20) NOT NULL,
    discount_value numeric(15,4) NOT NULL,
    currency character varying(3),
    max_redemptions integer,
    redeemed_count integer DEFAULT 0 NOT NULL,
    valid_from timestamp with time zone,
    valid_until timestamp with time zone,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid
);


ALTER TABLE public.billing_coupons OWNER TO fleet_user;

--
-- Name: billing_credit_transactions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_credit_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    balance_id uuid NOT NULL,
    transaction_type character varying(50) NOT NULL,
    amount numeric(15,4) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    reference_type character varying(50),
    reference_id uuid,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid
);


ALTER TABLE public.billing_credit_transactions OWNER TO fleet_user;

--
-- Name: billing_customer_balances; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_customer_balances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    balance numeric(15,4) DEFAULT 0.0000 NOT NULL,
    credit_limit numeric(15,4) DEFAULT 0.0000 NOT NULL,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_customer_balances OWNER TO fleet_user;

--
-- Name: billing_hardware_products; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_hardware_products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    model_code character varying(100) NOT NULL,
    category character varying(50) NOT NULL,
    one_time_price numeric(15,2) NOT NULL,
    lease_monthly_price numeric(15,2),
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.billing_hardware_products OWNER TO fleet_user;

--
-- Name: billing_invoice_documents; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_invoice_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid NOT NULL,
    template_id uuid NOT NULL,
    file_url text NOT NULL,
    storage_key text NOT NULL,
    generated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    template_version integer DEFAULT 1 NOT NULL,
    snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    checksum text
);


ALTER TABLE public.billing_invoice_documents OWNER TO fleet_user;

--
-- Name: COLUMN billing_invoice_documents.snapshot; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.billing_invoice_documents.snapshot IS 'JSON snapshot of all data used for rendering this specific PDF version';


--
-- Name: COLUMN billing_invoice_documents.checksum; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.billing_invoice_documents.checksum IS 'SHA256 checksum of the generated PDF file for integrity verification';


--
-- Name: billing_invoice_sequences; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_invoice_sequences (
    org_id uuid NOT NULL,
    prefix character varying(20) DEFAULT 'INV-'::character varying NOT NULL,
    next_value bigint DEFAULT 1 NOT NULL,
    suffix character varying(20) DEFAULT ''::character varying,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_invoice_sequences OWNER TO fleet_user;

--
-- Name: billing_invoice_templates; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_invoice_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    version integer NOT NULL,
    html_content text NOT NULL,
    is_default boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_invoice_templates OWNER TO fleet_user;

--
-- Name: billing_plans; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_plans OWNER TO fleet_user;

--
-- Name: billing_pricing_components; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_pricing_components (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(20) NOT NULL,
    unit_price numeric(15,4) DEFAULT 0.0000 NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    meter_event_name character varying(50),
    frequency character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_pricing_components OWNER TO fleet_user;

--
-- Name: billing_recognized_revenue; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_recognized_revenue (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    schedule_id uuid NOT NULL,
    amount numeric(15,4) NOT NULL,
    recognized_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_recognized_revenue OWNER TO fleet_user;

--
-- Name: billing_revenue_schedules; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_revenue_schedules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    invoice_line_item_id uuid NOT NULL,
    total_amount numeric(15,4) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_revenue_schedules OWNER TO fleet_user;

--
-- Name: billing_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_settings (
    org_id uuid NOT NULL,
    default_tax_rate numeric(5,2) DEFAULT 0.00 NOT NULL,
    base_currency text DEFAULT 'USD'::text NOT NULL,
    grace_period_days integer DEFAULT 14 NOT NULL,
    auto_invoicing_enabled boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_settings OWNER TO fleet_user;

--
-- Name: billing_subscriptions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    current_period_start timestamp with time zone NOT NULL,
    current_period_end timestamp with time zone NOT NULL,
    trial_end timestamp with time zone,
    cancel_at_period_end boolean DEFAULT false NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_subscriptions OWNER TO fleet_user;

--
-- Name: billing_tax_rates; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_tax_rates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    region_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    percentage numeric(5,2) NOT NULL,
    tax_type character varying(50) NOT NULL,
    is_default boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_tax_rates OWNER TO fleet_user;

--
-- Name: billing_tax_regions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_tax_regions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    country_code character varying(2) NOT NULL,
    state_code character varying(10),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_tax_regions OWNER TO fleet_user;

--
-- Name: blocked_ips; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.blocked_ips (
    ip_address inet NOT NULL,
    reason text,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.blocked_ips OWNER TO fleet_user;

--
-- Name: bulk_config; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.bulk_config (
    organization_id uuid NOT NULL,
    max_records_per_file integer DEFAULT 5000,
    concurrent_threads integer DEFAULT 4,
    retention_months integer DEFAULT 6,
    mandatory_fields jsonb DEFAULT '["vin", "registration_no", "make", "model_year"]'::jsonb,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.bulk_config OWNER TO fleet_user;

--
-- Name: bulk_job_records; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.bulk_job_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id uuid NOT NULL,
    row_number integer NOT NULL,
    record_data jsonb,
    status character varying(50) NOT NULL,
    error_message text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT bulk_job_records_status_check CHECK (((status)::text = ANY ((ARRAY['success'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.bulk_job_records OWNER TO fleet_user;

--
-- Name: bulk_jobs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.bulk_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    file_name character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    total_records integer DEFAULT 0,
    success_count integer DEFAULT 0,
    failed_count integer DEFAULT 0,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    retry_count integer DEFAULT 0,
    CONSTRAINT bulk_jobs_status_check CHECK (((status)::text = ANY ((ARRAY['processing'::character varying, 'completed'::character varying, 'failed'::character varying, 'partial_success'::character varying])::text[])))
);


ALTER TABLE public.bulk_jobs OWNER TO fleet_user;

--
-- Name: consumption_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.consumption_events (
    "time" timestamp with time zone NOT NULL,
    org_id uuid NOT NULL,
    vehicle_id uuid,
    meter_code character varying(50) NOT NULL,
    amount numeric(15,4) NOT NULL,
    metadata jsonb,
    processed_invoice_id uuid
);


ALTER TABLE public.consumption_events OWNER TO fleet_user;

--
-- Name: devices; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    device_id text NOT NULL,
    device_name text,
    trusted boolean DEFAULT false,
    last_seen timestamp with time zone DEFAULT now()
);


ALTER TABLE public.devices OWNER TO fleet_user;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    doc_number character varying(100) NOT NULL,
    issue_date date NOT NULL,
    expiry_date date NOT NULL,
    file_url text,
    status character varying(20) DEFAULT 'pending'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    org_id uuid,
    title character varying(255),
    file_name character varying(255) DEFAULT ''::character varying,
    file_size_bytes integer DEFAULT 0,
    mime_type character varying(100) DEFAULT 'application/octet-stream'::character varying,
    storage_path character varying(500) DEFAULT ''::character varying,
    reminder_days integer DEFAULT 30,
    uploaded_by uuid,
    deleted_at timestamp with time zone
);


ALTER TABLE public.documents OWNER TO fleet_user;

--
-- Name: TABLE documents; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.documents IS 'Stores compliance documents associated with vehicles';


--
-- Name: COLUMN documents.metadata; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.documents.metadata IS 'Flexible JSON storage for document-specific attributes';


--
-- Name: dr_test_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.dr_test_logs (
    id uuid NOT NULL,
    test_id uuid NOT NULL,
    ts timestamp with time zone DEFAULT now() NOT NULL,
    level text NOT NULL,
    message text NOT NULL
);


ALTER TABLE public.dr_test_logs OWNER TO fleet_user;

--
-- Name: dr_test_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.dr_test_settings (
    id boolean DEFAULT true NOT NULL,
    schedule_enabled boolean DEFAULT false NOT NULL,
    frequency text DEFAULT 'WEEKLY'::text NOT NULL,
    schedule_day text DEFAULT 'SATURDAY'::text NOT NULL,
    schedule_time text DEFAULT '02:00'::text NOT NULL,
    intensity text DEFAULT 'NORMAL'::text NOT NULL,
    notification_emails jsonb DEFAULT '[]'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dr_test_settings_id_check CHECK ((id = true))
);


ALTER TABLE public.dr_test_settings OWNER TO fleet_user;

--
-- Name: dr_test_steps; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.dr_test_steps (
    id uuid NOT NULL,
    test_id uuid NOT NULL,
    step_order integer NOT NULL,
    step_name text NOT NULL,
    status text NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone
);


ALTER TABLE public.dr_test_steps OWNER TO fleet_user;

--
-- Name: dr_tests; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.dr_tests (
    id uuid NOT NULL,
    test_id text NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text,
    test_type text NOT NULL,
    target_env text NOT NULL,
    status text NOT NULL,
    progress_percent integer DEFAULT 0 NOT NULL,
    initiated_by text DEFAULT ''::text NOT NULL,
    success_criteria text DEFAULT ''::text,
    scheduled_at timestamp with time zone,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dr_tests OWNER TO fleet_user;

--
-- Name: driver_behavior; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_behavior (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    driver_id uuid NOT NULL,
    org_id uuid NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    score double precision,
    safety_score double precision,
    efficiency_score double precision,
    compliance_score double precision,
    harsh_accelerations integer DEFAULT 0,
    harsh_brakings integer DEFAULT 0,
    harsh_cornerings integer DEFAULT 0,
    speeding_incidents integer DEFAULT 0,
    phone_usage integer DEFAULT 0,
    seatbelt_violations integer DEFAULT 0,
    fuel_consumption double precision DEFAULT 0,
    distance_driven double precision DEFAULT 0,
    idle_time integer DEFAULT 0,
    eco_driving_score double precision,
    hours_of_service double precision,
    rest_periods integer,
    document_compliance boolean DEFAULT true,
    maintenance_adherence boolean DEFAULT true,
    night_driving_hours double precision DEFAULT 0,
    highway_percentage double precision DEFAULT 0,
    city_driving_percentage double precision DEFAULT 0,
    risk_level character varying(20),
    risk_factors jsonb,
    improvement_areas jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_behavior OWNER TO fleet_user;

--
-- Name: driver_behavior_analytics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_behavior_analytics (
    id character varying(36) NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    analysis_period_start date NOT NULL,
    analysis_period_end date NOT NULL,
    total_driving_hours numeric(8,2) DEFAULT 0 NOT NULL,
    aggressive_acceleration_count integer DEFAULT 0 NOT NULL,
    hard_braking_count integer DEFAULT 0 NOT NULL,
    sharp_turn_count integer DEFAULT 0 NOT NULL,
    over_speeding_count integer DEFAULT 0 NOT NULL,
    idling_time numeric(8,2) DEFAULT 0 NOT NULL,
    average_speed numeric(8,2) DEFAULT 0 NOT NULL,
    max_speed numeric(8,2) DEFAULT 0 NOT NULL,
    fuel_efficiency numeric(8,2) DEFAULT 0 NOT NULL,
    safety_score numeric(5,2) DEFAULT 0 NOT NULL,
    efficiency_score numeric(5,2) DEFAULT 0 NOT NULL,
    comfort_score numeric(5,2) DEFAULT 0 NOT NULL,
    ranking integer,
    improvement_suggestions jsonb DEFAULT '[]'::jsonb NOT NULL,
    behavior_trend character varying(20) DEFAULT 'stable'::character varying NOT NULL,
    generated_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT driver_behavior_analytics_comfort_score_check CHECK (((comfort_score >= (0)::numeric) AND (comfort_score <= (100)::numeric))),
    CONSTRAINT driver_behavior_analytics_efficiency_score_check CHECK (((efficiency_score >= (0)::numeric) AND (efficiency_score <= (100)::numeric))),
    CONSTRAINT driver_behavior_analytics_safety_score_check CHECK (((safety_score >= (0)::numeric) AND (safety_score <= (100)::numeric)))
);


ALTER TABLE public.driver_behavior_analytics OWNER TO fleet_user;

--
-- Name: driver_incidents; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_incidents (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    driver_id uuid NOT NULL,
    org_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    location jsonb,
    speed double precision,
    details jsonb,
    resolved boolean DEFAULT false,
    resolution_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_incidents OWNER TO fleet_user;

--
-- Name: drivers; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.drivers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    full_name character varying(100) GENERATED ALWAYS AS ((((first_name)::text || ' '::text) || (last_name)::text)) STORED,
    email character varying(100) NOT NULL,
    phone character varying(20) NOT NULL,
    license_number character varying(50) NOT NULL,
    license_type character varying(20),
    license_expiry timestamp with time zone,
    license_authority character varying(100),
    date_of_birth timestamp with time zone,
    address jsonb,
    emergency_contact jsonb,
    status character varying(20) DEFAULT 'active'::character varying,
    current_vehicle_id uuid,
    current_trip_id uuid,
    joining_date timestamp with time zone DEFAULT now(),
    resignation_date timestamp with time zone,
    experience_years integer DEFAULT 0,
    rating double precision DEFAULT 5.0,
    total_trips integer DEFAULT 0,
    total_distance_km double precision DEFAULT 0,
    total_hours_driven double precision DEFAULT 0,
    behavior_score integer DEFAULT 100,
    documents jsonb,
    attendance_records jsonb,
    schedules jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.drivers OWNER TO fleet_user;

--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.email_verification_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.email_verification_tokens OWNER TO fleet_user;

--
-- Name: entity_audit_history; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.entity_audit_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(100) NOT NULL,
    change_data jsonb NOT NULL,
    actor uuid,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.entity_audit_history OWNER TO fleet_user;

--
-- Name: evidence_exports; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.evidence_exports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    module character varying(50) NOT NULL,
    date_range_start timestamp with time zone,
    date_range_end timestamp with time zone,
    format character varying(20) DEFAULT 'pdf'::character varying,
    status character varying(20) DEFAULT 'processing'::character varying,
    requested_by uuid,
    file_url text,
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.evidence_exports OWNER TO fleet_user;

--
-- Name: firmware_packages; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.firmware_packages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    version character varying(50) NOT NULL,
    hardware_target character varying(50) NOT NULL,
    file_url text NOT NULL,
    file_size integer,
    checksum character varying(64),
    release_notes text,
    status character varying(20) DEFAULT 'draft'::character varying,
    is_critical boolean DEFAULT false,
    released_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.firmware_packages OWNER TO fleet_user;

--
-- Name: firmware_rollout_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.firmware_rollout_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    rollout_id uuid NOT NULL,
    org_id uuid NOT NULL,
    event_type character varying(64) NOT NULL,
    from_status character varying(32),
    to_status character varying(32),
    actor_user_id uuid,
    message text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.firmware_rollout_events OWNER TO fleet_user;

--
-- Name: firmware_rollouts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.firmware_rollouts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    firmware_id uuid,
    org_id uuid,
    name character varying(100),
    device_group character varying(100),
    target_filter jsonb,
    total_devices integer DEFAULT 0,
    completed_devices integer DEFAULT 0,
    failed_devices integer DEFAULT 0,
    status character varying(20) DEFAULT 'scheduled'::character varying,
    rollout_strategy character varying(20) DEFAULT 'gradual'::character varying,
    max_concurrent integer DEFAULT 10,
    created_by uuid,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.firmware_rollouts OWNER TO fleet_user;

--
-- Name: fleet_analytics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.fleet_analytics (
    id character varying(36) NOT NULL,
    organization_id uuid NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    total_vehicles integer DEFAULT 0 NOT NULL,
    active_vehicles integer DEFAULT 0 NOT NULL,
    total_distance numeric(12,2) DEFAULT 0 NOT NULL,
    average_speed numeric(8,2) DEFAULT 0 NOT NULL,
    total_fuel_consumption numeric(12,2) DEFAULT 0 NOT NULL,
    average_fuel_efficiency numeric(8,2) DEFAULT 0 NOT NULL,
    total_trips integer DEFAULT 0 NOT NULL,
    completed_trips integer DEFAULT 0 NOT NULL,
    cancelled_trips integer DEFAULT 0 NOT NULL,
    average_trip_duration numeric(8,2) DEFAULT 0 NOT NULL,
    idle_time_percentage numeric(5,2) DEFAULT 0 NOT NULL,
    routing_efficiency numeric(5,2) DEFAULT 0 NOT NULL,
    fuel_cost numeric(12,2) DEFAULT 0 NOT NULL,
    maintenance_cost numeric(12,2) DEFAULT 0 NOT NULL,
    revenue numeric(15,2) DEFAULT 0 NOT NULL,
    profit_margin numeric(5,2) DEFAULT 0 NOT NULL,
    safety_score numeric(5,2) DEFAULT 0 NOT NULL,
    accidents_count integer DEFAULT 0 NOT NULL,
    incidents_count integer DEFAULT 0 NOT NULL,
    emergency_stops integer DEFAULT 0 NOT NULL,
    geofence_violations integer DEFAULT 0 NOT NULL,
    alerts_triggered integer DEFAULT 0 NOT NULL,
    data_points_collected bigint DEFAULT 0 NOT NULL,
    processing_time numeric(10,3) DEFAULT 0 NOT NULL,
    generated_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT fleet_analytics_idle_time_percentage_check CHECK (((idle_time_percentage >= (0)::numeric) AND (idle_time_percentage <= (100)::numeric))),
    CONSTRAINT fleet_analytics_routing_efficiency_check CHECK (((routing_efficiency >= (0)::numeric) AND (routing_efficiency <= (100)::numeric))),
    CONSTRAINT fleet_analytics_safety_score_check CHECK (((safety_score >= (0)::numeric) AND (safety_score <= (100)::numeric)))
);


ALTER TABLE public.fleet_analytics OWNER TO fleet_user;

--
-- Name: geofences; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.geofences (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(20) NOT NULL,
    center jsonb,
    radius_meters integer,
    coordinates jsonb,
    route_polyline text,
    buffer_meters integer,
    entry_alert boolean DEFAULT true,
    exit_alert boolean DEFAULT true,
    speed_limit integer,
    vehicles jsonb,
    enabled boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.geofences OWNER TO fleet_user;

--
-- Name: global_notification_defaults; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.global_notification_defaults (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email_enabled boolean DEFAULT true NOT NULL,
    sms_enabled boolean DEFAULT false NOT NULL,
    push_enabled boolean DEFAULT true NOT NULL,
    in_app_enabled boolean DEFAULT true NOT NULL,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.global_notification_defaults OWNER TO fleet_user;

--
-- Name: gps_locations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.gps_locations (
    "time" timestamp with time zone NOT NULL,
    vehicle_id uuid NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    altitude double precision,
    speed double precision,
    heading double precision,
    accuracy double precision,
    ignition boolean,
    odometer double precision,
    battery_level double precision,
    satellites integer,
    raw_data jsonb
);


ALTER TABLE public.gps_locations OWNER TO fleet_user;

--
-- Name: TABLE gps_locations; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.gps_locations IS 'Stores raw GPS telemetry from vehicles';


--
-- Name: incident_comments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.incident_comments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ticket_id uuid NOT NULL,
    author_id uuid,
    author_name character varying(100),
    comment_type character varying(20) DEFAULT 'INTERNAL'::character varying,
    content text NOT NULL,
    is_private boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.incident_comments OWNER TO fleet_user;

--
-- Name: TABLE incident_comments; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.incident_comments IS 'Comments and history for support tickets';


--
-- Name: inspection_templates; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.inspection_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    applicable_vehicle_types character varying(50)[],
    checklist_items jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.inspection_templates OWNER TO fleet_user;

--
-- Name: TABLE inspection_templates; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.inspection_templates IS 'Structure for digital inspection checklists';


--
-- Name: integration_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.integration_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    integration_id uuid,
    method character varying(10) NOT NULL,
    endpoint text NOT NULL,
    request_body jsonb,
    response_body jsonb,
    status_code integer,
    status character varying(20),
    duration_ms integer,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.integration_logs OWNER TO fleet_user;

--
-- Name: integrations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.integrations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(50) NOT NULL,
    provider character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    config jsonb DEFAULT '{}'::jsonb,
    last_sync timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.integrations OWNER TO fleet_user;

--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.invoice_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid NOT NULL,
    description text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(15,2) DEFAULT 0.00 NOT NULL,
    tax_percent numeric(5,2) DEFAULT 0.00 NOT NULL,
    total numeric(15,2) DEFAULT 0.00 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    org_id uuid,
    amount double precision DEFAULT 0 NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.invoice_items OWNER TO fleet_user;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    customer_name text NOT NULL,
    invoice_date date NOT NULL,
    due_date date NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    total_amount numeric(15,2) DEFAULT 0.00 NOT NULL,
    amount_paid numeric(15,2) DEFAULT 0.00 NOT NULL,
    balance_due numeric(15,2) DEFAULT 0.00 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    invoice_number text,
    customer_email text,
    billing_address text,
    subtotal double precision DEFAULT 0 NOT NULL,
    tax_amount double precision DEFAULT 0 NOT NULL,
    amount_remaining double precision DEFAULT 0 NOT NULL,
    notes text,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    custom_fields jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.invoices OWNER TO fleet_user;

--
-- Name: ip_rules; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.ip_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    cidr character varying(45) NOT NULL,
    action character varying(10) NOT NULL,
    description text,
    added_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT ip_rules_action_check CHECK (((action)::text = ANY ((ARRAY['ALLOW'::character varying, 'BLOCK'::character varying])::text[])))
);


ALTER TABLE public.ip_rules OWNER TO fleet_user;

--
-- Name: login_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.login_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    user_id uuid,
    email character varying(255),
    ip_address character varying(45),
    device text,
    browser text,
    location character varying(255),
    status character varying(20),
    risk_level character varying(20) DEFAULT 'low'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT login_events_status_check CHECK (((status)::text = ANY ((ARRAY['SUCCESS'::character varying, 'FAILED'::character varying, 'CHALLENGED'::character varying])::text[])))
);


ALTER TABLE public.login_events OWNER TO fleet_user;

--
-- Name: login_history; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.login_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    ip_address inet,
    user_agent text,
    country text,
    success boolean,
    risk_score double precision DEFAULT 0.0,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.login_history OWNER TO fleet_user;

--
-- Name: maintenance_vendors; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.maintenance_vendors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    specialization character varying(100),
    rating numeric(3,2) DEFAULT 0.00,
    contact_info jsonb DEFAULT '{}'::jsonb,
    payment_terms character varying(100),
    status character varying(20) DEFAULT 'ACTIVE'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT maintenance_vendors_rating_check CHECK (((rating >= (0)::numeric) AND (rating <= (5)::numeric)))
);


ALTER TABLE public.maintenance_vendors OWNER TO fleet_user;

--
-- Name: TABLE maintenance_vendors; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.maintenance_vendors IS 'Service providers and part suppliers';


--
-- Name: mfa_codes; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    code character varying(10) NOT NULL,
    method character varying(50) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_codes OWNER TO fleet_user;

--
-- Name: mfa_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    event_type character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    method character varying(20),
    ip_address character varying(45),
    user_agent text,
    location character varying(255),
    details jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_events OWNER TO fleet_user;

--
-- Name: mfa_exceptions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_exceptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    reason text NOT NULL,
    granted_by uuid,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    start_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_exceptions OWNER TO fleet_user;

--
-- Name: mfa_failures; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_failures (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    method character varying(20),
    failure_reason text,
    ip_address character varying(45),
    location character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_failures OWNER TO fleet_user;

--
-- Name: mfa_lockouts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_lockouts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    reason character varying(255),
    locked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    unlocked_at timestamp with time zone,
    unlocked_by uuid
);


ALTER TABLE public.mfa_lockouts OWNER TO fleet_user;

--
-- Name: mfa_org_overrides; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_org_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    enabled boolean DEFAULT true,
    allowed_methods jsonb DEFAULT '["totp", "sms"]'::jsonb,
    max_attempts integer DEFAULT 5,
    lockout_minutes integer DEFAULT 30,
    remember_device_days integer DEFAULT 30,
    grace_period_days integer DEFAULT 7,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_org_overrides OWNER TO fleet_user;

--
-- Name: mfa_policies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    require_mfa boolean DEFAULT false,
    allowed_methods jsonb DEFAULT '["totp", "sms"]'::jsonb,
    max_attempts integer DEFAULT 5,
    lockout_minutes integer DEFAULT 30,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    grace_period_days integer DEFAULT 7,
    remember_device_days integer DEFAULT 30,
    enforce_at_login boolean DEFAULT true,
    admin_only_mode boolean DEFAULT false,
    remember_device_allowed boolean DEFAULT true,
    mfa_challenge_timeout integer DEFAULT 60,
    version integer DEFAULT 1
);


ALTER TABLE public.mfa_policies OWNER TO fleet_user;

--
-- Name: mfa_policy_history; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_policy_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    policy_id uuid,
    org_id uuid,
    snapshot jsonb NOT NULL,
    changed_by uuid,
    change_reason text,
    version integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_policy_history OWNER TO fleet_user;

--
-- Name: mfa_recovery_codes; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_recovery_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    code_hash text NOT NULL,
    used boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.mfa_recovery_codes OWNER TO fleet_user;

--
-- Name: mfa_users; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_users (
    user_id uuid NOT NULL,
    org_id uuid,
    status character varying(20) DEFAULT 'DISABLED'::character varying,
    method character varying(50),
    trusted_devices_count integer DEFAULT 0,
    last_reset timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.mfa_users OWNER TO fleet_user;

--
-- Name: notification_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.notification_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    notification_id uuid NOT NULL,
    event_type text NOT NULL,
    message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification_events OWNER TO fleet_user;

--
-- Name: notification_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.notification_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    correlation_id text,
    user_id uuid,
    user_email text,
    channel text NOT NULL,
    type text NOT NULL,
    subject text NOT NULL,
    body text,
    status text NOT NULL,
    provider text,
    provider_response text,
    retry_count integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification_logs OWNER TO fleet_user;

--
-- Name: notification_preference_audit; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.notification_preference_audit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    changed_by uuid,
    old_values jsonb,
    new_values jsonb,
    change_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification_preference_audit OWNER TO fleet_user;

--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.notification_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    priority integer DEFAULT 100 NOT NULL,
    retention_months integer DEFAULT 6 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification_settings OWNER TO fleet_user;

--
-- Name: oauth_clients; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.oauth_clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_id text NOT NULL,
    client_secret_hash text NOT NULL,
    redirect_uris text[] NOT NULL,
    grant_types text[] DEFAULT '{authorization_code}'::text[],
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.oauth_clients OWNER TO fleet_user;

--
-- Name: obd_readings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.obd_readings (
    "time" timestamp with time zone NOT NULL,
    vehicle_id uuid NOT NULL,
    rpm integer,
    coolant_temp integer,
    engine_load numeric(5,2),
    throttle_pos numeric(5,2),
    fuel_level numeric(5,2),
    dtcs jsonb,
    vin character varying(50),
    raw_data jsonb
);


ALTER TABLE public.obd_readings OWNER TO fleet_user;

--
-- Name: TABLE obd_readings; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.obd_readings IS 'Stores On-Board Diagnostics data from vehicles';


--
-- Name: org_support_metrics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.org_support_metrics (
    org_id uuid NOT NULL,
    open_tickets integer DEFAULT 0,
    resolved_tickets integer DEFAULT 0,
    avg_resolution_time interval,
    sla_breaches integer DEFAULT 0,
    critical_issues integer DEFAULT 0,
    last_calculated timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.org_support_metrics OWNER TO fleet_user;

--
-- Name: TABLE org_support_metrics; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.org_support_metrics IS 'Pre-calculated organization support metrics';


--
-- Name: organization_memberships; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.organization_memberships (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    user_id uuid,
    role text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.organization_memberships OWNER TO fleet_user;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    domain character varying(255),
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    default_theme character varying(20) DEFAULT 'light'::character varying,
    is_deleted boolean DEFAULT false,
    contact_email character varying(255),
    plan character varying(50) DEFAULT 'enterprise'::character varying,
    max_users_limit integer DEFAULT 10,
    max_api_keys_limit integer DEFAULT 5,
    CONSTRAINT organizations_default_theme_check CHECK (((default_theme)::text = ANY ((ARRAY['light'::character varying, 'dark'::character varying, 'system'::character varying])::text[])))
);


ALTER TABLE public.organizations OWNER TO fleet_user;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.password_reset_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.password_reset_tokens OWNER TO fleet_user;

--
-- Name: TABLE password_reset_tokens; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.password_reset_tokens IS 'Stores password reset tokens for secure password recovery';


--
-- Name: COLUMN password_reset_tokens.expires_at; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.password_reset_tokens.expires_at IS 'Token expiration time (typically 1 hour)';


--
-- Name: COLUMN password_reset_tokens.used; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.password_reset_tokens.used IS 'True if token has been used';


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    role_id uuid,
    resource character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.permissions OWNER TO fleet_user;

--
-- Name: prediction_results; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.prediction_results (
    id character varying(36) NOT NULL,
    model_id character varying(36) NOT NULL,
    prediction_input jsonb NOT NULL,
    predicted_value jsonb,
    confidence_score numeric(5,4) NOT NULL,
    probability_scores jsonb,
    feature_importance jsonb,
    anomaly_detected boolean DEFAULT false NOT NULL,
    anomaly_score numeric(5,4),
    explanation text,
    organization_id uuid NOT NULL,
    request_id character varying(36) NOT NULL,
    predicted_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT prediction_results_anomaly_score_check CHECK (((anomaly_score >= (0)::numeric) AND (anomaly_score <= (1)::numeric))),
    CONSTRAINT prediction_results_confidence_score_check CHECK (((confidence_score >= (0)::numeric) AND (confidence_score <= (1)::numeric)))
);


ALTER TABLE public.prediction_results OWNER TO fleet_user;

--
-- Name: predictive_maintenance_analytics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.predictive_maintenance_analytics (
    id character varying(36) NOT NULL,
    vehicle_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    analysis_date date NOT NULL,
    next_service_due date NOT NULL,
    service_priority character varying(20) NOT NULL,
    component_risks jsonb DEFAULT '{}'::jsonb NOT NULL,
    failure_prediction jsonb,
    maintenance_schedule jsonb DEFAULT '[]'::jsonb NOT NULL,
    parts_needed jsonb DEFAULT '[]'::jsonb NOT NULL,
    cost_estimation numeric(12,2) DEFAULT 0 NOT NULL,
    uptime_prediction numeric(5,2) DEFAULT 0 NOT NULL,
    reliability_score numeric(5,2) DEFAULT 0 NOT NULL,
    recommendations jsonb DEFAULT '[]'::jsonb NOT NULL,
    generated_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT predictive_maintenance_analytics_reliability_score_check CHECK (((reliability_score >= (0)::numeric) AND (reliability_score <= (100)::numeric))),
    CONSTRAINT predictive_maintenance_analytics_uptime_prediction_check CHECK (((uptime_prediction >= (0)::numeric) AND (uptime_prediction <= (100)::numeric)))
);


ALTER TABLE public.predictive_maintenance_analytics OWNER TO fleet_user;

--
-- Name: predictive_models; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.predictive_models (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    version character varying(50) NOT NULL,
    model_type character varying(100) NOT NULL,
    description text,
    algorithm character varying(100) NOT NULL,
    input_features jsonb DEFAULT '[]'::jsonb NOT NULL,
    output_variable character varying(255),
    training_data_start timestamp with time zone NOT NULL,
    training_data_end timestamp with time zone NOT NULL,
    accuracy numeric(5,4),
    "precision" numeric(5,4),
    recall numeric(5,4),
    f1_score numeric(5,4),
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    trained_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT predictive_models_accuracy_check CHECK (((accuracy >= (0)::numeric) AND (accuracy <= (1)::numeric))),
    CONSTRAINT predictive_models_f1_score_check CHECK (((f1_score >= (0)::numeric) AND (f1_score <= (1)::numeric))),
    CONSTRAINT predictive_models_precision_check CHECK ((("precision" >= (0)::numeric) AND ("precision" <= (1)::numeric))),
    CONSTRAINT predictive_models_recall_check CHECK (((recall >= (0)::numeric) AND (recall <= (1)::numeric)))
);


ALTER TABLE public.predictive_models OWNER TO fleet_user;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    revoked boolean DEFAULT false,
    revoked_at timestamp with time zone,
    used_at timestamp with time zone,
    ip_address inet,
    user_agent text,
    last_used_at timestamp with time zone
);


ALTER TABLE public.refresh_tokens OWNER TO fleet_user;

--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.refresh_tokens IS 'Stores JWT refresh tokens for session management';


--
-- Name: COLUMN refresh_tokens.revoked; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.refresh_tokens.revoked IS 'True if token has been revoked (logout)';


--
-- Name: restore_jobs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.restore_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    backup_id uuid NOT NULL,
    status character varying(50) NOT NULL,
    target_environment character varying(50) NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    performed_by uuid NOT NULL,
    logs text
);


ALTER TABLE public.restore_jobs OWNER TO fleet_user;

--
-- Name: review_items; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.review_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    review_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid,
    current_status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    reviewer_id uuid,
    reviewed_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT review_items_current_status_check CHECK (((current_status)::text = ANY ((ARRAY['PENDING'::character varying, 'APPROVED'::character varying, 'REVOKED'::character varying])::text[])))
);


ALTER TABLE public.review_items OWNER TO fleet_user;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    is_system boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles OWNER TO fleet_user;

--
-- Name: route_optimization_jobs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.route_optimization_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_id uuid NOT NULL,
    status character varying(50) DEFAULT 'queued'::character varying NOT NULL,
    worker_id character varying(100),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.route_optimization_jobs OWNER TO fleet_user;

--
-- Name: route_optimization_requests; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.route_optimization_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    constraints jsonb DEFAULT '{}'::jsonb,
    stops jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.route_optimization_requests OWNER TO fleet_user;

--
-- Name: route_optimization_results; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.route_optimization_results (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_id uuid NOT NULL,
    routes jsonb DEFAULT '[]'::jsonb NOT NULL,
    total_distance numeric(10,2) DEFAULT 0,
    total_duration numeric(10,2) DEFAULT 0,
    total_cost numeric(10,2) DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.route_optimization_results OWNER TO fleet_user;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.schema_migrations (
    version bigint NOT NULL,
    dirty boolean NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO fleet_user;

--
-- Name: schema_migrations_legacy; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.schema_migrations_legacy (
    version text NOT NULL,
    applied_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.schema_migrations_legacy OWNER TO fleet_user;

--
-- Name: security_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.security_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    event_type character varying(100) NOT NULL,
    ip_address character varying(45),
    user_agent text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.security_events OWNER TO fleet_user;

--
-- Name: service_accounts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.service_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    name text,
    secret_hash text NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.service_accounts OWNER TO fleet_user;

--
-- Name: signing_keys; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.signing_keys (
    kid text NOT NULL,
    private_key_enc text NOT NULL,
    public_key text NOT NULL,
    status text NOT NULL,
    algorithm text DEFAULT 'RS256'::text,
    created_at timestamp with time zone DEFAULT now(),
    activated_at timestamp with time zone,
    expires_at timestamp with time zone
);


ALTER TABLE public.signing_keys OWNER TO fleet_user;

--
-- Name: sla_metrics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.sla_metrics (
    "time" timestamp with time zone NOT NULL,
    org_id uuid NOT NULL,
    metric_name character varying(50) NOT NULL,
    value numeric(15,4) NOT NULL,
    metadata jsonb
);


ALTER TABLE public.sla_metrics OWNER TO fleet_user;

--
-- Name: storage_pools; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.storage_pools (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(50) DEFAULT 'ACTIVE'::character varying NOT NULL,
    total_bytes bigint DEFAULT 0 NOT NULL,
    used_bytes bigint DEFAULT 0 NOT NULL,
    available_bytes bigint DEFAULT 0 NOT NULL,
    location character varying(255),
    backup_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.storage_pools OWNER TO fleet_user;

--
-- Name: support_audit_log; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.support_audit_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ticket_id uuid,
    user_id uuid,
    action character varying(100) NOT NULL,
    old_value jsonb,
    new_value jsonb,
    details text,
    created_at timestamp with time zone DEFAULT now(),
    ip_address character varying(45)
);


ALTER TABLE public.support_audit_log OWNER TO fleet_user;

--
-- Name: TABLE support_audit_log; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.support_audit_log IS 'Audit trail for all support operations';


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.support_tickets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ticket_id character varying(50) NOT NULL,
    org_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'OPEN'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'MEDIUM'::character varying NOT NULL,
    category character varying(100),
    assigned_to uuid,
    reporter_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone,
    sla_deadline timestamp with time zone,
    tags jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.support_tickets OWNER TO fleet_user;

--
-- Name: TABLE support_tickets; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.support_tickets IS 'Core support ticket records';


--
-- Name: telemetry; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    trip_id uuid,
    latitude numeric(10,8),
    longitude numeric(11,8),
    speed numeric(6,2),
    heading numeric(5,2),
    event_type character varying(50),
    event_time timestamp without time zone DEFAULT now()
);


ALTER TABLE public.telemetry OWNER TO fleet_user;

--
-- Name: telemetry_analytics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_analytics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    analysis_type character varying(100) NOT NULL,
    data jsonb NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    confidence numeric(3,2) NOT NULL,
    CONSTRAINT telemetry_analytics_confidence_check CHECK (((confidence >= (0)::numeric) AND (confidence <= (1)::numeric)))
);


ALTER TABLE public.telemetry_analytics OWNER TO fleet_user;

--
-- Name: TABLE telemetry_analytics; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.telemetry_analytics IS 'Stores advanced analytics results for vehicle telemetry data';


--
-- Name: COLUMN telemetry_analytics.analysis_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.telemetry_analytics.analysis_type IS 'Type of analysis performed (e.g., speed_analysis, fuel_efficiency)';


--
-- Name: COLUMN telemetry_analytics.confidence; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.telemetry_analytics.confidence IS 'Confidence score for the analysis results (0-1)';


--
-- Name: telemetry_anomalies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_anomalies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    anomaly_type character varying(100) NOT NULL,
    data jsonb NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    confidence numeric(3,2) NOT NULL,
    anomaly_score numeric(5,2) NOT NULL,
    recommendation text,
    CONSTRAINT telemetry_anomalies_confidence_check CHECK (((confidence >= (0)::numeric) AND (confidence <= (1)::numeric)))
);


ALTER TABLE public.telemetry_anomalies OWNER TO fleet_user;

--
-- Name: TABLE telemetry_anomalies; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.telemetry_anomalies IS 'Stores detected anomalies in vehicle telemetry data';


--
-- Name: COLUMN telemetry_anomalies.anomaly_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.telemetry_anomalies.anomaly_type IS 'Type of anomaly detected (e.g., unusual_speed, fuel_theft)';


--
-- Name: COLUMN telemetry_anomalies.anomaly_score; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.telemetry_anomalies.anomaly_score IS 'Numerical score representing severity of the anomaly';


--
-- Name: COLUMN telemetry_anomalies.recommendation; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.telemetry_anomalies.recommendation IS 'Suggested action for addressing the anomaly';


--
-- Name: threat_alerts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.threat_alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    ip character varying(45),
    user_id uuid,
    description text,
    status character varying(20) DEFAULT 'open'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.threat_alerts OWNER TO fleet_user;

--
-- Name: trip_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.trip_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    retention_period integer DEFAULT 36,
    policies jsonb DEFAULT '{}'::jsonb,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.trip_settings OWNER TO fleet_user;

--
-- Name: trips; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.trips (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    vehicle_id uuid,
    driver_id uuid,
    status character varying(50) DEFAULT 'planned'::character varying NOT NULL,
    title character varying(255),
    description text,
    planned_route jsonb,
    actual_route jsonb,
    waypoints jsonb,
    start_location jsonb,
    end_location jsonb,
    estimated_distance_km numeric(10,2),
    actual_distance_km numeric(10,2),
    estimated_duration_min integer,
    actual_duration_min integer,
    fuel_consumed_liters numeric(10,2) DEFAULT 0,
    idling_time_minutes integer DEFAULT 0,
    cargo_details jsonb,
    pod_documents jsonb,
    scheduled_start timestamp with time zone,
    started_at timestamp with time zone,
    ended_at timestamp with time zone,
    customer_name character varying(255),
    customer_phone character varying(50),
    customer_email character varying(255),
    cancellation_reason text,
    events jsonb,
    is_deleted boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.trips OWNER TO fleet_user;

--
-- Name: usage_meters; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.usage_meters (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    unit character varying(20) NOT NULL,
    unit_price numeric(15,4) DEFAULT 0.0000 NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.usage_meters OWNER TO fleet_user;

--
-- Name: user_notification_preferences; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.user_notification_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    email_enabled boolean DEFAULT true NOT NULL,
    sms_enabled boolean DEFAULT false NOT NULL,
    push_enabled boolean DEFAULT true NOT NULL,
    in_app_enabled boolean DEFAULT true NOT NULL,
    last_modified_by uuid,
    last_modified_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_notification_preferences OWNER TO fleet_user;

--
-- Name: user_organizations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.user_organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    role character varying(50) DEFAULT 'member'::character varying,
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_organizations OWNER TO fleet_user;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    session_id character varying(100) NOT NULL,
    ip_address character varying(45),
    user_agent text,
    device_info jsonb,
    login_time timestamp with time zone DEFAULT now(),
    last_activity timestamp with time zone DEFAULT now(),
    logout_time timestamp with time zone,
    is_active boolean DEFAULT true,
    location jsonb
);


ALTER TABLE public.user_sessions OWNER TO fleet_user;

--
-- Name: TABLE user_sessions; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.user_sessions IS 'User session tracking for support investigations';


--
-- Name: users; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash text NOT NULL,
    name character varying(255),
    phone character varying(50),
    mfa_enabled boolean DEFAULT false,
    mfa_secret text,
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    theme_updated_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    role_id uuid,
    org_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    last_password_change timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_by uuid,
    mfa_methods text[] DEFAULT '{}'::text[],
    role text DEFAULT 'user'::text,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    last_login_at timestamp with time zone,
    data_retention_until timestamp with time zone
);


ALTER TABLE public.users OWNER TO fleet_user;

--
-- Name: COLUMN users.failed_login_attempts; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.users.failed_login_attempts IS 'Count of consecutive failed login attempts';


--
-- Name: COLUMN users.locked_until; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.users.locked_until IS 'Account lockout expiry time';


--
-- Name: vehicle_inspections; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicle_inspections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    template_id uuid,
    inspector_id uuid NOT NULL,
    status character varying(20) DEFAULT 'COMPLETED'::character varying,
    results jsonb DEFAULT '[]'::jsonb NOT NULL,
    notes text,
    odometer_at_inspection bigint,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.vehicle_inspections OWNER TO fleet_user;

--
-- Name: TABLE vehicle_inspections; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.vehicle_inspections IS 'Completed vehicle inspection reports';


--
-- Name: vehicle_telemetry; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicle_telemetry (
    "time" timestamp with time zone NOT NULL,
    vehicle_id uuid NOT NULL,
    latitude double precision,
    longitude double precision,
    speed_kph double precision,
    heading double precision,
    odometer_km double precision,
    fuel_level_percent double precision,
    engine_temp_celsius double precision,
    alerts jsonb DEFAULT '[]'::jsonb
);


ALTER TABLE public.vehicle_telemetry OWNER TO fleet_user;

--
-- Name: TABLE vehicle_telemetry; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.vehicle_telemetry IS 'Aggregated telemetry data for trip reporting';


--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    license_plate character varying(20) NOT NULL,
    model character varying(50) NOT NULL,
    make character varying(50) NOT NULL,
    year integer NOT NULL,
    color character varying(30),
    status character varying(20) DEFAULT 'active'::character varying,
    capacity integer DEFAULT 1,
    fuel_type character varying(20),
    vin character varying(50),
    registration character varying(50),
    insurance character varying(50),
    odometer bigint DEFAULT 0,
    last_service timestamp with time zone,
    current_driver_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    vehicle_no character varying(50),
    service_due timestamp with time zone,
    notes text,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.vehicles OWNER TO fleet_user;

--
-- Name: video_analytics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.video_analytics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    recording_id uuid NOT NULL,
    stream_id uuid,
    objects_detected jsonb DEFAULT '[]'::jsonb NOT NULL,
    behavior_events jsonb DEFAULT '[]'::jsonb NOT NULL,
    traffic_signs jsonb DEFAULT '[]'::jsonb NOT NULL,
    incidents jsonb DEFAULT '[]'::jsonb NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    confidence numeric(3,2) NOT NULL,
    processed_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT video_analytics_confidence_check CHECK (((confidence >= (0)::numeric) AND (confidence <= (1)::numeric)))
);


ALTER TABLE public.video_analytics OWNER TO fleet_user;

--
-- Name: TABLE video_analytics; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.video_analytics IS 'Stores AI-powered insights extracted from video analysis';


--
-- Name: COLUMN video_analytics.objects_detected; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_analytics.objects_detected IS 'List of objects detected in the video';


--
-- Name: COLUMN video_analytics.behavior_events; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_analytics.behavior_events IS 'List of behavioral events detected in the video';


--
-- Name: COLUMN video_analytics.incidents; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_analytics.incidents IS 'List of incidents detected in the video';


--
-- Name: COLUMN video_analytics.confidence; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_analytics.confidence IS 'Confidence score for the analytics results (0-1)';


--
-- Name: video_recordings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.video_recordings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    stream_id uuid NOT NULL,
    camera_id character varying(255) NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    filename character varying(500) NOT NULL,
    filepath text NOT NULL,
    file_size bigint NOT NULL,
    duration integer NOT NULL,
    resolution character varying(20),
    framerate integer,
    bitrate integer,
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone NOT NULL,
    location_start jsonb NOT NULL,
    location_end jsonb NOT NULL,
    status character varying(50) DEFAULT 'processing'::character varying NOT NULL,
    thumbnail_path text,
    tags jsonb DEFAULT '[]'::jsonb,
    event_type character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.video_recordings OWNER TO fleet_user;

--
-- Name: TABLE video_recordings; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.video_recordings IS 'Stores information about recorded video clips';


--
-- Name: COLUMN video_recordings.status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_recordings.status IS 'Status of the video recording (recorded, processing, available, archived, deleted)';


--
-- Name: COLUMN video_recordings.event_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_recordings.event_type IS 'Type of event that triggered the recording (sudden_stop, harsh_acceleration, etc.)';


--
-- Name: video_retention_policies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.video_retention_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    event_type character varying(100),
    retention_period integer NOT NULL,
    auto_archive boolean DEFAULT false,
    auto_delete boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.video_retention_policies OWNER TO fleet_user;

--
-- Name: TABLE video_retention_policies; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.video_retention_policies IS 'Stores retention policies for video data';


--
-- Name: COLUMN video_retention_policies.retention_period; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_retention_policies.retention_period IS 'Number of days to retain videos before archiving/deletion';


--
-- Name: COLUMN video_retention_policies.auto_archive; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_retention_policies.auto_archive IS 'Flag to automatically archive videos after retention period';


--
-- Name: COLUMN video_retention_policies.auto_delete; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_retention_policies.auto_delete IS 'Flag to automatically delete videos after retention period';


--
-- Name: video_streams; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.video_streams (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    camera_id character varying(255) NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    url text NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    resolution character varying(20),
    framerate integer,
    bitrate integer,
    protocol character varying(20),
    location jsonb NOT NULL,
    started_at timestamp with time zone NOT NULL,
    ended_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    analytics_enabled boolean DEFAULT false
);


ALTER TABLE public.video_streams OWNER TO fleet_user;

--
-- Name: TABLE video_streams; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.video_streams IS 'Stores information about live video streams from vehicles';


--
-- Name: COLUMN video_streams.status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_streams.status IS 'Status of the video stream (active, inactive, error)';


--
-- Name: COLUMN video_streams.analytics_enabled; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_streams.analytics_enabled IS 'Flag to enable AI-powered analytics on this stream';


--
-- Name: video_thumbnails; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.video_thumbnails (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    recording_id uuid NOT NULL,
    image_path text NOT NULL,
    image_url text NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.video_thumbnails OWNER TO fleet_user;

--
-- Name: TABLE video_thumbnails; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.video_thumbnails IS 'Stores thumbnail images for video recordings';


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    url text NOT NULL,
    events text[] DEFAULT '{}'::text[],
    secret character varying(255),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.webhooks OWNER TO fleet_user;

--
-- Name: work_orders; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.work_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    vehicle_id uuid,
    title text NOT NULL,
    description text,
    maintenance_type text DEFAULT 'PREVENTIVE'::text NOT NULL,
    priority text DEFAULT 'MEDIUM'::text NOT NULL,
    status text DEFAULT 'OPEN'::text NOT NULL,
    assigned_to uuid,
    scheduled_date timestamp with time zone,
    completed_date timestamp with time zone,
    estimated_cost double precision DEFAULT 0 NOT NULL,
    actual_cost double precision DEFAULT 0 NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    vendor_id uuid,
    approval_status text DEFAULT 'PENDING'::text NOT NULL,
    cost_breakdown jsonb DEFAULT '{}'::jsonb NOT NULL,
    inspection_id uuid,
    updated_by uuid
);


ALTER TABLE public.work_orders OWNER TO fleet_user;

--
-- Data for Name: hypertable; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.hypertable (id, schema_name, table_name, associated_schema_name, associated_table_prefix, num_dimensions, chunk_sizing_func_schema, chunk_sizing_func_name, chunk_target_size, compression_state, compressed_hypertable_id, status) FROM stdin;
3	public	gps_locations	_timescaledb_internal	_hyper_3	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
4	public	obd_readings	_timescaledb_internal	_hyper_4	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
5	public	vehicle_telemetry	_timescaledb_internal	_hyper_5	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
6	public	consumption_events	_timescaledb_internal	_hyper_6	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
7	public	sla_metrics	_timescaledb_internal	_hyper_7	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
\.


--
-- Data for Name: bgw_job; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.bgw_job (id, application_name, schedule_interval, max_runtime, max_retries, retry_period, proc_schema, proc_name, owner, scheduled, fixed_schedule, initial_start, hypertable_id, config, check_schema, check_name, timezone) FROM stdin;
1000	Retention Policy [1000]	1 day	00:05:00	-1	00:05:00	_timescaledb_functions	policy_retention	fleet_user	t	f	\N	3	{"drop_after": "90 days", "hypertable_id": 3}	_timescaledb_functions	policy_retention_check	\N
1001	Retention Policy [1001]	1 day	00:05:00	-1	00:05:00	_timescaledb_functions	policy_retention	fleet_user	t	f	\N	4	{"drop_after": "90 days", "hypertable_id": 4}	_timescaledb_functions	policy_retention_check	\N
\.


--
-- Data for Name: chunk; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.chunk (id, hypertable_id, schema_name, table_name, compressed_chunk_id, dropped, status, osm_chunk, creation_time) FROM stdin;
\.


--
-- Data for Name: chunk_column_stats; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.chunk_column_stats (id, hypertable_id, chunk_id, column_name, range_start, range_end, valid) FROM stdin;
\.


--
-- Data for Name: dimension; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.dimension (id, hypertable_id, column_name, column_type, aligned, num_slices, partitioning_func_schema, partitioning_func, interval_length, compress_interval_length, integer_now_func_schema, integer_now_func) FROM stdin;
3	3	time	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
4	4	time	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
5	5	time	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
6	6	time	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
7	7	time	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
\.


--
-- Data for Name: dimension_slice; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.dimension_slice (id, dimension_id, range_start, range_end) FROM stdin;
\.


--
-- Data for Name: chunk_constraint; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.chunk_constraint (chunk_id, dimension_slice_id, constraint_name, hypertable_constraint_name) FROM stdin;
\.


--
-- Data for Name: compression_chunk_size; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.compression_chunk_size (chunk_id, compressed_chunk_id, uncompressed_heap_size, uncompressed_toast_size, uncompressed_index_size, compressed_heap_size, compressed_toast_size, compressed_index_size, numrows_pre_compression, numrows_post_compression, numrows_frozen_immediately) FROM stdin;
\.


--
-- Data for Name: compression_settings; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.compression_settings (relid, compress_relid, segmentby, orderby, orderby_desc, orderby_nullsfirst, index) FROM stdin;
\.


--
-- Data for Name: continuous_agg; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_agg (mat_hypertable_id, raw_hypertable_id, parent_mat_hypertable_id, user_view_schema, user_view_name, partial_view_schema, partial_view_name, direct_view_schema, direct_view_name, materialized_only) FROM stdin;
\.


--
-- Data for Name: continuous_agg_migrate_plan; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_agg_migrate_plan (mat_hypertable_id, start_ts, end_ts, user_view_definition) FROM stdin;
\.


--
-- Data for Name: continuous_agg_migrate_plan_step; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_agg_migrate_plan_step (mat_hypertable_id, step_id, status, start_ts, end_ts, type, config) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_bucket_function; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_aggs_bucket_function (mat_hypertable_id, bucket_func, bucket_width, bucket_origin, bucket_offset, bucket_timezone, bucket_fixed_width) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_hypertable_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_aggs_hypertable_invalidation_log (hypertable_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_invalidation_threshold; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_aggs_invalidation_threshold (hypertable_id, watermark) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_aggs_materialization_invalidation_log (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_aggs_materialization_ranges (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_watermark; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_aggs_watermark (mat_hypertable_id, watermark) FROM stdin;
\.


--
-- Data for Name: metadata; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.metadata (key, value, include_in_telemetry) FROM stdin;
install_timestamp	2026-03-12 07:58:22.725568+00	t
timescaledb_version	2.25.2	f
exported_uuid	d5318071-74e5-4c75-96fc-48a83f7b1dba	t
\.


--
-- Data for Name: tablespace; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.tablespace (id, hypertable_id, tablespace_name) FROM stdin;
\.


--
-- Data for Name: access_reviews; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.access_reviews (id, org_id, title, status, due_date, total_users, reviewed_users, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alert_rules; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.alert_rules (id, org_id, name, type, description, severity, conditions, actions, vehicles, driver_ids, enabled, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.alerts (id, org_id, rule_id, type, severity, vehicle_id, driver_id, "timestamp", location, details, status, notes, acknowledged_by, acknowledged_at, resolved_by, resolved_at, created_at, updated_at, dedup_key, escalation_level, last_escalated_at, escalated_to, sla_deadline) FROM stdin;
\.


--
-- Data for Name: analytics_jobs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.analytics_jobs (id, name, type, description, status, job_type, parameters, input_source, output_destination, start_time, end_time, progress, error_details, organization_id, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_clients; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.api_clients (id, org_id, client_id, client_secret_hash, name, scopes, expiry, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.api_keys (id, org_id, name, prefix, secret_hash, permissions, last_used_at, expires_at, created_at, revoked) FROM stdin;
06ce53ec-ccfb-4224-b1df-f492be116445	00000000-0000-0000-0000-000000000000	Audit-Test-Key	7acaaac52569	$argon2id$v=19$m=65536,t=3,p=4$WpsZZUkP2Kol9iDQxwn46g$2nRKtElqdCOLOXrByS18t84Gqrv5DTGbOie1pS0+1qc	[]	\N	\N	2026-03-12 09:50:42.007477+00	f
3a2891b2-5d83-492c-a0e8-6119a0081c7d	00000000-0000-0000-0000-000000000000	Audit-Key-1	3e0007d0b745	$argon2id$v=19$m=65536,t=3,p=4$PPMN181H7xy8kDpeVZFeOQ$1ig1nBMm9dQMtBI5SbuUMmZzev1wwfPcc1pWpo6pv+8	[]	\N	\N	2026-03-12 10:05:15.70223+00	f
76e20bb3-2ecc-4177-bf59-06f1a0b6130d	00000000-0000-0000-0000-000000000000	Audit-Key-1	bdfe3d38e0e5	$argon2id$v=19$m=65536,t=3,p=4$0iqvzC/JoMwjzl292nReCQ$qK9IXcGMfd/0Kzd6b20kbqSjIi5cO2k5kT6K64ngFr8	[]	\N	\N	2026-03-12 10:05:31.817288+00	f
073254ce-d076-4cb7-9cd1-b03cda85d87b	00000000-0000-0000-0000-000000000000	Audit-Key-1	5bc3d71df7a9	$argon2id$v=19$m=65536,t=3,p=4$uSDoTduYDvZQ9FgVyVV4LQ$rt8wUvIHTJ7pCGK4499EYX1oE9cuErba+l2OsjniLnI	[]	\N	\N	2026-03-12 10:06:47.317339+00	f
6e815ab0-85ca-4e0e-b6ce-3b9a7c0765d2	00000000-0000-0000-0000-000000000000	Audit-Key-Phase5	11c670ffa8e8	$argon2id$v=19$m=65536,t=3,p=4$+QpnR0pNiBlNjMStlBiMzA$bMv6mWylZ2lTfAIhbPK3qNuJNGtEWskK+EtNksZhNoE	[]	\N	\N	2026-03-12 10:17:27.219467+00	f
60bd316f-f2fe-4b63-82a4-d0f30377351b	00000000-0000-0000-0000-000000000000	Audit-Key-Phase5	2256d84707db	$argon2id$v=19$m=65536,t=3,p=4$SWJE3FD84552Z8ZQIUarHw$n5ifdZOgs5E/wfHwwb5riaCQRGK6ywYBXgeU57CTjBA	[]	\N	\N	2026-03-12 10:17:59.151044+00	f
a7acbb85-02e3-474d-9e44-e5ffbb11610a	00000000-0000-0000-0000-000000000000	Audit-Key-Phase5	38f2804eb7ee	$argon2id$v=19$m=65536,t=3,p=4$vfE4hq7v+AnidLsVrR77Wg$uG7MiT7chpylZs3SmGHDlCoU1Din8cC9TYb94Fd/kJ4	[]	\N	\N	2026-03-12 10:18:49.093475+00	f
8bd50484-2e51-4b03-8b39-996f12dd67fc	00000000-0000-0000-0000-000000000000	Audit-Key-Phase5	148673efcde1	$argon2id$v=19$m=65536,t=3,p=4$5zcpbdIAxuxALAvB75+rPg$ehw8l38KzpByq7u7XHNcZbYr2ZQhSzV8s7Dco0yTX0g	[]	\N	\N	2026-03-12 10:19:07.021981+00	f
5a4679f4-4c6e-4873-962c-126ed9d9e7ca	00000000-0000-0000-0000-000000000000	Audit-Key-Phase5	46883a39066d	$argon2id$v=19$m=65536,t=3,p=4$SQTojPY1EFpmtCTdNG/v9g$Xc7ENw7kzDpndxQY7ZwNJZNEMuYcom6A/iEaxrWTvvA	[]	\N	\N	2026-03-12 10:19:19.789545+00	f
8715068f-c1ae-4412-b963-e7bc2d4c04ce	00000000-0000-0000-0000-000000000000	Audit-Key-Final	c3fefc2392f9	$argon2id$v=19$m=65536,t=3,p=4$OSK3/a4d3LBzpC+J4BIVkA$JRLly/ABZYfQgriylmZVQZYv3ulzGvvqL9YJXaCX6D4	[]	\N	\N	2026-03-12 10:20:48.986476+00	f
9dc2c3ad-5f2b-40ab-973f-ed5ca2ced8c3	00000000-0000-0000-0000-000000000000	Audit-Key-Phase5	f0cb51400f95	$argon2id$v=19$m=65536,t=3,p=4$/m7GYLRtkuK4TGkqmLiH5A$E8SOtvJbrhU9d4RAcdyEixIG0JpPoQw89/nclH1acdw	[]	\N	\N	2026-03-12 10:21:17.293074+00	f
ab3d76b8-9363-4369-ab20-ea7dcb2f7b4e	00000000-0000-0000-0000-000000000000	Audit-Key-Phase5	1cbd1b5ce5a2	$argon2id$v=19$m=65536,t=3,p=4$XQj9DhrFe649QqGS9UIIbA$8lE9zcJLFfGUU2ffad7+2eNh+qMFuDofGHmY2ol5P44	[]	\N	\N	2026-03-12 11:14:16.15644+00	f
64dc3b04-cfc0-416a-89ca-94eecda2b725	00000000-0000-0000-0000-000000000000	Audit-Key-Phase5	4e8b9368d818	$argon2id$v=19$m=65536,t=3,p=4$cp6tHZSi/uEuOzCFHuEh2Q$9xqaGml700aMSgfoHZdFuhstMmGPyDQ1nbBRSaGgOEY	[]	\N	\N	2026-03-12 11:26:46.991041+00	t
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.audit_logs (id, user_id, action, resource, details, ip_address, user_agent, created_at, severity, status, org_id, module, entity_id, before_state, after_state, metadata) FROM stdin;
\.


--
-- Data for Name: audit_policies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.audit_policies (id, org_id, retention_years, archive_policy, masking_rules, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.audit_settings (id, org_id, retention_days_online, retention_days_archival, masking_rules, tracked_event_types, alert_on_critical, updated_at) FROM stdin;
\.


--
-- Data for Name: auth_audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.auth_audit_logs (id, actor_id, actor_type, action, entity_type, entity_id, org_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: auth_tokens; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.auth_tokens (id, user_id, access_token, refresh_token, device_id, expires_at, created_at, ip_address, user_agent, last_active, is_active) FROM stdin;
\.


--
-- Data for Name: backup_verifications; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.backup_verifications (id, backup_id, status, checksum, verified_at, verified_by, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.backups (id, type, status, s3_key, size_bytes, created_by, created_at, completed_at, metadata) FROM stdin;
\.


--
-- Data for Name: billing_accounting_exports; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_accounting_exports (id, org_id, external_system, export_type, status, file_key, records_count, error_message, created_at, completed_at, created_by) FROM stdin;
\.


--
-- Data for Name: billing_coupons; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_coupons (id, code, name, discount_type, discount_value, currency, max_redemptions, redeemed_count, valid_from, valid_until, status, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: billing_credit_transactions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_credit_transactions (id, balance_id, transaction_type, amount, currency, reference_type, reference_id, description, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: billing_customer_balances; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_customer_balances (id, org_id, currency, balance, credit_limit, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: billing_hardware_products; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_hardware_products (id, name, model_code, category, one_time_price, lease_monthly_price, currency, metadata, created_at, updated_at) FROM stdin;
ef27ce2d-7271-4005-9916-3c81154e93f7	FlyFleet Vision Pro Dashcam	FF-CAM-V2	DASHCAM	399.00	25.00	USD	{}	2026-03-12 07:58:49.381525+00	2026-03-12 07:58:49.381525+00
0d1939c7-d9e5-481b-a266-97d14d482820	FlyFleet Standard GPS Tracker	FF-GPS-100	TRACKER	99.00	10.00	USD	{}	2026-03-12 07:58:49.381525+00	2026-03-12 07:58:49.381525+00
25ad0693-02f5-4ce5-a6cc-fba6c1361b1c	FlyFleet OBD-II Telematics Node	FF-OBD-V1	TRACKER	149.00	15.00	USD	{}	2026-03-12 07:58:49.381525+00	2026-03-12 07:58:49.381525+00
\.


--
-- Data for Name: billing_invoice_documents; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_invoice_documents (id, invoice_id, template_id, file_url, storage_key, generated_at, template_version, snapshot, checksum) FROM stdin;
\.


--
-- Data for Name: billing_invoice_sequences; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_invoice_sequences (org_id, prefix, next_value, suffix, updated_at) FROM stdin;
\.


--
-- Data for Name: billing_invoice_templates; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_invoice_templates (id, name, version, html_content, is_default, created_at) FROM stdin;
\.


--
-- Data for Name: billing_plans; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_plans (id, name, description, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: billing_pricing_components; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_pricing_components (id, plan_id, name, type, unit_price, currency, meter_event_name, frequency, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: billing_recognized_revenue; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_recognized_revenue (id, schedule_id, amount, recognized_at, created_at) FROM stdin;
\.


--
-- Data for Name: billing_revenue_schedules; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_revenue_schedules (id, org_id, invoice_line_item_id, total_amount, currency, start_date, end_date, status, created_at) FROM stdin;
\.


--
-- Data for Name: billing_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_settings (org_id, default_tax_rate, base_currency, grace_period_days, auto_invoicing_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: billing_subscriptions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_subscriptions (id, org_id, plan_id, status, current_period_start, current_period_end, trial_end, cancel_at_period_end, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: billing_tax_rates; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_tax_rates (id, region_id, name, percentage, tax_type, is_default, created_at) FROM stdin;
\.


--
-- Data for Name: billing_tax_regions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_tax_regions (id, name, country_code, state_code, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: blocked_ips; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.blocked_ips (ip_address, reason, expires_at) FROM stdin;
\.


--
-- Data for Name: bulk_config; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.bulk_config (organization_id, max_records_per_file, concurrent_threads, retention_months, mandatory_fields, updated_at) FROM stdin;
\.


--
-- Data for Name: bulk_job_records; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.bulk_job_records (id, job_id, row_number, record_data, status, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: bulk_jobs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.bulk_jobs (id, organization_id, file_name, status, total_records, success_count, failed_count, created_by, created_at, updated_at, retry_count) FROM stdin;
\.


--
-- Data for Name: consumption_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.consumption_events ("time", org_id, vehicle_id, meter_code, amount, metadata, processed_invoice_id) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.devices (id, user_id, device_id, device_name, trusted, last_seen) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.documents (id, vehicle_id, type, doc_number, issue_date, expiry_date, file_url, status, metadata, created_at, updated_at, org_id, title, file_name, file_size_bytes, mime_type, storage_path, reminder_days, uploaded_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: dr_test_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.dr_test_logs (id, test_id, ts, level, message) FROM stdin;
\.


--
-- Data for Name: dr_test_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.dr_test_settings (id, schedule_enabled, frequency, schedule_day, schedule_time, intensity, notification_emails, updated_at) FROM stdin;
t	f	WEEKLY	SATURDAY	02:00	NORMAL	[]	2026-03-12 07:58:49.1656+00
\.


--
-- Data for Name: dr_test_steps; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.dr_test_steps (id, test_id, step_order, step_name, status, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: dr_tests; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.dr_tests (id, test_id, name, description, test_type, target_env, status, progress_percent, initiated_by, success_criteria, scheduled_at, started_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_behavior; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_behavior (id, driver_id, org_id, period_start, period_end, score, safety_score, efficiency_score, compliance_score, harsh_accelerations, harsh_brakings, harsh_cornerings, speeding_incidents, phone_usage, seatbelt_violations, fuel_consumption, distance_driven, idle_time, eco_driving_score, hours_of_service, rest_periods, document_compliance, maintenance_adherence, night_driving_hours, highway_percentage, city_driving_percentage, risk_level, risk_factors, improvement_areas, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_behavior_analytics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_behavior_analytics (id, driver_id, organization_id, analysis_period_start, analysis_period_end, total_driving_hours, aggressive_acceleration_count, hard_braking_count, sharp_turn_count, over_speeding_count, idling_time, average_speed, max_speed, fuel_efficiency, safety_score, efficiency_score, comfort_score, ranking, improvement_suggestions, behavior_trend, generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_incidents; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_incidents (id, driver_id, org_id, type, severity, "timestamp", location, speed, details, resolved, resolution_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.drivers (id, org_id, first_name, last_name, email, phone, license_number, license_type, license_expiry, license_authority, date_of_birth, address, emergency_contact, status, current_vehicle_id, current_trip_id, joining_date, resignation_date, experience_years, rating, total_trips, total_distance_km, total_hours_driven, behavior_score, documents, attendance_records, schedules, metadata, created_at, updated_at, deleted_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.email_verification_tokens (id, user_id, token, expires_at, used, created_at) FROM stdin;
\.


--
-- Data for Name: entity_audit_history; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.entity_audit_history (id, entity_type, entity_id, change_data, actor, "timestamp") FROM stdin;
\.


--
-- Data for Name: evidence_exports; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.evidence_exports (id, org_id, module, date_range_start, date_range_end, format, status, requested_by, file_url, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: firmware_packages; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.firmware_packages (id, version, hardware_target, file_url, file_size, checksum, release_notes, status, is_critical, released_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: firmware_rollout_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.firmware_rollout_events (id, rollout_id, org_id, event_type, from_status, to_status, actor_user_id, message, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: firmware_rollouts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.firmware_rollouts (id, firmware_id, org_id, name, device_group, target_filter, total_devices, completed_devices, failed_devices, status, rollout_strategy, max_concurrent, created_by, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: fleet_analytics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.fleet_analytics (id, organization_id, start_date, end_date, total_vehicles, active_vehicles, total_distance, average_speed, total_fuel_consumption, average_fuel_efficiency, total_trips, completed_trips, cancelled_trips, average_trip_duration, idle_time_percentage, routing_efficiency, fuel_cost, maintenance_cost, revenue, profit_margin, safety_score, accidents_count, incidents_count, emergency_stops, geofence_violations, alerts_triggered, data_points_collected, processing_time, generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: geofences; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.geofences (id, org_id, name, type, center, radius_meters, coordinates, route_polyline, buffer_meters, entry_alert, exit_alert, speed_limit, vehicles, enabled, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: global_notification_defaults; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.global_notification_defaults (id, email_enabled, sms_enabled, push_enabled, in_app_enabled, updated_by, updated_at) FROM stdin;
610b7128-3173-4875-badf-8ae4046ad891	t	f	t	t	\N	2026-03-12 07:58:48.587783+00
\.


--
-- Data for Name: gps_locations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.gps_locations ("time", vehicle_id, latitude, longitude, altitude, speed, heading, accuracy, ignition, odometer, battery_level, satellites, raw_data) FROM stdin;
\.


--
-- Data for Name: incident_comments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.incident_comments (id, ticket_id, author_id, author_name, comment_type, content, is_private, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inspection_templates; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.inspection_templates (id, organization_id, name, description, applicable_vehicle_types, checklist_items, is_active, created_at, updated_at) FROM stdin;
6a55c116-6206-4643-bc59-493d08fd60c5	00000000-0000-0000-0000-000000000001	Standard Safety Inspection	Routine safety check for all fleet vehicles	{TRUCK,VAN,CAR}	[{"text": "Brake pad thickness & fluid level", "type": "pass_fail", "item_id": "brakes", "required": true}, {"text": "Tire pressure & tread depth", "type": "pass_fail", "item_id": "tires", "required": true}, {"text": "Headlights, tail lights & signals", "type": "pass_fail", "item_id": "lights", "required": true}, {"text": "Oil, coolant & washer fluid", "type": "pass_fail", "item_id": "fluids", "required": false}, {"text": "Engine noise & diagnostic codes", "type": "pass_fail", "item_id": "engine", "required": true}]	t	2026-03-12 07:58:48.277904+00	2026-03-12 07:58:48.277904+00
\.


--
-- Data for Name: integration_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.integration_logs (id, org_id, integration_id, method, endpoint, request_body, response_body, status_code, status, duration_ms, "timestamp") FROM stdin;
\.


--
-- Data for Name: integrations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.integrations (id, org_id, name, type, provider, status, config, last_sync, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.invoice_items (id, invoice_id, description, quantity, unit_price, tax_percent, total, created_at, updated_at, org_id, amount, is_deleted, deleted_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.invoices (id, org_id, customer_name, invoice_date, due_date, status, currency, total_amount, amount_paid, balance_due, created_at, updated_at, invoice_number, customer_email, billing_address, subtotal, tax_amount, amount_remaining, notes, is_deleted, deleted_at, custom_fields) FROM stdin;
\.


--
-- Data for Name: ip_rules; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.ip_rules (id, org_id, cidr, action, description, added_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: login_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.login_events (id, org_id, user_id, email, ip_address, device, browser, location, status, risk_level, created_at) FROM stdin;
\.


--
-- Data for Name: login_history; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.login_history (id, user_id, ip_address, user_agent, country, success, risk_score, created_at) FROM stdin;
7e87fc69-f779-441c-80ff-9d8376381afd	669091a5-8fa5-480b-acd5-552f4a273cb4	127.0.0.1	test-agent	US	t	30	2026-03-12 08:46:43.236136+00
e4bc8dc2-a42e-4c31-ac71-95b904aa58bf	669091a5-8fa5-480b-acd5-552f4a273cb4	127.0.0.1	test-agent	US	t	30	2026-03-12 08:47:37.399467+00
73edc0ab-1681-48af-93d5-980966d79d77	669091a5-8fa5-480b-acd5-552f4a273cb4	127.0.0.1	test	US	t	30	2026-03-12 08:57:02.857285+00
60eeb4c7-f887-4e56-9345-e723efda1456	669091a5-8fa5-480b-acd5-552f4a273cb4	127.0.0.1	test	US	t	30	2026-03-12 08:58:04.128529+00
b9062093-9927-4099-92df-77d1aa53d0f5	669091a5-8fa5-480b-acd5-552f4a273cb4	127.0.0.1	test	US	t	30	2026-03-12 08:58:42.331405+00
1928063c-5e85-4e75-97b2-a87706026976	669091a5-8fa5-480b-acd5-552f4a273cb4	127.0.0.1	test	US	t	30	2026-03-12 09:00:08.550432+00
ae6def35-f52b-47f1-b077-f7b0262af885	669091a5-8fa5-480b-acd5-552f4a273cb4	127.0.0.1	test	US	t	30	2026-03-12 09:01:19.367314+00
da337763-d7f5-4035-a6b2-358cdc97d6e7	669091a5-8fa5-480b-acd5-552f4a273cb4	127.0.0.1	hacker-agent	US	f	30	2026-03-12 09:09:58.461117+00
dd60386a-5ace-420e-98ce-f1c1358b8dc7	669091a5-8fa5-480b-acd5-552f4a273cb4	127.0.0.1	hacker-agent	US	f	30	2026-03-12 09:09:58.526815+00
1374afbf-3d08-4b57-bd11-2df292f6068b	669091a5-8fa5-480b-acd5-552f4a273cb4	127.0.0.1	hacker-agent	US	f	30	2026-03-12 09:09:58.576122+00
d6bb21a4-1958-45c7-ab80-0b8919f7cce6	669091a5-8fa5-480b-acd5-552f4a273cb4	127.0.0.1	hacker-agent	US	f	30	2026-03-12 09:09:58.625977+00
09a17142-0e84-4381-ba43-515c904a5a03	669091a5-8fa5-480b-acd5-552f4a273cb4	127.0.0.1	hacker-agent	US	f	30	2026-03-12 09:09:58.674219+00
167e8377-2794-4006-9944-ca53ecdf8ff0	4ecfb772-ccd7-42ab-aebd-d4a80e4407b5	10.0.1.1	curl/8.5.0	FR	f	30	2026-03-12 09:27:29.852838+00
fdaf926c-e02f-4417-b32f-2a3438402e21	4a665e5c-e5e9-4d05-8a72-d38a40a5e91b	::1	curl/8.5.0	US	t	30	2026-03-12 15:31:01.977199+00
6702a6ea-fa6d-47b5-a4fa-23a05f6ce9fd	4a665e5c-e5e9-4d05-8a72-d38a40a5e91b	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	US	t	30	2026-03-12 15:31:40.683042+00
\.


--
-- Data for Name: maintenance_vendors; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.maintenance_vendors (id, organization_id, name, specialization, rating, contact_info, payment_terms, status, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_codes; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_codes (id, user_id, code, method, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_events (id, user_id, org_id, event_type, status, method, ip_address, user_agent, location, details, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_exceptions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_exceptions (id, user_id, org_id, reason, granted_by, expires_at, created_at, start_date) FROM stdin;
\.


--
-- Data for Name: mfa_failures; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_failures (id, user_id, org_id, method, failure_reason, ip_address, location, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_lockouts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_lockouts (id, user_id, org_id, reason, locked_at, expires_at, unlocked_at, unlocked_by) FROM stdin;
\.


--
-- Data for Name: mfa_org_overrides; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_org_overrides (id, org_id, enabled, allowed_methods, max_attempts, lockout_minutes, remember_device_days, grace_period_days, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_policies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_policies (id, org_id, require_mfa, allowed_methods, max_attempts, lockout_minutes, created_at, updated_at, grace_period_days, remember_device_days, enforce_at_login, admin_only_mode, remember_device_allowed, mfa_challenge_timeout, version) FROM stdin;
\.


--
-- Data for Name: mfa_policy_history; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_policy_history (id, policy_id, org_id, snapshot, changed_by, change_reason, version, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_recovery_codes; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_recovery_codes (id, user_id, code_hash, used, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_users; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_users (user_id, org_id, status, method, trusted_devices_count, last_reset, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.notification_events (id, notification_id, event_type, message, created_at) FROM stdin;
\.


--
-- Data for Name: notification_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.notification_logs (id, correlation_id, user_id, user_email, channel, type, subject, body, status, provider, provider_response, retry_count, max_retries, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_preference_audit; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.notification_preference_audit (id, user_id, changed_by, old_values, new_values, change_reason, created_at) FROM stdin;
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.notification_settings (id, channel, enabled, max_retries, priority, retention_months, updated_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.oauth_clients (id, client_id, client_secret_hash, redirect_uris, grant_types, created_at) FROM stdin;
\.


--
-- Data for Name: obd_readings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.obd_readings ("time", vehicle_id, rpm, coolant_temp, engine_load, throttle_pos, fuel_level, dtcs, vin, raw_data) FROM stdin;
\.


--
-- Data for Name: org_support_metrics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.org_support_metrics (org_id, open_tickets, resolved_tickets, avg_resolution_time, sla_breaches, critical_issues, last_calculated, updated_at) FROM stdin;
\.


--
-- Data for Name: organization_memberships; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.organization_memberships (id, org_id, user_id, role, created_at) FROM stdin;
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.organizations (id, name, domain, status, created_at, updated_at, default_theme, is_deleted, contact_email, plan, max_users_limit, max_api_keys_limit) FROM stdin;
00000000-0000-0000-0000-000000000001	Default Org	\N	active	2026-03-12 08:07:07.485059+00	2026-03-12 08:07:07.485059+00	light	f	\N	enterprise	10	5
00000000-0000-0000-0000-000000000000	Default Nil Org	\N	active	2026-03-12 08:15:45.471051+00	2026-03-12 08:15:45.471051+00	light	f	\N	enterprise	10	5
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.password_reset_tokens (id, user_id, token, expires_at, used, created_at) FROM stdin;
c9f8d426-a0d1-41c3-8727-1c225431a364	e90b8c07-9b4d-433b-b729-353e85821458	mP26tjgws5Gt53fd3W78opbv4MFRMulEKi6TPfrea1A=	2026-03-12 11:55:56.352275+00	f	2026-03-12 10:55:56.352276+00
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.permissions (id, role_id, resource, action, created_at) FROM stdin;
\.


--
-- Data for Name: prediction_results; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.prediction_results (id, model_id, prediction_input, predicted_value, confidence_score, probability_scores, feature_importance, anomaly_detected, anomaly_score, explanation, organization_id, request_id, predicted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: predictive_maintenance_analytics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.predictive_maintenance_analytics (id, vehicle_id, organization_id, analysis_date, next_service_due, service_priority, component_risks, failure_prediction, maintenance_schedule, parts_needed, cost_estimation, uptime_prediction, reliability_score, recommendations, generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: predictive_models; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.predictive_models (id, name, version, model_type, description, algorithm, input_features, output_variable, training_data_start, training_data_end, accuracy, "precision", recall, f1_score, status, trained_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.refresh_tokens (id, user_id, token, expires_at, created_at, revoked, revoked_at, used_at, ip_address, user_agent, last_used_at) FROM stdin;
729ed51d-4fde-4bdb-a878-fa32da86a00a	669091a5-8fa5-480b-acd5-552f4a273cb4	BjYZ7ycGXIvJ1xcZ-DCKbpGm9HsmBQew5GOd476u0RE=	2026-03-19 09:01:19.364282+00	2026-03-12 09:01:19.364282+00	t	2026-03-12 09:01:19.391238+00	\N	127.0.0.1	test	2026-03-12 09:01:19.380944+00
1996c76d-81a1-467d-87ad-72aa1432514a	669091a5-8fa5-480b-acd5-552f4a273cb4	cNwdMIQCIDUuj1ayQ89e8ujy3bwNSmNW4JQuy-8dIZQ=	2026-03-19 08:46:43.232971+00	2026-03-12 08:46:43.232971+00	t	2026-03-12 09:01:19.391238+00	\N	127.0.0.1	test-agent	2026-03-12 08:46:43.232971+00
782ec419-28f9-4388-a0b9-e5d14dce2953	669091a5-8fa5-480b-acd5-552f4a273cb4	b_v1-esNm6aXERQ56nFrJYfr3n1jnCfT5NxE1jPpDn4=	2026-03-19 08:47:37.39654+00	2026-03-12 08:47:37.39654+00	t	2026-03-12 09:01:19.391238+00	\N	127.0.0.1	test-agent	2026-03-12 08:47:37.39654+00
0cf2b331-20ab-440b-9250-1a1ac3ab96e5	669091a5-8fa5-480b-acd5-552f4a273cb4	MMH_jfmTggIGyammkYmPpfJy4vtLVB23Es5gnja75Ho=	2026-03-19 08:57:02.854132+00	2026-03-12 08:57:02.854132+00	t	2026-03-12 09:01:19.391238+00	\N	127.0.0.1	test	2026-03-12 08:57:02.854132+00
28f7cf9c-ae45-48f8-ba6f-dee2a6d8aadb	669091a5-8fa5-480b-acd5-552f4a273cb4	Psyt8i-vWNYq0EcHcdKcZrXGe_Wc2vjuinBJ4bsVN2s=	2026-03-19 08:58:04.125782+00	2026-03-12 08:58:04.125782+00	t	2026-03-12 09:01:19.391238+00	\N	127.0.0.1	test	2026-03-12 08:58:04.125782+00
622a7269-689b-4b37-9cb1-5259ae8b71f5	669091a5-8fa5-480b-acd5-552f4a273cb4	SyP8fZkYtNbEspMcZg6OK_VTdFQlOB5j4DvoZ4GBg7Q=	2026-03-19 08:58:42.328596+00	2026-03-12 08:58:42.328596+00	t	2026-03-12 09:01:19.391238+00	\N	127.0.0.1	test	2026-03-12 08:58:42.328596+00
9edb08f2-4e13-44f3-a53b-5ec4f4cb454a	669091a5-8fa5-480b-acd5-552f4a273cb4	3Z0m-K-i8s-MV7v6IEbSVdCH5iB7iFiWuhnHF80ps_U=	2026-03-19 09:00:08.547425+00	2026-03-12 09:00:08.547425+00	t	2026-03-12 09:01:19.391238+00	\N	127.0.0.1	test	2026-03-12 09:00:08.547425+00
042ac729-e0f2-4023-a172-65cecb90ee66	669091a5-8fa5-480b-acd5-552f4a273cb4	xYntrnJdwyhoiTV-2MP-w15T867GWMNX__HMciEDGtY=	2026-03-19 09:01:19.378159+00	2026-03-12 09:01:19.378159+00	t	2026-03-12 09:01:19.391238+00	\N	127.0.0.1	test-agent-2	2026-03-12 09:01:19.389078+00
210b6f59-b5d0-4d3a-bdd6-8375988bec19	4a665e5c-e5e9-4d05-8a72-d38a40a5e91b	r4gB0PnETiSju4_cpR3k469cibLfjbZEFE0JmZSkM80=	2026-03-19 15:31:01.973855+00	2026-03-12 15:31:01.973855+00	f	\N	\N	::1	curl/8.5.0	2026-03-12 15:31:01.973855+00
81ea1051-15e9-447a-9ea8-6f002312c849	4a665e5c-e5e9-4d05-8a72-d38a40a5e91b	RRB2zwMkcZ8e3Udjr1kIQP3qeGOB47buru_7uKhu-OM=	2026-03-19 15:31:40.679195+00	2026-03-12 15:31:40.679195+00	f	\N	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-12 15:31:40.679195+00
\.


--
-- Data for Name: restore_jobs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.restore_jobs (id, backup_id, status, target_environment, started_at, completed_at, performed_by, logs) FROM stdin;
\.


--
-- Data for Name: review_items; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.review_items (id, review_id, user_id, role_id, current_status, reviewer_id, reviewed_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.roles (id, name, description, is_system, created_at, updated_at) FROM stdin;
cbcb0b04-5107-4b03-a875-aa5e22c71b26	super_admin	Full platform access	t	2026-03-12 07:58:44.566179+00	2026-03-12 07:58:44.566179+00
05b43f65-be51-4125-adac-76dc73b5436f	org_admin	Organization level administrator	t	2026-03-12 07:58:44.566179+00	2026-03-12 07:58:44.566179+00
4fd6723f-227f-4113-947e-77e3a965eb96	fleet_manager	Manages vehicles and drivers	t	2026-03-12 07:58:44.566179+00	2026-03-12 07:58:44.566179+00
177a34dd-e37e-460b-9ff3-b282ad00e30a	driver	Driver app access only	t	2026-03-12 07:58:44.566179+00	2026-03-12 07:58:44.566179+00
\.


--
-- Data for Name: route_optimization_jobs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.route_optimization_jobs (id, request_id, status, worker_id, started_at, completed_at, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: route_optimization_requests; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.route_optimization_requests (id, organization_id, status, constraints, stops, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: route_optimization_results; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.route_optimization_results (id, request_id, routes, total_distance, total_duration, total_cost, created_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.schema_migrations (version, dirty) FROM stdin;
\.


--
-- Data for Name: schema_migrations_legacy; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.schema_migrations_legacy (version, applied_at) FROM stdin;
\.


--
-- Data for Name: security_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.security_events (id, user_id, event_type, ip_address, user_agent, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: service_accounts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.service_accounts (id, org_id, name, secret_hash, permissions, created_at) FROM stdin;
\.


--
-- Data for Name: signing_keys; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.signing_keys (kid, private_key_enc, public_key, status, algorithm, created_at, activated_at, expires_at) FROM stdin;
test-kid-1773302897	-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCclydTVpVSPi3H\nKNzmMyNhBp1ltG1Qu3hImrhjj8+0cv+8FVi45/8NvWtwN8U+GIwPgXXSQoJeR5wz\n+NCQozqs3ZN4tEtp21EPS/7qgTv4dEG5WHeanTpNnpKtg19uiAipY3cB60HUulkq\ndZsJJXs7UoDUcl5tALajUJ8RoA4KmZRP2coqXrKy79rn52DX8oYNg+JLqn0p1Wmj\nnn59mwp499BPwicSfSSrhO3MikIVBHfJWuK4BoSYGct73s3XP13g++zdZ5lHmIpu\n3fT6omziXA+ZBGUAmW5XlK1uIMCyuu5anj/uADyISuO2GsbvmVkJYOhlyXjKIOml\nfOTfLid3AgMBAAECggEADJpDsXrd8K0NbSJ2SNajycrI/yb6x00XPKyrG2Q3ILxC\npcYICnWtetMcYv8yEjHSj+ro6x+sM19LDInBa2qfrcr1c/j6us3KY9NHdGMrSu88\nXOjoU1rFFvskre9NTm2HWO6m5NIkzbSjuX2WmTFZjigxMyfzPo2YpWM3MilyB9s9\nLs/HsiES/M3KNOtbOuiro5T6KjShZZhmMgdoIpeZgNfkUblnD8ToZK9Qa+CLnVgi\ni/9LpiRFORWi3MIC+jQjDgP14y66OZ48HqT9aS8cZrnhmuVtlhIoN87bGSJxBTcd\nSOlZCMjhZSGM/zPElynI8y7rVO2XDVgXOuzL6pVzJQKBgQDMdqyc5tZibg0pSzLb\nAc31ZNAgbpZJUIPxw67SKTbHWpvqpAQ3YB/aAv9t/p3xk440QRTwoMdV8HFK/EmA\ns478FlU3g9Ro1V1zxIci8H9FCWAzRYtLgUzQYCEqW3ndmWUB3efxBVuOC+Yi0pH6\noZLF2zF0VFvF35LO6u0lbSYZhQKBgQDED2RvG0JeTT6SIHOTPmCgFLyBhWKnsSQM\nnXAQzEl3TAL47wy+cwDAQU0F7DX3pIp77I4WIaMlwXYsXg0l6Y/yo1xt/vQq30R+\nLEmRTydTV92uCLoW4Fu4yLt4ZUHaZ00dVjeVvWDLzP0+2aUB17oHctIee7mPiYBp\n8BIMgE6vywKBgCyN27VhE+xlANczvMQ+k2va6QN4NaWKNwZS1uCS/I3ab8lkrkqG\n1soCBzkn17ERr1YxrGd3EZjniTiG21mBRzIlh7JONtYVUITumWgCsikQDvd9Owpc\nBaoOmIuLXXXtfDY47db2jOnaK+8ApbDQzpPw3Mj1rP3kZzBRvxV9wGSlAoGBAMJ1\nqd3xoZA6+TaibT+7/MaKCrZEgCdnMSQ5+28N0Eg84i3ZnEBBfJszqZuYP6bSUnC7\nneohjtnh2r4CwvO5hwbYNNL8r1zeeebTMlynr4+gdMUq7rfF6/OJVTgC5qAjGX9h\nhlxEq384YG44HMuJFoBQyEtn2BKgBPgOHzi7AlClAoGBAJRrhSOdt4jSnQ729Hr0\nx5waDDO6aIRCURk1VAgHSJntd6luBvmIYYm9TpUKhgadKUl7vdJnGyGQv5NOnr87\nK/NGDpOHOExJDeI2DWnPAuOwyhEei53eQJEUtBGGV9mwVyYOJ3Bom/rLlZA11I4H\n6vsYlotN0cGQmZMd1J5JEFhg\n-----END PRIVATE KEY-----	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnJcnU1aVUj4txyjc5jMj\nYQadZbRtULt4SJq4Y4/PtHL/vBVYuOf/Db1rcDfFPhiMD4F10kKCXkecM/jQkKM6\nrN2TeLRLadtRD0v+6oE7+HRBuVh3mp06TZ6SrYNfbogIqWN3AetB1LpZKnWbCSV7\nO1KA1HJebQC2o1CfEaAOCpmUT9nKKl6ysu/a5+dg1/KGDYPiS6p9KdVpo55+fZsK\nePfQT8InEn0kq4TtzIpCFQR3yVriuAaEmBnLe97N1z9d4Pvs3WeZR5iKbt30+qJs\n4lwPmQRlAJluV5StbiDAsrruWp4/7gA8iErjthrG75lZCWDoZcl4yiDppXzk3y4n\ndwIDAQAB\n-----END PUBLIC KEY-----	active	RS256	2026-03-12 08:08:17.942634+00	2026-03-12 08:08:17.942634+00	\N
\.


--
-- Data for Name: sla_metrics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.sla_metrics ("time", org_id, metric_name, value, metadata) FROM stdin;
\.


--
-- Data for Name: storage_pools; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.storage_pools (id, name, status, total_bytes, used_bytes, available_bytes, location, backup_count, created_at, updated_at) FROM stdin;
a1b2c3d4-0001-0001-0001-000000000001	Primary Storage	ACTIVE	1073741824000	375809638400	697932185600	us-east-1	24	2025-12-12 07:58:47.79385+00	2026-03-12 07:58:47.79385+00
a1b2c3d4-0002-0002-0002-000000000002	DR Storage	ACTIVE	2147483648000	858993459200	1288490188800	us-west-2	48	2025-09-13 07:58:47.79385+00	2026-03-12 07:58:47.79385+00
a1b2c3d4-0003-0003-0003-000000000003	Archive Storage	WARNING	5368709120000	4509715660800	858993459200	eu-central-1	120	2025-03-12 07:58:47.79385+00	2026-03-11 07:58:47.79385+00
\.


--
-- Data for Name: support_audit_log; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.support_audit_log (id, ticket_id, user_id, action, old_value, new_value, details, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.support_tickets (id, ticket_id, org_id, title, description, status, priority, category, assigned_to, reporter_id, created_at, updated_at, resolved_at, sla_deadline, tags, metadata) FROM stdin;
\.


--
-- Data for Name: telemetry; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry (id, trip_id, latitude, longitude, speed, heading, event_type, event_time) FROM stdin;
\.


--
-- Data for Name: telemetry_analytics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_analytics (id, vehicle_id, analysis_type, data, "timestamp", confidence) FROM stdin;
\.


--
-- Data for Name: telemetry_anomalies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_anomalies (id, vehicle_id, anomaly_type, data, "timestamp", confidence, anomaly_score, recommendation) FROM stdin;
\.


--
-- Data for Name: threat_alerts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.threat_alerts (id, org_id, type, severity, ip, user_id, description, status, created_at) FROM stdin;
\.


--
-- Data for Name: trip_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.trip_settings (id, organization_id, retention_period, policies, updated_at) FROM stdin;
\.


--
-- Data for Name: trips; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.trips (id, org_id, vehicle_id, driver_id, status, title, description, planned_route, actual_route, waypoints, start_location, end_location, estimated_distance_km, actual_distance_km, estimated_duration_min, actual_duration_min, fuel_consumed_liters, idling_time_minutes, cargo_details, pod_documents, scheduled_start, started_at, ended_at, customer_name, customer_phone, customer_email, cancellation_reason, events, is_deleted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: usage_meters; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.usage_meters (id, code, name, description, unit, unit_price, currency, status, created_at) FROM stdin;
452778d0-6099-4212-8576-8f2ad1ac8d8e	DISTANCE_KM	Mileage	\N	km	0.1500	USD	active	2026-03-12 07:58:48.820966+00
15a2aa06-aadb-44ea-86c6-afff212842dd	HEARTBEAT_COUNT	Device Connectivity	\N	count	0.0100	USD	active	2026-03-12 07:58:48.820966+00
\.


--
-- Data for Name: user_notification_preferences; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.user_notification_preferences (id, user_id, email_enabled, sms_enabled, push_enabled, in_app_enabled, last_modified_by, last_modified_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_organizations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.user_organizations (id, user_id, org_id, role, status, created_at) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.user_sessions (id, user_id, session_id, ip_address, user_agent, device_info, login_time, last_activity, logout_time, is_active, location) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.users (id, email, password_hash, name, phone, mfa_enabled, mfa_secret, status, created_at, updated_at, theme_updated_at, is_deleted, role_id, org_id, last_password_change, created_by, updated_by, mfa_methods, role, failed_login_attempts, locked_until, last_login_at, data_retention_until) FROM stdin;
e90b8c07-9b4d-433b-b729-353e85821458	prodtest_1773312955@flyfleet.io	$argon2id$v=19$m=65536,t=3,p=4$ao+CPKsVZ3l4b4AfvXWSrw$T0wiBZJoqqL/98lm3dxnhN9BTF2pQxFbYgYAGII0mA0	\N	\N	f	\N	active	2026-03-12 10:55:55.934669+00	2026-03-12 10:55:56.0034+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 10:55:55.934669+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	0	\N	\N	\N
b5e6783b-a4a3-484d-8d1a-19eb1df19fcf	rate1@test.com	$argon2id$v=19$m=65536,t=3,p=4$va+qdZjmo4K+qRkQ4Zrsbg$d74v/+4X89eE+gyKOVomsvvO26pu6RA8JWauRNYC9f4	\N	\N	f	\N	active	2026-03-12 10:06:47.573943+00	2026-03-12 10:06:47.573943+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 10:06:47.573943+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	0	\N	\N	\N
fac04963-e543-4af2-8430-7d337f39792d	rate2@test.com	$argon2id$v=19$m=65536,t=3,p=4$1OASIys4vjgYA8U7d5FIDA$5m5Uqf3d2/YL6rXLEJ8PNKh23Ow9FHS+wzXTMD3fG0U	\N	\N	f	\N	active	2026-03-12 10:06:47.723887+00	2026-03-12 10:06:47.723887+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 10:06:47.723887+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	0	\N	\N	\N
5972883f-1488-487a-ad0e-bb37ac03cca4	rate3@test.com	$argon2id$v=19$m=65536,t=3,p=4$ivP96q96fkLko+qtHmTmOQ$nPt1nHZWB2rXdwEwE238eB01bWoNFChXjetPYMBmRy4	\N	\N	f	\N	active	2026-03-12 10:06:47.880177+00	2026-03-12 10:06:47.880177+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 10:06:47.880177+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	0	\N	\N	\N
eb0577b3-b8fa-4ae2-b552-d87fb5ad42ac	rate4@test.com	$argon2id$v=19$m=65536,t=3,p=4$KXAhA8AuDxGPhvDMf1vbAA$Uxl3ldQmmbm25kzWhmtKE12gJBdDCjweZcxu/8D/MSA	\N	\N	f	\N	active	2026-03-12 10:06:48.0635+00	2026-03-12 10:06:48.0635+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 10:06:48.0635+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	0	\N	\N	\N
4a665e5c-e5e9-4d05-8a72-d38a40a5e91b	test-e2e@flyfleet.io	$argon2id$v=19$m=65536,t=3,p=4$zX9bCuAttgtKa5o89+tl0g$aOJYmvYMSw5181JLUYm6XCh92HdlpXLxGtQqajBcq8I	\N	\N	f	\N	active	2026-03-12 15:31:01.872462+00	2026-03-12 15:31:40.671703+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 15:31:01.872462+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	0	\N	\N	\N
6f7ab3a1-2cb2-448f-a7c6-ca273783156c	audit_user_final@flyfleet.test	$argon2id$v=19$m=65536,t=3,p=4$dOPDFU0s/yc1CRE41VJsbQ$0B7Rkk6Vy5i4fi2BoQXUdiGxYN1ZnSBd29MwroEkzGw	\N	\N	f	\N	active	2026-03-12 10:19:07.148796+00	2026-03-12 10:19:07.148796+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 10:19:07.148796+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	0	\N	\N	\N
ff72131a-5e00-404e-805a-8c55e5175a6e	bruteforce_1773312956@flyfleet.io	$argon2id$v=19$m=65536,t=3,p=4$ckAgDZpROwBm4IpAMaRYLg$uA7SVJ6TXgGmN8ZJEXrMJvbp6twrR3vps7RMQHpv0dM	\N	\N	f	\N	active	2026-03-12 10:55:56.090806+00	2026-03-12 10:55:56.333196+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 10:55:56.090806+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	5	2026-03-12 11:10:56.333062+00	\N	\N
c8f8501c-aa74-45bf-b0b4-ba7c0fe5de0b	test_reg_unique_1@flyfleet.test	$argon2id$v=19$m=65536,t=3,p=4$4PFtD2Agcqt6iyh7LX35hA$/aQ4ZI/9hN7QrlSw8nqbcZGEilxf8/CYZRGywU1FABo	\N	\N	f	\N	active	2026-03-12 10:20:38.415067+00	2026-03-12 10:20:38.415067+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 10:20:38.415067+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	0	\N	\N	\N
325bfc40-9a03-40b8-af1b-0534474bc47b	rate_audit_20_final@flyfleet.test	$argon2id$v=19$m=65536,t=3,p=4$7x3g+fZVZV1CxmHtmKgI4Q$uhYxmSkqXRWaNATkK+y1akHMxVqFRGzpsiLAeKTwZqo	\N	\N	f	\N	active	2026-03-12 10:21:17.337489+00	2026-03-12 10:21:17.337489+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 10:21:17.337489+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	0	\N	\N	\N
669091a5-8fa5-480b-acd5-552f4a273cb4	testadmin4@flyfleet.test	$argon2id$v=19$m=65536,t=3,p=4$su7hpth3NCRMSM7MqhWobQ$I6XaMNXkFKJN9XYV55xWzpFfbVaZKRjWcVM4AYDd3LE	\N	\N	f	\N	active	2026-03-12 08:15:54.050694+00	2026-03-12 09:09:58.671741+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 08:15:54.050694+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	5	2026-03-12 09:24:58.671426+00	\N	\N
0d7cc368-cedd-48ce-8450-0579776a7454	rate_audit_21_final@flyfleet.test	$argon2id$v=19$m=65536,t=3,p=4$yDrw0aoj2BNFrBzIwuv2HQ$uOxsYZpJTvmzk+jnLGW4nb3yvrmzYRgFluvsvbNHfl4	\N	\N	f	\N	active	2026-03-12 10:21:17.381028+00	2026-03-12 10:21:17.381028+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 10:21:17.381028+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	0	\N	\N	\N
4ecfb772-ccd7-42ab-aebd-d4a80e4407b5	brutetest@flyfleet.test	$argon2id$v=19$m=65536,t=3,p=4$83tYmq3Iyq4A+xrR26NvMg$2PxqFOxf+BWOa3Dt0VhkkGJy98IlZ783SrrQhgd0KEo	\N	\N	f	MGBAHR57F42E6ADWTO2X5XL443N3T7OL	active	2026-03-12 09:23:34.870032+00	2026-03-12 11:26:46.919451+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 09:23:34.870032+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	5	2026-03-12 09:49:59.350037+00	\N	\N
58df7342-d4f9-4dd1-abc8-065351887b4d	rate_audit_22_final@flyfleet.test	$argon2id$v=19$m=65536,t=3,p=4$+VZhkLDYOP9RIuzOLjnotg$vrJHjbas+uTfagHzO9P4rl0AA21h7gEsnHe6dftKamU	\N	\N	f	\N	active	2026-03-12 10:21:17.445046+00	2026-03-12 10:21:17.445046+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 10:21:17.445046+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	0	\N	\N	\N
c2454d31-d276-458f-9b0d-c44380357fb0	rate_audit_23_final@flyfleet.test	$argon2id$v=19$m=65536,t=3,p=4$+kYKu5c4p8ANxgZ9Fdy5yA$m8AHg+BeRZMgXi09lHpV+zQy6lCQUdX7cDNik/xVzlU	\N	\N	f	\N	active	2026-03-12 10:21:17.512331+00	2026-03-12 10:21:17.512331+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 10:21:17.512331+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	0	\N	\N	\N
784b7f16-5f8f-4b73-8eb1-933f85a390c2	rate_audit_24_final@flyfleet.test	$argon2id$v=19$m=65536,t=3,p=4$PJo+ekYy2oLSfzBDn41duQ$FricSF3eivTW1U6nS1fPSidCg3Dy7vsTo12F3snq8gY	\N	\N	f	\N	active	2026-03-12 10:21:17.552221+00	2026-03-12 10:21:17.552221+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 10:21:17.552221+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	0	\N	\N	\N
7b5717ac-e87c-4684-9227-23ffb3f186e9	rate_audit_25_final@flyfleet.test	$argon2id$v=19$m=65536,t=3,p=4$fgn6S3Nave58lppmt8sVcw$zrLf7eESAvDKmI4j59y80ajAhb+WXHea3trJ5VtBVMQ	\N	\N	f	\N	active	2026-03-12 10:21:17.596594+00	2026-03-12 10:21:17.596594+00	\N	f	\N	00000000-0000-0000-0000-000000000000	2026-03-12 10:21:17.596594+00	00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000000	{}	user	0	\N	\N	\N
\.


--
-- Data for Name: vehicle_inspections; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicle_inspections (id, organization_id, vehicle_id, template_id, inspector_id, status, results, notes, odometer_at_inspection, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: vehicle_telemetry; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicle_telemetry ("time", vehicle_id, latitude, longitude, speed_kph, heading, odometer_km, fuel_level_percent, engine_temp_celsius, alerts) FROM stdin;
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicles (id, org_id, license_plate, model, make, year, color, status, capacity, fuel_type, vin, registration, insurance, odometer, last_service, current_driver_id, created_at, updated_at, deleted_at, vehicle_no, service_due, notes, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: video_analytics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.video_analytics (id, recording_id, stream_id, objects_detected, behavior_events, traffic_signs, incidents, "timestamp", confidence, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: video_recordings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.video_recordings (id, stream_id, camera_id, vehicle_id, driver_id, organization_id, filename, filepath, file_size, duration, resolution, framerate, bitrate, start_time, end_time, location_start, location_end, status, thumbnail_path, tags, event_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: video_retention_policies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.video_retention_policies (id, organization_id, name, description, event_type, retention_period, auto_archive, auto_delete, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: video_streams; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.video_streams (id, camera_id, vehicle_id, driver_id, organization_id, url, status, resolution, framerate, bitrate, protocol, location, started_at, ended_at, created_at, updated_at, analytics_enabled) FROM stdin;
\.


--
-- Data for Name: video_thumbnails; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.video_thumbnails (id, recording_id, image_path, image_url, "timestamp", created_at) FROM stdin;
\.


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.webhooks (id, org_id, url, events, secret, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: work_orders; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.work_orders (id, organization_id, vehicle_id, title, description, maintenance_type, priority, status, assigned_to, scheduled_date, completed_date, estimated_cost, actual_cost, created_by, created_at, updated_at, vendor_id, approval_status, cost_breakdown, inspection_id, updated_by) FROM stdin;
\.


--
-- Name: bgw_job_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.bgw_job_id_seq', 1001, true);


--
-- Name: chunk_column_stats_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_column_stats_id_seq', 1, false);


--
-- Name: chunk_constraint_name; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_constraint_name', 1, false);


--
-- Name: chunk_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_id_seq', 1, false);


--
-- Name: continuous_agg_migrate_plan_step_step_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.continuous_agg_migrate_plan_step_step_id_seq', 1, false);


--
-- Name: dimension_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_id_seq', 7, true);


--
-- Name: dimension_slice_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_slice_id_seq', 1, false);


--
-- Name: hypertable_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.hypertable_id_seq', 7, true);


--
-- Name: access_reviews access_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.access_reviews
    ADD CONSTRAINT access_reviews_pkey PRIMARY KEY (id);


--
-- Name: alert_rules alert_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alert_rules
    ADD CONSTRAINT alert_rules_pkey PRIMARY KEY (id);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: analytics_jobs analytics_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.analytics_jobs
    ADD CONSTRAINT analytics_jobs_pkey PRIMARY KEY (id);


--
-- Name: api_clients api_clients_client_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT api_clients_client_id_key UNIQUE (client_id);


--
-- Name: api_clients api_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT api_clients_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: audit_policies audit_policies_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_org_id_key UNIQUE (org_id);


--
-- Name: audit_policies audit_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_pkey PRIMARY KEY (id);


--
-- Name: audit_settings audit_settings_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_settings
    ADD CONSTRAINT audit_settings_org_id_key UNIQUE (org_id);


--
-- Name: audit_settings audit_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_settings
    ADD CONSTRAINT audit_settings_pkey PRIMARY KEY (id);


--
-- Name: auth_audit_logs auth_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.auth_audit_logs
    ADD CONSTRAINT auth_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: auth_tokens auth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_pkey PRIMARY KEY (id);


--
-- Name: backup_verifications backup_verifications_backup_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backup_verifications
    ADD CONSTRAINT backup_verifications_backup_id_key UNIQUE (backup_id);


--
-- Name: backup_verifications backup_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backup_verifications
    ADD CONSTRAINT backup_verifications_pkey PRIMARY KEY (id);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: billing_accounting_exports billing_accounting_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_accounting_exports
    ADD CONSTRAINT billing_accounting_exports_pkey PRIMARY KEY (id);


--
-- Name: billing_coupons billing_coupons_code_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_coupons
    ADD CONSTRAINT billing_coupons_code_key UNIQUE (code);


--
-- Name: billing_coupons billing_coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_coupons
    ADD CONSTRAINT billing_coupons_pkey PRIMARY KEY (id);


--
-- Name: billing_credit_transactions billing_credit_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_credit_transactions
    ADD CONSTRAINT billing_credit_transactions_pkey PRIMARY KEY (id);


--
-- Name: billing_customer_balances billing_customer_balances_org_id_currency_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_customer_balances
    ADD CONSTRAINT billing_customer_balances_org_id_currency_key UNIQUE (org_id, currency);


--
-- Name: billing_customer_balances billing_customer_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_customer_balances
    ADD CONSTRAINT billing_customer_balances_pkey PRIMARY KEY (id);


--
-- Name: billing_hardware_products billing_hardware_products_model_code_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_hardware_products
    ADD CONSTRAINT billing_hardware_products_model_code_key UNIQUE (model_code);


--
-- Name: billing_hardware_products billing_hardware_products_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_hardware_products
    ADD CONSTRAINT billing_hardware_products_pkey PRIMARY KEY (id);


--
-- Name: billing_invoice_documents billing_invoice_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_invoice_documents
    ADD CONSTRAINT billing_invoice_documents_pkey PRIMARY KEY (id);


--
-- Name: billing_invoice_sequences billing_invoice_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_invoice_sequences
    ADD CONSTRAINT billing_invoice_sequences_pkey PRIMARY KEY (org_id);


--
-- Name: billing_invoice_templates billing_invoice_templates_name_version_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_invoice_templates
    ADD CONSTRAINT billing_invoice_templates_name_version_key UNIQUE (name, version);


--
-- Name: billing_invoice_templates billing_invoice_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_invoice_templates
    ADD CONSTRAINT billing_invoice_templates_pkey PRIMARY KEY (id);


--
-- Name: billing_plans billing_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_plans
    ADD CONSTRAINT billing_plans_pkey PRIMARY KEY (id);


--
-- Name: billing_pricing_components billing_pricing_components_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_pricing_components
    ADD CONSTRAINT billing_pricing_components_pkey PRIMARY KEY (id);


--
-- Name: billing_recognized_revenue billing_recognized_revenue_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_recognized_revenue
    ADD CONSTRAINT billing_recognized_revenue_pkey PRIMARY KEY (id);


--
-- Name: billing_revenue_schedules billing_revenue_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_revenue_schedules
    ADD CONSTRAINT billing_revenue_schedules_pkey PRIMARY KEY (id);


--
-- Name: billing_settings billing_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_settings
    ADD CONSTRAINT billing_settings_pkey PRIMARY KEY (org_id);


--
-- Name: billing_subscriptions billing_subscriptions_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_subscriptions
    ADD CONSTRAINT billing_subscriptions_org_id_key UNIQUE (org_id);


--
-- Name: billing_subscriptions billing_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_subscriptions
    ADD CONSTRAINT billing_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: billing_tax_rates billing_tax_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_tax_rates
    ADD CONSTRAINT billing_tax_rates_pkey PRIMARY KEY (id);


--
-- Name: billing_tax_regions billing_tax_regions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_tax_regions
    ADD CONSTRAINT billing_tax_regions_pkey PRIMARY KEY (id);


--
-- Name: blocked_ips blocked_ips_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.blocked_ips
    ADD CONSTRAINT blocked_ips_pkey PRIMARY KEY (ip_address);


--
-- Name: bulk_config bulk_config_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_config
    ADD CONSTRAINT bulk_config_pkey PRIMARY KEY (organization_id);


--
-- Name: bulk_job_records bulk_job_records_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_job_records
    ADD CONSTRAINT bulk_job_records_pkey PRIMARY KEY (id);


--
-- Name: bulk_jobs bulk_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_jobs
    ADD CONSTRAINT bulk_jobs_pkey PRIMARY KEY (id);


--
-- Name: devices devices_device_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_device_id_key UNIQUE (device_id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: dr_test_logs dr_test_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_test_logs
    ADD CONSTRAINT dr_test_logs_pkey PRIMARY KEY (id);


--
-- Name: dr_test_settings dr_test_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_test_settings
    ADD CONSTRAINT dr_test_settings_pkey PRIMARY KEY (id);


--
-- Name: dr_test_steps dr_test_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_test_steps
    ADD CONSTRAINT dr_test_steps_pkey PRIMARY KEY (id);


--
-- Name: dr_tests dr_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_tests
    ADD CONSTRAINT dr_tests_pkey PRIMARY KEY (id);


--
-- Name: dr_tests dr_tests_test_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_tests
    ADD CONSTRAINT dr_tests_test_id_key UNIQUE (test_id);


--
-- Name: driver_behavior_analytics driver_behavior_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_behavior_analytics
    ADD CONSTRAINT driver_behavior_analytics_pkey PRIMARY KEY (id);


--
-- Name: driver_behavior driver_behavior_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_behavior
    ADD CONSTRAINT driver_behavior_pkey PRIMARY KEY (id);


--
-- Name: driver_incidents driver_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_incidents
    ADD CONSTRAINT driver_incidents_pkey PRIMARY KEY (id);


--
-- Name: drivers drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_token_key UNIQUE (token);


--
-- Name: entity_audit_history entity_audit_history_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.entity_audit_history
    ADD CONSTRAINT entity_audit_history_pkey PRIMARY KEY (id);


--
-- Name: evidence_exports evidence_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.evidence_exports
    ADD CONSTRAINT evidence_exports_pkey PRIMARY KEY (id);


--
-- Name: firmware_packages firmware_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_packages
    ADD CONSTRAINT firmware_packages_pkey PRIMARY KEY (id);


--
-- Name: firmware_rollout_events firmware_rollout_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollout_events
    ADD CONSTRAINT firmware_rollout_events_pkey PRIMARY KEY (id);


--
-- Name: firmware_rollouts firmware_rollouts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_pkey PRIMARY KEY (id);


--
-- Name: fleet_analytics fleet_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fleet_analytics
    ADD CONSTRAINT fleet_analytics_pkey PRIMARY KEY (id);


--
-- Name: geofences geofences_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofences
    ADD CONSTRAINT geofences_pkey PRIMARY KEY (id);


--
-- Name: global_notification_defaults global_notification_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.global_notification_defaults
    ADD CONSTRAINT global_notification_defaults_pkey PRIMARY KEY (id);


--
-- Name: gps_locations gps_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.gps_locations
    ADD CONSTRAINT gps_locations_pkey PRIMARY KEY ("time", vehicle_id);


--
-- Name: incident_comments incident_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_comments
    ADD CONSTRAINT incident_comments_pkey PRIMARY KEY (id);


--
-- Name: inspection_templates inspection_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.inspection_templates
    ADD CONSTRAINT inspection_templates_pkey PRIMARY KEY (id);


--
-- Name: integration_logs integration_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: ip_rules ip_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.ip_rules
    ADD CONSTRAINT ip_rules_pkey PRIMARY KEY (id);


--
-- Name: login_events login_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.login_events
    ADD CONSTRAINT login_events_pkey PRIMARY KEY (id);


--
-- Name: login_history login_history_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_pkey PRIMARY KEY (id);


--
-- Name: maintenance_vendors maintenance_vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.maintenance_vendors
    ADD CONSTRAINT maintenance_vendors_pkey PRIMARY KEY (id);


--
-- Name: mfa_codes mfa_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_codes
    ADD CONSTRAINT mfa_codes_pkey PRIMARY KEY (id);


--
-- Name: mfa_events mfa_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_events
    ADD CONSTRAINT mfa_events_pkey PRIMARY KEY (id);


--
-- Name: mfa_exceptions mfa_exceptions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_pkey PRIMARY KEY (id);


--
-- Name: mfa_failures mfa_failures_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_failures
    ADD CONSTRAINT mfa_failures_pkey PRIMARY KEY (id);


--
-- Name: mfa_lockouts mfa_lockouts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_pkey PRIMARY KEY (id);


--
-- Name: mfa_org_overrides mfa_org_overrides_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_org_overrides
    ADD CONSTRAINT mfa_org_overrides_org_id_key UNIQUE (org_id);


--
-- Name: mfa_org_overrides mfa_org_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_org_overrides
    ADD CONSTRAINT mfa_org_overrides_pkey PRIMARY KEY (id);


--
-- Name: mfa_policies mfa_policies_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policies
    ADD CONSTRAINT mfa_policies_org_id_key UNIQUE (org_id);


--
-- Name: mfa_policies mfa_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policies
    ADD CONSTRAINT mfa_policies_pkey PRIMARY KEY (id);


--
-- Name: mfa_policy_history mfa_policy_history_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policy_history
    ADD CONSTRAINT mfa_policy_history_pkey PRIMARY KEY (id);


--
-- Name: mfa_recovery_codes mfa_recovery_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_recovery_codes
    ADD CONSTRAINT mfa_recovery_codes_pkey PRIMARY KEY (id);


--
-- Name: mfa_users mfa_users_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_users
    ADD CONSTRAINT mfa_users_pkey PRIMARY KEY (user_id);


--
-- Name: notification_events notification_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_events
    ADD CONSTRAINT notification_events_pkey PRIMARY KEY (id);


--
-- Name: notification_logs notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_pkey PRIMARY KEY (id);


--
-- Name: notification_preference_audit notification_preference_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_preference_audit
    ADD CONSTRAINT notification_preference_audit_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_channel_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_channel_key UNIQUE (channel);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_client_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.oauth_clients
    ADD CONSTRAINT oauth_clients_client_id_key UNIQUE (client_id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: obd_readings obd_readings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.obd_readings
    ADD CONSTRAINT obd_readings_pkey PRIMARY KEY ("time", vehicle_id);


--
-- Name: org_support_metrics org_support_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.org_support_metrics
    ADD CONSTRAINT org_support_metrics_pkey PRIMARY KEY (org_id);


--
-- Name: organization_memberships organization_memberships_org_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organization_memberships
    ADD CONSTRAINT organization_memberships_org_id_user_id_key UNIQUE (org_id, user_id);


--
-- Name: organization_memberships organization_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organization_memberships
    ADD CONSTRAINT organization_memberships_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_domain_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_domain_key UNIQUE (domain);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_role_id_resource_action_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_role_id_resource_action_key UNIQUE (role_id, resource, action);


--
-- Name: prediction_results prediction_results_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.prediction_results
    ADD CONSTRAINT prediction_results_pkey PRIMARY KEY (id);


--
-- Name: predictive_maintenance_analytics predictive_maintenance_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.predictive_maintenance_analytics
    ADD CONSTRAINT predictive_maintenance_analytics_pkey PRIMARY KEY (id);


--
-- Name: predictive_models predictive_models_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.predictive_models
    ADD CONSTRAINT predictive_models_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_key UNIQUE (token);


--
-- Name: restore_jobs restore_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.restore_jobs
    ADD CONSTRAINT restore_jobs_pkey PRIMARY KEY (id);


--
-- Name: review_items review_items_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: route_optimization_jobs route_optimization_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_jobs
    ADD CONSTRAINT route_optimization_jobs_pkey PRIMARY KEY (id);


--
-- Name: route_optimization_requests route_optimization_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_requests
    ADD CONSTRAINT route_optimization_requests_pkey PRIMARY KEY (id);


--
-- Name: route_optimization_results route_optimization_results_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_results
    ADD CONSTRAINT route_optimization_results_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations_legacy schema_migrations_legacy_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.schema_migrations_legacy
    ADD CONSTRAINT schema_migrations_legacy_pkey PRIMARY KEY (version);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);


--
-- Name: service_accounts service_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.service_accounts
    ADD CONSTRAINT service_accounts_pkey PRIMARY KEY (id);


--
-- Name: signing_keys signing_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.signing_keys
    ADD CONSTRAINT signing_keys_pkey PRIMARY KEY (kid);


--
-- Name: storage_pools storage_pools_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.storage_pools
    ADD CONSTRAINT storage_pools_pkey PRIMARY KEY (id);


--
-- Name: support_audit_log support_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_audit_log
    ADD CONSTRAINT support_audit_log_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_ticket_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_ticket_id_key UNIQUE (ticket_id);


--
-- Name: telemetry_analytics telemetry_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_analytics
    ADD CONSTRAINT telemetry_analytics_pkey PRIMARY KEY (id);


--
-- Name: telemetry_anomalies telemetry_anomalies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_anomalies
    ADD CONSTRAINT telemetry_anomalies_pkey PRIMARY KEY (id);


--
-- Name: telemetry telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry
    ADD CONSTRAINT telemetry_pkey PRIMARY KEY (id);


--
-- Name: threat_alerts threat_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.threat_alerts
    ADD CONSTRAINT threat_alerts_pkey PRIMARY KEY (id);


--
-- Name: trip_settings trip_settings_organization_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trip_settings
    ADD CONSTRAINT trip_settings_organization_id_key UNIQUE (organization_id);


--
-- Name: trip_settings trip_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trip_settings
    ADD CONSTRAINT trip_settings_pkey PRIMARY KEY (id);


--
-- Name: trips trips_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_pkey PRIMARY KEY (id);


--
-- Name: maintenance_vendors unique_vendor_per_org; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.maintenance_vendors
    ADD CONSTRAINT unique_vendor_per_org UNIQUE (organization_id, name);


--
-- Name: usage_meters usage_meters_code_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.usage_meters
    ADD CONSTRAINT usage_meters_code_key UNIQUE (code);


--
-- Name: usage_meters usage_meters_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.usage_meters
    ADD CONSTRAINT usage_meters_pkey PRIMARY KEY (id);


--
-- Name: user_notification_preferences user_notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_notification_preferences user_notification_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_user_id_key UNIQUE (user_id);


--
-- Name: user_organizations user_organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_pkey PRIMARY KEY (id);


--
-- Name: user_organizations user_organizations_user_id_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_user_id_org_id_key UNIQUE (user_id, org_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_session_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_session_id_key UNIQUE (session_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vehicle_inspections vehicle_inspections_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_inspections
    ADD CONSTRAINT vehicle_inspections_pkey PRIMARY KEY (id);


--
-- Name: vehicle_telemetry vehicle_telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_telemetry
    ADD CONSTRAINT vehicle_telemetry_pkey PRIMARY KEY ("time", vehicle_id);


--
-- Name: vehicles vehicles_license_plate_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_license_plate_key UNIQUE (license_plate);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_vehicle_no_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_vehicle_no_key UNIQUE (vehicle_no);


--
-- Name: video_analytics video_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_analytics
    ADD CONSTRAINT video_analytics_pkey PRIMARY KEY (id);


--
-- Name: video_recordings video_recordings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_recordings
    ADD CONSTRAINT video_recordings_pkey PRIMARY KEY (id);


--
-- Name: video_retention_policies video_retention_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_retention_policies
    ADD CONSTRAINT video_retention_policies_pkey PRIMARY KEY (id);


--
-- Name: video_streams video_streams_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_streams
    ADD CONSTRAINT video_streams_pkey PRIMARY KEY (id);


--
-- Name: video_thumbnails video_thumbnails_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_thumbnails
    ADD CONSTRAINT video_thumbnails_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: work_orders work_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT work_orders_pkey PRIMARY KEY (id);


--
-- Name: consumption_events_time_idx; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX consumption_events_time_idx ON public.consumption_events USING btree ("time" DESC);


--
-- Name: gps_locations_time_idx; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX gps_locations_time_idx ON public.gps_locations USING btree ("time" DESC);


--
-- Name: idx_access_reviews_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_access_reviews_org ON public.access_reviews USING btree (org_id);


--
-- Name: idx_access_reviews_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_access_reviews_status ON public.access_reviews USING btree (org_id, status);


--
-- Name: idx_accounting_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_accounting_org_id ON public.billing_accounting_exports USING btree (org_id);


--
-- Name: idx_accounting_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_accounting_status ON public.billing_accounting_exports USING btree (status);


--
-- Name: idx_alerts_dedup_active; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_dedup_active ON public.alerts USING btree (dedup_key) WHERE ((status)::text = 'new'::text);


--
-- Name: idx_alerts_escalation_worker; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_escalation_worker ON public.alerts USING btree (status, sla_deadline) WHERE ((status)::text = 'new'::text);


--
-- Name: idx_alerts_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_org_id ON public.alerts USING btree (org_id);


--
-- Name: idx_alerts_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_status ON public.alerts USING btree (status);


--
-- Name: idx_alerts_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_timestamp ON public.alerts USING btree ("timestamp");


--
-- Name: idx_alerts_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_vehicle_id ON public.alerts USING btree (vehicle_id);


--
-- Name: idx_analytics_jobs_org_status_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_analytics_jobs_org_status_type ON public.analytics_jobs USING btree (organization_id, status, job_type);


--
-- Name: idx_api_clients_client_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_api_clients_client_id ON public.api_clients USING btree (client_id);


--
-- Name: idx_api_clients_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_api_clients_org ON public.api_clients USING btree (org_id);


--
-- Name: idx_api_keys_prefix; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_api_keys_prefix ON public.api_keys USING btree (prefix);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: idx_audit_logs_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_org_id ON public.audit_logs USING btree (org_id);


--
-- Name: idx_audit_logs_severity; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_severity ON public.audit_logs USING btree (severity);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_auth_tokens_refresh_token; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_auth_tokens_refresh_token ON public.auth_tokens USING btree (refresh_token);


--
-- Name: idx_auth_tokens_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_auth_tokens_user_id ON public.auth_tokens USING btree (user_id);


--
-- Name: idx_backup_verifications_backup_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_backup_verifications_backup_id ON public.backup_verifications USING btree (backup_id);


--
-- Name: idx_backup_verifications_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_backup_verifications_status ON public.backup_verifications USING btree (status);


--
-- Name: idx_backups_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_backups_created_at ON public.backups USING btree (created_at);


--
-- Name: idx_backups_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_backups_status ON public.backups USING btree (status);


--
-- Name: idx_behavior_driver_period; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_behavior_driver_period ON public.driver_behavior USING btree (driver_id, period_start);


--
-- Name: idx_billing_invoice_docs_snapshot; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_billing_invoice_docs_snapshot ON public.billing_invoice_documents USING gin (snapshot);


--
-- Name: idx_bulk_job_records_job_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_bulk_job_records_job_id ON public.bulk_job_records USING btree (job_id);


--
-- Name: idx_bulk_jobs_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_bulk_jobs_org ON public.bulk_jobs USING btree (organization_id);


--
-- Name: idx_bulk_jobs_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_bulk_jobs_status ON public.bulk_jobs USING btree (status);


--
-- Name: idx_components_plan_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_components_plan_id ON public.billing_pricing_components USING btree (plan_id);


--
-- Name: idx_consumption_aggregation; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_consumption_aggregation ON public.consumption_events USING btree (org_id, meter_code, "time" DESC) WHERE (processed_invoice_id IS NULL);


--
-- Name: idx_coupons_code; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_coupons_code ON public.billing_coupons USING btree (code);


--
-- Name: idx_credit_txn_balance_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_credit_txn_balance_id ON public.billing_credit_transactions USING btree (balance_id);


--
-- Name: idx_doc_invoice_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_doc_invoice_id ON public.billing_invoice_documents USING btree (invoice_id);


--
-- Name: idx_documents_expiry_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_expiry_date ON public.documents USING btree (expiry_date);


--
-- Name: idx_documents_org_expiry; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_org_expiry ON public.documents USING btree (org_id, expiry_date) WHERE ((deleted_at IS NULL) AND ((status)::text <> 'expired'::text));


--
-- Name: idx_documents_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_org_id ON public.documents USING btree (org_id);


--
-- Name: idx_documents_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_status ON public.documents USING btree (status);


--
-- Name: idx_documents_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_type ON public.documents USING btree (type);


--
-- Name: idx_documents_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_vehicle_id ON public.documents USING btree (vehicle_id);


--
-- Name: idx_documents_vehicle_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_vehicle_status ON public.documents USING btree (vehicle_id, status) WHERE (deleted_at IS NULL);


--
-- Name: idx_dr_test_logs_test_id_ts; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dr_test_logs_test_id_ts ON public.dr_test_logs USING btree (test_id, ts DESC);


--
-- Name: idx_dr_test_steps_test_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dr_test_steps_test_id ON public.dr_test_steps USING btree (test_id, step_order);


--
-- Name: idx_dr_tests_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dr_tests_created_at ON public.dr_tests USING btree (created_at DESC);


--
-- Name: idx_dr_tests_scheduled_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dr_tests_scheduled_at ON public.dr_tests USING btree (scheduled_at);


--
-- Name: idx_dr_tests_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dr_tests_status ON public.dr_tests USING btree (status);


--
-- Name: idx_driver_behavior_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_behavior_driver ON public.driver_behavior_analytics USING btree (driver_id, analysis_period_start, analysis_period_end);


--
-- Name: idx_driver_behavior_org_dates; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_behavior_org_dates ON public.driver_behavior_analytics USING btree (organization_id, analysis_period_start, analysis_period_end);


--
-- Name: idx_drivers_created_by; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_created_by ON public.drivers USING btree (created_by);


--
-- Name: idx_drivers_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_org_id ON public.drivers USING btree (org_id);


--
-- Name: idx_drivers_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_status ON public.drivers USING btree (status);


--
-- Name: idx_drivers_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_vehicle ON public.drivers USING btree (current_vehicle_id);


--
-- Name: idx_entity_history_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_entity_history_id ON public.entity_audit_history USING btree (entity_id);


--
-- Name: idx_entity_history_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_entity_history_type ON public.entity_audit_history USING btree (entity_type);


--
-- Name: idx_firmware_rollout_events_org_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_firmware_rollout_events_org_created ON public.firmware_rollout_events USING btree (org_id, created_at DESC);


--
-- Name: idx_firmware_rollout_events_rollout_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_firmware_rollout_events_rollout_created ON public.firmware_rollout_events USING btree (rollout_id, created_at DESC);


--
-- Name: idx_firmware_rollouts_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_firmware_rollouts_org ON public.firmware_rollouts USING btree (org_id);


--
-- Name: idx_firmware_rollouts_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_firmware_rollouts_status ON public.firmware_rollouts USING btree (status);


--
-- Name: idx_fleet_analytics_org_dates; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fleet_analytics_org_dates ON public.fleet_analytics USING btree (organization_id, start_date, end_date);


--
-- Name: idx_gps_locations_vehicle_time_desc; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gps_locations_vehicle_time_desc ON public.gps_locations USING btree (vehicle_id, "time" DESC);


--
-- Name: idx_gps_raw_data_gin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gps_raw_data_gin ON public.gps_locations USING gin (raw_data);


--
-- Name: idx_gps_vehicle_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gps_vehicle_time ON public.gps_locations USING btree (vehicle_id, "time" DESC);


--
-- Name: idx_gps_vehicle_time_brin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gps_vehicle_time_brin ON public.gps_locations USING brin (vehicle_id, "time");


--
-- Name: idx_incident_comments_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_incident_comments_created_at ON public.incident_comments USING btree (created_at);


--
-- Name: idx_incident_comments_ticket_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_incident_comments_ticket_id ON public.incident_comments USING btree (ticket_id);


--
-- Name: idx_incidents_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_incidents_driver ON public.driver_incidents USING btree (driver_id);


--
-- Name: idx_inspection_templates_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_inspection_templates_org ON public.inspection_templates USING btree (organization_id);


--
-- Name: idx_inspections_created_by; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_inspections_created_by ON public.vehicle_inspections USING btree (created_by);


--
-- Name: idx_integration_logs_integration; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_logs_integration ON public.integration_logs USING btree (integration_id);


--
-- Name: idx_integration_logs_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_logs_org ON public.integration_logs USING btree (org_id);


--
-- Name: idx_integration_logs_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_logs_timestamp ON public.integration_logs USING btree ("timestamp" DESC);


--
-- Name: idx_integrations_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integrations_org ON public.integrations USING btree (org_id);


--
-- Name: idx_integrations_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integrations_status ON public.integrations USING btree (status);


--
-- Name: idx_invoice_items_invoice_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_items_invoice_id ON public.invoice_items USING btree (invoice_id);


--
-- Name: idx_invoice_items_org_deleted; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_items_org_deleted ON public.invoice_items USING btree (org_id, is_deleted);


--
-- Name: idx_invoices_org_deleted; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoices_org_deleted ON public.invoices USING btree (org_id, is_deleted);


--
-- Name: idx_invoices_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoices_org_id ON public.invoices USING btree (org_id);


--
-- Name: idx_ip_rules_action; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_ip_rules_action ON public.ip_rules USING btree (org_id, action);


--
-- Name: idx_ip_rules_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_ip_rules_org ON public.ip_rules USING btree (org_id);


--
-- Name: idx_login_events_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_login_events_created_at ON public.login_events USING btree (created_at);


--
-- Name: idx_login_events_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_login_events_org_id ON public.login_events USING btree (org_id);


--
-- Name: idx_login_events_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_login_events_status ON public.login_events USING btree (status);


--
-- Name: idx_login_events_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_login_events_user_id ON public.login_events USING btree (user_id);


--
-- Name: idx_maintenance_vendors_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_maintenance_vendors_org ON public.maintenance_vendors USING btree (organization_id);


--
-- Name: idx_mfa_codes_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_codes_user_id ON public.mfa_codes USING btree (user_id);


--
-- Name: idx_mfa_events_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_events_created_at ON public.mfa_events USING btree (created_at);


--
-- Name: idx_mfa_events_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_events_org_id ON public.mfa_events USING btree (org_id);


--
-- Name: idx_mfa_events_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_events_user_id ON public.mfa_events USING btree (user_id);


--
-- Name: idx_mfa_exceptions_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_exceptions_user_id ON public.mfa_exceptions USING btree (user_id);


--
-- Name: idx_mfa_failures_location; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_failures_location ON public.mfa_failures USING btree (location);


--
-- Name: idx_mfa_failures_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_failures_user_id ON public.mfa_failures USING btree (user_id);


--
-- Name: idx_mfa_lockouts_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_lockouts_user_id ON public.mfa_lockouts USING btree (user_id);


--
-- Name: idx_mfa_org_overrides_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_org_overrides_org_id ON public.mfa_org_overrides USING btree (org_id);


--
-- Name: idx_mfa_policy_history_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_policy_history_org_id ON public.mfa_policy_history USING btree (org_id);


--
-- Name: idx_notification_events_notification_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_notification_events_notification_id ON public.notification_events USING btree (notification_id, created_at);


--
-- Name: idx_notification_logs_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_notification_logs_created_at ON public.notification_logs USING btree (created_at DESC);


--
-- Name: idx_notification_logs_status_channel; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_notification_logs_status_channel ON public.notification_logs USING btree (status, channel);


--
-- Name: idx_notification_pref_audit_user; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_notification_pref_audit_user ON public.notification_preference_audit USING btree (user_id, created_at DESC);


--
-- Name: idx_obd_dtcs_gin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_obd_dtcs_gin ON public.obd_readings USING gin (dtcs);


--
-- Name: idx_obd_raw_data_gin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_obd_raw_data_gin ON public.obd_readings USING gin (raw_data);


--
-- Name: idx_obd_vehicle_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_obd_vehicle_time ON public.obd_readings USING btree (vehicle_id, "time" DESC);


--
-- Name: idx_obd_vehicle_time_brin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_obd_vehicle_time_brin ON public.obd_readings USING brin (vehicle_id, "time");


--
-- Name: idx_password_reset_tokens_expires_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_password_reset_tokens_expires_at ON public.password_reset_tokens USING btree (expires_at);


--
-- Name: idx_password_reset_tokens_token; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_password_reset_tokens_token ON public.password_reset_tokens USING btree (token);


--
-- Name: idx_password_reset_tokens_used; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_password_reset_tokens_used ON public.password_reset_tokens USING btree (used);


--
-- Name: idx_password_reset_tokens_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_password_reset_tokens_user_id ON public.password_reset_tokens USING btree (user_id);


--
-- Name: idx_permissions_role_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_permissions_role_id ON public.permissions USING btree (role_id);


--
-- Name: idx_pred_maint_analysis_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_pred_maint_analysis_date ON public.predictive_maintenance_analytics USING btree (analysis_date);


--
-- Name: idx_pred_maint_org_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_pred_maint_org_vehicle ON public.predictive_maintenance_analytics USING btree (organization_id, vehicle_id);


--
-- Name: idx_prediction_results_anomaly; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_prediction_results_anomaly ON public.prediction_results USING btree (anomaly_detected, created_at);


--
-- Name: idx_prediction_results_model_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_prediction_results_model_created ON public.prediction_results USING btree (model_id, created_at);


--
-- Name: idx_prediction_results_org_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_prediction_results_org_created ON public.prediction_results USING btree (organization_id, created_at);


--
-- Name: idx_refresh_tokens_expires_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_refresh_tokens_expires_at ON public.refresh_tokens USING btree (expires_at);


--
-- Name: idx_refresh_tokens_revoked; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_refresh_tokens_revoked ON public.refresh_tokens USING btree (revoked);


--
-- Name: idx_refresh_tokens_token; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_refresh_tokens_token ON public.refresh_tokens USING btree (token);


--
-- Name: idx_refresh_tokens_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_refresh_tokens_user_id ON public.refresh_tokens USING btree (user_id);


--
-- Name: idx_restore_jobs_backup_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_restore_jobs_backup_id ON public.restore_jobs USING btree (backup_id);


--
-- Name: idx_restore_jobs_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_restore_jobs_status ON public.restore_jobs USING btree (status);


--
-- Name: idx_revenue_sch_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_revenue_sch_org ON public.billing_revenue_schedules USING btree (org_id);


--
-- Name: idx_review_items_review; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_review_items_review ON public.review_items USING btree (review_id);


--
-- Name: idx_review_items_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_review_items_status ON public.review_items USING btree (review_id, current_status);


--
-- Name: idx_review_items_user; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_review_items_user ON public.review_items USING btree (user_id);


--
-- Name: idx_route_opt_jobs_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_opt_jobs_status ON public.route_optimization_jobs USING btree (status);


--
-- Name: idx_route_opt_req_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_opt_req_org ON public.route_optimization_requests USING btree (organization_id);


--
-- Name: idx_route_opt_req_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_opt_req_status ON public.route_optimization_requests USING btree (status);


--
-- Name: idx_route_opt_res_req; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_opt_res_req ON public.route_optimization_results USING btree (request_id);


--
-- Name: idx_storage_pools_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_storage_pools_status ON public.storage_pools USING btree (status);


--
-- Name: idx_subs_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_subs_org_id ON public.billing_subscriptions USING btree (org_id);


--
-- Name: idx_subs_plan_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_subs_plan_id ON public.billing_subscriptions USING btree (plan_id);


--
-- Name: idx_support_audit_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_audit_created_at ON public.support_audit_log USING btree (created_at);


--
-- Name: idx_support_audit_ticket_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_audit_ticket_id ON public.support_audit_log USING btree (ticket_id);


--
-- Name: idx_support_tickets_assigned_to; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_assigned_to ON public.support_tickets USING btree (assigned_to);


--
-- Name: idx_support_tickets_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_created_at ON public.support_tickets USING btree (created_at);


--
-- Name: idx_support_tickets_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_org_id ON public.support_tickets USING btree (org_id);


--
-- Name: idx_support_tickets_priority; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_priority ON public.support_tickets USING btree (priority);


--
-- Name: idx_support_tickets_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_status ON public.support_tickets USING btree (status);


--
-- Name: idx_tax_rates_region; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_tax_rates_region ON public.billing_tax_rates USING btree (region_id);


--
-- Name: idx_telemetry_analytics_composite; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_analytics_composite ON public.telemetry_analytics USING btree (vehicle_id, analysis_type, "timestamp" DESC);


--
-- Name: idx_telemetry_analytics_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_analytics_timestamp ON public.telemetry_analytics USING btree ("timestamp");


--
-- Name: idx_telemetry_analytics_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_analytics_type ON public.telemetry_analytics USING btree (analysis_type);


--
-- Name: idx_telemetry_analytics_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_analytics_vehicle_id ON public.telemetry_analytics USING btree (vehicle_id);


--
-- Name: idx_telemetry_anomalies_composite; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_anomalies_composite ON public.telemetry_anomalies USING btree (vehicle_id, anomaly_type, "timestamp" DESC);


--
-- Name: idx_telemetry_anomalies_score; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_anomalies_score ON public.telemetry_anomalies USING btree (anomaly_score DESC);


--
-- Name: idx_telemetry_anomalies_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_anomalies_timestamp ON public.telemetry_anomalies USING btree ("timestamp");


--
-- Name: idx_telemetry_anomalies_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_anomalies_type ON public.telemetry_anomalies USING btree (anomaly_type);


--
-- Name: idx_telemetry_anomalies_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_anomalies_vehicle_id ON public.telemetry_anomalies USING btree (vehicle_id);


--
-- Name: idx_telemetry_event_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_event_time ON public.telemetry USING btree (event_time);


--
-- Name: idx_telemetry_trip_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_trip_id ON public.telemetry USING btree (trip_id);


--
-- Name: idx_template_name; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_template_name ON public.billing_invoice_templates USING btree (name);


--
-- Name: idx_threat_alerts_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_threat_alerts_org_id ON public.threat_alerts USING btree (org_id);


--
-- Name: idx_threat_alerts_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_threat_alerts_status ON public.threat_alerts USING btree (status);


--
-- Name: idx_trips_driver_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_driver_id ON public.trips USING btree (driver_id);


--
-- Name: idx_trips_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_org_id ON public.trips USING btree (org_id);


--
-- Name: idx_trips_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_status ON public.trips USING btree (status);


--
-- Name: idx_trips_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_vehicle_id ON public.trips USING btree (vehicle_id);


--
-- Name: idx_user_org_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_org_org_id ON public.user_organizations USING btree (org_id);


--
-- Name: idx_user_org_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_org_user_id ON public.user_organizations USING btree (user_id);


--
-- Name: idx_user_sessions_is_active; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_sessions_is_active ON public.user_sessions USING btree (is_active);


--
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: idx_users_locked_until; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_users_locked_until ON public.users USING btree (locked_until);


--
-- Name: idx_users_role_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_users_role_id ON public.users USING btree (role_id);


--
-- Name: idx_vehicle_inspections_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_inspections_vehicle ON public.vehicle_inspections USING btree (vehicle_id);


--
-- Name: idx_vehicle_telemetry_alerts_gin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_telemetry_alerts_gin ON public.vehicle_telemetry USING gin (alerts);


--
-- Name: idx_vehicle_telemetry_vehicle_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_telemetry_vehicle_time ON public.vehicle_telemetry USING btree (vehicle_id, "time" DESC);


--
-- Name: idx_vehicles_created_by; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_created_by ON public.vehicles USING btree (created_by);


--
-- Name: idx_vehicles_license; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_license ON public.vehicles USING btree (license_plate);


--
-- Name: idx_vehicles_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_org_id ON public.vehicles USING btree (org_id);


--
-- Name: idx_vehicles_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_status ON public.vehicles USING btree (status);


--
-- Name: idx_vehicles_vehicle_no; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_vehicle_no ON public.vehicles USING btree (vehicle_no);


--
-- Name: idx_vehicles_vin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_vin ON public.vehicles USING btree (vin);


--
-- Name: idx_video_analytics_recording_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_analytics_recording_id ON public.video_analytics USING btree (recording_id);


--
-- Name: idx_video_analytics_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_analytics_timestamp ON public.video_analytics USING btree ("timestamp");


--
-- Name: idx_video_recordings_start_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_start_time ON public.video_recordings USING btree (start_time);


--
-- Name: idx_video_recordings_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_status ON public.video_recordings USING btree (status);


--
-- Name: idx_video_recordings_stream_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_stream_id ON public.video_recordings USING btree (stream_id);


--
-- Name: idx_video_recordings_stream_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_stream_status ON public.video_recordings USING btree (stream_id, status);


--
-- Name: idx_video_recordings_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_vehicle_id ON public.video_recordings USING btree (vehicle_id);


--
-- Name: idx_video_recordings_vehicle_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_vehicle_time ON public.video_recordings USING btree (vehicle_id, start_time);


--
-- Name: idx_video_retention_policies_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_retention_policies_org_id ON public.video_retention_policies USING btree (organization_id);


--
-- Name: idx_video_streams_started_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_streams_started_at ON public.video_streams USING btree (started_at);


--
-- Name: idx_video_streams_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_streams_status ON public.video_streams USING btree (status);


--
-- Name: idx_video_streams_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_streams_vehicle_id ON public.video_streams USING btree (vehicle_id);


--
-- Name: idx_video_streams_vehicle_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_streams_vehicle_status ON public.video_streams USING btree (vehicle_id, status);


--
-- Name: idx_video_thumbnails_recording_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_thumbnails_recording_id ON public.video_thumbnails USING btree (recording_id);


--
-- Name: idx_webhooks_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_webhooks_org ON public.webhooks USING btree (org_id);


--
-- Name: idx_work_orders_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_created_at ON public.work_orders USING btree (created_at DESC);


--
-- Name: idx_work_orders_created_by; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_created_by ON public.work_orders USING btree (created_by);


--
-- Name: idx_work_orders_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_org ON public.work_orders USING btree (organization_id);


--
-- Name: idx_work_orders_org_priority; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_org_priority ON public.work_orders USING btree (organization_id, priority);


--
-- Name: idx_work_orders_org_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_org_status ON public.work_orders USING btree (organization_id, status);


--
-- Name: obd_readings_time_idx; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX obd_readings_time_idx ON public.obd_readings USING btree ("time" DESC);


--
-- Name: sla_metrics_time_idx; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX sla_metrics_time_idx ON public.sla_metrics USING btree ("time" DESC);


--
-- Name: vehicle_telemetry_time_idx; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX vehicle_telemetry_time_idx ON public.vehicle_telemetry USING btree ("time" DESC);


--
-- Name: analytics_jobs update_analytics_jobs_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_analytics_jobs_updated_at BEFORE UPDATE ON public.analytics_jobs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: driver_behavior_analytics update_driver_behavior_analytics_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_driver_behavior_analytics_updated_at BEFORE UPDATE ON public.driver_behavior_analytics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: fleet_analytics update_fleet_analytics_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_fleet_analytics_updated_at BEFORE UPDATE ON public.fleet_analytics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: incident_comments update_incident_comments_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_incident_comments_updated_at BEFORE UPDATE ON public.incident_comments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: org_support_metrics update_org_support_metrics_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_org_support_metrics_updated_at BEFORE UPDATE ON public.org_support_metrics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: prediction_results update_prediction_results_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_prediction_results_updated_at BEFORE UPDATE ON public.prediction_results FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: predictive_maintenance_analytics update_predictive_maintenance_analytics_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_predictive_maintenance_analytics_updated_at BEFORE UPDATE ON public.predictive_maintenance_analytics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: predictive_models update_predictive_models_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_predictive_models_updated_at BEFORE UPDATE ON public.predictive_models FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: support_tickets update_support_tickets_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_support_tickets_updated_at BEFORE UPDATE ON public.support_tickets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: access_reviews access_reviews_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.access_reviews
    ADD CONSTRAINT access_reviews_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: access_reviews access_reviews_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.access_reviews
    ADD CONSTRAINT access_reviews_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: alert_rules alert_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alert_rules
    ADD CONSTRAINT alert_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: alert_rules alert_rules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alert_rules
    ADD CONSTRAINT alert_rules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: alerts alerts_acknowledged_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_acknowledged_by_fkey FOREIGN KEY (acknowledged_by) REFERENCES public.users(id);


--
-- Name: alerts alerts_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id);


--
-- Name: alerts alerts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: alerts alerts_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: alerts alerts_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.alert_rules(id);


--
-- Name: alerts alerts_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: api_clients api_clients_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT api_clients_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: api_keys api_keys_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_policies audit_policies_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_policies audit_policies_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_settings audit_settings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_settings
    ADD CONSTRAINT audit_settings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: auth_audit_logs auth_audit_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.auth_audit_logs
    ADD CONSTRAINT auth_audit_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: auth_tokens auth_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: backup_verifications backup_verifications_backup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backup_verifications
    ADD CONSTRAINT backup_verifications_backup_id_fkey FOREIGN KEY (backup_id) REFERENCES public.backups(id) ON DELETE CASCADE;


--
-- Name: backup_verifications backup_verifications_verified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backup_verifications
    ADD CONSTRAINT backup_verifications_verified_by_fkey FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: billing_accounting_exports billing_accounting_exports_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_accounting_exports
    ADD CONSTRAINT billing_accounting_exports_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: billing_credit_transactions billing_credit_transactions_balance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_credit_transactions
    ADD CONSTRAINT billing_credit_transactions_balance_id_fkey FOREIGN KEY (balance_id) REFERENCES public.billing_customer_balances(id);


--
-- Name: billing_customer_balances billing_customer_balances_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_customer_balances
    ADD CONSTRAINT billing_customer_balances_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: billing_invoice_documents billing_invoice_documents_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_invoice_documents
    ADD CONSTRAINT billing_invoice_documents_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: billing_invoice_documents billing_invoice_documents_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_invoice_documents
    ADD CONSTRAINT billing_invoice_documents_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.billing_invoice_templates(id);


--
-- Name: billing_invoice_sequences billing_invoice_sequences_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_invoice_sequences
    ADD CONSTRAINT billing_invoice_sequences_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: billing_pricing_components billing_pricing_components_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_pricing_components
    ADD CONSTRAINT billing_pricing_components_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.billing_plans(id) ON DELETE CASCADE;


--
-- Name: billing_recognized_revenue billing_recognized_revenue_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_recognized_revenue
    ADD CONSTRAINT billing_recognized_revenue_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.billing_revenue_schedules(id);


--
-- Name: billing_revenue_schedules billing_revenue_schedules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_revenue_schedules
    ADD CONSTRAINT billing_revenue_schedules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: billing_subscriptions billing_subscriptions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_subscriptions
    ADD CONSTRAINT billing_subscriptions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: billing_subscriptions billing_subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_subscriptions
    ADD CONSTRAINT billing_subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.billing_plans(id);


--
-- Name: billing_tax_rates billing_tax_rates_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_tax_rates
    ADD CONSTRAINT billing_tax_rates_region_id_fkey FOREIGN KEY (region_id) REFERENCES public.billing_tax_regions(id);


--
-- Name: bulk_job_records bulk_job_records_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_job_records
    ADD CONSTRAINT bulk_job_records_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.bulk_jobs(id) ON DELETE CASCADE;


--
-- Name: consumption_events consumption_events_meter_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.consumption_events
    ADD CONSTRAINT consumption_events_meter_code_fkey FOREIGN KEY (meter_code) REFERENCES public.usage_meters(code);


--
-- Name: consumption_events consumption_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.consumption_events
    ADD CONSTRAINT consumption_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: consumption_events consumption_events_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.consumption_events
    ADD CONSTRAINT consumption_events_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: devices devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: documents documents_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: documents documents_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: documents documents_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: dr_test_logs dr_test_logs_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_test_logs
    ADD CONSTRAINT dr_test_logs_test_id_fkey FOREIGN KEY (test_id) REFERENCES public.dr_tests(id) ON DELETE CASCADE;


--
-- Name: dr_test_steps dr_test_steps_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_test_steps
    ADD CONSTRAINT dr_test_steps_test_id_fkey FOREIGN KEY (test_id) REFERENCES public.dr_tests(id) ON DELETE CASCADE;


--
-- Name: driver_behavior driver_behavior_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_behavior
    ADD CONSTRAINT driver_behavior_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id);


--
-- Name: driver_incidents driver_incidents_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_incidents
    ADD CONSTRAINT driver_incidents_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id);


--
-- Name: drivers drivers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: drivers drivers_current_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_current_vehicle_id_fkey FOREIGN KEY (current_vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: drivers drivers_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: email_verification_tokens email_verification_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: entity_audit_history entity_audit_history_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.entity_audit_history
    ADD CONSTRAINT entity_audit_history_actor_fkey FOREIGN KEY (actor) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: evidence_exports evidence_exports_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.evidence_exports
    ADD CONSTRAINT evidence_exports_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: evidence_exports evidence_exports_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.evidence_exports
    ADD CONSTRAINT evidence_exports_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: firmware_rollout_events firmware_rollout_events_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollout_events
    ADD CONSTRAINT firmware_rollout_events_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id);


--
-- Name: firmware_rollout_events firmware_rollout_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollout_events
    ADD CONSTRAINT firmware_rollout_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: firmware_rollout_events firmware_rollout_events_rollout_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollout_events
    ADD CONSTRAINT firmware_rollout_events_rollout_id_fkey FOREIGN KEY (rollout_id) REFERENCES public.firmware_rollouts(id) ON DELETE CASCADE;


--
-- Name: firmware_rollouts firmware_rollouts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: firmware_rollouts firmware_rollouts_firmware_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_firmware_id_fkey FOREIGN KEY (firmware_id) REFERENCES public.firmware_packages(id) ON DELETE CASCADE;


--
-- Name: firmware_rollouts firmware_rollouts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: telemetry_analytics fk_telemetry_analytics_vehicle; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_analytics
    ADD CONSTRAINT fk_telemetry_analytics_vehicle FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: telemetry_anomalies fk_telemetry_anomalies_vehicle; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_anomalies
    ADD CONSTRAINT fk_telemetry_anomalies_vehicle FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: video_analytics fk_video_analytics_recording; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_analytics
    ADD CONSTRAINT fk_video_analytics_recording FOREIGN KEY (recording_id) REFERENCES public.video_recordings(id);


--
-- Name: video_analytics fk_video_analytics_stream; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_analytics
    ADD CONSTRAINT fk_video_analytics_stream FOREIGN KEY (stream_id) REFERENCES public.video_streams(id);


--
-- Name: video_recordings fk_video_recordings_driver; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_recordings
    ADD CONSTRAINT fk_video_recordings_driver FOREIGN KEY (driver_id) REFERENCES public.drivers(id);


--
-- Name: video_recordings fk_video_recordings_organization; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_recordings
    ADD CONSTRAINT fk_video_recordings_organization FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: video_recordings fk_video_recordings_stream; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_recordings
    ADD CONSTRAINT fk_video_recordings_stream FOREIGN KEY (stream_id) REFERENCES public.video_streams(id);


--
-- Name: video_recordings fk_video_recordings_vehicle; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_recordings
    ADD CONSTRAINT fk_video_recordings_vehicle FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: video_retention_policies fk_video_retention_policies_org; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_retention_policies
    ADD CONSTRAINT fk_video_retention_policies_org FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: video_streams fk_video_streams_driver; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_streams
    ADD CONSTRAINT fk_video_streams_driver FOREIGN KEY (driver_id) REFERENCES public.drivers(id);


--
-- Name: video_streams fk_video_streams_organization; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_streams
    ADD CONSTRAINT fk_video_streams_organization FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: video_streams fk_video_streams_vehicle; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_streams
    ADD CONSTRAINT fk_video_streams_vehicle FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: video_thumbnails fk_video_thumbnails_recording; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_thumbnails
    ADD CONSTRAINT fk_video_thumbnails_recording FOREIGN KEY (recording_id) REFERENCES public.video_recordings(id);


--
-- Name: geofences geofences_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofences
    ADD CONSTRAINT geofences_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: geofences geofences_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofences
    ADD CONSTRAINT geofences_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: incident_comments incident_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_comments
    ADD CONSTRAINT incident_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: incident_comments incident_comments_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_comments
    ADD CONSTRAINT incident_comments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: integration_logs integration_logs_integration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_integration_id_fkey FOREIGN KEY (integration_id) REFERENCES public.integrations(id) ON DELETE SET NULL;


--
-- Name: integration_logs integration_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: integrations integrations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: invoice_items invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: ip_rules ip_rules_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.ip_rules
    ADD CONSTRAINT ip_rules_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id);


--
-- Name: ip_rules ip_rules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.ip_rules
    ADD CONSTRAINT ip_rules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: login_events login_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.login_events
    ADD CONSTRAINT login_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: login_events login_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.login_events
    ADD CONSTRAINT login_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: login_history login_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_codes mfa_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_codes
    ADD CONSTRAINT mfa_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_events mfa_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_events
    ADD CONSTRAINT mfa_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_events mfa_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_events
    ADD CONSTRAINT mfa_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_exceptions mfa_exceptions_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.users(id);


--
-- Name: mfa_exceptions mfa_exceptions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_exceptions mfa_exceptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_failures mfa_failures_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_failures
    ADD CONSTRAINT mfa_failures_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_failures mfa_failures_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_failures
    ADD CONSTRAINT mfa_failures_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_lockouts mfa_lockouts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_lockouts mfa_lockouts_unlocked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_unlocked_by_fkey FOREIGN KEY (unlocked_by) REFERENCES public.users(id);


--
-- Name: mfa_lockouts mfa_lockouts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_org_overrides mfa_org_overrides_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_org_overrides
    ADD CONSTRAINT mfa_org_overrides_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_policies mfa_policies_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policies
    ADD CONSTRAINT mfa_policies_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_policy_history mfa_policy_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policy_history
    ADD CONSTRAINT mfa_policy_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: mfa_policy_history mfa_policy_history_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policy_history
    ADD CONSTRAINT mfa_policy_history_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_recovery_codes mfa_recovery_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_recovery_codes
    ADD CONSTRAINT mfa_recovery_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_users mfa_users_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_users
    ADD CONSTRAINT mfa_users_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: mfa_users mfa_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_users
    ADD CONSTRAINT mfa_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notification_events notification_events_notification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_events
    ADD CONSTRAINT notification_events_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES public.notification_logs(id) ON DELETE CASCADE;


--
-- Name: notification_preference_audit notification_preference_audit_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_preference_audit
    ADD CONSTRAINT notification_preference_audit_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: org_support_metrics org_support_metrics_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.org_support_metrics
    ADD CONSTRAINT org_support_metrics_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_memberships organization_memberships_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organization_memberships
    ADD CONSTRAINT organization_memberships_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_memberships organization_memberships_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organization_memberships
    ADD CONSTRAINT organization_memberships_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: permissions permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: prediction_results prediction_results_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.prediction_results
    ADD CONSTRAINT prediction_results_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.predictive_models(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: restore_jobs restore_jobs_backup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.restore_jobs
    ADD CONSTRAINT restore_jobs_backup_id_fkey FOREIGN KEY (backup_id) REFERENCES public.backups(id);


--
-- Name: review_items review_items_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.access_reviews(id) ON DELETE CASCADE;


--
-- Name: review_items review_items_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id);


--
-- Name: review_items review_items_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: review_items review_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: route_optimization_jobs route_optimization_jobs_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_jobs
    ADD CONSTRAINT route_optimization_jobs_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.route_optimization_requests(id) ON DELETE CASCADE;


--
-- Name: route_optimization_requests route_optimization_requests_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_requests
    ADD CONSTRAINT route_optimization_requests_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: route_optimization_results route_optimization_results_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_results
    ADD CONSTRAINT route_optimization_results_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.route_optimization_requests(id) ON DELETE CASCADE;


--
-- Name: security_events security_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: service_accounts service_accounts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.service_accounts
    ADD CONSTRAINT service_accounts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: sla_metrics sla_metrics_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.sla_metrics
    ADD CONSTRAINT sla_metrics_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: support_audit_log support_audit_log_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_audit_log
    ADD CONSTRAINT support_audit_log_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id);


--
-- Name: support_audit_log support_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_audit_log
    ADD CONSTRAINT support_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: support_tickets support_tickets_reporter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_reporter_id_fkey FOREIGN KEY (reporter_id) REFERENCES public.users(id);


--
-- Name: telemetry telemetry_trip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry
    ADD CONSTRAINT telemetry_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES public.trips(id) ON DELETE CASCADE;


--
-- Name: threat_alerts threat_alerts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.threat_alerts
    ADD CONSTRAINT threat_alerts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: threat_alerts threat_alerts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.threat_alerts
    ADD CONSTRAINT threat_alerts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: trips trips_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id);


--
-- Name: trips trips_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: trips trips_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: user_notification_preferences user_notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_organizations user_organizations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: user_organizations user_organizations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: vehicle_inspections vehicle_inspections_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_inspections
    ADD CONSTRAINT vehicle_inspections_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: vehicle_inspections vehicle_inspections_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_inspections
    ADD CONSTRAINT vehicle_inspections_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.inspection_templates(id);


--
-- Name: vehicle_inspections vehicle_inspections_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_inspections
    ADD CONSTRAINT vehicle_inspections_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: vehicles vehicles_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: vehicles vehicles_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: webhooks webhooks_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: work_orders work_orders_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT work_orders_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: billing_accounting_exports accounting_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY accounting_tenant_policy ON public.billing_accounting_exports TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: billing_customer_balances balances_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY balances_tenant_policy ON public.billing_customer_balances TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: billing_accounting_exports; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_accounting_exports ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_customer_balances; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_customer_balances ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_hardware_products; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_hardware_products ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_invoice_documents; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_invoice_documents ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_invoice_sequences; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_invoice_sequences ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_invoice_templates; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_invoice_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_revenue_schedules; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_revenue_schedules ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_subscriptions; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_subscriptions ENABLE ROW LEVEL SECURITY;

--
-- Name: consumption_events; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.consumption_events ENABLE ROW LEVEL SECURITY;

--
-- Name: consumption_events consumption_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY consumption_tenant_policy ON public.consumption_events TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: billing_invoice_documents document_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY document_tenant_policy ON public.billing_invoice_documents TO flyfleet_app USING ((EXISTS ( SELECT 1
   FROM public.invoices i
  WHERE ((i.id = billing_invoice_documents.invoice_id) AND (i.org_id = public.get_current_org_id())))));


--
-- Name: gps_locations; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.gps_locations ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_hardware_products hardware_products_read_all; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY hardware_products_read_all ON public.billing_hardware_products FOR SELECT USING (true);


--
-- Name: obd_readings; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.obd_readings ENABLE ROW LEVEL SECURITY;

--
-- Name: organizations org_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY org_tenant_policy ON public.organizations TO flyfleet_app USING ((id = public.get_current_org_id())) WITH CHECK ((id = public.get_current_org_id()));


--
-- Name: organizations; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_revenue_schedules revenue_schedule_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY revenue_schedule_tenant_policy ON public.billing_revenue_schedules TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: billing_invoice_sequences sequences_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY sequences_tenant_policy ON public.billing_invoice_sequences TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: sla_metrics; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.sla_metrics ENABLE ROW LEVEL SECURITY;

--
-- Name: sla_metrics sla_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY sla_tenant_policy ON public.sla_metrics TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: billing_subscriptions subs_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY subs_tenant_policy ON public.billing_subscriptions TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: telemetry; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.telemetry ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_invoice_templates template_read_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY template_read_policy ON public.billing_invoice_templates FOR SELECT TO flyfleet_app USING (true);


--
-- Name: trips trip_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY trip_tenant_policy ON public.trips TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: trips; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.trips ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: vehicles vehicle_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY vehicle_tenant_policy ON public.vehicles TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: vehicles; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;

--
-- Name: TABLE billing_accounting_exports; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_accounting_exports TO flyfleet_app;


--
-- Name: TABLE billing_coupons; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_coupons TO flyfleet_app;


--
-- Name: TABLE billing_credit_transactions; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT ON TABLE public.billing_credit_transactions TO flyfleet_app;


--
-- Name: TABLE billing_customer_balances; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_customer_balances TO flyfleet_app;


--
-- Name: TABLE billing_invoice_documents; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.billing_invoice_documents TO flyfleet_app;


--
-- Name: TABLE billing_invoice_sequences; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_invoice_sequences TO flyfleet_app;


--
-- Name: TABLE billing_invoice_templates; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.billing_invoice_templates TO flyfleet_app;


--
-- Name: TABLE billing_plans; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_plans TO flyfleet_app;


--
-- Name: TABLE billing_pricing_components; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_pricing_components TO flyfleet_app;


--
-- Name: TABLE billing_recognized_revenue; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT ON TABLE public.billing_recognized_revenue TO flyfleet_app;


--
-- Name: TABLE billing_revenue_schedules; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_revenue_schedules TO flyfleet_app;


--
-- Name: TABLE billing_subscriptions; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_subscriptions TO flyfleet_app;


--
-- Name: TABLE billing_tax_rates; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT ON TABLE public.billing_tax_rates TO flyfleet_app;


--
-- Name: TABLE billing_tax_regions; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT ON TABLE public.billing_tax_regions TO flyfleet_app;


--
-- Name: TABLE consumption_events; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.consumption_events TO flyfleet_app;


--
-- Name: TABLE organizations; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.organizations TO flyfleet_app;


--
-- Name: TABLE sla_metrics; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT ON TABLE public.sla_metrics TO flyfleet_app;


--
-- Name: TABLE telemetry; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.telemetry TO flyfleet_app;


--
-- Name: TABLE trips; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.trips TO flyfleet_app;


--
-- Name: TABLE usage_meters; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.usage_meters TO flyfleet_app;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.users TO flyfleet_app;


--
-- Name: TABLE vehicles; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vehicles TO flyfleet_app;


--
-- PostgreSQL database dump complete
--

\unrestrict RwehVIg9fSwnsBKzLC2i4auLjJTgh1KJDohM1Wzh2qWoU7ByyokZaz5sbN8Jz93

