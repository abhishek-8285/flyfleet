--
-- PostgreSQL database dump
--

\restrict bhuXobS3vooURxyMZT5cMTMMh8ez6NNKwziEnO1B481KlPzpkB2hSFbixrBVjol

-- Dumped from database version 15.17 (Ubuntu 15.17-1.pgdg22.04+1)
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: timescaledb; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION timescaledb IS 'Enables scalable inserts and complex queries for time-series data (Community Edition)';


--
-- Name: timescaledb_toolkit; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb_toolkit WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb_toolkit; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION timescaledb_toolkit IS 'Library of analytical hyperfunctions, time-series pipelining, and other SQL utilities';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: governance_request_status; Type: TYPE; Schema: public; Owner: fleet_user
--

CREATE TYPE public.governance_request_status AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED',
    'EXPIRED',
    'COMPLETED',
    'PROCESSING',
    'FAILED'
);


ALTER TYPE public.governance_request_status OWNER TO fleet_user;

--
-- Name: governance_request_type; Type: TYPE; Schema: public; Owner: fleet_user
--

CREATE TYPE public.governance_request_type AS ENUM (
    'EXPORT',
    'DELETION',
    'ACCESS_REVIEW'
);


ALTER TYPE public.governance_request_type OWNER TO fleet_user;

--
-- Name: calculate_fuel_efficiency(numeric, numeric, numeric); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.calculate_fuel_efficiency(p_current_odometer numeric, p_previous_odometer numeric, p_fuel_quantity numeric) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF p_fuel_quantity <= 0 THEN
        RETURN 0;
    END IF;
    
    IF p_current_odometer <= p_previous_odometer THEN
        RETURN 0;
    END IF;
    
    RETURN ROUND((p_current_odometer - p_previous_odometer) / p_fuel_quantity, 2);
END;
$$;


ALTER FUNCTION public.calculate_fuel_efficiency(p_current_odometer numeric, p_previous_odometer numeric, p_fuel_quantity numeric) OWNER TO fleet_user;

--
-- Name: calculate_invoice_total(uuid); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.calculate_invoice_total(p_invoice_id uuid) RETURNS TABLE(total_amount numeric, balance_due numeric)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_total DECIMAL := 0;
    v_paid DECIMAL;
BEGIN
    -- Sum all line items
    SELECT COALESCE(SUM(total), 0) INTO v_total
    FROM invoice_items
    WHERE invoice_id = p_invoice_id;
    
    -- Get amount paid
    SELECT COALESCE(amount_paid, 0) INTO v_paid
    FROM invoices
    WHERE id = p_invoice_id;
    
    RETURN QUERY SELECT v_total, (v_total - v_paid);
END;
$$;


ALTER FUNCTION public.calculate_invoice_total(p_invoice_id uuid) OWNER TO fleet_user;

--
-- Name: check_gps_device_uniqueness(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.check_gps_device_uniqueness() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.gps_device_id IS NOT NULL THEN
        IF EXISTS (
            SELECT 1 FROM vehicles
            WHERE gps_device_id = NEW.gps_device_id
              AND id != NEW.id
              AND deleted_at IS NULL
        ) THEN
            RAISE EXCEPTION 'GPS device % is already bound to another vehicle', NEW.gps_device_id;
        END IF;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.check_gps_device_uniqueness() OWNER TO fleet_user;

--
-- Name: check_invoice_permission(uuid, uuid, character varying); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.check_invoice_permission(p_user_id uuid, p_org_id uuid, p_permission character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
DECLARE
    user_role VARCHAR(50);
    has_permission BOOLEAN;
    override BOOLEAN;
BEGIN
    -- Get user's role
    SELECT role INTO user_role FROM users WHERE id = p_user_id AND org_id = p_org_id;
    
    IF user_role IS NULL THEN
        RETURN false;
    END IF;
    
    -- Check for user-specific override
    SELECT override_role INTO override 
    FROM user_invoice_access 
    WHERE user_id = p_user_id AND org_id = p_org_id AND deleted_at IS NULL;
    
    IF override THEN
        -- Use user-specific permissions
        EXECUTE format('SELECT %I FROM user_invoice_access WHERE user_id = $1 AND org_id = $2 AND deleted_at IS NULL', p_permission)
        INTO has_permission USING p_user_id, p_org_id;
        RETURN COALESCE(has_permission, false);
    ELSE
        -- Use role-based permissions
        EXECUTE format('SELECT %I FROM invoice_permissions WHERE role_name = $1 AND org_id = $2', p_permission)
        INTO has_permission USING user_role, p_org_id;
        RETURN COALESCE(has_permission, false);
    END IF;
END;
$_$;


ALTER FUNCTION public.check_invoice_permission(p_user_id uuid, p_org_id uuid, p_permission character varying) OWNER TO fleet_user;

--
-- Name: check_license_expiry(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.check_license_expiry() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    driver_record RECORD;
BEGIN
    FOR driver_record IN 
        SELECT id, email, full_name, license_expiry
        FROM drivers
        WHERE deleted_at IS NULL
          AND status = 'active'
          AND license_expiry < CURRENT_DATE
    LOOP
        -- Log expired license
        RAISE NOTICE 'Driver % (%) has expired license: %', 
            driver_record.full_name, driver_record.email, driver_record.license_expiry;
        
        -- Could send notification here
        -- Could auto-suspend driver here
    END LOOP;
END;
$$;


ALTER FUNCTION public.check_license_expiry() OWNER TO fleet_user;

--
-- Name: cleanup_expired_reset_tokens(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.cleanup_expired_reset_tokens() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM password_reset_tokens WHERE expires_at < NOW() - INTERVAL '24 hours';
    DELETE FROM refresh_tokens WHERE expires_at < NOW() - INTERVAL '30 days';
END;
$$;


ALTER FUNCTION public.cleanup_expired_reset_tokens() OWNER TO fleet_user;

--
-- Name: cleanup_expired_tokens(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.cleanup_expired_tokens() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM refresh_tokens WHERE expires_at < NOW() - INTERVAL '30 days';
END;
$$;


ALTER FUNCTION public.cleanup_expired_tokens() OWNER TO fleet_user;

--
-- Name: cleanup_old_audit_logs(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.cleanup_old_audit_logs() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM settings_audit_logs
    WHERE created_at < NOW() - INTERVAL '1 year';
END;
$$;


ALTER FUNCTION public.cleanup_old_audit_logs() OWNER TO fleet_user;

--
-- Name: cleanup_old_health_history(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.cleanup_old_health_history() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM health_history
    WHERE timestamp < NOW() - INTERVAL '90 days';
END;
$$;


ALTER FUNCTION public.cleanup_old_health_history() OWNER TO fleet_user;

--
-- Name: cleanup_old_route_jobs(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.cleanup_old_route_jobs() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM route_optimization_jobs
    WHERE completed_at < NOW() - INTERVAL '30 days';
END;
$$;


ALTER FUNCTION public.cleanup_old_route_jobs() OWNER TO fleet_user;

--
-- Name: cleanup_old_route_requests(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.cleanup_old_route_requests() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM route_optimization_requests
    WHERE status = 'completed'
      AND created_at < NOW() - INTERVAL '90 days';
END;
$$;


ALTER FUNCTION public.cleanup_old_route_requests() OWNER TO fleet_user;

--
-- Name: cleanup_resolved_alerts(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.cleanup_resolved_alerts() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM health_alerts
    WHERE status = 'resolved'
      AND resolved_at < NOW() - INTERVAL '30 days';
END;
$$;


ALTER FUNCTION public.cleanup_resolved_alerts() OWNER TO fleet_user;

--
-- Name: create_annotation_on_edit(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.create_annotation_on_edit() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only create annotation if this is an edit
    IF NEW.is_edit = true AND NEW.edit_reason IS NOT NULL THEN
        INSERT INTO hos_annotations (
            duty_status_log_id,
            annotation_type,
            reason,
            original_data,
            new_data,
            requires_approval,
            created_by
        ) VALUES (
            NEW.id,
            'edit',
            NEW.edit_reason,
            to_jsonb(OLD),
            to_jsonb(NEW),
            false,
            NEW.edit_approved_by
        );
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.create_annotation_on_edit() OWNER TO fleet_user;

--
-- Name: create_malfunction_from_diagnostic(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.create_malfunction_from_diagnostic() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only create malfunction for certain event types
    IF NEW.event_type IN ('POWER_DATA_DIAGNOSTIC', 'ENGINE_SYNC_DIAGNOSTIC', 'TIMING_DIAGNOSTIC', 'POSITION_DIAGNOSTIC', 'DATA_TRANSFER_DIAGNOSTIC') THEN
        INSERT INTO eld_malfunctions (
            vehicle_id,
            malfunction_type,
            malfunction_code,
            event_description,
            detected_at
        ) VALUES (
            NEW.vehicle_id,
            detect_malfunction_from_event(NEW.vehicle_id, NEW.event_type, NEW.event_code),
            NEW.event_code,
            NEW.event_description,
            NEW.detected_at
        );
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.create_malfunction_from_diagnostic() OWNER TO fleet_user;

--
-- Name: detect_malfunction_from_event(uuid, character varying, character varying); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.detect_malfunction_from_event(p_vehicle_id uuid, p_event_type character varying, p_event_code character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_malfunction_type VARCHAR;
BEGIN
    -- Map diagnostic events to malfunction types per FMCSA §395.34
    CASE p_event_type
        WHEN 'POWER_DATA_DIAGNOSTIC' THEN
            v_malfunction_type := 'POWER';
        WHEN 'ENGINE_SYNC_DIAGNOSTIC' THEN
            v_malfunction_type := 'ENGINE_SYNC';
        WHEN 'TIMING_DIAGNOSTIC' THEN
            v_malfunction_type := 'TIMING';
        WHEN 'POSITION_DIAGNOSTIC' THEN
            v_malfunction_type := 'POSITION';
        WHEN 'DATA_TRANSFER_DIAGNOSTIC' THEN
            v_malfunction_type := 'DATA_TRANSFER';
        ELSE
            v_malfunction_type := 'UNKNOWN';
    END CASE;
    
    RETURN v_malfunction_type;
END;
$$;


ALTER FUNCTION public.detect_malfunction_from_event(p_vehicle_id uuid, p_event_type character varying, p_event_code character varying) OWNER TO fleet_user;

--
-- Name: generate_credit_note_number(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.generate_credit_note_number() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    org_prefix VARCHAR(20);
    year_part VARCHAR(4);
    seq INTEGER;
BEGIN
    -- Get org prefix (or use default)
    SELECT COALESCE(invoice_prefix, 'CN') INTO org_prefix
    FROM billing_configurations
    WHERE org_id = NEW.org_id;
    
    year_part := TO_CHAR(NEW.issue_date, 'YYYY');
    
    -- Get next sequence number
    SELECT COALESCE(MAX(CAST(SUBSTRING(credit_note_no FROM LENGTH(org_prefix) + 6) AS INTEGER)), 0) + 1 INTO seq
    FROM credit_notes
    WHERE org_id = NEW.org_id
      AND credit_note_no LIKE org_prefix || '/' || year_part || '%';
    
    NEW.credit_note_no := org_prefix || '/' || year_part || '-' || LPAD(seq::TEXT, 6, '0');
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.generate_credit_note_number() OWNER TO fleet_user;

--
-- Name: generate_invoice_number(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.generate_invoice_number() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    seq_record RECORD;
    new_number INTEGER;
BEGIN
    -- Get and increment sequence
    SELECT * INTO seq_record FROM invoice_sequence WHERE id = 1 FOR UPDATE;
    
    -- Reset sequence if year changed
    IF seq_record.year != EXTRACT(YEAR FROM CURRENT_DATE) THEN
        new_number := 1;
        UPDATE invoice_sequence 
        SET current_value = 2, 
            year = EXTRACT(YEAR FROM CURRENT_DATE),
            updated_at = CURRENT_TIMESTAMP
        WHERE id = 1;
    ELSE
        new_number := seq_record.current_value;
        UPDATE invoice_sequence 
        SET current_value = current_value + 1,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = 1;
    END IF;
    
    -- Set invoice number
    NEW.invoice_number := format('%s-%s-%06d', seq_record.prefix, EXTRACT(YEAR FROM CURRENT_DATE), new_number);
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.generate_invoice_number() OWNER TO fleet_user;

--
-- Name: FUNCTION generate_invoice_number(); Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON FUNCTION public.generate_invoice_number() IS 'Auto-generates invoice numbers in format INV-YYYY-NNNNNN';


--
-- Name: generate_irn_hash(character varying, character varying, character varying, character varying, numeric); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.generate_irn_hash(p_invoice_no character varying, p_fin_year character varying, p_gstin character varying, p_inv_type character varying, p_inv_value numeric) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_input TEXT;
    v_hash TEXT;
BEGIN
    -- IRN is SHA-256 hash of: InvoiceNo|FinYear|GSTIN|InvType|InvValue
    v_input := p_invoice_no || '|' || p_fin_year || '|' || p_gstin || '|' || p_inv_type || '|' || p_inv_value::TEXT;
    
    -- In production, use actual SHA-256 via extension or external service
    -- For now, return a placeholder
    v_hash := encode(sha256(v_input::bytea), 'hex');
    
    RETURN v_hash;
END;
$$;


ALTER FUNCTION public.generate_irn_hash(p_invoice_no character varying, p_fin_year character varying, p_gstin character varying, p_inv_type character varying, p_inv_value numeric) OWNER TO fleet_user;

--
-- Name: get_current_org_id(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.get_current_org_id() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
    SELECT current_setting('app.current_org_id', true)::uuid;
$$;


ALTER FUNCTION public.get_current_org_id() OWNER TO fleet_user;

--
-- Name: get_driver_inspection_history(uuid, integer); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.get_driver_inspection_history(p_driver_id uuid, p_months integer DEFAULT 12) RETURNS TABLE(inspection_id uuid, inspection_date timestamp with time zone, inspection_level integer, location text, overall_status character varying, violations_found integer, oos_violations integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        di.id,
        di.inspection_date,
        di.inspection_level,
        di.inspection_location,
        di.overall_status,
        di.violations_found,
        di.oos_violations
    FROM dot_inspections di
    WHERE di.driver_id = p_driver_id
      AND di.inspection_date >= CURRENT_TIMESTAMP - (p_months || ' months')::INTERVAL
    ORDER BY di.inspection_date DESC;
END;
$$;


ALTER FUNCTION public.get_driver_inspection_history(p_driver_id uuid, p_months integer) OWNER TO fleet_user;

--
-- Name: get_feature_flag(character varying); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.get_feature_flag(p_key character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_enabled BOOLEAN;
BEGIN
    SELECT enabled INTO v_enabled
    FROM feature_flags
    WHERE key = p_key
    LIMIT 1;
    
    RETURN COALESCE(v_enabled, FALSE);
END;
$$;


ALTER FUNCTION public.get_feature_flag(p_key character varying) OWNER TO fleet_user;

--
-- Name: get_geofences_for_vehicle(uuid); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.get_geofences_for_vehicle(p_vehicle_id uuid) RETURNS TABLE(geofence_id uuid, name character varying, type character varying, assignment_type character varying, dwell_minutes integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        g.id,
        g.name,
        g.type,
        ga.assignment_type,
        ga.dwell_minutes
    FROM geofences g
    LEFT JOIN geofence_assignments ga ON ga.geofence_id = g.id AND ga.is_active = true
    WHERE g.enabled = true
      AND (ga.vehicle_id = p_vehicle_id OR array_length(g.vehicles, 1) IS NULL OR g.vehicles @> ARRAY[p_vehicle_id]);
END;
$$;


ALTER FUNCTION public.get_geofences_for_vehicle(p_vehicle_id uuid) OWNER TO fleet_user;

--
-- Name: get_last_odometer(uuid, uuid); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.get_last_odometer(p_vehicle_id uuid, p_org_id uuid) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE
    last_odometer DECIMAL;
BEGIN
    SELECT odometer INTO last_odometer
    FROM fuel_logs
    WHERE vehicle_id = p_vehicle_id 
      AND organization_id = p_org_id
      AND status = 'APPROVED'
    ORDER BY transaction_date DESC, created_at DESC
    LIMIT 1;
    
    RETURN COALESCE(last_odometer, 0);
END;
$$;


ALTER FUNCTION public.get_last_odometer(p_vehicle_id uuid, p_org_id uuid) OWNER TO fleet_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: billing_configurations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_configurations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    company_name character varying(255) NOT NULL,
    company_address text,
    company_gstin character varying(20),
    company_pan character varying(10),
    company_email character varying(255),
    company_phone character varying(20),
    company_website character varying(255),
    company_logo_url text,
    primary_color character varying(7) DEFAULT '#3b82f6'::character varying,
    secondary_color character varying(7) DEFAULT '#1e40af'::character varying,
    theme character varying(50) DEFAULT 'modern'::character varying,
    bank_name character varying(255),
    bank_account_name character varying(255),
    bank_account_number character varying(50),
    bank_ifsc character varying(20),
    bank_branch character varying(255),
    bank_upi character varying(255),
    invoice_prefix character varying(20) DEFAULT 'INV'::character varying,
    invoice_terms text[],
    invoice_notes text,
    show_hsn boolean DEFAULT true,
    show_qr_code boolean DEFAULT true,
    show_payment_info boolean DEFAULT true,
    default_currency character varying(10) DEFAULT 'INR'::character varying,
    default_tax_calculation character varying(20) DEFAULT 'exclusive'::character varying,
    default_payment_terms_days integer DEFAULT 30,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by uuid
);


ALTER TABLE public.billing_configurations OWNER TO fleet_user;

--
-- Name: TABLE billing_configurations; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.billing_configurations IS 'Per-organization billing/invoice customization';


--
-- Name: COLUMN billing_configurations.org_id; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.billing_configurations.org_id IS 'Organization ID (one config per org)';


--
-- Name: COLUMN billing_configurations.company_logo_url; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.billing_configurations.company_logo_url IS 'Base64 encoded or S3 URL';


--
-- Name: COLUMN billing_configurations.invoice_terms; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.billing_configurations.invoice_terms IS 'Array of terms and conditions';


--
-- Name: get_or_create_billing_config(uuid); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.get_or_create_billing_config(p_org_id uuid) RETURNS public.billing_configurations
    LANGUAGE plpgsql
    AS $$
DECLARE
    config billing_configurations;
BEGIN
    -- Try to get existing config
    SELECT * INTO config
    FROM billing_configurations
    WHERE org_id = p_org_id AND is_active = true;
    
    -- If not found, return defaults
    IF config.id IS NULL THEN
        config.org_id := p_org_id;
        config.company_name := 'Organization';
        config.primary_color := '#3b82f6';
        config.invoice_prefix := 'INV';
        config.default_currency := 'INR';
        config.default_payment_terms_days := 30;
        config.show_hsn := true;
        config.show_qr_code := true;
        config.show_payment_info := true;
    END IF;
    
    RETURN config;
END;
$$;


ALTER FUNCTION public.get_or_create_billing_config(p_org_id uuid) OWNER TO fleet_user;

--
-- Name: get_org_compliance_summary(uuid); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.get_org_compliance_summary(p_org_id uuid) RETURNS TABLE(total_inspections bigint, inspections_with_violations bigint, oos_inspections bigint, oos_rate numeric, avg_violations_per_inspection numeric, last_review_date timestamp with time zone, last_review_rating character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COUNT(di.id) as total_inspections,
        COUNT(CASE WHEN di.violations_found > 0 THEN 1 END) as inspections_with_violations,
        COUNT(CASE WHEN di.overall_status = 'out_of_service' THEN 1 END) as oos_inspections,
        CASE 
            WHEN COUNT(di.id) > 0 THEN 
                ROUND(COUNT(CASE WHEN di.overall_status = 'out_of_service' THEN 1 END)::DECIMAL / COUNT(di.id)::DECIMAL * 100, 2)
            ELSE 0 
        END as oos_rate,
        CASE 
            WHEN COUNT(di.id) > 0 THEN 
                ROUND(AVG(di.violations_found)::DECIMAL, 2)
            ELSE 0 
        END as avg_violations_per_inspection,
        (SELECT MAX(review_date) FROM compliance_reviews WHERE org_id = p_org_id) as last_review_date,
        (SELECT overall_rating FROM compliance_reviews WHERE org_id = p_org_id ORDER BY review_date DESC LIMIT 1) as last_review_rating
    FROM dot_inspections di
    JOIN drivers d ON di.driver_id = d.id
    WHERE d.org_id = p_org_id;
END;
$$;


ALTER FUNCTION public.get_org_compliance_summary(p_org_id uuid) OWNER TO fleet_user;

--
-- Name: get_required_approvers(uuid, numeric); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.get_required_approvers(p_org_id uuid, p_amount numeric) RETURNS TABLE(role character varying, specific_user uuid)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        unnest(app.approver_roles) as role,
        unnest(app.specific_approvers) as specific_user
    FROM invoice_approval_policies app
    WHERE app.org_id = p_org_id
      AND app.is_active = true
      AND app.min_amount <= p_amount
      AND (app.max_amount IS NULL OR app.max_amount >= p_amount)
    ORDER BY app.priority DESC;
END;
$$;


ALTER FUNCTION public.get_required_approvers(p_org_id uuid, p_amount numeric) OWNER TO fleet_user;

--
-- Name: get_unreported_malfunctions(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.get_unreported_malfunctions() RETURNS TABLE(malfunction_id uuid, vehicle_id uuid, driver_id uuid, malfunction_type character varying, detected_at timestamp with time zone, hours_since_detection integer, is_overdue boolean)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        em.id,
        em.vehicle_id,
        em.driver_id,
        em.malfunction_type,
        em.detected_at,
        EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - em.detected_at)) / 3600::INTEGER as hours_since_detection,
        CASE 
            WHEN CURRENT_TIMESTAMP - em.detected_at > INTERVAL '24 hours' THEN true
            ELSE false
        END as is_overdue
    FROM eld_malfunctions em
    WHERE em.status = 'open'
      AND em.reported_to_fmcsa = false
    ORDER BY em.detected_at ASC;
END;
$$;


ALTER FUNCTION public.get_unreported_malfunctions() OWNER TO fleet_user;

--
-- Name: invoice_requires_approval(uuid, numeric, uuid); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.invoice_requires_approval(p_org_id uuid, p_amount numeric, p_created_by uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_policy_count INTEGER;
BEGIN
    -- Check if any active policy applies
    SELECT COUNT(*) INTO v_policy_count
    FROM invoice_approval_policies
    WHERE org_id = p_org_id
      AND is_active = true
      AND min_amount <= p_amount
      AND (max_amount IS NULL OR max_amount >= p_amount);
    
    RETURN v_policy_count > 0;
END;
$$;


ALTER FUNCTION public.invoice_requires_approval(p_org_id uuid, p_amount numeric, p_created_by uuid) OWNER TO fleet_user;

--
-- Name: is_einvoice_mandatory(uuid, numeric); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.is_einvoice_mandatory(p_org_id uuid, p_amount numeric) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_mandatory_above DECIMAL;
    v_enabled BOOLEAN;
BEGIN
    -- Get org configuration
    SELECT mandatory_above, is_enabled INTO v_mandatory_above, v_enabled
    FROM einvoice_config
    WHERE org_id = p_org_id AND is_active = true;
    
    -- If not enabled, return false
    IF NOT v_enabled THEN
        RETURN false;
    END IF;
    
    -- Check if amount is above threshold
    RETURN p_amount > v_mandatory_above;
END;
$$;


ALTER FUNCTION public.is_einvoice_mandatory(p_org_id uuid, p_amount numeric) OWNER TO fleet_user;

--
-- Name: is_point_inside_geofence(double precision, double precision, uuid); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.is_point_inside_geofence(p_longitude double precision, p_latitude double precision, p_geofence_id uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_inside BOOLEAN;
    v_geofence_type VARCHAR;
    v_center GEOGRAPHY;
    v_radius INTEGER;
    v_polygon GEOGRAPHY;
    v_point GEOGRAPHY;
BEGIN
    v_point := ST_SetSRID(ST_MakePoint(p_longitude, p_latitude), 4326)::geography;
    
    -- Get geofence details
    SELECT type, center, radius_meters, coordinates
    INTO v_geofence_type, v_center, v_radius, v_polygon
    FROM geofences
    WHERE id = p_geofence_id AND enabled = true;
    
    IF NOT FOUND THEN
        RETURN FALSE;
    END IF;
    
    -- Check based on geofence type
    IF v_geofence_type = 'circle' THEN
        SELECT ST_DWithin(v_point, v_center, v_radius) INTO v_inside;
    ELSIF v_geofence_type = 'polygon' THEN
        SELECT ST_Within(v_point, v_polygon) INTO v_inside;
    ELSE
        RETURN FALSE;
    END IF;
    
    RETURN v_inside;
END;
$$;


ALTER FUNCTION public.is_point_inside_geofence(p_longitude double precision, p_latitude double precision, p_geofence_id uuid) OWNER TO fleet_user;

--
-- Name: log_customer_audit(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.log_customer_audit() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO customer_audit_log (
            org_id, entity_type, entity_id, action, new_value, user_type
        ) VALUES (
            NEW.org_id, 'customer', NEW.id, 'created', to_jsonb(NEW), 'system'
        );
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO customer_audit_log (
            org_id, entity_type, entity_id, action, old_value, new_value, user_type
        ) VALUES (
            NEW.org_id, 'customer', NEW.id, 'updated', to_jsonb(OLD), to_jsonb(NEW), 'system'
        );
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO customer_audit_log (
            org_id, entity_type, entity_id, action, old_value, user_type
        ) VALUES (
            OLD.org_id, 'customer', OLD.id, 'deleted', to_jsonb(OLD), 'system'
        );
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.log_customer_audit() OWNER TO fleet_user;

--
-- Name: log_invoice_change(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.log_invoice_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO invoice_audit_log (invoice_id, action, new_value, changed_by, changed_at)
        VALUES (NEW.id, 'created', to_jsonb(NEW), NEW.created_by, NEW.created_at);
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO invoice_audit_log (invoice_id, action, old_value, new_value, changed_by, changed_at)
        VALUES (NEW.id, 'updated', to_jsonb(OLD), to_jsonb(NEW), NEW.updated_by, NEW.updated_at);
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO invoice_audit_log (invoice_id, action, old_value, changed_at)
        VALUES (OLD.id, 'deleted', to_jsonb(OLD), CURRENT_TIMESTAMP);
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.log_invoice_change() OWNER TO fleet_user;

--
-- Name: log_shipment_status_change(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.log_shipment_status_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF OLD.status IS DISTINCT FROM NEW.status THEN
        INSERT INTO customer_audit_log (
            org_id, entity_type, entity_id, action, old_value, new_value, reason, user_type
        ) SELECT
            c.org_id, 'shipment', NEW.id, 'status_changed', 
            jsonb_build_object('status', OLD.status),
            jsonb_build_object('status', NEW.status),
            'Status changed from ' || OLD.status || ' to ' || NEW.status,
            'system'
        FROM customers c
        WHERE c.id = NEW.customer_id;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.log_shipment_status_change() OWNER TO fleet_user;

--
-- Name: mark_webhook_failed(uuid, integer, text, text); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.mark_webhook_failed(p_delivery_id uuid, p_http_status integer, p_error_message text, p_response_body text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_subscription_id UUID;
    v_attempt INTEGER;
    v_max_retries INTEGER;
    v_retry_delay INTEGER;
BEGIN
    -- Get subscription details
    SELECT ws.id, wd.attempt, ws.max_retries, ws.retry_delay_seconds
    INTO v_subscription_id, v_attempt, v_max_retries, v_retry_delay
    FROM webhook_deliveries wd
    JOIN webhook_subscriptions ws ON wd.subscription_id = ws.id
    WHERE wd.id = p_delivery_id;
    
    -- Update delivery record
    UPDATE webhook_deliveries SET
        status = CASE 
            WHEN v_attempt >= v_max_retries THEN 'failed'
            ELSE 'retrying'
        END,
        http_status = p_http_status,
        error_message = p_error_message,
        response_body = p_response_body,
        next_retry_at = CASE 
            WHEN v_attempt >= v_max_retries THEN NULL
            ELSE CURRENT_TIMESTAMP + (v_retry_delay * INTERVAL '1 second' * POWER(2, v_attempt))
        END
    WHERE id = p_delivery_id;
    
    -- Update subscription statistics
    UPDATE webhook_subscriptions SET
        failed_deliveries = failed_deliveries + 1,
        last_failure_at = CURRENT_TIMESTAMP
    WHERE id = v_subscription_id;
END;
$$;


ALTER FUNCTION public.mark_webhook_failed(p_delivery_id uuid, p_http_status integer, p_error_message text, p_response_body text) OWNER TO fleet_user;

--
-- Name: mark_webhook_success(uuid, integer, text, integer); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.mark_webhook_success(p_delivery_id uuid, p_http_status integer, p_response_body text, p_duration_ms integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE webhook_deliveries SET
        status = 'success',
        http_status = p_http_status,
        response_body = p_response_body,
        delivered_at = CURRENT_TIMESTAMP,
        duration_ms = p_duration_ms
    WHERE id = p_delivery_id;
    
    -- Update subscription statistics
    UPDATE webhook_subscriptions SET
        successful_deliveries = successful_deliveries + 1,
        last_success_at = CURRENT_TIMESTAMP
    WHERE id = (SELECT subscription_id FROM webhook_deliveries WHERE id = p_delivery_id);
END;
$$;


ALTER FUNCTION public.mark_webhook_success(p_delivery_id uuid, p_http_status integer, p_response_body text, p_duration_ms integer) OWNER TO fleet_user;

--
-- Name: protect_audit_logs(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.protect_audit_logs() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF (TG_OP = 'UPDATE' OR TG_OP = 'DELETE') THEN
        RAISE EXCEPTION 'Admin Audit Logs are immutable';
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.protect_audit_logs() OWNER TO fleet_user;

--
-- Name: queue_webhook_delivery(uuid, character varying, uuid, jsonb); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.queue_webhook_delivery(p_subscription_id uuid, p_event_type character varying, p_event_id uuid, p_payload jsonb) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_delivery_id UUID;
    v_signature TEXT;
    v_secret TEXT;
BEGIN
    -- Get subscription secret
    SELECT secret INTO v_secret FROM webhook_subscriptions WHERE id = p_subscription_id;
    
    -- Generate HMAC signature
    v_signature := encode(hmac(p_payload::text, v_secret, 'sha256'), 'hex');
    
    -- Create delivery record
    INSERT INTO webhook_deliveries (
        subscription_id, event_type, event_id, payload, signature, status
    ) VALUES (
        p_subscription_id, p_event_type, p_event_id, p_payload, v_signature, 'pending'
    ) RETURNING id INTO v_delivery_id;
    
    -- Update subscription statistics
    UPDATE webhook_subscriptions 
    SET total_deliveries = total_deliveries + 1,
        last_delivery_at = CURRENT_TIMESTAMP
    WHERE id = p_subscription_id;
    
    RETURN v_delivery_id;
END;
$$;


ALTER FUNCTION public.queue_webhook_delivery(p_subscription_id uuid, p_event_type character varying, p_event_id uuid, p_payload jsonb) OWNER TO fleet_user;

--
-- Name: refresh_vehicle_status(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.refresh_vehicle_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY vehicle_status;
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.refresh_vehicle_status() OWNER TO fleet_user;

--
-- Name: set_finance_fuel_updated_at(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.set_finance_fuel_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_finance_fuel_updated_at() OWNER TO fleet_user;

--
-- Name: tp_set_geo(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.tp_set_geo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.geo := ST_SetSRID(ST_MakePoint(NEW.lng, NEW.lat), 4326);
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.tp_set_geo() OWNER TO fleet_user;

--
-- Name: trigger_insert_diagnostics_audit_log(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.trigger_insert_diagnostics_audit_log() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO diagnostics_audit_logs (entity_type, entity_id, action, metadata)
        VALUES (TG_TABLE_NAME, NEW.id, 'INSERT', row_to_json(NEW));
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO diagnostics_audit_logs (entity_type, entity_id, action, metadata)
        VALUES (TG_TABLE_NAME, NEW.id, 'UPDATE', jsonb_build_object('old', row_to_json(OLD), 'new', row_to_json(NEW)));
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO diagnostics_audit_logs (entity_type, entity_id, action, metadata)
        VALUES (TG_TABLE_NAME, OLD.id, 'DELETE', row_to_json(OLD));
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.trigger_insert_diagnostics_audit_log() OWNER TO fleet_user;

--
-- Name: update_config_timestamp(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_config_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_config_timestamp() OWNER TO fleet_user;

--
-- Name: update_driver_stats_after_trip(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_driver_stats_after_trip() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- This would be called when a trip is completed
    -- Updates driver statistics
    UPDATE drivers SET
        total_trips = total_trips + 1,
        total_distance_km = total_distance_km + COALESCE(NEW.distance_km, 0),
        total_hours_driven = total_hours_driven + COALESCE(NEW.duration_hours, 0),
        updated_at = CURRENT_TIMESTAMP
    WHERE id = NEW.driver_id AND deleted_at IS NULL;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_driver_stats_after_trip() OWNER TO fleet_user;

--
-- Name: update_driver_verification_timestamp(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_driver_verification_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_driver_verification_timestamp() OWNER TO fleet_user;

--
-- Name: update_ewaybill_timestamp(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_ewaybill_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_ewaybill_timestamp() OWNER TO fleet_user;

--
-- Name: update_fastag_timestamp(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_fastag_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_fastag_timestamp() OWNER TO fleet_user;

--
-- Name: update_fuel_logs_timestamp(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_fuel_logs_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_fuel_logs_timestamp() OWNER TO fleet_user;

--
-- Name: update_geofencing_timestamp(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_geofencing_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_geofencing_timestamp() OWNER TO fleet_user;

--
-- Name: update_governance_requests_updated_at(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_governance_requests_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_governance_requests_updated_at() OWNER TO fleet_user;

--
-- Name: update_governance_settings_updated_at(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_governance_settings_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_governance_settings_updated_at() OWNER TO fleet_user;

--
-- Name: update_gst_timestamp(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_gst_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_gst_timestamp() OWNER TO fleet_user;

--
-- Name: update_overdue_invoices(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_overdue_invoices() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE invoices 
    SET status = 'OVERDUE', 
        updated_at = CURRENT_TIMESTAMP,
        metadata = jsonb_set(metadata, '{overdue_updated_at}', to_jsonb(CURRENT_TIMESTAMP))
    WHERE status IN ('PENDING', 'PARTIAL')
      AND due_date < CURRENT_DATE
      AND id NOT IN (
          SELECT id FROM invoices 
          WHERE status = 'OVERDUE' 
            AND metadata->>'overdue_updated_at' IS NOT NULL
            AND (metadata->>'overdue_updated_at')::TIMESTAMPTZ > CURRENT_DATE - INTERVAL '1 day'
      );
END;
$$;


ALTER FUNCTION public.update_overdue_invoices() OWNER TO fleet_user;

--
-- Name: FUNCTION update_overdue_invoices(); Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON FUNCTION public.update_overdue_invoices() IS 'Marks invoices as OVERDUE when past due date';


--
-- Name: update_permit_timestamp(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_permit_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_permit_timestamp() OWNER TO fleet_user;

--
-- Name: update_timestamp(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
   NEW.updated_at = NOW();
   RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_timestamp() OWNER TO fleet_user;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO fleet_user;

--
-- Name: update_vehicle_verification_timestamp(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_vehicle_verification_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_vehicle_verification_timestamp() OWNER TO fleet_user;

--
-- Name: validate_credit_note_amount(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.validate_credit_note_amount() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    original_outstanding DECIMAL(12, 2);
    existing_credits DECIMAL(12, 2);
BEGIN
    -- Get original invoice outstanding
    SELECT balance_due INTO original_outstanding
    FROM invoices
    WHERE id = NEW.original_invoice_id;
    
    -- Get sum of existing credit notes for this invoice
    SELECT COALESCE(SUM(total_amount), 0) INTO existing_credits
    FROM credit_notes
    WHERE original_invoice_id = NEW.original_invoice_id
      AND id != NEW.id
      AND status != 'cancelled';
    
    -- Validate
    IF NEW.total_amount > (original_outstanding - existing_credits) THEN
        RAISE EXCEPTION 'Credit note amount exceeds outstanding invoice balance';
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.validate_credit_note_amount() OWNER TO fleet_user;

--
-- Name: ab_test_experiments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.ab_test_experiments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    status text DEFAULT 'DRAFT'::text,
    variants jsonb NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ab_test_experiments OWNER TO fleet_user;

--
-- Name: access_reviews; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.access_reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    due_date timestamp with time zone,
    total_users integer DEFAULT 0,
    reviewed_users integer DEFAULT 0,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT access_reviews_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'IN_PROGRESS'::character varying, 'COMPLETED'::character varying])::text[])))
);


ALTER TABLE public.access_reviews OWNER TO fleet_user;

--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.feature_flags (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    key character varying(100) NOT NULL,
    description text,
    scope character varying(50) DEFAULT 'GLOBAL'::character varying NOT NULL,
    enabled boolean DEFAULT false,
    tags text[] DEFAULT '{}'::text[],
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by uuid NOT NULL
);


ALTER TABLE public.feature_flags OWNER TO fleet_user;

--
-- Name: TABLE feature_flags; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.feature_flags IS 'Feature flag toggles for gradual rollouts';


--
-- Name: active_feature_flags; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.active_feature_flags AS
 SELECT feature_flags.id,
    feature_flags.key,
    feature_flags.description,
    feature_flags.scope,
    feature_flags.enabled,
    feature_flags.tags
   FROM public.feature_flags
  WHERE (feature_flags.enabled = true)
  ORDER BY feature_flags.key;


ALTER VIEW public.active_feature_flags OWNER TO fleet_user;

--
-- Name: notification_channels; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.notification_channels (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    channel_type character varying(50) NOT NULL,
    provider character varying(100) NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by uuid NOT NULL
);


ALTER TABLE public.notification_channels OWNER TO fleet_user;

--
-- Name: TABLE notification_channels; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.notification_channels IS 'External notification provider configurations';


--
-- Name: COLUMN notification_channels.config; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.notification_channels.config IS 'Encrypted provider configuration (API keys, etc.)';


--
-- Name: active_notification_channels; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.active_notification_channels AS
 SELECT notification_channels.id,
    notification_channels.channel_type,
    notification_channels.provider,
    notification_channels.enabled
   FROM public.notification_channels
  WHERE (notification_channels.enabled = true)
  ORDER BY notification_channels.channel_type;


ALTER VIEW public.active_notification_channels OWNER TO fleet_user;

--
-- Name: admin_audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.admin_audit_logs (
    id uuid NOT NULL,
    actor_id uuid NOT NULL,
    action text NOT NULL,
    resource_type text NOT NULL,
    resource_id text NOT NULL,
    before_state jsonb,
    after_state jsonb,
    ip_address text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_audit_logs OWNER TO fleet_user;

--
-- Name: admin_operation_approvals; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.admin_operation_approvals (
    id uuid NOT NULL,
    operation_type text NOT NULL,
    target_id text,
    payload jsonb,
    requested_by uuid NOT NULL,
    status text NOT NULL,
    approved_by uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    resolved_at timestamp without time zone
);


ALTER TABLE public.admin_operation_approvals OWNER TO fleet_user;

--
-- Name: admin_permissions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.admin_permissions (
    id uuid NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.admin_permissions OWNER TO fleet_user;

--
-- Name: admin_role_permissions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.admin_role_permissions (
    role text NOT NULL,
    permission text NOT NULL
);


ALTER TABLE public.admin_role_permissions OWNER TO fleet_user;

--
-- Name: admin_search_sync_state; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.admin_search_sync_state (
    domain text NOT NULL,
    last_synced_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_search_sync_state OWNER TO fleet_user;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.admin_users (
    id uuid NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    mfa_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_users OWNER TO fleet_user;

--
-- Name: alert_rules; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.alert_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    description text,
    severity character varying(20) DEFAULT 'warning'::character varying,
    conditions jsonb NOT NULL,
    actions jsonb,
    vehicles jsonb,
    driver_ids jsonb,
    enabled boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.alert_rules OWNER TO fleet_user;

--
-- Name: health_alerts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.health_alerts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    alert_type character varying(50) NOT NULL,
    component character varying(100) NOT NULL,
    metric character varying(100) NOT NULL,
    current_value double precision NOT NULL,
    threshold double precision NOT NULL,
    severity character varying(20) NOT NULL,
    message text NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    triggered_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    acknowledged_at timestamp with time zone,
    resolved_at timestamp with time zone,
    CONSTRAINT health_alerts_severity_check CHECK (((severity)::text = ANY ((ARRAY['critical'::character varying, 'warning'::character varying, 'info'::character varying])::text[]))),
    CONSTRAINT health_alerts_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'acknowledged'::character varying, 'resolved'::character varying])::text[])))
);


ALTER TABLE public.health_alerts OWNER TO fleet_user;

--
-- Name: TABLE health_alerts; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.health_alerts IS 'Active system health alerts';


--
-- Name: COLUMN health_alerts.status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.health_alerts.status IS 'active=new alert, acknowledged=being handled, resolved=fixed';


--
-- Name: alert_summary; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.alert_summary AS
 SELECT health_alerts.severity,
    health_alerts.status,
    count(*) AS count,
    min(health_alerts.triggered_at) AS oldest_alert,
    max(health_alerts.triggered_at) AS newest_alert
   FROM public.health_alerts
  GROUP BY health_alerts.severity, health_alerts.status;


ALTER VIEW public.alert_summary OWNER TO fleet_user;

--
-- Name: alert_thresholds; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.alert_thresholds (
    component character varying(100) NOT NULL,
    metric character varying(100) NOT NULL,
    threshold double precision NOT NULL,
    operator character varying(10) NOT NULL,
    severity character varying(20) NOT NULL,
    enabled boolean DEFAULT true,
    notification_channels text[] DEFAULT '{}'::text[],
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT alert_thresholds_operator_check CHECK (((operator)::text = ANY ((ARRAY['gt'::character varying, 'lt'::character varying, 'gte'::character varying, 'lte'::character varying, 'eq'::character varying])::text[]))),
    CONSTRAINT alert_thresholds_severity_check CHECK (((severity)::text = ANY ((ARRAY['critical'::character varying, 'warning'::character varying, 'info'::character varying])::text[])))
);


ALTER TABLE public.alert_thresholds OWNER TO fleet_user;

--
-- Name: TABLE alert_thresholds; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.alert_thresholds IS 'Alert threshold configuration';


--
-- Name: COLUMN alert_thresholds.operator; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.alert_thresholds.operator IS 'gt=greater than, lt=less than, gte=greater or equal, lte=less or equal, eq=equal';


--
-- Name: COLUMN alert_thresholds.notification_channels; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.alert_thresholds.notification_channels IS 'Array of notification channels: email, slack, sms';


--
-- Name: alerts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.alerts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    rule_id uuid,
    type character varying(50) NOT NULL,
    severity character varying(20) DEFAULT 'warning'::character varying,
    vehicle_id uuid,
    driver_id uuid,
    "timestamp" timestamp with time zone DEFAULT now(),
    location jsonb,
    details jsonb,
    status character varying(20) DEFAULT 'new'::character varying,
    notes text,
    acknowledged_by uuid,
    acknowledged_at timestamp with time zone,
    resolved_by uuid,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    dedup_key text,
    escalation_level integer DEFAULT 0,
    last_escalated_at timestamp with time zone,
    escalated_to uuid[],
    sla_deadline timestamp with time zone
);


ALTER TABLE public.alerts OWNER TO fleet_user;

--
-- Name: alerts_v2_dlq; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.alerts_v2_dlq (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    log_id uuid,
    reason text,
    payload jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.alerts_v2_dlq OWNER TO fleet_user;

--
-- Name: alerts_v2_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.alerts_v2_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    recipient text NOT NULL,
    channel character varying(50) NOT NULL,
    alert_type character varying(100),
    subject text,
    body text NOT NULL,
    status character varying(50) DEFAULT 'QUEUED'::character varying NOT NULL,
    retry_count integer DEFAULT 0,
    max_retries integer DEFAULT 3,
    provider character varying(100),
    provider_response jsonb,
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    scheduled_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.alerts_v2_logs OWNER TO fleet_user;

--
-- Name: alerts_v2_templates; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.alerts_v2_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    channel character varying(50) NOT NULL,
    language character varying(10) DEFAULT 'en'::character varying NOT NULL,
    subject text,
    body text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.alerts_v2_templates OWNER TO fleet_user;

--
-- Name: alerts_v2_user_preferences; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.alerts_v2_user_preferences (
    user_id uuid NOT NULL,
    channel character varying(50) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.alerts_v2_user_preferences OWNER TO fleet_user;

--
-- Name: analytics_access_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.analytics_access_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    resource_id text NOT NULL,
    resource_type text NOT NULL,
    access_context jsonb,
    ip_address text,
    user_agent text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.analytics_access_logs OWNER TO fleet_user;

--
-- Name: analytics_jobs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.analytics_jobs (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(100) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    job_type character varying(100) NOT NULL,
    parameters jsonb DEFAULT '{}'::jsonb NOT NULL,
    input_source character varying(255) NOT NULL,
    output_destination character varying(255) NOT NULL,
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    progress numeric(5,2) DEFAULT 0,
    error_details text,
    organization_id uuid NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    idempotency_key text,
    CONSTRAINT analytics_jobs_progress_check CHECK (((progress >= (0)::numeric) AND (progress <= (100)::numeric)))
);


ALTER TABLE public.analytics_jobs OWNER TO fleet_user;

--
-- Name: analytics_query_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.analytics_query_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid,
    query_type character varying(50) NOT NULL,
    parameters jsonb,
    duration_ms integer NOT NULL,
    row_count integer,
    cache_hit boolean DEFAULT false,
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.analytics_query_logs OWNER TO fleet_user;

--
-- Name: TABLE analytics_query_logs; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.analytics_query_logs IS 'Audit trail for all analytics query executions';


--
-- Name: analytics_query_plans; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.analytics_query_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    query_type text NOT NULL,
    query_params jsonb,
    execution_duration_ms bigint NOT NULL,
    query_plan text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.analytics_query_plans OWNER TO fleet_user;

--
-- Name: analytics_quotas; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.analytics_quotas (
    organization_id uuid NOT NULL,
    daily_limit bigint DEFAULT 10000,
    used_credits bigint DEFAULT 0,
    last_reset_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.analytics_quotas OWNER TO fleet_user;

--
-- Name: COLUMN analytics_quotas.daily_limit; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.analytics_quotas.daily_limit IS 'Dynamic limit that can be adjusted via support module during high load';


--
-- Name: api_clients; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.api_clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    client_id character varying(100) NOT NULL,
    client_secret_hash text NOT NULL,
    name character varying(255) NOT NULL,
    scopes text[] DEFAULT '{}'::text[],
    expiry timestamp with time zone,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.api_clients OWNER TO fleet_user;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    name text NOT NULL,
    prefix text NOT NULL,
    secret_hash text NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    revoked boolean DEFAULT false
);


ALTER TABLE public.api_keys OWNER TO fleet_user;

--
-- Name: approval_actions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.approval_actions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    instance_id uuid,
    approver_id uuid NOT NULL,
    action character varying(20) NOT NULL,
    level_index integer NOT NULL,
    comments text,
    action_time timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.approval_actions OWNER TO fleet_user;

--
-- Name: TABLE approval_actions; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.approval_actions IS 'Audit log of individual approval/rejection actions';


--
-- Name: approval_configs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.approval_configs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    entity_type character varying(50) NOT NULL,
    min_amount numeric(15,2) DEFAULT 0,
    max_amount numeric(15,2),
    levels jsonb NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.approval_configs OWNER TO fleet_user;

--
-- Name: TABLE approval_configs; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.approval_configs IS 'Configuration for multi-level approval workflows based on organization and amount';


--
-- Name: approval_instances; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.approval_instances (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    entity_id uuid NOT NULL,
    entity_type character varying(50) NOT NULL,
    config_id uuid,
    current_level_index integer DEFAULT 0,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.approval_instances OWNER TO fleet_user;

--
-- Name: TABLE approval_instances; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.approval_instances IS 'Running instances of approval workflows for specific entities';


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    resource character varying(100) NOT NULL,
    details jsonb,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    severity character varying(20) DEFAULT 'info'::character varying,
    status character varying(20) DEFAULT 'success'::character varying,
    org_id uuid,
    module character varying(100),
    entity_id character varying(100),
    before_state jsonb,
    after_state jsonb,
    metadata jsonb
);


ALTER TABLE public.audit_logs OWNER TO fleet_user;

--
-- Name: audit_policies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.audit_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    retention_years integer DEFAULT 7,
    archive_policy character varying(100) DEFAULT 'MOVE_TO_COLD_STORAGE_1Y'::character varying,
    masking_rules jsonb DEFAULT '["credit_card", "ssn", "phone", "email"]'::jsonb,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_policies OWNER TO fleet_user;

--
-- Name: audit_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.audit_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    retention_days_online integer DEFAULT 90,
    retention_days_archival integer DEFAULT 2555,
    masking_rules jsonb DEFAULT '["password", "secret", "token", "phone", "email_local"]'::jsonb,
    tracked_event_types jsonb DEFAULT '["MFA_POLICY_UPDATE", "MFA_EXCEPTION_GRANT", "MFA_OVERRIDE_TOGGLE", "LOGIN_SUCCESS", "LOGIN_FAILED"]'::jsonb,
    alert_on_critical boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_settings OWNER TO fleet_user;

--
-- Name: auth_audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.auth_audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_id uuid NOT NULL,
    actor_type text NOT NULL,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text NOT NULL,
    org_id uuid,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.auth_audit_logs OWNER TO fleet_user;

--
-- Name: auth_tokens; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.auth_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    access_token text NOT NULL,
    refresh_token text NOT NULL,
    device_id character varying(255),
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    ip_address character varying(45),
    user_agent text,
    last_active timestamp with time zone DEFAULT now(),
    is_active boolean DEFAULT true
);


ALTER TABLE public.auth_tokens OWNER TO fleet_user;

--
-- Name: backup_verifications; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.backup_verifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    backup_id uuid NOT NULL,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    checksum character varying(128),
    verified_at timestamp with time zone,
    verified_by uuid,
    error_message text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.backup_verifications OWNER TO fleet_user;

--
-- Name: backups; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.backups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    s3_key character varying(255) NOT NULL,
    size_bytes bigint DEFAULT 0 NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.backups OWNER TO fleet_user;

--
-- Name: bank_transactions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.bank_transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    bank_account_id character varying(50),
    transaction_id character varying(100),
    amount numeric(15,2) NOT NULL,
    currency character varying(3) DEFAULT 'INR'::character varying,
    transaction_date date NOT NULL,
    description text,
    category character varying(50),
    status character varying(20) DEFAULT 'UNRECONCILED'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.bank_transactions OWNER TO fleet_user;

--
-- Name: driver_behavior; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_behavior (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    driver_id uuid NOT NULL,
    org_id uuid NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    score double precision,
    safety_score double precision,
    efficiency_score double precision,
    compliance_score double precision,
    harsh_accelerations integer DEFAULT 0,
    harsh_brakings integer DEFAULT 0,
    harsh_cornerings integer DEFAULT 0,
    speeding_incidents integer DEFAULT 0,
    phone_usage integer DEFAULT 0,
    seatbelt_violations integer DEFAULT 0,
    fuel_consumption double precision DEFAULT 0,
    distance_driven double precision DEFAULT 0,
    idle_time integer DEFAULT 0,
    eco_driving_score double precision,
    hours_of_service double precision,
    rest_periods integer,
    document_compliance boolean DEFAULT true,
    maintenance_adherence boolean DEFAULT true,
    night_driving_hours double precision DEFAULT 0,
    highway_percentage double precision DEFAULT 0,
    city_driving_percentage double precision DEFAULT 0,
    risk_level character varying(20),
    risk_factors jsonb,
    improvement_areas jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_behavior OWNER TO fleet_user;

--
-- Name: TABLE driver_behavior; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.driver_behavior IS 'Driver behavior analytics and scoring';


--
-- Name: COLUMN driver_behavior.risk_level; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.driver_behavior.risk_level IS 'Risk assessment: low, medium, high, critical';


--
-- Name: behavior_score_trends; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.behavior_score_trends AS
 SELECT driver_behavior.driver_id,
    date_trunc('week'::text, driver_behavior.period_end) AS week,
    avg(driver_behavior.score) AS avg_score,
    avg(driver_behavior.safety_score) AS avg_safety_score,
    avg(driver_behavior.efficiency_score) AS avg_efficiency_score,
    avg(driver_behavior.compliance_score) AS avg_compliance_score,
    sum(driver_behavior.speeding_incidents) AS total_speeding,
    sum(driver_behavior.harsh_brakings) AS total_harsh_brakings,
    driver_behavior.risk_level
   FROM public.driver_behavior
  WHERE (driver_behavior.period_end >= (CURRENT_DATE - '90 days'::interval))
  GROUP BY driver_behavior.driver_id, (date_trunc('week'::text, driver_behavior.period_end)), driver_behavior.risk_level
  ORDER BY driver_behavior.driver_id, (date_trunc('week'::text, driver_behavior.period_end)) DESC;


ALTER VIEW public.behavior_score_trends OWNER TO fleet_user;

--
-- Name: behavior_score_updates; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.behavior_score_updates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    driver_id uuid NOT NULL,
    score_change integer NOT NULL,
    reason text NOT NULL,
    event_type character varying(50) NOT NULL,
    details jsonb,
    created_by character varying(100) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.behavior_score_updates OWNER TO fleet_user;

--
-- Name: TABLE behavior_score_updates; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.behavior_score_updates IS 'Audit trail for behavior score changes';


--
-- Name: billing_accounting_exports; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_accounting_exports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    external_system character varying(50) NOT NULL,
    export_type character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    file_key text,
    records_count integer DEFAULT 0 NOT NULL,
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp with time zone,
    created_by uuid
);


ALTER TABLE public.billing_accounting_exports OWNER TO fleet_user;

--
-- Name: billing_coupons; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_coupons (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    discount_type character varying(20) NOT NULL,
    discount_value numeric(15,4) NOT NULL,
    currency character varying(3),
    max_redemptions integer,
    redeemed_count integer DEFAULT 0 NOT NULL,
    valid_from timestamp with time zone,
    valid_until timestamp with time zone,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid
);


ALTER TABLE public.billing_coupons OWNER TO fleet_user;

--
-- Name: billing_credit_transactions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_credit_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    balance_id uuid NOT NULL,
    transaction_type character varying(50) NOT NULL,
    amount numeric(15,4) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    reference_type character varying(50),
    reference_id uuid,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid
);


ALTER TABLE public.billing_credit_transactions OWNER TO fleet_user;

--
-- Name: billing_customer_balances; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_customer_balances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    balance numeric(15,4) DEFAULT 0.0000 NOT NULL,
    credit_limit numeric(15,4) DEFAULT 0.0000 NOT NULL,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_customer_balances OWNER TO fleet_user;

--
-- Name: billing_hardware_products; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_hardware_products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    model_code character varying(100) NOT NULL,
    category character varying(50) NOT NULL,
    one_time_price numeric(15,2) NOT NULL,
    lease_monthly_price numeric(15,2),
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.billing_hardware_products OWNER TO fleet_user;

--
-- Name: billing_invoice_documents; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_invoice_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid NOT NULL,
    template_id uuid NOT NULL,
    file_url text NOT NULL,
    storage_key text NOT NULL,
    generated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    template_version integer DEFAULT 1 NOT NULL,
    snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    checksum text
);


ALTER TABLE public.billing_invoice_documents OWNER TO fleet_user;

--
-- Name: COLUMN billing_invoice_documents.snapshot; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.billing_invoice_documents.snapshot IS 'JSON snapshot of all data used for rendering this specific PDF version';


--
-- Name: COLUMN billing_invoice_documents.checksum; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.billing_invoice_documents.checksum IS 'SHA256 checksum of the generated PDF file for integrity verification';


--
-- Name: billing_invoice_sequences; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_invoice_sequences (
    org_id uuid NOT NULL,
    prefix character varying(20) DEFAULT 'INV-'::character varying NOT NULL,
    next_value bigint DEFAULT 1 NOT NULL,
    suffix character varying(20) DEFAULT ''::character varying,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_invoice_sequences OWNER TO fleet_user;

--
-- Name: billing_invoice_templates; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_invoice_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    version integer NOT NULL,
    html_content text NOT NULL,
    is_default boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_invoice_templates OWNER TO fleet_user;

--
-- Name: billing_plans; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_plans OWNER TO fleet_user;

--
-- Name: billing_pricing_components; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_pricing_components (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(20) NOT NULL,
    unit_price numeric(15,4) DEFAULT 0.0000 NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    meter_event_name character varying(50),
    frequency character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_pricing_components OWNER TO fleet_user;

--
-- Name: billing_recognized_revenue; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_recognized_revenue (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    schedule_id uuid NOT NULL,
    amount numeric(15,4) NOT NULL,
    recognized_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_recognized_revenue OWNER TO fleet_user;

--
-- Name: billing_revenue_schedules; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_revenue_schedules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    invoice_line_item_id uuid NOT NULL,
    total_amount numeric(15,4) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_revenue_schedules OWNER TO fleet_user;

--
-- Name: billing_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_settings (
    org_id uuid NOT NULL,
    default_tax_rate numeric(5,2) DEFAULT 0.00 NOT NULL,
    base_currency text DEFAULT 'USD'::text NOT NULL,
    grace_period_days integer DEFAULT 14 NOT NULL,
    auto_invoicing_enabled boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_settings OWNER TO fleet_user;

--
-- Name: TABLE billing_settings; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.billing_settings IS 'Organization-level billing configuration';


--
-- Name: billing_subscriptions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    current_period_start timestamp with time zone NOT NULL,
    current_period_end timestamp with time zone NOT NULL,
    trial_end timestamp with time zone,
    cancel_at_period_end boolean DEFAULT false NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_subscriptions OWNER TO fleet_user;

--
-- Name: billing_tax_rates; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_tax_rates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    region_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    percentage numeric(5,2) NOT NULL,
    tax_type character varying(50) NOT NULL,
    is_default boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_tax_rates OWNER TO fleet_user;

--
-- Name: billing_tax_regions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.billing_tax_regions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    country_code character varying(2) NOT NULL,
    state_code character varying(10),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_tax_regions OWNER TO fleet_user;

--
-- Name: blocked_ips; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.blocked_ips (
    ip_address inet NOT NULL,
    reason text,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.blocked_ips OWNER TO fleet_user;

--
-- Name: booking_requests; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.booking_requests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    request_type character varying(50) DEFAULT 'standard'::character varying,
    origin jsonb NOT NULL,
    destination jsonb NOT NULL,
    requested_pickup_time timestamp with time zone,
    cargo_details jsonb,
    status character varying(50) DEFAULT 'pending'::character varying,
    notes text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT chk_booking_requests_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying, 'converted'::character varying])::text[]))),
    CONSTRAINT chk_booking_requests_type CHECK (((request_type)::text = ANY ((ARRAY['standard'::character varying, 'express'::character varying, 'hazardous'::character varying])::text[])))
);


ALTER TABLE public.booking_requests OWNER TO fleet_user;

--
-- Name: CONSTRAINT chk_booking_requests_status ON booking_requests; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON CONSTRAINT chk_booking_requests_status ON public.booking_requests IS 'Valid booking status values';


--
-- Name: CONSTRAINT chk_booking_requests_type ON booking_requests; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON CONSTRAINT chk_booking_requests_type ON public.booking_requests IS 'Valid booking request types';


--
-- Name: bulk_config; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.bulk_config (
    organization_id uuid NOT NULL,
    max_records_per_file integer DEFAULT 5000,
    concurrent_threads integer DEFAULT 4,
    retention_months integer DEFAULT 6,
    mandatory_fields jsonb DEFAULT '["vin", "registration_no", "make", "model_year"]'::jsonb,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.bulk_config OWNER TO fleet_user;

--
-- Name: bulk_job_records; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.bulk_job_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id uuid NOT NULL,
    row_number integer NOT NULL,
    record_data jsonb,
    status character varying(50) NOT NULL,
    error_message text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT bulk_job_records_status_check CHECK (((status)::text = ANY ((ARRAY['success'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.bulk_job_records OWNER TO fleet_user;

--
-- Name: bulk_jobs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.bulk_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    file_name character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    total_records integer DEFAULT 0,
    success_count integer DEFAULT 0,
    failed_count integer DEFAULT 0,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    retry_count integer DEFAULT 0,
    CONSTRAINT bulk_jobs_status_check CHECK (((status)::text = ANY ((ARRAY['processing'::character varying, 'completed'::character varying, 'failed'::character varying, 'partial_success'::character varying])::text[])))
);


ALTER TABLE public.bulk_jobs OWNER TO fleet_user;

--
-- Name: compliance_reviews; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.compliance_reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    review_type character varying(50) NOT NULL,
    review_date timestamp with time zone NOT NULL,
    review_location text,
    fmcsa_representative text,
    overall_rating character varying(20),
    acute_violations integer DEFAULT 0,
    serious_violations integer DEFAULT 0,
    other_violations integer DEFAULT 0,
    unsafe_driving_score numeric(5,2),
    hos_compliance_score numeric(5,2),
    driver_fitness_score numeric(5,2),
    controlled_substances_score numeric(5,2),
    vehicle_maintenance_score numeric(5,2),
    hazmat_score numeric(5,2),
    crash_indicator_score numeric(5,2),
    corrective_action_required boolean DEFAULT false,
    corrective_action_plan text,
    follow_up_date date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    CONSTRAINT chk_overall_rating CHECK (((overall_rating)::text = ANY ((ARRAY['satisfactory'::character varying, 'conditional'::character varying, 'unsatisfactory'::character varying])::text[]))),
    CONSTRAINT chk_review_type CHECK (((review_type)::text = ANY ((ARRAY['compliance_review'::character varying, 'focused_review'::character varying, 'offsite_review'::character varying])::text[])))
);


ALTER TABLE public.compliance_reviews OWNER TO fleet_user;

--
-- Name: TABLE compliance_reviews; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.compliance_reviews IS 'FMCSA compliance review results';


--
-- Name: consumption_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.consumption_events (
    "time" timestamp with time zone NOT NULL,
    org_id uuid NOT NULL,
    vehicle_id uuid,
    meter_code character varying(50) NOT NULL,
    amount numeric(15,4) NOT NULL,
    metadata jsonb,
    processed_invoice_id uuid
);


ALTER TABLE public.consumption_events OWNER TO fleet_user;

--
-- Name: currency_rates; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.currency_rates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    from_currency character varying(3) NOT NULL,
    to_currency character varying(3) NOT NULL,
    rate numeric(18,6) NOT NULL,
    provider character varying(50),
    last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    currency_code character varying(3),
    org_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.currency_rates OWNER TO fleet_user;

--
-- Name: customer_audit_log; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    old_value jsonb,
    new_value jsonb,
    user_id uuid,
    user_type character varying(20),
    user_email character varying(255),
    ip_address inet,
    user_agent text,
    reason text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customer_audit_log OWNER TO fleet_user;

--
-- Name: TABLE customer_audit_log; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.customer_audit_log IS 'Audit trail for customer domain operations';


--
-- Name: COLUMN customer_audit_log.entity_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.customer_audit_log.entity_type IS 'Type of entity: customer, shipment, booking, invoice';


--
-- Name: COLUMN customer_audit_log.action; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.customer_audit_log.action IS 'Action performed: created, updated, deleted, status_changed';


--
-- Name: COLUMN customer_audit_log.old_value; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.customer_audit_log.old_value IS 'Previous state of entity (JSON)';


--
-- Name: COLUMN customer_audit_log.new_value; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.customer_audit_log.new_value IS 'New state of entity (JSON)';


--
-- Name: customer_audit_history; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.customer_audit_history AS
 SELECT customer_audit_log.id,
    customer_audit_log.org_id,
    customer_audit_log.entity_type,
    customer_audit_log.entity_id,
    customer_audit_log.action,
    customer_audit_log.old_value,
    customer_audit_log.new_value,
    customer_audit_log.user_id,
    customer_audit_log.user_type,
    customer_audit_log.user_email,
    customer_audit_log.ip_address,
    customer_audit_log.reason,
    customer_audit_log.created_at
   FROM public.customer_audit_log
  ORDER BY customer_audit_log.created_at DESC;


ALTER VIEW public.customer_audit_history OWNER TO fleet_user;

--
-- Name: customer_v2_booking_approvals; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_booking_approvals (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    booking_id uuid NOT NULL,
    approver_user_id uuid NOT NULL,
    approval_status character varying(50) DEFAULT 'PENDING'::character varying,
    approved_at timestamp with time zone,
    comments text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_booking_approvals OWNER TO fleet_user;

--
-- Name: customer_v2_booking_quotes; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_booking_quotes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    booking_id uuid NOT NULL,
    quote_amount numeric(12,2) NOT NULL,
    currency character varying(10) DEFAULT 'INR'::character varying,
    valid_until timestamp with time zone,
    status character varying(50) DEFAULT 'PENDING'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_booking_quotes OWNER TO fleet_user;

--
-- Name: customer_v2_booking_requests; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_booking_requests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    pickup_location jsonb NOT NULL,
    drop_location jsonb NOT NULL,
    cargo_type character varying(100),
    weight numeric(10,2),
    volume numeric(10,2),
    vehicle_type character varying(100),
    requested_pickup_time timestamp with time zone,
    status character varying(50) DEFAULT 'REQUESTED'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_booking_requests OWNER TO fleet_user;

--
-- Name: customer_v2_booking_shipments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_booking_shipments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    booking_id uuid NOT NULL,
    shipment_id uuid NOT NULL,
    sequence_number integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_booking_shipments OWNER TO fleet_user;

--
-- Name: customer_v2_booking_status_history; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_booking_status_history (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    booking_id uuid NOT NULL,
    previous_status character varying(50),
    new_status character varying(50) NOT NULL,
    changed_by uuid,
    changed_at timestamp with time zone DEFAULT now(),
    reason text
);


ALTER TABLE public.customer_v2_booking_status_history OWNER TO fleet_user;

--
-- Name: customer_v2_booking_validations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_booking_validations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    booking_id uuid NOT NULL,
    validation_type character varying(100) NOT NULL,
    status character varying(50) NOT NULL,
    details text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_booking_validations OWNER TO fleet_user;

--
-- Name: customer_v2_credit_limits; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_credit_limits (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    max_limit numeric(12,2) DEFAULT 0.00 NOT NULL,
    currency character varying(10) DEFAULT 'INR'::character varying,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_credit_limits OWNER TO fleet_user;

--
-- Name: customer_v2_credit_transactions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_credit_transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    wallet_id uuid NOT NULL,
    transaction_type character varying(50) NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency character varying(10) DEFAULT 'INR'::character varying,
    reference_id uuid,
    description text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_credit_transactions OWNER TO fleet_user;

--
-- Name: customer_v2_customer_addresses; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_customer_addresses (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    address_type character varying(50),
    address jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_customer_addresses OWNER TO fleet_user;

--
-- Name: customer_v2_customer_api_keys; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_customer_api_keys (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    key_name character varying(100) NOT NULL,
    api_key_hash character varying(255) NOT NULL,
    expires_at timestamp with time zone,
    status character varying(50) DEFAULT 'ACTIVE'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_customer_api_keys OWNER TO fleet_user;

--
-- Name: customer_v2_customer_api_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_customer_api_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    api_key_id uuid,
    endpoint character varying(255) NOT NULL,
    method character varying(10) NOT NULL,
    status_code integer,
    response_time_ms integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_customer_api_logs OWNER TO fleet_user;

--
-- Name: customer_v2_customer_audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_customer_audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    user_id uuid,
    event_type character varying(100) NOT NULL,
    resource_id uuid,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_customer_audit_logs OWNER TO fleet_user;

--
-- Name: customer_v2_customer_contacts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_customer_contacts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255),
    phone character varying(50),
    role character varying(100),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_customer_contacts OWNER TO fleet_user;

--
-- Name: customer_v2_customer_contracts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_customer_contracts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    contract_number character varying(100),
    valid_from date NOT NULL,
    valid_to date,
    terms jsonb,
    status character varying(50) DEFAULT 'ACTIVE'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_customer_contracts OWNER TO fleet_user;

--
-- Name: customer_v2_customer_credit_limits; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_customer_credit_limits (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    credit_limit numeric(12,2) DEFAULT 0.00 NOT NULL,
    available_credit numeric(12,2) DEFAULT 0.00 NOT NULL,
    currency character varying(10) DEFAULT 'INR'::character varying,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_customer_credit_limits OWNER TO fleet_user;

--
-- Name: customer_v2_customer_invoice_views; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_customer_invoice_views (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    invoice_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    downloaded_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_customer_invoice_views OWNER TO fleet_user;

--
-- Name: customer_v2_customer_sessions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_customer_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_customer_sessions OWNER TO fleet_user;

--
-- Name: customer_v2_customer_users; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_customer_users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(50),
    role character varying(50) DEFAULT 'VIEW_ONLY'::character varying,
    password_hash character varying(255) NOT NULL,
    status character varying(50) DEFAULT 'ACTIVE'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_customer_users OWNER TO fleet_user;

--
-- Name: customer_v2_customer_wallets; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_customer_wallets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    balance numeric(12,2) DEFAULT 0.00 NOT NULL,
    currency character varying(10) DEFAULT 'INR'::character varying,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_customer_wallets OWNER TO fleet_user;

--
-- Name: customer_v2_customers; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_customers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    company_name character varying(255) NOT NULL,
    gst_number character varying(50),
    billing_address jsonb,
    contact_email character varying(255),
    contact_phone character varying(50),
    status character varying(50) DEFAULT 'ACTIVE'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_customers OWNER TO fleet_user;

--
-- Name: customer_v2_delivery_proofs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_delivery_proofs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    shipment_id uuid NOT NULL,
    receiver_name character varying(255) NOT NULL,
    receiver_phone character varying(50),
    signature_url character varying(255),
    photo_url character varying(255),
    delivered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_delivery_proofs OWNER TO fleet_user;

--
-- Name: customer_v2_dispute_attachments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_dispute_attachments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    dispute_id uuid NOT NULL,
    message_id uuid,
    file_url character varying(255) NOT NULL,
    uploaded_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_dispute_attachments OWNER TO fleet_user;

--
-- Name: customer_v2_dispute_messages; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_dispute_messages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    dispute_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    sender_type character varying(50) NOT NULL,
    message text NOT NULL,
    sent_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_dispute_messages OWNER TO fleet_user;

--
-- Name: customer_v2_disputes; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_disputes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    shipment_id uuid,
    invoice_id uuid,
    status character varying(50) DEFAULT 'OPEN'::character varying,
    reason character varying(100) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone
);


ALTER TABLE public.customer_v2_disputes OWNER TO fleet_user;

--
-- Name: customer_v2_pod_images; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_pod_images (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    delivery_proof_id uuid NOT NULL,
    photo_url character varying(255) NOT NULL,
    uploaded_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_pod_images OWNER TO fleet_user;

--
-- Name: customer_v2_pod_signatures; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_pod_signatures (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    delivery_proof_id uuid NOT NULL,
    signature_url character varying(255) NOT NULL,
    signed_by character varying(255) NOT NULL,
    signed_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_pod_signatures OWNER TO fleet_user;

--
-- Name: customer_v2_pricing_components; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_pricing_components (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    rule_id uuid NOT NULL,
    component_type character varying(50) NOT NULL,
    value numeric(12,2) NOT NULL,
    is_percentage boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_pricing_components OWNER TO fleet_user;

--
-- Name: customer_v2_pricing_contracts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_pricing_contracts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    contract_name character varying(255) NOT NULL,
    valid_from date NOT NULL,
    valid_to date,
    status character varying(50) DEFAULT 'ACTIVE'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_pricing_contracts OWNER TO fleet_user;

--
-- Name: customer_v2_pricing_quotes; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_pricing_quotes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    booking_id uuid NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    currency character varying(10) DEFAULT 'INR'::character varying,
    breakdown jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_pricing_quotes OWNER TO fleet_user;

--
-- Name: customer_v2_pricing_rules; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_pricing_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    contract_id uuid NOT NULL,
    pricing_model character varying(50) NOT NULL,
    base_rate numeric(12,2) NOT NULL,
    currency character varying(10) DEFAULT 'INR'::character varying,
    conditions jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_pricing_rules OWNER TO fleet_user;

--
-- Name: customer_v2_shipment_document_versions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_shipment_document_versions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    document_id uuid NOT NULL,
    version_number integer NOT NULL,
    file_url character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_shipment_document_versions OWNER TO fleet_user;

--
-- Name: customer_v2_shipment_documents; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_shipment_documents (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    shipment_id uuid NOT NULL,
    document_type character varying(50) NOT NULL,
    file_url character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_shipment_documents OWNER TO fleet_user;

--
-- Name: customer_v2_shipment_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_shipment_events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    shipment_id uuid NOT NULL,
    event_type character varying(100) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    location jsonb,
    metadata jsonb
);


ALTER TABLE public.customer_v2_shipment_events OWNER TO fleet_user;

--
-- Name: customer_v2_shipment_sla_rules; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_shipment_sla_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    rule_name character varying(255) NOT NULL,
    metric character varying(50) NOT NULL,
    target_value numeric(10,2) NOT NULL,
    unit character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_shipment_sla_rules OWNER TO fleet_user;

--
-- Name: customer_v2_shipment_sla_violations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_shipment_sla_violations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    shipment_id uuid NOT NULL,
    rule_id uuid NOT NULL,
    actual_value numeric(10,2) NOT NULL,
    violated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_shipment_sla_violations OWNER TO fleet_user;

--
-- Name: customer_v2_shipment_status_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_shipment_status_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    shipment_id uuid NOT NULL,
    old_status character varying(50),
    new_status character varying(50) NOT NULL,
    changed_by uuid,
    changed_at timestamp with time zone DEFAULT now(),
    reason text
);


ALTER TABLE public.customer_v2_shipment_status_logs OWNER TO fleet_user;

--
-- Name: customer_v2_shipment_stops; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_shipment_stops (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    shipment_id uuid NOT NULL,
    stop_type character varying(50) NOT NULL,
    sequence integer NOT NULL,
    location jsonb NOT NULL,
    expected_arrival timestamp with time zone,
    actual_arrival timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.customer_v2_shipment_stops OWNER TO fleet_user;

--
-- Name: customer_v2_shipments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customer_v2_shipments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    trip_id uuid,
    booking_id uuid,
    status character varying(50) DEFAULT 'BOOKED'::character varying,
    origin jsonb NOT NULL,
    destination jsonb NOT NULL,
    distance_km numeric(10,2),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    eway_bill_number character varying(100),
    eway_bill_expiry timestamp with time zone,
    eway_bill_document character varying(255)
);


ALTER TABLE public.customer_v2_shipments OWNER TO fleet_user;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.customers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(50),
    api_key character varying(255),
    api_secret_hash character varying(255),
    address jsonb,
    billing_info jsonb,
    status character varying(50) DEFAULT 'active'::character varying,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    CONSTRAINT chk_customers_email_format CHECK (((email)::text ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'::text)),
    CONSTRAINT chk_customers_name_length CHECK (((length((name)::text) >= 2) AND (length((name)::text) <= 255))),
    CONSTRAINT chk_customers_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'suspended'::character varying])::text[])))
);


ALTER TABLE public.customers OWNER TO fleet_user;

--
-- Name: CONSTRAINT chk_customers_email_format ON customers; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON CONSTRAINT chk_customers_email_format ON public.customers IS 'Email must be valid format';


--
-- Name: CONSTRAINT chk_customers_name_length ON customers; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON CONSTRAINT chk_customers_name_length ON public.customers IS 'Name must be 2-255 characters';


--
-- Name: CONSTRAINT chk_customers_status ON customers; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON CONSTRAINT chk_customers_status ON public.customers IS 'Status must be active, inactive, or suspended';


--
-- Name: device_alerts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_alerts (
    id bigint NOT NULL,
    device_id uuid,
    alert_type text,
    severity text,
    alert_message text,
    created_at timestamp without time zone DEFAULT now(),
    resolved_at timestamp without time zone,
    CONSTRAINT device_alerts_severity_check CHECK ((severity = ANY (ARRAY['INFO'::text, 'WARNING'::text, 'CRITICAL'::text])))
);


ALTER TABLE public.device_alerts OWNER TO fleet_user;

--
-- Name: device_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: fleet_user
--

CREATE SEQUENCE public.device_alerts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.device_alerts_id_seq OWNER TO fleet_user;

--
-- Name: device_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleet_user
--

ALTER SEQUENCE public.device_alerts_id_seq OWNED BY public.device_alerts.id;


--
-- Name: device_auth_tokens; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_auth_tokens (
    device_id uuid NOT NULL,
    device_token text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.device_auth_tokens OWNER TO fleet_user;

--
-- Name: device_commands; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_id uuid,
    org_id uuid,
    command character varying(100) NOT NULL,
    category character varying(50),
    params jsonb,
    status character varying(20) DEFAULT 'pending'::character varying,
    result jsonb,
    error_message text,
    created_by uuid,
    sent_at timestamp with time zone,
    executed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.device_commands OWNER TO fleet_user;

--
-- Name: TABLE device_commands; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.device_commands IS 'Outbound command queue for device control channel';


--
-- Name: device_diagnostics_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_diagnostics_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_id uuid,
    org_id uuid,
    log_type character varying(50),
    source character varying(50),
    message text,
    metadata jsonb,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.device_diagnostics_logs OWNER TO fleet_user;

--
-- Name: device_firmware_status; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_firmware_status (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_id uuid,
    rollout_id uuid,
    status character varying(20) DEFAULT 'pending'::character varying,
    progress integer DEFAULT 0,
    error_message text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.device_firmware_status OWNER TO fleet_user;

--
-- Name: device_registry; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_registry (
    device_id character varying(100) NOT NULL,
    vehicle_id uuid,
    firmware_version character varying(50),
    sim_iccid character varying(30),
    carrier character varying(50),
    last_heartbeat timestamp with time zone,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    certificate_hash character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT device_registry_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'offline'::character varying, 'decommissioned'::character varying])::text[])))
);


ALTER TABLE public.device_registry OWNER TO fleet_user;

--
-- Name: TABLE device_registry; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.device_registry IS 'IoT device control plane: firmware, SIM, certificate, health';


--
-- Name: device_telemetry; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_telemetry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_id uuid,
    org_id uuid,
    payload jsonb NOT NULL,
    packet_type character varying(50),
    raw_hex text,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.device_telemetry OWNER TO fleet_user;

--
-- Name: device_twins; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_twins (
    device_id uuid NOT NULL,
    org_id uuid NOT NULL,
    desired_state jsonb DEFAULT '{}'::jsonb NOT NULL,
    reported_state jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_seen timestamp with time zone,
    drift_status character varying(20) DEFAULT 'unknown'::character varying NOT NULL,
    drift_reason text,
    last_command_id uuid,
    last_command_status character varying(32),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_device_twins_drift_status CHECK (((drift_status)::text = ANY ((ARRAY['in_sync'::character varying, 'drifted'::character varying, 'unknown'::character varying])::text[])))
);


ALTER TABLE public.device_twins OWNER TO fleet_user;

--
-- Name: devices; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    vehicle_id uuid,
    serial_number character varying(100) NOT NULL,
    type character varying(50) DEFAULT 'gps'::character varying,
    status character varying(20) DEFAULT 'active'::character varying,
    last_ping_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    firmware_version character varying(50),
    battery_level integer,
    signal_strength integer,
    hardware_revision character varying(20),
    last_heartbeat timestamp with time zone,
    model character varying(50),
    manufacturer character varying(50)
);


ALTER TABLE public.devices OWNER TO fleet_user;

--
-- Name: diagnostics_audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.diagnostics_audit_logs (
    id bigint NOT NULL,
    entity_type text,
    entity_id uuid,
    action text,
    actor_id uuid,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.diagnostics_audit_logs OWNER TO fleet_user;

--
-- Name: diagnostics_audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: fleet_user
--

CREATE SEQUENCE public.diagnostics_audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.diagnostics_audit_logs_id_seq OWNER TO fleet_user;

--
-- Name: diagnostics_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleet_user
--

ALTER SEQUENCE public.diagnostics_audit_logs_id_seq OWNED BY public.diagnostics_audit_logs.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    doc_number character varying(100) NOT NULL,
    issue_date date NOT NULL,
    expiry_date date NOT NULL,
    file_url text,
    status character varying(20) DEFAULT 'pending'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    org_id uuid,
    title character varying(255),
    file_name character varying(255) DEFAULT ''::character varying,
    file_size_bytes integer DEFAULT 0,
    mime_type character varying(100) DEFAULT 'application/octet-stream'::character varying,
    storage_path character varying(500) DEFAULT ''::character varying,
    reminder_days integer DEFAULT 30,
    uploaded_by uuid,
    deleted_at timestamp with time zone
);


ALTER TABLE public.documents OWNER TO fleet_user;

--
-- Name: TABLE documents; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.documents IS 'Stores compliance documents associated with vehicles';


--
-- Name: COLUMN documents.metadata; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.documents.metadata IS 'Flexible JSON storage for document-specific attributes';


--
-- Name: dot_inspection_mode; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.dot_inspection_mode (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    is_enabled boolean DEFAULT false,
    active_inspection_id uuid,
    default_roc_template uuid,
    default_violation_codes jsonb,
    safety_director_name text,
    safety_director_phone text,
    safety_director_email text,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by uuid
);


ALTER TABLE public.dot_inspection_mode OWNER TO fleet_user;

--
-- Name: dot_inspections; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.dot_inspections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    driver_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    inspection_date timestamp with time zone NOT NULL,
    inspection_level integer NOT NULL,
    inspection_location text,
    inspector_name text,
    inspector_agency text,
    inspector_id character varying(50),
    overall_status character varying(20) DEFAULT 'none'::character varying,
    violations_found integer DEFAULT 0,
    oos_violations integer DEFAULT 0,
    violation_details jsonb,
    was_eligible_for_time_credit boolean DEFAULT false,
    time_credit_minutes integer DEFAULT 0,
    roc_provided boolean DEFAULT false,
    medical_certificate_provided boolean DEFAULT false,
    cdl_provided boolean DEFAULT false,
    skill_performance_eval_provided boolean DEFAULT false,
    vehicle_oos boolean DEFAULT false,
    driver_oos boolean DEFAULT false,
    fine_amount numeric(10,2) DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by uuid,
    CONSTRAINT chk_inspection_level CHECK (((inspection_level >= 1) AND (inspection_level <= 6))),
    CONSTRAINT chk_overall_status CHECK (((overall_status)::text = ANY ((ARRAY['none'::character varying, 'warning'::character varying, 'out_of_service'::character varying])::text[])))
);


ALTER TABLE public.dot_inspections OWNER TO fleet_user;

--
-- Name: TABLE dot_inspections; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.dot_inspections IS 'DOT/FMCSA roadside inspection records';


--
-- Name: COLUMN dot_inspections.inspection_level; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.dot_inspections.inspection_level IS 'FMCSA inspection level (1-6): 1=Full, 2=Walk-Around, 3=Driver-Only, 4=Special, 5=Crash, 6=Enhanced';


--
-- Name: COLUMN dot_inspections.overall_status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.dot_inspections.overall_status IS 'Inspection result: none, warning, or out_of_service';


--
-- Name: dr_test_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.dr_test_logs (
    id uuid NOT NULL,
    test_id uuid NOT NULL,
    ts timestamp with time zone DEFAULT now() NOT NULL,
    level text NOT NULL,
    message text NOT NULL
);


ALTER TABLE public.dr_test_logs OWNER TO fleet_user;

--
-- Name: dr_test_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.dr_test_settings (
    id boolean DEFAULT true NOT NULL,
    schedule_enabled boolean DEFAULT false NOT NULL,
    frequency text DEFAULT 'WEEKLY'::text NOT NULL,
    schedule_day text DEFAULT 'SATURDAY'::text NOT NULL,
    schedule_time text DEFAULT '02:00'::text NOT NULL,
    intensity text DEFAULT 'NORMAL'::text NOT NULL,
    notification_emails jsonb DEFAULT '[]'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dr_test_settings_id_check CHECK ((id = true))
);


ALTER TABLE public.dr_test_settings OWNER TO fleet_user;

--
-- Name: dr_test_steps; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.dr_test_steps (
    id uuid NOT NULL,
    test_id uuid NOT NULL,
    step_order integer NOT NULL,
    step_name text NOT NULL,
    status text NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone
);


ALTER TABLE public.dr_test_steps OWNER TO fleet_user;

--
-- Name: dr_tests; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.dr_tests (
    id uuid NOT NULL,
    test_id text NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text,
    test_type text NOT NULL,
    target_env text NOT NULL,
    status text NOT NULL,
    progress_percent integer DEFAULT 0 NOT NULL,
    initiated_by text DEFAULT ''::text NOT NULL,
    success_criteria text DEFAULT ''::text,
    scheduled_at timestamp with time zone,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dr_tests OWNER TO fleet_user;

--
-- Name: driver_audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    driver_id uuid NOT NULL,
    org_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    old_value jsonb,
    new_value jsonb,
    user_id uuid NOT NULL,
    user_type character varying(20) NOT NULL,
    user_email character varying(255) NOT NULL,
    reason text,
    metadata jsonb,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.driver_audit_logs OWNER TO fleet_user;

--
-- Name: driver_behavior_analytics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_behavior_analytics (
    id character varying(36) NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    analysis_period_start date NOT NULL,
    analysis_period_end date NOT NULL,
    total_driving_hours numeric(8,2) DEFAULT 0 NOT NULL,
    aggressive_acceleration_count integer DEFAULT 0 NOT NULL,
    hard_braking_count integer DEFAULT 0 NOT NULL,
    sharp_turn_count integer DEFAULT 0 NOT NULL,
    over_speeding_count integer DEFAULT 0 NOT NULL,
    idling_time numeric(8,2) DEFAULT 0 NOT NULL,
    average_speed numeric(8,2) DEFAULT 0 NOT NULL,
    max_speed numeric(8,2) DEFAULT 0 NOT NULL,
    fuel_efficiency numeric(8,2) DEFAULT 0 NOT NULL,
    safety_score numeric(5,2) DEFAULT 0 NOT NULL,
    efficiency_score numeric(5,2) DEFAULT 0 NOT NULL,
    comfort_score numeric(5,2) DEFAULT 0 NOT NULL,
    ranking integer,
    improvement_suggestions jsonb DEFAULT '[]'::jsonb NOT NULL,
    behavior_trend character varying(20) DEFAULT 'stable'::character varying NOT NULL,
    generated_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT driver_behavior_analytics_comfort_score_check CHECK (((comfort_score >= (0)::numeric) AND (comfort_score <= (100)::numeric))),
    CONSTRAINT driver_behavior_analytics_efficiency_score_check CHECK (((efficiency_score >= (0)::numeric) AND (efficiency_score <= (100)::numeric))),
    CONSTRAINT driver_behavior_analytics_safety_score_check CHECK (((safety_score >= (0)::numeric) AND (safety_score <= (100)::numeric)))
);


ALTER TABLE public.driver_behavior_analytics OWNER TO fleet_user;

--
-- Name: driver_daily_stats; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_daily_stats (
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    date date NOT NULL,
    total_driving_hours numeric(15,2) DEFAULT 0,
    total_distance numeric(15,2) DEFAULT 0,
    total_idle_hours numeric(15,2) DEFAULT 0,
    safety_score numeric(5,2) DEFAULT 0,
    eco_score numeric(5,2) DEFAULT 0,
    violation_count integer DEFAULT 0,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.driver_daily_stats OWNER TO fleet_user;

--
-- Name: TABLE driver_daily_stats; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.driver_daily_stats IS 'Pre-aggregated daily metrics per driver';


--
-- Name: driver_expenses; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_expenses (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    driver_id uuid NOT NULL,
    trip_id uuid,
    type character varying(50) NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying,
    receipt_url text,
    notes text,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    transaction_date timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT driver_expenses_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'APPROVED'::character varying, 'REJECTED'::character varying])::text[])))
);


ALTER TABLE public.driver_expenses OWNER TO fleet_user;

--
-- Name: TABLE driver_expenses; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.driver_expenses IS 'Driver-incurred expenses';


--
-- Name: driver_fuel_limits; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_fuel_limits (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    daily_liters_limit numeric(10,2),
    monthly_liters_limit numeric(10,2),
    daily_amount_limit numeric(10,2),
    monthly_amount_limit numeric(10,2),
    currency character varying(3) DEFAULT 'INR'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.driver_fuel_limits OWNER TO fleet_user;

--
-- Name: TABLE driver_fuel_limits; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.driver_fuel_limits IS 'Daily and monthly fuel spending and volume limits per driver';


--
-- Name: driver_incidents; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_incidents (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    driver_id uuid NOT NULL,
    org_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    location jsonb,
    speed double precision,
    details jsonb,
    resolved boolean DEFAULT false,
    resolution_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_incidents OWNER TO fleet_user;

--
-- Name: TABLE driver_incidents; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.driver_incidents IS 'Specific driving incidents (speeding, harsh braking, etc.)';


--
-- Name: driver_messages; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_messages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    driver_id uuid NOT NULL,
    trip_id uuid,
    direction character varying(10) NOT NULL,
    type character varying(20) DEFAULT 'TEXT'::character varying NOT NULL,
    content text,
    attachment_url text,
    is_read boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT driver_messages_direction_check CHECK (((direction)::text = ANY ((ARRAY['INBOUND'::character varying, 'OUTBOUND'::character varying])::text[]))),
    CONSTRAINT driver_messages_type_check CHECK (((type)::text = ANY ((ARRAY['TEXT'::character varying, 'AUDIO'::character varying, 'IMAGE'::character varying])::text[])))
);


ALTER TABLE public.driver_messages OWNER TO fleet_user;

--
-- Name: TABLE driver_messages; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.driver_messages IS 'Messages between driver and dispatch';


--
-- Name: driver_mobile_sync_queue; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_mobile_sync_queue (
    id uuid NOT NULL,
    driver_id uuid NOT NULL,
    action_type character varying(50) NOT NULL,
    payload jsonb NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_mobile_sync_queue OWNER TO fleet_user;

--
-- Name: driver_onboarding_steps; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_onboarding_steps (
    id uuid NOT NULL,
    driver_id uuid NOT NULL,
    step character varying(50) NOT NULL,
    status character varying(30) NOT NULL,
    remarks text,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_onboarding_steps OWNER TO fleet_user;

--
-- Name: driver_payouts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_payouts (
    id uuid NOT NULL,
    driver_id uuid NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    paid_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_payouts OWNER TO fleet_user;

--
-- Name: drivers; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.drivers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    full_name character varying(100) GENERATED ALWAYS AS ((((first_name)::text || ' '::text) || (last_name)::text)) STORED,
    email character varying(100) NOT NULL,
    phone character varying(20) NOT NULL,
    license_number character varying(50) NOT NULL,
    license_type character varying(20),
    license_expiry timestamp with time zone,
    license_authority character varying(100),
    date_of_birth timestamp with time zone,
    address jsonb,
    emergency_contact jsonb,
    status character varying(20) DEFAULT 'active'::character varying,
    current_vehicle_id uuid,
    current_trip_id uuid,
    joining_date timestamp with time zone DEFAULT now(),
    resignation_date timestamp with time zone,
    experience_years integer DEFAULT 0,
    rating double precision DEFAULT 5.0,
    total_trips integer DEFAULT 0,
    total_distance_km double precision DEFAULT 0,
    total_hours_driven double precision DEFAULT 0,
    behavior_score integer DEFAULT 100,
    documents jsonb,
    attendance_records jsonb,
    schedules jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    created_by uuid,
    updated_by uuid,
    last_known_location jsonb,
    last_location_update timestamp with time zone,
    employee_code character varying(50),
    aadhaar_number character varying(12),
    pan_number character varying(10),
    license_issue_date date,
    employment_type character varying(20) DEFAULT 'FULL_TIME'::character varying,
    CONSTRAINT drivers_employment_type_check CHECK (((employment_type)::text = ANY ((ARRAY['FULL_TIME'::character varying, 'CONTRACT'::character varying])::text[])))
);


ALTER TABLE public.drivers OWNER TO fleet_user;

--
-- Name: TABLE drivers; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.drivers IS 'Driver profiles with license, behavior, and assignment tracking';


--
-- Name: COLUMN drivers.rating; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.drivers.rating IS 'Driver rating 0-5 stars';


--
-- Name: COLUMN drivers.behavior_score; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.drivers.behavior_score IS 'Overall behavior score 0-100';


--
-- Name: COLUMN drivers.employee_code; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.drivers.employee_code IS 'Internal employee identifier';


--
-- Name: COLUMN drivers.aadhaar_number; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.drivers.aadhaar_number IS 'Indian Aadhaar 12-digit UID';


--
-- Name: COLUMN drivers.pan_number; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.drivers.pan_number IS 'Indian PAN Permanent Account Number';


--
-- Name: COLUMN drivers.employment_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.drivers.employment_type IS 'FULL_TIME or CONTRACT employment status';


--
-- Name: driver_performance_summary; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.driver_performance_summary AS
 SELECT d.id,
    d.full_name,
    d.email,
    d.status,
    d.rating,
    d.behavior_score,
    d.total_trips,
    d.total_distance_km,
    d.total_hours_driven,
    d.current_vehicle_id,
    d.license_expiry,
        CASE
            WHEN (d.license_expiry < CURRENT_DATE) THEN false
            ELSE true
        END AS license_valid,
        CASE
            WHEN (d.current_vehicle_id IS NOT NULL) THEN true
            ELSE false
        END AS vehicle_assigned,
    COALESCE(max(dbr.created_at), d.created_at) AS last_active,
    COALESCE(avg(dbr.score), (0)::double precision) AS avg_behavior_score_30d
   FROM (public.drivers d
     LEFT JOIN public.driver_behavior dbr ON (((d.id = dbr.driver_id) AND (dbr.period_end >= (CURRENT_DATE - '30 days'::interval)))))
  WHERE (d.deleted_at IS NULL)
  GROUP BY d.id, d.full_name, d.email, d.status, d.rating, d.behavior_score, d.total_trips, d.total_distance_km, d.total_hours_driven, d.current_vehicle_id, d.license_expiry, d.created_at;


ALTER VIEW public.driver_performance_summary OWNER TO fleet_user;

--
-- Name: driver_ratings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_ratings (
    id uuid NOT NULL,
    driver_id uuid NOT NULL,
    trip_id uuid NOT NULL,
    punctuality_score integer,
    behavior_score integer,
    driving_score integer,
    overall_rating numeric(3,2) NOT NULL,
    comments text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT driver_ratings_behavior_score_check CHECK (((behavior_score >= 1) AND (behavior_score <= 5))),
    CONSTRAINT driver_ratings_driving_score_check CHECK (((driving_score >= 1) AND (driving_score <= 5))),
    CONSTRAINT driver_ratings_punctuality_score_check CHECK (((punctuality_score >= 1) AND (punctuality_score <= 5)))
);


ALTER TABLE public.driver_ratings OWNER TO fleet_user;

--
-- Name: driver_risk_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_risk_events (
    id uuid NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    risk_type text NOT NULL,
    score_delta double precision NOT NULL,
    metadata jsonb,
    event_time timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_risk_events OWNER TO fleet_user;

--
-- Name: driver_safety_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_safety_events (
    id uuid NOT NULL,
    driver_id uuid NOT NULL,
    trip_id uuid,
    event_type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    gps_lat numeric(9,6),
    gps_lng numeric(9,6),
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_safety_events OWNER TO fleet_user;

--
-- Name: driver_safety_leaderboard; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.driver_safety_leaderboard AS
 SELECT drivers.id AS driver_id,
    drivers.behavior_score AS avg_score
   FROM public.drivers
  ORDER BY drivers.behavior_score DESC;


ALTER VIEW public.driver_safety_leaderboard OWNER TO fleet_user;

--
-- Name: driver_salary; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_salary (
    id uuid NOT NULL,
    driver_id uuid NOT NULL,
    base_salary numeric(12,2) DEFAULT 0,
    per_km_rate numeric(12,2) DEFAULT 0,
    daily_allowance numeric(12,2) DEFAULT 0,
    night_allowance numeric(12,2) DEFAULT 0,
    effective_from date NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_salary OWNER TO fleet_user;

--
-- Name: driver_shift_assignments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_shift_assignments (
    id uuid NOT NULL,
    shift_id uuid,
    vehicle_id uuid,
    assigned_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_shift_assignments OWNER TO fleet_user;

--
-- Name: driver_shifts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_shifts (
    id uuid NOT NULL,
    driver_id uuid,
    shift_start timestamp with time zone NOT NULL,
    shift_end timestamp with time zone NOT NULL,
    shift_type character varying(20),
    status character varying(20),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_shifts OWNER TO fleet_user;

--
-- Name: driver_training_modules; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_training_modules (
    id uuid NOT NULL,
    name text NOT NULL,
    description text
);


ALTER TABLE public.driver_training_modules OWNER TO fleet_user;

--
-- Name: driver_training_records; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_training_records (
    id uuid NOT NULL,
    driver_id uuid NOT NULL,
    module_id uuid,
    completed_at timestamp with time zone,
    certificate_url text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_training_records OWNER TO fleet_user;

--
-- Name: driver_trip_earnings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_trip_earnings (
    id uuid NOT NULL,
    driver_id uuid NOT NULL,
    trip_id uuid NOT NULL,
    distance_km numeric(12,2) DEFAULT 0,
    earnings numeric(12,2) DEFAULT 0,
    bonus numeric(12,2) DEFAULT 0,
    penalty numeric(12,2) DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_trip_earnings OWNER TO fleet_user;

--
-- Name: driver_verifications; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_verifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    license_number character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    verification_date timestamp with time zone NOT NULL,
    name character varying(200) NOT NULL,
    father_name character varying(200),
    date_of_birth date NOT NULL,
    gender character varying(10),
    address text,
    city character varying(100),
    district character varying(100),
    state character varying(100),
    pin character varying(10),
    license_class text[],
    issue_date date NOT NULL,
    validity_from date NOT NULL,
    validity_to date NOT NULL,
    last_transaction character varying(100),
    enrollment_number character varying(100),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid NOT NULL,
    CONSTRAINT driver_verifications_status_check CHECK (((status)::text = ANY ((ARRAY['verified'::character varying, 'pending'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.driver_verifications OWNER TO fleet_user;

--
-- Name: TABLE driver_verifications; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.driver_verifications IS 'SARATHI driver license verification records';


--
-- Name: COLUMN driver_verifications.license_class; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.driver_verifications.license_class IS 'Array of license classes: MCWG, LMV, HMV, etc.';


--
-- Name: drivers_expiring_documents; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.drivers_expiring_documents AS
 SELECT d.id,
    d.full_name,
    d.email,
    d.license_number,
    d.license_expiry,
    d.status,
    d.phone,
        CASE
            WHEN (d.license_expiry < CURRENT_DATE) THEN 'expired'::text
            WHEN (d.license_expiry < (CURRENT_DATE + '30 days'::interval)) THEN 'expiring_soon'::text
            ELSE 'valid'::text
        END AS license_status,
    (d.license_expiry - (CURRENT_DATE)::timestamp with time zone) AS days_until_expiry
   FROM public.drivers d
  WHERE ((d.deleted_at IS NULL) AND (d.license_expiry < (CURRENT_DATE + '90 days'::interval)))
  ORDER BY d.license_expiry;


ALTER VIEW public.drivers_expiring_documents OWNER TO fleet_user;

--
-- Name: duty_status_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.duty_status_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    driver_id uuid NOT NULL,
    status character varying(50) NOT NULL,
    location jsonb,
    started_at timestamp with time zone NOT NULL,
    ended_at timestamp with time zone,
    duration_minutes integer,
    remarks text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    is_edit boolean DEFAULT false,
    edit_reason text,
    original_log_id uuid,
    edit_approved_by uuid,
    edit_approved_at timestamp with time zone,
    CONSTRAINT duty_status_logs_status_check CHECK (((status)::text = ANY ((ARRAY['OFF_DUTY'::character varying, 'SLEEPER_BERTH'::character varying, 'DRIVING'::character varying, 'ON_DUTY'::character varying])::text[])))
);


ALTER TABLE public.duty_status_logs OWNER TO fleet_user;

--
-- Name: TABLE duty_status_logs; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.duty_status_logs IS 'Hours of Service (HOOS) logs';


--
-- Name: COLUMN duty_status_logs.status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.duty_status_logs.status IS 'FMCSA duty status: OFF_DUTY, SLEEPER_BERTH, DRIVING, ON_DUTY';


--
-- Name: COLUMN duty_status_logs.is_edit; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.duty_status_logs.is_edit IS 'True if this is an edited version of a log';


--
-- Name: COLUMN duty_status_logs.edit_reason; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.duty_status_logs.edit_reason IS 'FMCSA requires reason for all edits';


--
-- Name: COLUMN duty_status_logs.original_log_id; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.duty_status_logs.original_log_id IS 'Reference to original log being edited';


--
-- Name: e_way_bills; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.e_way_bills (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    eway_bill_number character varying(20) NOT NULL,
    eway_bill_date timestamp with time zone NOT NULL,
    eway_bill_valid_till timestamp with time zone NOT NULL,
    document_number character varying(100) NOT NULL,
    document_date timestamp with time zone NOT NULL,
    document_type character varying(20) NOT NULL,
    goods_description text NOT NULL,
    goods_value numeric(15,2) NOT NULL,
    goods_tax_rate numeric(5,2) NOT NULL,
    goods_unit character varying(50) NOT NULL,
    goods_quantity numeric(15,3) NOT NULL,
    from_place character varying(200) NOT NULL,
    from_pincode character varying(10) NOT NULL,
    from_state_code integer NOT NULL,
    to_place character varying(200) NOT NULL,
    to_pincode character varying(10) NOT NULL,
    to_state_code integer NOT NULL,
    transporter_id character varying(50),
    transporter_name character varying(200),
    transport_mode character varying(20),
    transport_document_number character varying(100),
    transport_document_date date,
    transit_type character varying(20),
    vehicle_number character varying(20),
    vehicle_type character varying(10),
    remaining_distance numeric(10,2),
    user_gstin character varying(20) NOT NULL,
    recipient_gstin character varying(20),
    generated_by character varying(100) NOT NULL,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    cancelled boolean DEFAULT false NOT NULL,
    cancelled_by character varying(100),
    cancelled_on timestamp with time zone,
    cancelled_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid NOT NULL,
    CONSTRAINT e_way_bills_goods_quantity_check CHECK ((goods_quantity > (0)::numeric)),
    CONSTRAINT e_way_bills_goods_tax_rate_check CHECK ((goods_tax_rate >= (0)::numeric)),
    CONSTRAINT e_way_bills_goods_value_check CHECK ((goods_value > (0)::numeric)),
    CONSTRAINT e_way_bills_transit_type_check CHECK (((transit_type)::text = ANY ((ARRAY['own'::character varying, 'hired'::character varying, 'railways'::character varying])::text[]))),
    CONSTRAINT e_way_bills_transport_mode_check CHECK (((transport_mode)::text = ANY ((ARRAY['road'::character varying, 'rail'::character varying, 'air'::character varying, 'ship'::character varying])::text[]))),
    CONSTRAINT e_way_bills_vehicle_type_check CHECK (((vehicle_type)::text = ANY ((ARRAY['reg'::character varying, 'lr'::character varying, 'cn'::character varying])::text[])))
);


ALTER TABLE public.e_way_bills OWNER TO fleet_user;

--
-- Name: TABLE e_way_bills; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.e_way_bills IS 'E-Way Bill electronic goods movement permits';


--
-- Name: COLUMN e_way_bills.document_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.e_way_bills.document_type IS 'INV (Invoice), CHL (Challan), WBILL (Waybill), etc.';


--
-- Name: einvoice_config; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.einvoice_config (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    app_key character varying(255),
    secret_key character varying(255),
    username character varying(100),
    password character varying(255),
    is_enabled boolean DEFAULT false,
    environment character varying(20) DEFAULT 'sandbox'::character varying,
    gstin character varying(15),
    mandatory_above numeric(12,2) DEFAULT 50000,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_einvoice_gstin CHECK (((gstin IS NULL) OR (length((gstin)::text) = 15)))
);


ALTER TABLE public.einvoice_config OWNER TO fleet_user;

--
-- Name: TABLE einvoice_config; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.einvoice_config IS 'E-invoice configuration and NIC credentials';


--
-- Name: einvoice_irn; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.einvoice_irn (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid NOT NULL,
    org_id uuid NOT NULL,
    irn character varying(64),
    irn_status character varying(20) DEFAULT 'pending'::character varying,
    ack_no character varying(100),
    ack_dt timestamp with time zone,
    signed_response text,
    qr_code_str text,
    qr_code_image bytea,
    cancelled boolean DEFAULT false,
    cancelled_at timestamp with time zone,
    cancellation_reason text,
    retry_count integer DEFAULT 0,
    last_retry_at timestamp with time zone,
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by uuid,
    CONSTRAINT chk_einvoice_retry_count CHECK (((retry_count >= 0) AND (retry_count <= 5)))
);


ALTER TABLE public.einvoice_irn OWNER TO fleet_user;

--
-- Name: TABLE einvoice_irn; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.einvoice_irn IS 'E-invoice IRN (Invoice Reference Number) tracking for India GST';


--
-- Name: COLUMN einvoice_irn.irn; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.einvoice_irn.irn IS '64-character hash generated by NIC portal';


--
-- Name: COLUMN einvoice_irn.signed_response; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.einvoice_irn.signed_response IS 'Signed JSON response from NIC API';


--
-- Name: COLUMN einvoice_irn.qr_code_str; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.einvoice_irn.qr_code_str IS 'QR code string for printing on invoice';


--
-- Name: einvoice_item_mapping; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.einvoice_item_mapping (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    product_id uuid,
    hsn_code character varying(20) NOT NULL,
    sac_code character varying(20),
    nic_code character varying(20),
    gst_rate numeric(5,2),
    exemption_reason text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.einvoice_item_mapping OWNER TO fleet_user;

--
-- Name: TABLE einvoice_item_mapping; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.einvoice_item_mapping IS 'Product to HSN/SAC code mapping for e-invoicing';


--
-- Name: eld_diagnostic_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.eld_diagnostic_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    event_type character varying(50) NOT NULL,
    event_code character varying(20),
    event_description text,
    detected_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_diagnostic_event_type CHECK (((event_type)::text = ANY ((ARRAY['POWER_DATA_DIAGNOSTIC'::character varying, 'ENGINE_SYNC_DIAGNOSTIC'::character varying, 'TIMING_DIAGNOSTIC'::character varying, 'POSITION_DIAGNOSTIC'::character varying, 'DATA_TRANSFER_DIAGNOSTIC'::character varying])::text[])))
);


ALTER TABLE public.eld_diagnostic_events OWNER TO fleet_user;

--
-- Name: eld_malfunctions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.eld_malfunctions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid,
    malfunction_type character varying(50) NOT NULL,
    malfunction_code character varying(20),
    description text,
    status character varying(20) DEFAULT 'open'::character varying,
    detected_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    acknowledged_at timestamp with time zone,
    acknowledged_by uuid,
    resolved_at timestamp with time zone,
    resolved_by uuid,
    reported_to_carrier boolean DEFAULT false,
    reported_at timestamp with time zone,
    carrier_reference character varying(100),
    paper_logs_required boolean DEFAULT false,
    paper_logs_start timestamp with time zone,
    paper_logs_end timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    malfunction_category character varying(50),
    is_power_failure boolean DEFAULT false,
    is_engine_sync_failure boolean DEFAULT false,
    is_timing_failure boolean DEFAULT false,
    is_position_failure boolean DEFAULT false,
    is_data_transfer_failure boolean DEFAULT false,
    reported_to_fmcsa boolean DEFAULT false,
    fmcsa_reference character varying(100),
    CONSTRAINT chk_malfunction_status CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'acknowledged'::character varying, 'resolved'::character varying])::text[]))),
    CONSTRAINT chk_malfunction_type CHECK (((malfunction_type)::text = ANY ((ARRAY['POWER'::character varying, 'ENGINE_SYNC'::character varying, 'TIMING'::character varying, 'POSITION'::character varying, 'DATA_TRANSFER'::character varying, 'UNKNOWN'::character varying])::text[])))
);


ALTER TABLE public.eld_malfunctions OWNER TO fleet_user;

--
-- Name: COLUMN eld_malfunctions.malfunction_category; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.eld_malfunctions.malfunction_category IS 'POWER, ENGINE_SYNC, TIMING, POSITION, DATA_TRANSFER';


--
-- Name: COLUMN eld_malfunctions.reported_to_fmcsa; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.eld_malfunctions.reported_to_fmcsa IS 'FMCSA requires reporting within 24 hours';


--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.email_verification_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.email_verification_tokens OWNER TO fleet_user;

--
-- Name: emergency_audit_log; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.emergency_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    command_id uuid NOT NULL,
    action text NOT NULL,
    actor text NOT NULL,
    details text,
    ip_address text,
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.emergency_audit_log OWNER TO fleet_user;

--
-- Name: emergency_commands; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.emergency_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    command_id character varying(64) NOT NULL,
    command_type text NOT NULL,
    reason text,
    issued_by text NOT NULL,
    cleared_by text,
    issued_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    cleared_at timestamp with time zone,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.emergency_commands OWNER TO fleet_user;

--
-- Name: emergency_contacts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.emergency_contacts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    role text NOT NULL,
    phone text NOT NULL,
    email text,
    priority integer DEFAULT 1,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.emergency_contacts OWNER TO fleet_user;

--
-- Name: emergency_escalations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.emergency_escalations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    incident_id uuid NOT NULL,
    contact_id uuid NOT NULL,
    notification_channel character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'SENT'::character varying NOT NULL,
    attempted_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    responded_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT emergency_escalations_notification_channel_check CHECK (((notification_channel)::text = ANY ((ARRAY['SMS'::character varying, 'PHONE'::character varying, 'WHATSAPP'::character varying, 'PUSH'::character varying])::text[]))),
    CONSTRAINT emergency_escalations_status_check CHECK (((status)::text = ANY ((ARRAY['SENT'::character varying, 'DELIVERED'::character varying, 'FAILED'::character varying, 'RESPONDED'::character varying])::text[])))
);


ALTER TABLE public.emergency_escalations OWNER TO fleet_user;

--
-- Name: emergency_response_units; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.emergency_response_units (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    unit_type character varying(50) NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    coverage_city text,
    coverage_state text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT emergency_response_units_unit_type_check CHECK (((unit_type)::text = ANY ((ARRAY['POLICE'::character varying, 'AMBULANCE'::character varying, 'FIRE'::character varying, 'ROAD_ASSISTANCE'::character varying])::text[])))
);


ALTER TABLE public.emergency_response_units OWNER TO fleet_user;

--
-- Name: emergency_status; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.emergency_status (
    id integer NOT NULL,
    is_active boolean DEFAULT false,
    current_command_id uuid,
    last_halt_at timestamp with time zone,
    last_clear_at timestamp with time zone,
    halt_reason text,
    halt_issued_by text,
    clear_issued_by text,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT emergency_status_id_check CHECK ((id = 1))
);


ALTER TABLE public.emergency_status OWNER TO fleet_user;

--
-- Name: emergency_vehicle_state; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.emergency_vehicle_state (
    vehicle_id uuid NOT NULL,
    org_id uuid NOT NULL,
    halted boolean DEFAULT false,
    last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.emergency_vehicle_state OWNER TO fleet_user;

--
-- Name: entity_audit_history; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.entity_audit_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(100) NOT NULL,
    change_data jsonb NOT NULL,
    actor uuid,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.entity_audit_history OWNER TO fleet_user;

--
-- Name: erp_configs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.erp_configs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    endpoint_url text NOT NULL,
    auth_config jsonb NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.erp_configs OWNER TO fleet_user;

--
-- Name: evidence_exports; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.evidence_exports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    module character varying(50) NOT NULL,
    date_range_start timestamp with time zone,
    date_range_end timestamp with time zone,
    format character varying(20) DEFAULT 'pdf'::character varying,
    status character varying(20) DEFAULT 'processing'::character varying,
    requested_by uuid,
    file_url text,
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.evidence_exports OWNER TO fleet_user;

--
-- Name: expense_items; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.expense_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    report_id uuid NOT NULL,
    category character varying(30) NOT NULL,
    amount numeric(15,2) NOT NULL,
    gst_amount numeric(15,2) DEFAULT 0,
    gst_rate numeric(5,2) DEFAULT 0,
    receipt_url text,
    description text,
    vendor_name character varying(255),
    vendor_gstin character varying(15),
    transaction_date date DEFAULT CURRENT_DATE NOT NULL,
    ocr_processed boolean DEFAULT false,
    ocr_confidence numeric(4,2),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    org_id uuid,
    invoice_number character varying(100),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT expense_items_category_check CHECK (((category)::text = ANY ((ARRAY['FUEL'::character varying, 'MEALS'::character varying, 'LODGING'::character varying, 'TOLL'::character varying, 'MAINTENANCE'::character varying, 'OTHER'::character varying])::text[])))
);


ALTER TABLE public.expense_items OWNER TO fleet_user;

--
-- Name: TABLE expense_items; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.expense_items IS 'Granular line items for each expense report';


--
-- Name: expense_policies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.expense_policies (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    category character varying(50) NOT NULL,
    limit_amount numeric(10,2),
    currency character varying(3) DEFAULT 'USD'::character varying,
    requires_approval boolean DEFAULT true,
    receipt_required boolean DEFAULT true,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.expense_policies OWNER TO fleet_user;

--
-- Name: expense_reports; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.expense_reports (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    submitter_id uuid NOT NULL,
    period_start date,
    period_end date,
    total_amount numeric(10,2) DEFAULT 0,
    currency character varying(3) DEFAULT 'USD'::character varying,
    status character varying(20) DEFAULT 'DRAFT'::character varying,
    approved_by uuid,
    approval_date timestamp with time zone,
    rejection_reason text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    gst_number character varying(15),
    gst_rate numeric(5,2) DEFAULT 0,
    gst_amount numeric(10,2) DEFAULT 0,
    invoice_number character varying(100),
    vendor_gstin character varying(15),
    trip_id uuid,
    route_id uuid
);


ALTER TABLE public.expense_reports OWNER TO fleet_user;

--
-- Name: COLUMN expense_reports.gst_number; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.expense_reports.gst_number IS 'GSTIN associated with the expense';


--
-- Name: COLUMN expense_reports.trip_id; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.expense_reports.trip_id IS 'Associated trip ID';


--
-- Name: fastag_transactions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.fastag_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tag_number character varying(50) NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    transaction_id character varying(100) NOT NULL,
    transaction_type character varying(20) NOT NULL,
    amount numeric(10,2) NOT NULL,
    toll_plaza character varying(200) NOT NULL,
    toll_plaza_id character varying(50) NOT NULL,
    lane_id character varying(50) NOT NULL,
    transaction_time timestamp with time zone NOT NULL,
    transaction_date date NOT NULL,
    settlement_date date,
    status character varying(20) NOT NULL,
    error_code character varying(50),
    error_description text,
    reconciled boolean DEFAULT false NOT NULL,
    reconciliation_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid NOT NULL,
    CONSTRAINT fastag_transactions_amount_check CHECK ((amount >= (0)::numeric)),
    CONSTRAINT fastag_transactions_status_check CHECK (((status)::text = ANY ((ARRAY['success'::character varying, 'failed'::character varying, 'pending'::character varying])::text[]))),
    CONSTRAINT fastag_transactions_transaction_type_check CHECK (((transaction_type)::text = ANY ((ARRAY['debit'::character varying, 'credit'::character varying])::text[])))
);


ALTER TABLE public.fastag_transactions OWNER TO fleet_user;

--
-- Name: TABLE fastag_transactions; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.fastag_transactions IS 'FASTag electronic toll collection transactions';


--
-- Name: COLUMN fastag_transactions.transaction_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.fastag_transactions.transaction_type IS 'debit or credit transaction';


--
-- Name: COLUMN fastag_transactions.status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.fastag_transactions.status IS 'success, failed, or pending';


--
-- Name: finance_audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.finance_audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    entity_id uuid NOT NULL,
    entity_type character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    actor_id uuid,
    old_values jsonb,
    new_values jsonb,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.finance_audit_logs OWNER TO fleet_user;

--
-- Name: TABLE finance_audit_logs; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.finance_audit_logs IS 'Audit trail for all finance-related changes (expense reports, budgets, etc.)';


--
-- Name: trip_profitability; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.trip_profitability (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    trip_id uuid NOT NULL,
    org_id uuid NOT NULL,
    vehicle_id uuid,
    driver_id uuid,
    trip_revenue numeric(15,2) DEFAULT 0,
    fuel_cost numeric(15,2) DEFAULT 0,
    toll_cost numeric(15,2) DEFAULT 0,
    driver_cost numeric(15,2) DEFAULT 0,
    maintenance_cost numeric(15,2) DEFAULT 0,
    other_cost numeric(15,2) DEFAULT 0,
    total_cost numeric(15,2) GENERATED ALWAYS AS (((((fuel_cost + toll_cost) + driver_cost) + maintenance_cost) + other_cost)) STORED,
    profit numeric(15,2) GENERATED ALWAYS AS ((trip_revenue - ((((fuel_cost + toll_cost) + driver_cost) + maintenance_cost) + other_cost))) STORED,
    profit_margin numeric(5,2),
    distance_km numeric(10,2),
    cost_per_km numeric(10,4),
    calculated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.trip_profitability OWNER TO fleet_user;

--
-- Name: TABLE trip_profitability; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.trip_profitability IS 'Pre-calculated profitability metrics per trip';


--
-- Name: finance_dashboard_metrics; Type: MATERIALIZED VIEW; Schema: public; Owner: fleet_user
--

CREATE MATERIALIZED VIEW public.finance_dashboard_metrics AS
 SELECT o.org_id,
    date_trunc('month'::text, now()) AS metric_month,
    COALESCE(sum(tp.trip_revenue), (0)::numeric) AS total_revenue,
    COALESCE(sum(tp.fuel_cost), (0)::numeric) AS total_fuel_cost,
    COALESCE(sum(er.total_amount), (0)::numeric) AS total_expenses,
        CASE
            WHEN (sum(tp.trip_revenue) > (0)::numeric) THEN round((((sum(tp.trip_revenue) - sum(tp.total_cost)) / sum(tp.trip_revenue)) * (100)::numeric), 2)
            ELSE (0)::numeric
        END AS profit_margin,
        CASE
            WHEN (sum(tp.distance_km) > (0)::numeric) THEN round((sum(tp.total_cost) / sum(tp.distance_km)), 4)
            ELSE (0)::numeric
        END AS avg_cost_per_km
   FROM ((( SELECT DISTINCT trip_profitability.org_id
           FROM public.trip_profitability) o
     LEFT JOIN public.trip_profitability tp ON ((tp.org_id = o.org_id)))
     LEFT JOIN public.expense_reports er ON ((((er.metadata ->> 'org_id'::text) = (o.org_id)::text) OR ((er.org_id)::text = (o.org_id)::text))))
  GROUP BY o.org_id
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.finance_dashboard_metrics OWNER TO fleet_user;

--
-- Name: MATERIALIZED VIEW finance_dashboard_metrics; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON MATERIALIZED VIEW public.finance_dashboard_metrics IS 'Aggregated finance metrics per org, refreshed by FinanceMetricsWorker';


--
-- Name: fuel_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.fuel_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    station_name character varying(255) NOT NULL,
    fuel_type character varying(50) NOT NULL,
    quantity numeric(10,2) NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    total_cost numeric(10,2) NOT NULL,
    odometer numeric(10,2) NOT NULL,
    transaction_date timestamp with time zone NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    receipt_url text,
    notes text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    gst_number character varying(15),
    gst_rate numeric(5,2) DEFAULT 0,
    gst_amount numeric(10,2) DEFAULT 0,
    invoice_number character varying(100),
    vendor_gstin character varying(15),
    trip_id uuid,
    route_id uuid,
    vendor_id uuid,
    anomaly_flag boolean DEFAULT false,
    anomaly_reason text,
    fraud_score numeric(5,2) DEFAULT 0,
    risk_level character varying(10) DEFAULT 'LOW'::character varying,
    fraud_flags jsonb DEFAULT '[]'::jsonb,
    CONSTRAINT fuel_logs_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'APPROVED'::character varying, 'REJECTED'::character varying])::text[])))
);


ALTER TABLE public.fuel_logs OWNER TO fleet_user;

--
-- Name: TABLE fuel_logs; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.fuel_logs IS 'Fuel transaction logs for fleet vehicles';


--
-- Name: COLUMN fuel_logs.odometer; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.fuel_logs.odometer IS 'Vehicle odometer reading at time of fueling';


--
-- Name: COLUMN fuel_logs.status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.fuel_logs.status IS 'PENDING=awaiting approval, APPROVED=approved, REJECTED=rejected';


--
-- Name: COLUMN fuel_logs.gst_number; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.fuel_logs.gst_number IS 'GSTIN of the purchaser';


--
-- Name: COLUMN fuel_logs.vendor_gstin; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.fuel_logs.vendor_gstin IS 'GSTIN of the fuel station/vendor';


--
-- Name: COLUMN fuel_logs.trip_id; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.fuel_logs.trip_id IS 'Associated trip ID';


--
-- Name: COLUMN fuel_logs.anomaly_flag; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.fuel_logs.anomaly_flag IS 'Flagged if suspicion of theft or inefficiency detected by anomaly worker';


--
-- Name: COLUMN fuel_logs.anomaly_reason; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.fuel_logs.anomaly_reason IS 'Reason for flagging as anomalous';


--
-- Name: tds_records; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.tds_records (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    entity_type character varying(30) NOT NULL,
    entity_id uuid NOT NULL,
    vendor_id uuid,
    org_id uuid NOT NULL,
    pan_number character varying(10),
    tds_section character varying(10) DEFAULT '194C'::character varying,
    gross_amount numeric(15,2) NOT NULL,
    tds_rate numeric(5,2) NOT NULL,
    tds_amount numeric(15,2) NOT NULL,
    net_amount numeric(15,2) NOT NULL,
    deducted_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    deposited boolean DEFAULT false,
    deposit_challan character varying(50),
    financial_year character varying(10),
    quarter character varying(5),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tds_records OWNER TO fleet_user;

--
-- Name: TABLE tds_records; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.tds_records IS 'TDS deduction records for vendor payments per Indian tax law';


--
-- Name: finance_dashboard_summary; Type: MATERIALIZED VIEW; Schema: public; Owner: fleet_user
--

CREATE MATERIALIZED VIEW public.finance_dashboard_summary AS
 WITH monthly_fuel AS (
         SELECT fuel_logs.organization_id AS org_id,
            (date_trunc('month'::text, fuel_logs.transaction_date))::date AS month,
            sum(fuel_logs.total_cost) AS fuel_cost,
            count(*) AS fuel_count
           FROM public.fuel_logs
          GROUP BY fuel_logs.organization_id, ((date_trunc('month'::text, fuel_logs.transaction_date))::date)
        ), monthly_expenses AS (
         SELECT expense_items.org_id,
            (date_trunc('month'::text, (expense_items.transaction_date)::timestamp with time zone))::date AS month,
            sum(expense_items.amount) AS expense_cost,
            count(*) AS expense_count
           FROM public.expense_items
          GROUP BY expense_items.org_id, ((date_trunc('month'::text, (expense_items.transaction_date)::timestamp with time zone))::date)
        ), monthly_tds AS (
         SELECT tds_records.org_id,
            (date_trunc('month'::text, tds_records.deducted_at))::date AS month,
            sum(tds_records.tds_amount) AS tds_cost
           FROM public.tds_records
          GROUP BY tds_records.org_id, ((date_trunc('month'::text, tds_records.deducted_at))::date)
        )
 SELECT COALESCE(f.org_id, e.org_id, t.org_id) AS org_id,
    COALESCE(f.month, e.month, t.month) AS month,
    COALESCE(f.fuel_cost, (0)::numeric) AS total_fuel_cost,
    COALESCE(e.expense_cost, (0)::numeric) AS total_expense_cost,
    COALESCE(t.tds_cost, (0)::numeric) AS total_tds_deducted,
    (COALESCE(f.fuel_cost, (0)::numeric) + COALESCE(e.expense_cost, (0)::numeric)) AS total_cost,
    COALESCE(f.fuel_count, (0)::bigint) AS fuel_transaction_count,
    COALESCE(e.expense_count, (0)::bigint) AS expense_count,
    now() AS last_updated
   FROM ((monthly_fuel f
     FULL JOIN monthly_expenses e ON (((f.org_id = e.org_id) AND (f.month = e.month))))
     FULL JOIN monthly_tds t ON (((COALESCE(f.org_id, e.org_id) = t.org_id) AND (COALESCE(f.month, e.month) = t.month))))
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.finance_dashboard_summary OWNER TO fleet_user;

--
-- Name: finance_retention_policies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.finance_retention_policies (
    organization_id uuid NOT NULL,
    fuel_logs_retention_days integer DEFAULT 2555,
    expense_reports_retention_days integer DEFAULT 2555,
    audit_logs_retention_days integer DEFAULT 365,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.finance_retention_policies OWNER TO fleet_user;

--
-- Name: TABLE finance_retention_policies; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.finance_retention_policies IS 'Confirms how long financial records should be kept per organization';


--
-- Name: firmware_packages; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.firmware_packages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    version character varying(50) NOT NULL,
    hardware_target character varying(50) NOT NULL,
    file_url text NOT NULL,
    file_size integer,
    checksum character varying(64),
    release_notes text,
    status character varying(20) DEFAULT 'draft'::character varying,
    is_critical boolean DEFAULT false,
    released_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.firmware_packages OWNER TO fleet_user;

--
-- Name: firmware_rollout_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.firmware_rollout_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    rollout_id uuid NOT NULL,
    org_id uuid NOT NULL,
    event_type character varying(64) NOT NULL,
    from_status character varying(32),
    to_status character varying(32),
    actor_user_id uuid,
    message text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.firmware_rollout_events OWNER TO fleet_user;

--
-- Name: firmware_rollouts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.firmware_rollouts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    firmware_id uuid,
    org_id uuid,
    name character varying(100),
    device_group character varying(100),
    target_filter jsonb,
    total_devices integer DEFAULT 0,
    completed_devices integer DEFAULT 0,
    failed_devices integer DEFAULT 0,
    status character varying(20) DEFAULT 'scheduled'::character varying,
    rollout_strategy character varying(20) DEFAULT 'gradual'::character varying,
    max_concurrent integer DEFAULT 10,
    created_by uuid,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    failure_threshold integer DEFAULT 5,
    batch_size integer DEFAULT 100,
    rollback_enabled boolean DEFAULT false
);


ALTER TABLE public.firmware_rollouts OWNER TO fleet_user;

--
-- Name: fleet_analytics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.fleet_analytics (
    id character varying(36) NOT NULL,
    organization_id uuid NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    total_vehicles integer DEFAULT 0 NOT NULL,
    active_vehicles integer DEFAULT 0 NOT NULL,
    total_distance numeric(12,2) DEFAULT 0 NOT NULL,
    average_speed numeric(8,2) DEFAULT 0 NOT NULL,
    total_fuel_consumption numeric(12,2) DEFAULT 0 NOT NULL,
    average_fuel_efficiency numeric(8,2) DEFAULT 0 NOT NULL,
    total_trips integer DEFAULT 0 NOT NULL,
    completed_trips integer DEFAULT 0 NOT NULL,
    cancelled_trips integer DEFAULT 0 NOT NULL,
    average_trip_duration numeric(8,2) DEFAULT 0 NOT NULL,
    idle_time_percentage numeric(5,2) DEFAULT 0 NOT NULL,
    routing_efficiency numeric(5,2) DEFAULT 0 NOT NULL,
    fuel_cost numeric(12,2) DEFAULT 0 NOT NULL,
    maintenance_cost numeric(12,2) DEFAULT 0 NOT NULL,
    revenue numeric(15,2) DEFAULT 0 NOT NULL,
    profit_margin numeric(5,2) DEFAULT 0 NOT NULL,
    safety_score numeric(5,2) DEFAULT 0 NOT NULL,
    accidents_count integer DEFAULT 0 NOT NULL,
    incidents_count integer DEFAULT 0 NOT NULL,
    emergency_stops integer DEFAULT 0 NOT NULL,
    geofence_violations integer DEFAULT 0 NOT NULL,
    alerts_triggered integer DEFAULT 0 NOT NULL,
    data_points_collected bigint DEFAULT 0 NOT NULL,
    processing_time numeric(10,3) DEFAULT 0 NOT NULL,
    generated_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT fleet_analytics_idle_time_percentage_check CHECK (((idle_time_percentage >= (0)::numeric) AND (idle_time_percentage <= (100)::numeric))),
    CONSTRAINT fleet_analytics_routing_efficiency_check CHECK (((routing_efficiency >= (0)::numeric) AND (routing_efficiency <= (100)::numeric))),
    CONSTRAINT fleet_analytics_safety_score_check CHECK (((safety_score >= (0)::numeric) AND (safety_score <= (100)::numeric)))
);


ALTER TABLE public.fleet_analytics OWNER TO fleet_user;

--
-- Name: fleet_hourly_stats; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.fleet_hourly_stats (
    organization_id uuid NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    active_vehicles integer DEFAULT 0,
    total_distance numeric(15,2) DEFAULT 0,
    total_fuel_consumed numeric(15,2) DEFAULT 0,
    average_utilization numeric(5,2) DEFAULT 0,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.fleet_hourly_stats OWNER TO fleet_user;

--
-- Name: TABLE fleet_hourly_stats; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.fleet_hourly_stats IS 'Pre-aggregated hourly metrics for the entire fleet';


--
-- Name: fraud_incidents; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.fraud_incidents (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    entity_type character varying(30) NOT NULL,
    entity_id uuid NOT NULL,
    org_id uuid NOT NULL,
    vehicle_id uuid,
    driver_id uuid,
    fraud_score numeric(5,2) NOT NULL,
    risk_level character varying(10) NOT NULL,
    signals jsonb DEFAULT '[]'::jsonb,
    status character varying(20) DEFAULT 'OPEN'::character varying,
    investigated_by uuid,
    resolved_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.fraud_incidents OWNER TO fleet_user;

--
-- Name: TABLE fraud_incidents; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.fraud_incidents IS 'Fraud detected incidents from the risk scoring engine';


--
-- Name: fuel_audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.fuel_audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    fuel_log_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    changed_by uuid NOT NULL,
    changed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    old_values jsonb,
    new_values jsonb,
    diff jsonb,
    organization_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.fuel_audit_logs OWNER TO fleet_user;

--
-- Name: TABLE fuel_audit_logs; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.fuel_audit_logs IS 'Audit trail for fuel log changes';


--
-- Name: fuel_card_reconciliation; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.fuel_card_reconciliation (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    card_transaction_id uuid,
    internal_transaction_id uuid,
    org_id uuid NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    variance numeric(15,2) DEFAULT 0,
    card_amount numeric(15,2),
    internal_amount numeric(15,2),
    reconciled_by uuid,
    reconciled_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.fuel_card_reconciliation OWNER TO fleet_user;

--
-- Name: TABLE fuel_card_reconciliation; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.fuel_card_reconciliation IS 'Fuel card reconciliation - matches external card charges with internal fuel logs';


--
-- Name: fuel_card_transactions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.fuel_card_transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    vehicle_id uuid,
    card_id character varying(100) NOT NULL,
    provider character varying(50) NOT NULL,
    station character varying(255),
    liters numeric(10,2) NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'INR'::character varying,
    transaction_time timestamp with time zone NOT NULL,
    synced_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    external_transaction_id character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.fuel_card_transactions OWNER TO fleet_user;

--
-- Name: TABLE fuel_card_transactions; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.fuel_card_transactions IS 'Transactions synced from external fuel card providers (IOCL, HPCL, BPCL)';


--
-- Name: COLUMN fuel_card_transactions.provider; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.fuel_card_transactions.provider IS 'Indian fuel card providers: IOCL, HPCL, BPCL';


--
-- Name: fuel_consumption_by_driver; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.fuel_consumption_by_driver AS
 SELECT fuel_logs.organization_id,
    fuel_logs.driver_id,
    count(*) AS transaction_count,
    sum(fuel_logs.quantity) AS total_consumption,
    sum(fuel_logs.total_cost) AS total_cost,
    avg((fuel_logs.total_cost / NULLIF(fuel_logs.quantity, (0)::numeric))) AS avg_price,
    max(fuel_logs.transaction_date) AS last_fuel_date
   FROM public.fuel_logs
  WHERE ((fuel_logs.status)::text = 'APPROVED'::text)
  GROUP BY fuel_logs.organization_id, fuel_logs.driver_id;


ALTER VIEW public.fuel_consumption_by_driver OWNER TO fleet_user;

--
-- Name: fuel_consumption_by_type; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.fuel_consumption_by_type AS
 SELECT fuel_logs.organization_id,
    fuel_logs.fuel_type,
    count(*) AS transaction_count,
    sum(fuel_logs.quantity) AS total_consumption,
    sum(fuel_logs.total_cost) AS total_cost,
    avg((fuel_logs.total_cost / NULLIF(fuel_logs.quantity, (0)::numeric))) AS avg_price
   FROM public.fuel_logs
  WHERE ((fuel_logs.status)::text = 'APPROVED'::text)
  GROUP BY fuel_logs.organization_id, fuel_logs.fuel_type;


ALTER VIEW public.fuel_consumption_by_type OWNER TO fleet_user;

--
-- Name: fuel_consumption_by_vehicle; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.fuel_consumption_by_vehicle AS
 SELECT fuel_logs.organization_id,
    fuel_logs.vehicle_id,
    count(*) AS transaction_count,
    sum(fuel_logs.quantity) AS total_consumption,
    sum(fuel_logs.total_cost) AS total_cost,
    avg((fuel_logs.total_cost / NULLIF(fuel_logs.quantity, (0)::numeric))) AS avg_price,
    max(fuel_logs.transaction_date) AS last_fuel_date,
    max(fuel_logs.odometer) AS last_odometer
   FROM public.fuel_logs
  WHERE ((fuel_logs.status)::text = 'APPROVED'::text)
  GROUP BY fuel_logs.organization_id, fuel_logs.vehicle_id;


ALTER VIEW public.fuel_consumption_by_vehicle OWNER TO fleet_user;

--
-- Name: fuel_consumption_monthly; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.fuel_consumption_monthly AS
 SELECT fuel_logs.organization_id,
    date_trunc('month'::text, fuel_logs.transaction_date) AS month,
    count(*) AS transaction_count,
    sum(fuel_logs.quantity) AS total_consumption,
    sum(fuel_logs.total_cost) AS total_cost,
    avg((fuel_logs.total_cost / NULLIF(fuel_logs.quantity, (0)::numeric))) AS avg_price
   FROM public.fuel_logs
  WHERE ((fuel_logs.status)::text = 'APPROVED'::text)
  GROUP BY fuel_logs.organization_id, (date_trunc('month'::text, fuel_logs.transaction_date))
  ORDER BY (date_trunc('month'::text, fuel_logs.transaction_date)) DESC;


ALTER VIEW public.fuel_consumption_monthly OWNER TO fleet_user;

--
-- Name: fuel_efficiency_history; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.fuel_efficiency_history (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    vehicle_id uuid NOT NULL,
    distance numeric(10,2) NOT NULL,
    fuel_used numeric(10,2) NOT NULL,
    km_per_l numeric(10,2) NOT NULL,
    recorded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    anomaly_flag boolean DEFAULT false,
    anomaly_reason text
);


ALTER TABLE public.fuel_efficiency_history OWNER TO fleet_user;

--
-- Name: TABLE fuel_efficiency_history; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.fuel_efficiency_history IS 'Historical fuel efficiency data for anomaly detection';


--
-- Name: fuel_log_stats; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.fuel_log_stats AS
 SELECT fuel_logs.organization_id,
    count(*) FILTER (WHERE ((fuel_logs.status)::text = 'PENDING'::text)) AS pending_count,
    count(*) FILTER (WHERE ((fuel_logs.status)::text = 'APPROVED'::text)) AS approved_count,
    count(*) FILTER (WHERE ((fuel_logs.status)::text = 'REJECTED'::text)) AS rejected_count,
    sum(fuel_logs.quantity) FILTER (WHERE ((fuel_logs.status)::text = 'APPROVED'::text)) AS total_consumption,
    sum(fuel_logs.total_cost) FILTER (WHERE ((fuel_logs.status)::text = 'APPROVED'::text)) AS total_cost,
    avg((fuel_logs.total_cost / NULLIF(fuel_logs.quantity, (0)::numeric))) FILTER (WHERE ((fuel_logs.status)::text = 'APPROVED'::text)) AS avg_price_per_unit,
    count(DISTINCT fuel_logs.vehicle_id) AS unique_vehicles,
    count(DISTINCT fuel_logs.driver_id) AS unique_drivers
   FROM public.fuel_logs
  GROUP BY fuel_logs.organization_id;


ALTER VIEW public.fuel_log_stats OWNER TO fleet_user;

--
-- Name: fuel_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.fuel_settings (
    organization_id uuid NOT NULL,
    default_currency character varying(3) DEFAULT 'USD'::character varying,
    allowed_fuel_types jsonb DEFAULT '["diesel", "petrol-95", "adblue", "ev"]'::jsonb,
    validation_rules jsonb DEFAULT '{"odometer_check": true, "cost_calculation_verify": true}'::jsonb,
    auto_sync_enabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.fuel_settings OWNER TO fleet_user;

--
-- Name: TABLE fuel_settings; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.fuel_settings IS 'Organization-level fuel management settings';


--
-- Name: COLUMN fuel_settings.allowed_fuel_types; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.fuel_settings.allowed_fuel_types IS 'JSON array of allowed fuel types';


--
-- Name: COLUMN fuel_settings.validation_rules; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.fuel_settings.validation_rules IS 'JSON validation rules for fuel transactions';


--
-- Name: fuel_transactions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.fuel_transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid,
    card_id character varying(100),
    station_location character varying(255),
    liters numeric(10,2) NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying,
    odometer_reading numeric(10,2),
    efficiency_calculation numeric(10,2),
    anomaly_flag boolean DEFAULT false,
    transaction_date timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    gst_number character varying(15),
    gst_rate numeric(5,2) DEFAULT 0,
    gst_amount numeric(10,2) DEFAULT 0,
    invoice_number character varying(100),
    vendor_gstin character varying(15),
    trip_id uuid,
    route_id uuid,
    vendor_id uuid,
    fraud_score numeric(5,2) DEFAULT 0,
    risk_level character varying(10) DEFAULT 'LOW'::character varying,
    organization_id uuid NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    fraud_flags jsonb DEFAULT '[]'::jsonb
);


ALTER TABLE public.fuel_transactions OWNER TO fleet_user;

--
-- Name: COLUMN fuel_transactions.gst_number; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.fuel_transactions.gst_number IS 'GSTIN of the purchaser';


--
-- Name: COLUMN fuel_transactions.vendor_gstin; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.fuel_transactions.vendor_gstin IS 'GSTIN of the fuel station/vendor';


--
-- Name: fuel_vendors; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.fuel_vendors (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    gstin character varying(15),
    address text,
    contact_phone character varying(20),
    email character varying(255),
    status character varying(20) DEFAULT 'ACTIVE'::character varying,
    rating numeric(3,2) DEFAULT 0.0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.fuel_vendors OWNER TO fleet_user;

--
-- Name: TABLE fuel_vendors; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.fuel_vendors IS 'Fuel vendors and stations for procurement management';


--
-- Name: COLUMN fuel_vendors.gstin; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.fuel_vendors.gstin IS 'GST Identification Number of the vendor';


--
-- Name: geofence_assignments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.geofence_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    geofence_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    assignment_type character varying(20) NOT NULL,
    dwell_minutes integer,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT geofence_assignments_assignment_type_check CHECK (((assignment_type)::text = ANY ((ARRAY['enter'::character varying, 'exit'::character varying, 'dwell'::character varying, 'both'::character varying])::text[])))
);


ALTER TABLE public.geofence_assignments OWNER TO fleet_user;

--
-- Name: TABLE geofence_assignments; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.geofence_assignments IS 'Vehicle-specific geofence assignments';


--
-- Name: COLUMN geofence_assignments.assignment_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.geofence_assignments.assignment_type IS 'enter=alert on entry, exit=alert on exit, dwell=alert after dwell time, both=enter+exit';


--
-- Name: geofence_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.geofence_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "time" timestamp with time zone NOT NULL,
    vehicle_id uuid NOT NULL,
    geofence_id uuid NOT NULL,
    event_type character varying(20) NOT NULL,
    location public.geography(Point,4326),
    duration_minutes integer,
    speed_kmh numeric(5,2),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT geofence_events_event_type_check CHECK (((event_type)::text = ANY ((ARRAY['enter'::character varying, 'exit'::character varying, 'dwell'::character varying, 'speed'::character varying])::text[])))
);


ALTER TABLE public.geofence_events OWNER TO fleet_user;

--
-- Name: TABLE geofence_events; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.geofence_events IS 'Geofence entry/exit/dwell events (time-series)';


--
-- Name: geofences; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.geofences (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(20) NOT NULL,
    center jsonb,
    radius_meters integer,
    coordinates jsonb,
    route_polyline text,
    buffer_meters integer,
    entry_alert boolean DEFAULT true,
    exit_alert boolean DEFAULT true,
    speed_limit integer,
    vehicles jsonb,
    enabled boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    active_hours jsonb,
    active boolean DEFAULT true
);


ALTER TABLE public.geofences OWNER TO fleet_user;

--
-- Name: TABLE geofences; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.geofences IS 'Geographic boundaries for vehicle monitoring';


--
-- Name: COLUMN geofences.type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.geofences.type IS 'circle=point+radius, polygon=polygon, route_corridor=polyline+buffer';


--
-- Name: COLUMN geofences.center; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.geofences.center IS 'Center point for circle geofences (longitude, latitude)';


--
-- Name: COLUMN geofences.coordinates; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.geofences.coordinates IS 'Polygon coordinates for polygon geofences';


--
-- Name: COLUMN geofences.route_polyline; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.geofences.route_polyline IS 'Encoded polyline for route corridors';


--
-- Name: geofence_stats; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.geofence_stats AS
 SELECT g.id,
    g.org_id,
    g.name,
    g.type,
    g.enabled,
    count(DISTINCT ga.vehicle_id) FILTER (WHERE (ga.is_active = true)) AS assigned_vehicles,
    count(ge.id) FILTER (WHERE (ge."time" >= (now() - '24:00:00'::interval))) AS events_24h,
    count(ge.id) FILTER (WHERE (((ge.event_type)::text = 'enter'::text) AND (ge."time" >= (now() - '24:00:00'::interval)))) AS entries_24h,
    count(ge.id) FILTER (WHERE (((ge.event_type)::text = 'exit'::text) AND (ge."time" >= (now() - '24:00:00'::interval)))) AS exits_24h
   FROM ((public.geofences g
     LEFT JOIN public.geofence_assignments ga ON ((ga.geofence_id = g.id)))
     LEFT JOIN public.geofence_events ge ON ((ge.geofence_id = g.id)))
  GROUP BY g.id, g.org_id, g.name, g.type, g.enabled;


ALTER VIEW public.geofence_stats OWNER TO fleet_user;

--
-- Name: global_notification_defaults; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.global_notification_defaults (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email_enabled boolean DEFAULT true NOT NULL,
    sms_enabled boolean DEFAULT false NOT NULL,
    push_enabled boolean DEFAULT true NOT NULL,
    in_app_enabled boolean DEFAULT true NOT NULL,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.global_notification_defaults OWNER TO fleet_user;

--
-- Name: governance_audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.governance_audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    action text NOT NULL,
    module text NOT NULL,
    change_detail text,
    ip_address inet,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.governance_audit_logs OWNER TO fleet_user;

--
-- Name: TABLE governance_audit_logs; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.governance_audit_logs IS 'Audit trail for all governance-related actions for compliance reporting';


--
-- Name: COLUMN governance_audit_logs.action; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.governance_audit_logs.action IS 'Action performed: CREATE_REQUEST, APPROVE_REQUEST, REJECT_REQUEST, UPDATE_SETTINGS, etc.';


--
-- Name: COLUMN governance_audit_logs.module; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.governance_audit_logs.module IS 'Module affected: DATA_REQUESTS, GOVERNANCE_SETTINGS, etc.';


--
-- Name: COLUMN governance_audit_logs.change_detail; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.governance_audit_logs.change_detail IS 'Details of what changed (e.g., approval notes)';


--
-- Name: governance_compliance_reports; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.governance_compliance_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_id uuid,
    export_checksum text,
    export_size_bytes bigint,
    processing_time_ms integer,
    tables_accessed jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.governance_compliance_reports OWNER TO fleet_user;

--
-- Name: governance_download_tokens; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.governance_download_tokens (
    token uuid DEFAULT gen_random_uuid() NOT NULL,
    export_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.governance_download_tokens OWNER TO fleet_user;

--
-- Name: TABLE governance_download_tokens; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.governance_download_tokens IS 'Secure short-lived tokens for downloading exports';


--
-- Name: governance_export_lineage; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.governance_export_lineage (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_id uuid,
    table_name text NOT NULL,
    record_count integer,
    export_size_bytes bigint,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.governance_export_lineage OWNER TO fleet_user;

--
-- Name: governance_exports; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.governance_exports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_id uuid NOT NULL,
    file_path text NOT NULL,
    file_size bigint,
    checksum text,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.governance_exports OWNER TO fleet_user;

--
-- Name: TABLE governance_exports; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.governance_exports IS 'Stores metadata for generated data exports';


--
-- Name: governance_requests; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.governance_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    requester_id uuid NOT NULL,
    request_type public.governance_request_type NOT NULL,
    data_scope text NOT NULL,
    purpose text NOT NULL,
    format text DEFAULT 'CSV'::text NOT NULL,
    delivery_method text DEFAULT 'DIRECT'::text NOT NULL,
    status public.governance_request_status DEFAULT 'PENDING'::public.governance_request_status NOT NULL,
    expiry_date timestamp with time zone,
    comments text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    verification_status text DEFAULT 'PENDING'::text,
    verified_at timestamp with time zone,
    verified_by uuid,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.governance_requests OWNER TO fleet_user;

--
-- Name: TABLE governance_requests; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.governance_requests IS 'Stores data governance requests for export, deletion, and access review workflows';


--
-- Name: COLUMN governance_requests.request_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.governance_requests.request_type IS 'Type of governance request: EXPORT, DELETION, or ACCESS_REVIEW';


--
-- Name: COLUMN governance_requests.data_scope; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.governance_requests.data_scope IS 'Description of data covered by the request';


--
-- Name: COLUMN governance_requests.purpose; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.governance_requests.purpose IS 'Business justification for the request';


--
-- Name: COLUMN governance_requests.status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.governance_requests.status IS 'Current status: PENDING, APPROVED, REJECTED, EXPIRED, or COMPLETED';


--
-- Name: COLUMN governance_requests.expiry_date; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.governance_requests.expiry_date IS 'Date when approved request expires and data should be deleted';


--
-- Name: governance_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.governance_settings (
    organization_id uuid NOT NULL,
    retention_policies jsonb DEFAULT '{}'::jsonb NOT NULL,
    masking_rules jsonb DEFAULT '{}'::jsonb NOT NULL,
    auto_expiry_enabled boolean DEFAULT true NOT NULL,
    download_ttl_hours integer DEFAULT 48 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.governance_settings OWNER TO fleet_user;

--
-- Name: TABLE governance_settings; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.governance_settings IS 'Organization-level governance configuration including retention policies and masking rules';


--
-- Name: COLUMN governance_settings.retention_policies; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.governance_settings.retention_policies IS 'JSON configuration for data retention rules';


--
-- Name: COLUMN governance_settings.masking_rules; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.governance_settings.masking_rules IS 'JSON configuration for data masking requirements';


--
-- Name: COLUMN governance_settings.download_ttl_hours; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.governance_settings.download_ttl_hours IS 'Hours before approved export links expire (default: 48)';


--
-- Name: gps_locations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.gps_locations (
    "time" timestamp with time zone NOT NULL,
    vehicle_id uuid NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    altitude double precision,
    speed double precision,
    heading double precision,
    accuracy double precision,
    ignition boolean,
    odometer double precision,
    battery_level double precision,
    satellites integer,
    raw_data jsonb
);


ALTER TABLE public.gps_locations OWNER TO fleet_user;

--
-- Name: TABLE gps_locations; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.gps_locations IS 'Stores raw GPS telemetry from vehicles';


--
-- Name: gst_compliances; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.gst_compliances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    gstin character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    legal_name character varying(200) NOT NULL,
    trade_name character varying(200),
    address text NOT NULL,
    centre_jurisdiction character varying(200),
    state_jurisdiction character varying(200),
    date_of_registration timestamp with time zone NOT NULL,
    date_of_cancellation timestamp with time zone,
    last_updated timestamp with time zone NOT NULL,
    return_filing_frequency character varying(20),
    return_filing_status character varying(30),
    payment_status character varying(30),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid NOT NULL,
    CONSTRAINT gst_compliances_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'cancelled'::character varying, 'suspended'::character varying])::text[])))
);


ALTER TABLE public.gst_compliances OWNER TO fleet_user;

--
-- Name: TABLE gst_compliances; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.gst_compliances IS 'GST compliance status and filing records';


--
-- Name: COLUMN gst_compliances.return_filing_status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.gst_compliances.return_filing_status IS 'compliant or non_compliant with filing requirements';


--
-- Name: gst_invoices; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.gst_invoices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    invoice_number character varying(50) NOT NULL,
    irn character varying(64),
    ack_number character varying(30),
    ack_date timestamp with time zone,
    qr_code text,
    signed_invoice text,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    entity_type character varying(30),
    entity_id uuid,
    org_id uuid NOT NULL,
    gstin character varying(15) NOT NULL,
    buyer_gstin character varying(15),
    total_amount numeric(15,2) DEFAULT 0 NOT NULL,
    taxable_amount numeric(15,2) DEFAULT 0 NOT NULL,
    cgst_amount numeric(15,2) DEFAULT 0,
    sgst_amount numeric(15,2) DEFAULT 0,
    igst_amount numeric(15,2) DEFAULT 0,
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.gst_invoices OWNER TO fleet_user;

--
-- Name: TABLE gst_invoices; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.gst_invoices IS 'GST e-invoices with IRN from Invoice Registration Portal';


--
-- Name: health_history; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.health_history (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    component character varying(100) NOT NULL,
    status character varying(20) NOT NULL,
    response_time_ms integer,
    error text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT health_history_status_check CHECK (((status)::text = ANY ((ARRAY['up'::character varying, 'down'::character varying, 'degraded'::character varying, 'not_configured'::character varying])::text[])))
);


ALTER TABLE public.health_history OWNER TO fleet_user;

--
-- Name: TABLE health_history; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.health_history IS 'Historical health check results for trend analysis';


--
-- Name: COLUMN health_history.status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.health_history.status IS 'up=healthy, down=unhealthy, degraded=partial, not_configured=not monitored';


--
-- Name: historical_demand; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.historical_demand (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    route_id text NOT NULL,
    date date NOT NULL,
    hour integer NOT NULL,
    demand_count integer DEFAULT 0 NOT NULL,
    avg_price numeric(10,2),
    weather_condition text,
    is_holiday boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT historical_demand_hour_check CHECK (((hour >= 0) AND (hour <= 23)))
);


ALTER TABLE public.historical_demand OWNER TO fleet_user;

--
-- Name: hos_annotations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.hos_annotations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    duty_status_log_id uuid NOT NULL,
    annotation_type character varying(20) NOT NULL,
    reason text NOT NULL,
    original_data jsonb,
    new_data jsonb,
    requires_approval boolean DEFAULT false,
    approved_by uuid,
    approved_at timestamp with time zone,
    approval_status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    CONSTRAINT chk_annotation_type CHECK (((annotation_type)::text = ANY ((ARRAY['edit'::character varying, 'unassigned_driving'::character varying, 'co_driver_assignment'::character varying, 'duty_status_change'::character varying])::text[])))
);


ALTER TABLE public.hos_annotations OWNER TO fleet_user;

--
-- Name: hos_daily_limits; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.hos_daily_limits (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    driver_id uuid NOT NULL,
    date date NOT NULL,
    driving_used_minutes integer DEFAULT 0,
    driving_limit_minutes integer DEFAULT 660,
    driving_remaining_minutes integer GENERATED ALWAYS AS ((driving_limit_minutes - driving_used_minutes)) STORED,
    on_duty_used_minutes integer DEFAULT 0,
    on_duty_limit_minutes integer DEFAULT 840,
    on_duty_remaining_minutes integer GENERATED ALWAYS AS ((on_duty_limit_minutes - on_duty_used_minutes)) STORED,
    seventy_hour_used_minutes integer DEFAULT 0,
    seventy_hour_limit_minutes integer DEFAULT 4200,
    seventy_hour_remaining_minutes integer GENERATED ALWAYS AS ((seventy_hour_limit_minutes - seventy_hour_used_minutes)) STORED,
    last_break_duration_minutes integer DEFAULT 0,
    last_break_start timestamp with time zone,
    hours_since_break integer DEFAULT 0,
    break_required boolean DEFAULT false,
    restart_available boolean DEFAULT false,
    restart_taken_at timestamp with time zone,
    restart_eligible_at timestamp with time zone,
    is_violation boolean DEFAULT false,
    violation_details jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_driving_used CHECK ((driving_used_minutes >= 0)),
    CONSTRAINT chk_on_duty_used CHECK ((on_duty_used_minutes >= 0)),
    CONSTRAINT chk_seventy_hour_used CHECK ((seventy_hour_used_minutes >= 0))
);


ALTER TABLE public.hos_daily_limits OWNER TO fleet_user;

--
-- Name: id_mappings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.id_mappings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    erp_config_id uuid,
    entity_type text NOT NULL,
    local_id uuid NOT NULL,
    remote_id text NOT NULL,
    last_synced_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.id_mappings OWNER TO fleet_user;

--
-- Name: impersonation_sessions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.impersonation_sessions (
    id uuid NOT NULL,
    admin_id uuid NOT NULL,
    user_id uuid NOT NULL,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    audit_log_id uuid
);


ALTER TABLE public.impersonation_sessions OWNER TO fleet_user;

--
-- Name: incident_comments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.incident_comments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ticket_id uuid NOT NULL,
    author_id uuid,
    author_name character varying(100),
    comment_type character varying(20) DEFAULT 'INTERNAL'::character varying,
    content text NOT NULL,
    is_private boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.incident_comments OWNER TO fleet_user;

--
-- Name: TABLE incident_comments; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.incident_comments IS 'Comments and history for support tickets';


--
-- Name: incident_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.incident_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    incident_id uuid NOT NULL,
    user_id uuid,
    action text NOT NULL,
    notes text,
    "timestamp" timestamp with time zone DEFAULT now()
);


ALTER TABLE public.incident_logs OWNER TO fleet_user;

--
-- Name: incident_media; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.incident_media (
    id uuid NOT NULL,
    incident_id uuid NOT NULL,
    media_type character varying(20) NOT NULL,
    file_url text NOT NULL,
    uploaded_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.incident_media OWNER TO fleet_user;

--
-- Name: incident_timeline; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.incident_timeline (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    incident_id uuid NOT NULL,
    event_type character varying(50) NOT NULL,
    actor character varying(100) NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.incident_timeline OWNER TO fleet_user;

--
-- Name: incident_updates; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.incident_updates (
    id uuid NOT NULL,
    incident_id uuid NOT NULL,
    update_message text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.incident_updates OWNER TO fleet_user;

--
-- Name: incident_vehicle_snapshot; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.incident_vehicle_snapshot (
    incident_id uuid NOT NULL,
    speed integer,
    heading integer,
    engine_status boolean,
    fuel_level integer,
    battery_voltage double precision,
    gps_accuracy double precision,
    device_signal_strength integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.incident_vehicle_snapshot OWNER TO fleet_user;

--
-- Name: incidents; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.incidents (
    id uuid NOT NULL,
    severity text NOT NULL,
    status text NOT NULL,
    description text NOT NULL,
    detected_at timestamp without time zone NOT NULL,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.incidents OWNER TO fleet_user;

--
-- Name: inspection_documents; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.inspection_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    inspection_id uuid NOT NULL,
    document_type character varying(50) NOT NULL,
    document_url text,
    document_data bytea,
    provided_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_document_type CHECK (((document_type)::text = ANY ((ARRAY['ROC'::character varying, 'BILL_OF_LADING'::character varying, 'MEDICAL_CERT'::character varying, 'CDL'::character varying, 'SPE'::character varying, 'VEHICLE_REG'::character varying, 'INSURANCE'::character varying])::text[])))
);


ALTER TABLE public.inspection_documents OWNER TO fleet_user;

--
-- Name: TABLE inspection_documents; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.inspection_documents IS 'Documents provided during DOT inspections';


--
-- Name: inspection_templates; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.inspection_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    applicable_vehicle_types character varying(50)[],
    checklist_items jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.inspection_templates OWNER TO fleet_user;

--
-- Name: TABLE inspection_templates; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.inspection_templates IS 'Structure for digital inspection checklists';


--
-- Name: integration_configs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.integration_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    service_type character varying(30) NOT NULL,
    api_endpoint character varying(500) NOT NULL,
    api_key character varying(200),
    username character varying(100),
    password character varying(200),
    client_id character varying(100),
    client_secret character varying(200),
    environment character varying(20) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    last_sync_at timestamp with time zone,
    next_sync_at timestamp with time zone,
    sync_interval integer DEFAULT 60 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid NOT NULL,
    CONSTRAINT integration_configs_environment_check CHECK (((environment)::text = ANY ((ARRAY['production'::character varying, 'staging'::character varying, 'sandbox'::character varying])::text[]))),
    CONSTRAINT integration_configs_service_type_check CHECK (((service_type)::text = ANY ((ARRAY['fastag'::character varying, 'ewaybill'::character varying, 'vahan'::character varying, 'sarathi'::character varying, 'gst'::character varying, 'permit'::character varying])::text[])))
);


ALTER TABLE public.integration_configs OWNER TO fleet_user;

--
-- Name: TABLE integration_configs; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.integration_configs IS 'Third-party integration configurations for India services';


--
-- Name: COLUMN integration_configs.environment; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.integration_configs.environment IS 'production, staging, or sandbox environment';


--
-- Name: integration_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.integration_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    integration_id uuid,
    method character varying(10) NOT NULL,
    endpoint text NOT NULL,
    request_body jsonb,
    response_body jsonb,
    status_code integer,
    status character varying(20),
    duration_ms integer,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.integration_logs OWNER TO fleet_user;

--
-- Name: integrations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.integrations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(50) NOT NULL,
    provider character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    config jsonb DEFAULT '{}'::jsonb,
    last_sync timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.integrations OWNER TO fleet_user;

--
-- Name: inventory_parts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.inventory_parts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    part_number text NOT NULL,
    name text NOT NULL,
    description text,
    stock_location text,
    quantity_available integer DEFAULT 0 NOT NULL,
    reorder_level integer DEFAULT 5 NOT NULL,
    unit_cost numeric(10,2) DEFAULT 0 NOT NULL,
    category text,
    compatible_vehicles jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.inventory_parts OWNER TO fleet_user;

--
-- Name: invoice_approval_matrix; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.invoice_approval_matrix (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    min_amount numeric(12,2) NOT NULL,
    max_amount numeric(12,2),
    required_role character varying(50) NOT NULL,
    required_approvals integer DEFAULT 1,
    is_active boolean DEFAULT true,
    priority integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.invoice_approval_matrix OWNER TO fleet_user;

--
-- Name: TABLE invoice_approval_matrix; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.invoice_approval_matrix IS 'Approval rules based on invoice amount';


--
-- Name: invoice_approval_policies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.invoice_approval_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    min_amount numeric(12,2) NOT NULL,
    max_amount numeric(12,2),
    required_approvals integer DEFAULT 1,
    approver_roles text[] NOT NULL,
    specific_approvers uuid[],
    approval_type character varying(20) DEFAULT 'any'::character varying,
    priority integer DEFAULT 0,
    auto_approve_below numeric(12,2),
    auto_approve_roles text[],
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by uuid
);


ALTER TABLE public.invoice_approval_policies OWNER TO fleet_user;

--
-- Name: TABLE invoice_approval_policies; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.invoice_approval_policies IS 'Approval policies based on amount and other criteria';


--
-- Name: COLUMN invoice_approval_policies.approval_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.invoice_approval_policies.approval_type IS 'any=any approver, all=all approvers, sequential=ordered approvals';


--
-- Name: invoice_approvals; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.invoice_approvals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid NOT NULL,
    approver_id uuid NOT NULL,
    approver_role character varying(50),
    approval_status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    approval_comments text,
    requested_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    decided_at timestamp with time zone,
    ip_address inet,
    user_agent text,
    approval_level integer DEFAULT 1,
    is_required boolean DEFAULT true
);


ALTER TABLE public.invoice_approvals OWNER TO fleet_user;

--
-- Name: TABLE invoice_approvals; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.invoice_approvals IS 'Invoice approval tracking';


--
-- Name: invoice_audit_log; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.invoice_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    old_value jsonb,
    new_value jsonb,
    changed_by uuid,
    changed_by_email character varying(255),
    changed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    ip_address inet,
    user_agent text,
    reason text
);


ALTER TABLE public.invoice_audit_log OWNER TO fleet_user;

--
-- Name: TABLE invoice_audit_log; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.invoice_audit_log IS 'Audit trail for all invoice changes';


--
-- Name: COLUMN invoice_audit_log.action; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.invoice_audit_log.action IS 'Type of action performed';


--
-- Name: COLUMN invoice_audit_log.old_value; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.invoice_audit_log.old_value IS 'Previous state of invoice (JSON)';


--
-- Name: COLUMN invoice_audit_log.new_value; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.invoice_audit_log.new_value IS 'New state of invoice (JSON)';


--
-- Name: COLUMN invoice_audit_log.ip_address; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.invoice_audit_log.ip_address IS 'IP address of user who made change';


--
-- Name: COLUMN invoice_audit_log.reason; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.invoice_audit_log.reason IS 'Reason for change (required for cancellations)';


--
-- Name: invoice_audit_log_summary; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.invoice_audit_log_summary AS
 SELECT invoice_audit_log.invoice_id,
    count(*) AS total_changes,
    max(invoice_audit_log.changed_at) AS last_changed_at,
    array_agg(DISTINCT invoice_audit_log.action) AS actions_performed
   FROM public.invoice_audit_log
  GROUP BY invoice_audit_log.invoice_id;


ALTER VIEW public.invoice_audit_log_summary OWNER TO fleet_user;

--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.invoice_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid NOT NULL,
    description text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(15,2) DEFAULT 0.00 NOT NULL,
    tax_percent numeric(5,2) DEFAULT 0.00 NOT NULL,
    total numeric(15,2) DEFAULT 0.00 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    org_id uuid,
    amount double precision DEFAULT 0 NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.invoice_items OWNER TO fleet_user;

--
-- Name: TABLE invoice_items; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.invoice_items IS 'Line items for invoices';


--
-- Name: invoice_permissions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.invoice_permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    role_name character varying(50) NOT NULL,
    can_create_invoice boolean DEFAULT false,
    can_edit_invoice boolean DEFAULT false,
    can_delete_invoice boolean DEFAULT false,
    can_issue_invoice boolean DEFAULT false,
    can_cancel_invoice boolean DEFAULT false,
    can_record_payment boolean DEFAULT false,
    can_refund_payment boolean DEFAULT false,
    can_create_credit_note boolean DEFAULT false,
    can_approve_credit_note boolean DEFAULT false,
    can_view_invoices boolean DEFAULT true,
    can_export_invoices boolean DEFAULT false,
    can_approve_invoices boolean DEFAULT false,
    approval_limit numeric(12,2),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.invoice_permissions OWNER TO fleet_user;

--
-- Name: TABLE invoice_permissions; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.invoice_permissions IS 'Role-based permissions for invoice operations';


--
-- Name: invoice_sequence; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.invoice_sequence (
    id integer DEFAULT 1 NOT NULL,
    current_value integer DEFAULT 1 NOT NULL,
    prefix character varying(20) DEFAULT 'INV'::character varying NOT NULL,
    year integer DEFAULT EXTRACT(year FROM CURRENT_DATE) NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT single_row CHECK ((id = 1))
);


ALTER TABLE public.invoice_sequence OWNER TO fleet_user;

--
-- Name: TABLE invoice_sequence; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.invoice_sequence IS 'Auto-increment sequence for invoice numbers';


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    customer_name text NOT NULL,
    invoice_date date NOT NULL,
    due_date date NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    total_amount numeric(15,2) DEFAULT 0.00 NOT NULL,
    amount_paid numeric(15,2) DEFAULT 0.00 NOT NULL,
    balance_due numeric(15,2) DEFAULT 0.00 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    invoice_number text,
    customer_email text,
    billing_address text,
    subtotal double precision DEFAULT 0 NOT NULL,
    tax_amount double precision DEFAULT 0 NOT NULL,
    amount_remaining double precision DEFAULT 0 NOT NULL,
    notes text,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    custom_fields jsonb DEFAULT '{}'::jsonb,
    discount_type character varying(20) DEFAULT 'none'::character varying,
    discount_value numeric(12,2) DEFAULT 0,
    discount_reason text,
    discount_amount numeric(12,2) DEFAULT 0,
    approval_status character varying(20) DEFAULT 'not_required'::character varying,
    approval_required_at timestamp with time zone,
    approval_completed_at timestamp with time zone,
    subscription_id uuid,
    CONSTRAINT chk_invoice_approval_status CHECK (((approval_status)::text = ANY ((ARRAY['not_required'::character varying, 'pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[]))),
    CONSTRAINT chk_invoice_discount_amount CHECK (((discount_amount >= (0)::numeric) AND ((discount_amount)::double precision <= subtotal))),
    CONSTRAINT chk_invoice_discount_type CHECK (((discount_type)::text = ANY ((ARRAY['none'::character varying, 'percentage'::character varying, 'fixed'::character varying])::text[]))),
    CONSTRAINT chk_invoice_discount_value CHECK (((discount_value >= (0)::numeric) AND ((((discount_type)::text = 'percentage'::text) AND (discount_value <= (100)::numeric)) OR ((discount_type)::text <> 'percentage'::text)))),
    CONSTRAINT chk_invoices_currency CHECK ((length(currency) = 3)),
    CONSTRAINT chk_invoices_status CHECK ((status = ANY (ARRAY['draft'::text, 'issued'::text, 'paid'::text, 'overdue'::text, 'cancelled'::text])))
);


ALTER TABLE public.invoices OWNER TO fleet_user;

--
-- Name: TABLE invoices; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.invoices IS 'Stores customer invoices for billing';


--
-- Name: COLUMN invoices.subtotal; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.invoices.subtotal IS 'Total before discount';


--
-- Name: COLUMN invoices.discount_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.invoices.discount_type IS 'Type of discount: none, percentage, or fixed';


--
-- Name: COLUMN invoices.discount_value; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.invoices.discount_value IS 'Discount value (percentage or fixed amount)';


--
-- Name: COLUMN invoices.discount_reason; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.invoices.discount_reason IS 'Reason for applying discount';


--
-- Name: COLUMN invoices.discount_amount; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.invoices.discount_amount IS 'Actual discount amount applied';


--
-- Name: COLUMN invoices.approval_status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.invoices.approval_status IS 'Approval workflow status';


--
-- Name: CONSTRAINT chk_invoices_currency ON invoices; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON CONSTRAINT chk_invoices_currency ON public.invoices IS 'Currency must be 3-character ISO code';


--
-- Name: CONSTRAINT chk_invoices_status ON invoices; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON CONSTRAINT chk_invoices_status ON public.invoices IS 'Valid invoice status values';


--
-- Name: ip_rules; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.ip_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    cidr character varying(45) NOT NULL,
    action character varying(10) NOT NULL,
    description text,
    added_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT ip_rules_action_check CHECK (((action)::text = ANY ((ARRAY['ALLOW'::character varying, 'BLOCK'::character varying])::text[])))
);


ALTER TABLE public.ip_rules OWNER TO fleet_user;

--
-- Name: latest_health_status; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.latest_health_status AS
 SELECT DISTINCT ON (health_history.component) health_history.component,
    health_history.status,
    health_history.response_time_ms,
    health_history.error,
    health_history."timestamp" AS last_checked
   FROM public.health_history
  ORDER BY health_history.component, health_history."timestamp" DESC;


ALTER VIEW public.latest_health_status OWNER TO fleet_user;

--
-- Name: legal_holds; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.legal_holds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid NOT NULL,
    reason text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone
);


ALTER TABLE public.legal_holds OWNER TO fleet_user;

--
-- Name: local_permits; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.local_permits (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    permit_number character varying(50) NOT NULL,
    permit_type character varying(30) NOT NULL,
    permit_category character varying(30),
    permit_sub_category character varying(30),
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone NOT NULL,
    issuing_authority character varying(200) NOT NULL,
    jurisdiction character varying(200),
    route_details text,
    number_of_trips integer,
    max_load_capacity numeric(10,2),
    number_of_seats integer,
    fare numeric(10,2),
    status character varying(20) NOT NULL,
    remarks text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid NOT NULL,
    CONSTRAINT local_permits_fare_check CHECK ((fare >= (0)::numeric)),
    CONSTRAINT local_permits_max_load_capacity_check CHECK ((max_load_capacity > (0)::numeric)),
    CONSTRAINT local_permits_number_of_seats_check CHECK ((number_of_seats > 0)),
    CONSTRAINT local_permits_number_of_trips_check CHECK ((number_of_trips > 0)),
    CONSTRAINT local_permits_permit_type_check CHECK (((permit_type)::text = ANY ((ARRAY['stage_carriage'::character varying, 'contract_carriage'::character varying, 'goods_vehicle'::character varying])::text[]))),
    CONSTRAINT local_permits_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'expired'::character varying, 'cancelled'::character varying, 'suspended'::character varying])::text[])))
);


ALTER TABLE public.local_permits OWNER TO fleet_user;

--
-- Name: TABLE local_permits; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.local_permits IS 'Local transport permits and authorizations';


--
-- Name: COLUMN local_permits.permit_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.local_permits.permit_type IS 'stage_carriage, contract_carriage, or goods_vehicle';


--
-- Name: localization_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.localization_settings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    language_code character varying(10) NOT NULL,
    is_active boolean DEFAULT true,
    is_default boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by uuid NOT NULL
);


ALTER TABLE public.localization_settings OWNER TO fleet_user;

--
-- Name: TABLE localization_settings; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.localization_settings IS 'Language/localization configuration';


--
-- Name: login_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.login_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    user_id uuid,
    email character varying(255),
    ip_address character varying(45),
    device text,
    browser text,
    location character varying(255),
    status character varying(20),
    risk_level character varying(20) DEFAULT 'low'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT login_events_status_check CHECK (((status)::text = ANY ((ARRAY['SUCCESS'::character varying, 'FAILED'::character varying, 'CHALLENGED'::character varying])::text[])))
);


ALTER TABLE public.login_events OWNER TO fleet_user;

--
-- Name: login_history; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.login_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    ip_address inet,
    user_agent text,
    country text,
    success boolean,
    risk_score double precision DEFAULT 0.0,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.login_history OWNER TO fleet_user;

--
-- Name: maintenance_schedule; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.maintenance_schedule (
    vehicle_id uuid NOT NULL,
    next_service_date date,
    next_service_odometer numeric(10,2),
    engine_hours numeric(10,2),
    predictive_score numeric(5,2),
    last_service_date date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.maintenance_schedule OWNER TO fleet_user;

--
-- Name: TABLE maintenance_schedule; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.maintenance_schedule IS 'Predictive maintenance schedule per vehicle';


--
-- Name: maintenance_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.maintenance_settings (
    organization_id uuid NOT NULL,
    sla_p1_hours integer DEFAULT 4,
    sla_p2_hours integer DEFAULT 24,
    sla_p3_hours integer DEFAULT 72,
    low_stock_threshold integer DEFAULT 5,
    approval_threshold numeric(10,2) DEFAULT 5000.00,
    auto_assign_enabled boolean DEFAULT false,
    notification_enabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.maintenance_settings OWNER TO fleet_user;

--
-- Name: maintenance_vendors; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.maintenance_vendors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    specialization character varying(100),
    rating numeric(3,2) DEFAULT 0.00,
    contact_info jsonb DEFAULT '{}'::jsonb,
    payment_terms character varying(100),
    status character varying(20) DEFAULT 'ACTIVE'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT maintenance_vendors_rating_check CHECK (((rating >= (0)::numeric) AND (rating <= (5)::numeric)))
);


ALTER TABLE public.maintenance_vendors OWNER TO fleet_user;

--
-- Name: TABLE maintenance_vendors; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.maintenance_vendors IS 'Service providers and part suppliers';


--
-- Name: maintenance_windows; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.maintenance_windows (
    id uuid NOT NULL,
    service text NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.maintenance_windows OWNER TO fleet_user;

--
-- Name: malfunction_compliance_status; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.malfunction_compliance_status AS
 SELECT em.id,
    em.vehicle_id,
    em.driver_id,
    em.malfunction_type,
    em.status,
    em.detected_at,
    em.acknowledged_at,
    em.reported_to_fmcsa,
    em.reported_at,
    (EXTRACT(epoch FROM (CURRENT_TIMESTAMP - em.detected_at)) / (3600)::numeric) AS hours_since_detection,
        CASE
            WHEN ((em.status)::text = 'resolved'::text) THEN 'Compliant'::text
            WHEN (em.reported_to_fmcsa = true) THEN 'Reported'::text
            WHEN ((CURRENT_TIMESTAMP - em.detected_at) > '24:00:00'::interval) THEN 'Non-Compliant (Overdue)'::text
            WHEN (((em.status)::text = 'open'::text) AND ((CURRENT_TIMESTAMP - em.detected_at) <= '24:00:00'::interval)) THEN 'Compliant (Within 24h)'::text
            ELSE 'Unknown'::text
        END AS compliance_status
   FROM public.eld_malfunctions em
  WHERE (em.created_at >= (CURRENT_TIMESTAMP - '30 days'::interval))
  ORDER BY em.detected_at DESC;


ALTER VIEW public.malfunction_compliance_status OWNER TO fleet_user;

--
-- Name: materialized_fleet_reports; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.materialized_fleet_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    report_type text NOT NULL,
    metric_key text NOT NULL,
    metric_value double precision NOT NULL,
    period text NOT NULL,
    generated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.materialized_fleet_reports OWNER TO fleet_user;

--
-- Name: mfa_codes; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    code character varying(10) NOT NULL,
    method character varying(50) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_codes OWNER TO fleet_user;

--
-- Name: mfa_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    event_type character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    method character varying(20),
    ip_address character varying(45),
    user_agent text,
    location character varying(255),
    details jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_events OWNER TO fleet_user;

--
-- Name: mfa_exceptions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_exceptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    reason text NOT NULL,
    granted_by uuid,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    start_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_exceptions OWNER TO fleet_user;

--
-- Name: mfa_failures; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_failures (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    method character varying(20),
    failure_reason text,
    ip_address character varying(45),
    location character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_failures OWNER TO fleet_user;

--
-- Name: mfa_lockouts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_lockouts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    reason character varying(255),
    locked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    unlocked_at timestamp with time zone,
    unlocked_by uuid
);


ALTER TABLE public.mfa_lockouts OWNER TO fleet_user;

--
-- Name: mfa_org_overrides; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_org_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    enabled boolean DEFAULT true,
    allowed_methods jsonb DEFAULT '["totp", "sms"]'::jsonb,
    max_attempts integer DEFAULT 5,
    lockout_minutes integer DEFAULT 30,
    remember_device_days integer DEFAULT 30,
    grace_period_days integer DEFAULT 7,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_org_overrides OWNER TO fleet_user;

--
-- Name: mfa_policies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    require_mfa boolean DEFAULT false,
    allowed_methods jsonb DEFAULT '["totp", "sms"]'::jsonb,
    max_attempts integer DEFAULT 5,
    lockout_minutes integer DEFAULT 30,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    grace_period_days integer DEFAULT 7,
    remember_device_days integer DEFAULT 30,
    enforce_at_login boolean DEFAULT true,
    admin_only_mode boolean DEFAULT false,
    remember_device_allowed boolean DEFAULT true,
    mfa_challenge_timeout integer DEFAULT 60,
    version integer DEFAULT 1
);


ALTER TABLE public.mfa_policies OWNER TO fleet_user;

--
-- Name: mfa_policy_history; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_policy_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    policy_id uuid,
    org_id uuid,
    snapshot jsonb NOT NULL,
    changed_by uuid,
    change_reason text,
    version integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_policy_history OWNER TO fleet_user;

--
-- Name: mfa_recovery_codes; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_recovery_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    code_hash text NOT NULL,
    used boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.mfa_recovery_codes OWNER TO fleet_user;

--
-- Name: mfa_users; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_users (
    user_id uuid NOT NULL,
    org_id uuid,
    status character varying(20) DEFAULT 'DISABLED'::character varying,
    method character varying(50),
    trusted_devices_count integer DEFAULT 0,
    last_reset timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.mfa_users OWNER TO fleet_user;

--
-- Name: model_deployments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.model_deployments (
    id uuid NOT NULL,
    model_id text NOT NULL,
    organization_id uuid NOT NULL,
    deployment_strategy text NOT NULL,
    traffic_split double precision DEFAULT 0.0,
    is_active boolean DEFAULT true,
    deployed_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.model_deployments OWNER TO fleet_user;

--
-- Name: model_predictions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.model_predictions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    model_version text NOT NULL,
    route_id text NOT NULL,
    forecast_date date NOT NULL,
    forecast_hour integer NOT NULL,
    predicted_demand numeric(10,2) NOT NULL,
    confidence_interval_lower numeric(10,2),
    confidence_interval_upper numeric(10,2),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.model_predictions OWNER TO fleet_user;

--
-- Name: notification_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.notification_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    notification_id uuid NOT NULL,
    event_type text NOT NULL,
    message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification_events OWNER TO fleet_user;

--
-- Name: notification_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.notification_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    correlation_id text,
    user_id uuid,
    user_email text,
    channel text NOT NULL,
    type text NOT NULL,
    subject text NOT NULL,
    body text,
    status text NOT NULL,
    provider text,
    provider_response text,
    retry_count integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification_logs OWNER TO fleet_user;

--
-- Name: notification_preference_audit; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.notification_preference_audit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    changed_by uuid,
    old_values jsonb,
    new_values jsonb,
    change_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification_preference_audit OWNER TO fleet_user;

--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.notification_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    priority integer DEFAULT 100 NOT NULL,
    retention_months integer DEFAULT 6 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification_settings OWNER TO fleet_user;

--
-- Name: oauth_clients; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.oauth_clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_id text NOT NULL,
    client_secret_hash text NOT NULL,
    redirect_uris text[] NOT NULL,
    grant_types text[] DEFAULT '{authorization_code}'::text[],
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.oauth_clients OWNER TO fleet_user;

--
-- Name: obd_readings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.obd_readings (
    "time" timestamp with time zone NOT NULL,
    vehicle_id uuid NOT NULL,
    rpm integer,
    coolant_temp integer,
    engine_load numeric(5,2),
    throttle_pos numeric(5,2),
    fuel_level numeric(5,2),
    dtcs jsonb,
    vin character varying(50),
    raw_data jsonb
);


ALTER TABLE public.obd_readings OWNER TO fleet_user;

--
-- Name: TABLE obd_readings; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.obd_readings IS 'Stores On-Board Diagnostics data from vehicles';


--
-- Name: oidc_providers; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.oidc_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    issuer text NOT NULL,
    client_id text NOT NULL,
    client_secret_hash text NOT NULL,
    enabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.oidc_providers OWNER TO fleet_user;

--
-- Name: org_budgets; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.org_budgets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    category character varying(50) NOT NULL,
    limit_amount numeric(15,2) NOT NULL,
    spent_amount numeric(15,2) DEFAULT 0,
    currency character varying(3) DEFAULT 'INR'::character varying,
    period_start date NOT NULL,
    period_end date NOT NULL,
    alert_threshold_pct integer DEFAULT 80,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.org_budgets OWNER TO fleet_user;

--
-- Name: TABLE org_budgets; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.org_budgets IS 'Budgets for different expense categories at the organization level';


--
-- Name: org_fuel_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.org_fuel_settings (
    organization_id uuid NOT NULL,
    default_daily_liters_limit numeric(10,2),
    default_monthly_liters_limit numeric(10,2),
    default_daily_amount_limit numeric(10,2),
    default_monthly_amount_limit numeric(10,2),
    currency character varying(3) DEFAULT 'INR'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.org_fuel_settings OWNER TO fleet_user;

--
-- Name: TABLE org_fuel_settings; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.org_fuel_settings IS 'Organization-wide default fuel limits';


--
-- Name: org_support_metrics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.org_support_metrics (
    org_id uuid NOT NULL,
    open_tickets integer DEFAULT 0,
    resolved_tickets integer DEFAULT 0,
    avg_resolution_time interval,
    sla_breaches integer DEFAULT 0,
    critical_issues integer DEFAULT 0,
    last_calculated timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.org_support_metrics OWNER TO fleet_user;

--
-- Name: TABLE org_support_metrics; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.org_support_metrics IS 'Pre-calculated organization support metrics';


--
-- Name: organization_memberships; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.organization_memberships (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    user_id uuid,
    role text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.organization_memberships OWNER TO fleet_user;

--
-- Name: organization_users; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.organization_users (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    status text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.organization_users OWNER TO fleet_user;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    domain character varying(255),
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    default_theme character varying(20) DEFAULT 'light'::character varying,
    is_deleted boolean DEFAULT false,
    contact_email character varying(255),
    plan character varying(50) DEFAULT 'enterprise'::character varying,
    max_users_limit integer DEFAULT 10,
    max_api_keys_limit integer DEFAULT 5,
    CONSTRAINT organizations_default_theme_check CHECK (((default_theme)::text = ANY ((ARRAY['light'::character varying, 'dark'::character varying, 'system'::character varying])::text[])))
);


ALTER TABLE public.organizations OWNER TO fleet_user;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.password_reset_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    used boolean DEFAULT false,
    used_at timestamp with time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO fleet_user;

--
-- Name: TABLE password_reset_tokens; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.password_reset_tokens IS 'Stores password reset tokens for secure password recovery';


--
-- Name: COLUMN password_reset_tokens.expires_at; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.password_reset_tokens.expires_at IS 'Token expiration time (typically 1 hour)';


--
-- Name: COLUMN password_reset_tokens.used; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.password_reset_tokens.used IS 'True if token has been used';


--
-- Name: payment_records; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.payment_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid NOT NULL,
    amount numeric(12,2) NOT NULL,
    payment_method character varying(50),
    payment_reference character varying(255),
    payment_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid
);


ALTER TABLE public.payment_records OWNER TO fleet_user;

--
-- Name: TABLE payment_records; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.payment_records IS 'Audit trail for all payment transactions';


--
-- Name: pending_bookings; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.pending_bookings AS
 SELECT br.id,
    br.customer_id,
    c.name AS customer_name,
    c.email AS customer_email,
    br.request_type,
    br.status,
    br.requested_pickup_time,
    br.created_at,
    (EXTRACT(epoch FROM (now() - br.created_at)) / (3600)::numeric) AS hours_since_request
   FROM (public.booking_requests br
     JOIN public.customers c ON ((br.customer_id = c.id)))
  WHERE ((br.status)::text = 'pending'::text)
  ORDER BY br.created_at;


ALTER VIEW public.pending_bookings OWNER TO fleet_user;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    role_id uuid,
    resource character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.permissions OWNER TO fleet_user;

--
-- Name: platform_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.platform_settings (
    id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    system_name character varying(255) DEFAULT 'Enterprise Fleet Manager'::character varying NOT NULL,
    support_email character varying(255) NOT NULL,
    default_timezone character varying(100) DEFAULT 'UTC'::character varying NOT NULL,
    default_currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    default_language character varying(10) DEFAULT 'en-US'::character varying NOT NULL,
    white_label_enabled boolean DEFAULT false,
    smtp_config_id uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by uuid NOT NULL,
    CONSTRAINT chk_platform_settings_single_row CHECK ((id = '00000000-0000-0000-0000-000000000001'::uuid))
);


ALTER TABLE public.platform_settings OWNER TO fleet_user;

--
-- Name: TABLE platform_settings; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.platform_settings IS 'Global platform configuration (singleton record)';


--
-- Name: COLUMN platform_settings.id; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.platform_settings.id IS 'Singleton ID - only one row should exist';


--
-- Name: prediction_results; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.prediction_results (
    id character varying(36) NOT NULL,
    model_id character varying(36) NOT NULL,
    prediction_input jsonb NOT NULL,
    predicted_value jsonb,
    confidence_score numeric(5,4) NOT NULL,
    probability_scores jsonb,
    feature_importance jsonb,
    anomaly_detected boolean DEFAULT false NOT NULL,
    anomaly_score numeric(5,4),
    explanation text,
    organization_id uuid NOT NULL,
    request_id character varying(36) NOT NULL,
    predicted_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT prediction_results_anomaly_score_check CHECK (((anomaly_score >= (0)::numeric) AND (anomaly_score <= (1)::numeric))),
    CONSTRAINT prediction_results_confidence_score_check CHECK (((confidence_score >= (0)::numeric) AND (confidence_score <= (1)::numeric)))
);


ALTER TABLE public.prediction_results OWNER TO fleet_user;

--
-- Name: predictive_maintenance_analytics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.predictive_maintenance_analytics (
    id character varying(36) NOT NULL,
    vehicle_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    analysis_date date NOT NULL,
    next_service_due date NOT NULL,
    service_priority character varying(20) NOT NULL,
    component_risks jsonb DEFAULT '{}'::jsonb NOT NULL,
    failure_prediction jsonb,
    maintenance_schedule jsonb DEFAULT '[]'::jsonb NOT NULL,
    parts_needed jsonb DEFAULT '[]'::jsonb NOT NULL,
    cost_estimation numeric(12,2) DEFAULT 0 NOT NULL,
    uptime_prediction numeric(5,2) DEFAULT 0 NOT NULL,
    reliability_score numeric(5,2) DEFAULT 0 NOT NULL,
    recommendations jsonb DEFAULT '[]'::jsonb NOT NULL,
    generated_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT predictive_maintenance_analytics_reliability_score_check CHECK (((reliability_score >= (0)::numeric) AND (reliability_score <= (100)::numeric))),
    CONSTRAINT predictive_maintenance_analytics_uptime_prediction_check CHECK (((uptime_prediction >= (0)::numeric) AND (uptime_prediction <= (100)::numeric)))
);


ALTER TABLE public.predictive_maintenance_analytics OWNER TO fleet_user;

--
-- Name: predictive_models; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.predictive_models (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    version character varying(50) NOT NULL,
    model_type character varying(100) NOT NULL,
    description text,
    algorithm character varying(100) NOT NULL,
    input_features jsonb DEFAULT '[]'::jsonb NOT NULL,
    output_variable character varying(255),
    training_data_start timestamp with time zone NOT NULL,
    training_data_end timestamp with time zone NOT NULL,
    accuracy numeric(5,4),
    "precision" numeric(5,4),
    recall numeric(5,4),
    f1_score numeric(5,4),
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    trained_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    organization_id uuid,
    CONSTRAINT predictive_models_accuracy_check CHECK (((accuracy >= (0)::numeric) AND (accuracy <= (1)::numeric))),
    CONSTRAINT predictive_models_f1_score_check CHECK (((f1_score >= (0)::numeric) AND (f1_score <= (1)::numeric))),
    CONSTRAINT predictive_models_precision_check CHECK ((("precision" >= (0)::numeric) AND ("precision" <= (1)::numeric))),
    CONSTRAINT predictive_models_recall_check CHECK (((recall >= (0)::numeric) AND (recall <= (1)::numeric)))
);


ALTER TABLE public.predictive_models OWNER TO fleet_user;

--
-- Name: pricing_rules; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.pricing_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    description text,
    condition_json jsonb NOT NULL,
    action_json jsonb NOT NULL,
    priority integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.pricing_rules OWNER TO fleet_user;

--
-- Name: proof_of_delivery; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.proof_of_delivery (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    trip_id uuid NOT NULL,
    type character varying(20) NOT NULL,
    url text NOT NULL,
    metadata jsonb,
    uploaded_by uuid NOT NULL,
    verified boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT proof_of_delivery_type_check CHECK (((type)::text = ANY ((ARRAY['SIGNATURE'::character varying, 'PHOTO'::character varying, 'DOCUMENT'::character varying, 'QR_CODE'::character varying])::text[])))
);


ALTER TABLE public.proof_of_delivery OWNER TO fleet_user;

--
-- Name: receipt_ocr_jobs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.receipt_ocr_jobs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    expense_item_id uuid NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    error_message text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.receipt_ocr_jobs OWNER TO fleet_user;

--
-- Name: settings_audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.settings_audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    entity_type character varying(100) NOT NULL,
    entity_id uuid,
    action character varying(50) NOT NULL,
    actor_id uuid NOT NULL,
    actor_ip inet,
    changes jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.settings_audit_logs OWNER TO fleet_user;

--
-- Name: TABLE settings_audit_logs; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.settings_audit_logs IS 'Audit trail for settings changes';


--
-- Name: COLUMN settings_audit_logs.changes; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.settings_audit_logs.changes IS 'JSON diff of changes made';


--
-- Name: recent_audit_logs; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.recent_audit_logs AS
 SELECT settings_audit_logs.id,
    settings_audit_logs.entity_type,
    settings_audit_logs.entity_id,
    settings_audit_logs.action,
    settings_audit_logs.actor_id,
    settings_audit_logs.actor_ip,
    settings_audit_logs.changes,
    settings_audit_logs.created_at
   FROM public.settings_audit_logs
  WHERE (settings_audit_logs.created_at >= (now() - '30 days'::interval))
  ORDER BY settings_audit_logs.created_at DESC;


ALTER VIEW public.recent_audit_logs OWNER TO fleet_user;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    revoked boolean DEFAULT false,
    revoked_at timestamp with time zone,
    used_at timestamp with time zone,
    ip_address character varying(45),
    user_agent text,
    last_used_at timestamp with time zone,
    device_id uuid
);


ALTER TABLE public.refresh_tokens OWNER TO fleet_user;

--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.refresh_tokens IS 'Stores JWT refresh tokens for session management';


--
-- Name: COLUMN refresh_tokens.revoked; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.refresh_tokens.revoked IS 'True if token has been revoked (logout)';


--
-- Name: COLUMN refresh_tokens.ip_address; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.refresh_tokens.ip_address IS 'IP address from which the refresh token was issued';


--
-- Name: COLUMN refresh_tokens.user_agent; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.refresh_tokens.user_agent IS 'User agent string of the device issuing the token';


--
-- Name: COLUMN refresh_tokens.last_used_at; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.refresh_tokens.last_used_at IS 'Timestamp of the last time this refresh token was used to generate an access token';


--
-- Name: restore_jobs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.restore_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    backup_id uuid NOT NULL,
    status character varying(50) NOT NULL,
    target_environment character varying(50) NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    performed_by uuid NOT NULL,
    logs text
);


ALTER TABLE public.restore_jobs OWNER TO fleet_user;

--
-- Name: review_items; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.review_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    review_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid,
    current_status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    reviewer_id uuid,
    reviewed_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT review_items_current_status_check CHECK (((current_status)::text = ANY ((ARRAY['PENDING'::character varying, 'APPROVED'::character varying, 'REVOKED'::character varying])::text[])))
);


ALTER TABLE public.review_items OWNER TO fleet_user;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    is_system boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles OWNER TO fleet_user;

--
-- Name: rollout_device_status; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.rollout_device_status (
    id bigint NOT NULL,
    rollout_id uuid,
    device_id uuid,
    status text,
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT rollout_device_status_status_check CHECK ((status = ANY (ARRAY['PENDING'::text, 'UPDATING'::text, 'SUCCESS'::text, 'FAILED'::text])))
);


ALTER TABLE public.rollout_device_status OWNER TO fleet_user;

--
-- Name: rollout_device_status_id_seq; Type: SEQUENCE; Schema: public; Owner: fleet_user
--

CREATE SEQUENCE public.rollout_device_status_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rollout_device_status_id_seq OWNER TO fleet_user;

--
-- Name: rollout_device_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleet_user
--

ALTER SEQUENCE public.rollout_device_status_id_seq OWNED BY public.rollout_device_status.id;


--
-- Name: route_optimization_jobs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.route_optimization_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_id uuid NOT NULL,
    status character varying(50) DEFAULT 'queued'::character varying NOT NULL,
    worker_id character varying(100),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.route_optimization_jobs OWNER TO fleet_user;

--
-- Name: TABLE route_optimization_jobs; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.route_optimization_jobs IS 'Background job tracking for route optimization';


--
-- Name: route_optimization_job_stats; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.route_optimization_job_stats AS
 SELECT route_optimization_jobs.request_id,
    count(*) AS total_jobs,
    count(*) FILTER (WHERE ((route_optimization_jobs.status)::text = 'completed'::text)) AS completed_jobs,
    count(*) FILTER (WHERE ((route_optimization_jobs.status)::text = 'failed'::text)) AS failed_jobs,
    max(route_optimization_jobs.created_at) AS last_job_at,
    max(route_optimization_jobs.completed_at) AS last_completed_at
   FROM public.route_optimization_jobs
  GROUP BY route_optimization_jobs.request_id;


ALTER VIEW public.route_optimization_job_stats OWNER TO fleet_user;

--
-- Name: route_optimization_requests; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.route_optimization_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    constraints jsonb DEFAULT '{}'::jsonb,
    stops jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.route_optimization_requests OWNER TO fleet_user;

--
-- Name: TABLE route_optimization_requests; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.route_optimization_requests IS 'Route optimization requests with constraints and goals';


--
-- Name: COLUMN route_optimization_requests.constraints; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.route_optimization_requests.constraints IS 'Optimization constraints (max travel time, distance, etc.)';


--
-- Name: COLUMN route_optimization_requests.stops; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.route_optimization_requests.stops IS 'Array of stops with locations and time windows';


--
-- Name: route_optimization_results; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.route_optimization_results (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_id uuid NOT NULL,
    routes jsonb DEFAULT '[]'::jsonb NOT NULL,
    total_distance numeric(10,2) DEFAULT 0,
    total_duration numeric(10,2) DEFAULT 0,
    total_cost numeric(10,2) DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.route_optimization_results OWNER TO fleet_user;

--
-- Name: TABLE route_optimization_results; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.route_optimization_results IS 'Optimized route results with performance metrics';


--
-- Name: COLUMN route_optimization_results.routes; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.route_optimization_results.routes IS 'Optimized routes for each vehicle';


--
-- Name: route_optimization_stats; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.route_optimization_stats AS
 SELECT route_optimization_requests.organization_id,
    count(*) AS total_requests,
    count(*) FILTER (WHERE ((route_optimization_requests.status)::text = 'completed'::text)) AS completed_requests,
    count(*) FILTER (WHERE ((route_optimization_requests.status)::text = 'failed'::text)) AS failed_requests,
    count(*) FILTER (WHERE ((route_optimization_requests.status)::text = 'processing'::text)) AS processing_requests,
    avg(EXTRACT(epoch FROM (route_optimization_requests.updated_at - route_optimization_requests.created_at))) FILTER (WHERE ((route_optimization_requests.status)::text = 'completed'::text)) AS avg_processing_time_seconds,
    max(route_optimization_requests.created_at) AS last_request_at
   FROM public.route_optimization_requests
  GROUP BY route_optimization_requests.organization_id;


ALTER VIEW public.route_optimization_stats OWNER TO fleet_user;

--
-- Name: security_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.security_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    event_type character varying(100) NOT NULL,
    ip_address character varying(45),
    user_agent text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.security_events OWNER TO fleet_user;

--
-- Name: security_history; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.security_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    event_type text NOT NULL,
    ip_address text NOT NULL,
    location text,
    user_agent text,
    risk_score integer DEFAULT 0,
    result text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.security_history OWNER TO fleet_user;

--
-- Name: service_accounts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.service_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    name text,
    secret_hash text NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.service_accounts OWNER TO fleet_user;

--
-- Name: shipment_audit_history; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.shipment_audit_history AS
 SELECT cal.id,
    cal.org_id,
    cal.entity_id AS shipment_id,
    cal.action,
    cal.old_value,
    cal.new_value,
    cal.user_id,
    cal.user_type,
    cal.reason,
    cal.created_at
   FROM public.customer_audit_log cal
  WHERE ((cal.entity_type)::text = 'shipment'::text)
  ORDER BY cal.created_at DESC;


ALTER VIEW public.shipment_audit_history OWNER TO fleet_user;

--
-- Name: shipments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.shipments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    trip_id uuid,
    tracking_number character varying(100) NOT NULL,
    status character varying(50) DEFAULT 'created'::character varying,
    origin jsonb NOT NULL,
    destination jsonb NOT NULL,
    current_location jsonb,
    estimated_delivery timestamp with time zone,
    actual_delivery timestamp with time zone,
    cargo_details jsonb,
    pod_url character varying(255),
    pod_uploaded_at timestamp with time zone,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    CONSTRAINT chk_shipments_delivery_dates CHECK (((actual_delivery IS NULL) OR (actual_delivery >= estimated_delivery))),
    CONSTRAINT chk_shipments_status CHECK (((status)::text = ANY ((ARRAY['created'::character varying, 'picked_up'::character varying, 'in_transit'::character varying, 'delivered'::character varying, 'exception'::character varying])::text[]))),
    CONSTRAINT chk_shipments_tracking_format CHECK (((length((tracking_number)::text) >= 5) AND (length((tracking_number)::text) <= 100)))
);


ALTER TABLE public.shipments OWNER TO fleet_user;

--
-- Name: CONSTRAINT chk_shipments_delivery_dates ON shipments; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON CONSTRAINT chk_shipments_delivery_dates ON public.shipments IS 'Actual delivery cannot be before estimated';


--
-- Name: CONSTRAINT chk_shipments_status ON shipments; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON CONSTRAINT chk_shipments_status ON public.shipments IS 'Valid shipment status values';


--
-- Name: CONSTRAINT chk_shipments_tracking_format ON shipments; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON CONSTRAINT chk_shipments_tracking_format ON public.shipments IS 'Tracking number must be 5-100 characters';


--
-- Name: shipments_in_transit; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.shipments_in_transit AS
 SELECT s.id,
    s.tracking_number,
    s.customer_id,
    c.name AS customer_name,
    s.status,
    s.origin,
    s.destination,
    s.current_location,
    s.estimated_delivery,
    (EXTRACT(epoch FROM (s.estimated_delivery - now())) / (3600)::numeric) AS hours_until_delivery
   FROM (public.shipments s
     JOIN public.customers c ON ((s.customer_id = c.id)))
  WHERE ((s.status)::text = 'in_transit'::text)
  ORDER BY s.estimated_delivery;


ALTER VIEW public.shipments_in_transit OWNER TO fleet_user;

--
-- Name: signing_keys; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.signing_keys (
    kid text NOT NULL,
    private_key_enc text NOT NULL,
    public_key text NOT NULL,
    status text NOT NULL,
    algorithm text DEFAULT 'RS256'::text,
    created_at timestamp with time zone DEFAULT now(),
    activated_at timestamp with time zone,
    expires_at timestamp with time zone
);


ALTER TABLE public.signing_keys OWNER TO fleet_user;

--
-- Name: sla_metrics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.sla_metrics (
    "time" timestamp with time zone NOT NULL,
    org_id uuid NOT NULL,
    metric_name character varying(50) NOT NULL,
    value numeric(15,4) NOT NULL,
    metadata jsonb
);


ALTER TABLE public.sla_metrics OWNER TO fleet_user;

--
-- Name: sos_incidents; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.sos_incidents (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid,
    trip_id uuid,
    "timestamp" timestamp with time zone DEFAULT now(),
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    location_address text,
    status text DEFAULT 'TRIGGERED'::text NOT NULL,
    severity text DEFAULT 'CRITICAL'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    incident_type character varying(50) DEFAULT 'SOS_PANIC'::character varying,
    device_id uuid,
    panic_source character varying(50) DEFAULT 'DRIVER_MOBILE'::character varying,
    speed integer DEFAULT 0,
    heading integer DEFAULT 0,
    acknowledged_by uuid,
    resolved_by uuid,
    high_risk_location boolean DEFAULT false,
    simulation_mode boolean DEFAULT false,
    driver_feedback character varying(50),
    feedback_notes text,
    org_id uuid,
    acknowledged_at timestamp with time zone,
    resolved_at timestamp with time zone,
    CONSTRAINT check_incident_type CHECK (((incident_type)::text = ANY ((ARRAY['SOS_PANIC'::character varying, 'VEHICLE_ACCIDENT'::character varying, 'VEHICLE_BREAKDOWN'::character varying, 'MEDICAL_EMERGENCY'::character varying, 'SECURITY_THREAT'::character varying, 'FIRE_ALERT'::character varying])::text[]))),
    CONSTRAINT check_panic_source CHECK (((panic_source)::text = ANY ((ARRAY['AIS140_DEVICE'::character varying, 'DRIVER_MOBILE'::character varying, 'VEHICLE_TELEMATICS'::character varying, 'DISPATCHER'::character varying])::text[]))),
    CONSTRAINT sos_incidents_severity_check CHECK ((severity = ANY (ARRAY['LOW'::text, 'MEDIUM'::text, 'CRITICAL'::text]))),
    CONSTRAINT sos_incidents_status_check CHECK ((status = ANY (ARRAY['TRIGGERED'::text, 'ACKNOWLEDGED'::text, 'RESOLVED'::text, 'FALSE_ALARM'::text])))
);


ALTER TABLE public.sos_incidents OWNER TO fleet_user;

--
-- Name: storage_pools; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.storage_pools (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(50) DEFAULT 'ACTIVE'::character varying NOT NULL,
    total_bytes bigint DEFAULT 0 NOT NULL,
    used_bytes bigint DEFAULT 0 NOT NULL,
    available_bytes bigint DEFAULT 0 NOT NULL,
    location character varying(255),
    backup_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.storage_pools OWNER TO fleet_user;

--
-- Name: support_audit_log; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.support_audit_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ticket_id uuid,
    user_id uuid,
    action character varying(100) NOT NULL,
    old_value jsonb,
    new_value jsonb,
    details text,
    created_at timestamp with time zone DEFAULT now(),
    ip_address character varying(45)
);


ALTER TABLE public.support_audit_log OWNER TO fleet_user;

--
-- Name: TABLE support_audit_log; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.support_audit_log IS 'Audit trail for all support operations';


--
-- Name: support_ticket_attachments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.support_ticket_attachments (
    id uuid NOT NULL,
    ticket_id uuid NOT NULL,
    file_url text NOT NULL,
    uploaded_by uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.support_ticket_attachments OWNER TO fleet_user;

--
-- Name: support_ticket_messages; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.support_ticket_messages (
    id uuid NOT NULL,
    ticket_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    message text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.support_ticket_messages OWNER TO fleet_user;

--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.support_tickets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ticket_id character varying(50) NOT NULL,
    org_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'OPEN'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'MEDIUM'::character varying NOT NULL,
    category character varying(100),
    assigned_to uuid,
    reporter_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone,
    sla_deadline timestamp with time zone,
    tags jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.support_tickets OWNER TO fleet_user;

--
-- Name: TABLE support_tickets; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.support_tickets IS 'Core support ticket records';


--
-- Name: support_tickets_ticket_id_seq; Type: SEQUENCE; Schema: public; Owner: fleet_user
--

CREATE SEQUENCE public.support_tickets_ticket_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_tickets_ticket_id_seq OWNER TO fleet_user;

--
-- Name: sync_jobs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.sync_jobs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    erp_config_id uuid,
    entity_type text NOT NULL,
    direction text NOT NULL,
    status text DEFAULT 'PENDING'::text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    records_processed integer DEFAULT 0,
    error_log text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.sync_jobs OWNER TO fleet_user;

--
-- Name: system_audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.system_audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    action text NOT NULL,
    target_user_id uuid,
    ip_address text,
    user_agent text,
    status text NOT NULL,
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.system_audit_logs OWNER TO fleet_user;

--
-- Name: system_flags; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.system_flags (
    key text NOT NULL,
    value text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.system_flags OWNER TO fleet_user;

--
-- Name: system_limits; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.system_limits (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    api_rate_limit integer DEFAULT 10000 NOT NULL,
    burst_limit integer DEFAULT 500 NOT NULL,
    audit_retention character varying(20) DEFAULT '1y'::character varying NOT NULL,
    activity_retention character varying(20) DEFAULT '180d'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by uuid NOT NULL
);


ALTER TABLE public.system_limits OWNER TO fleet_user;

--
-- Name: TABLE system_limits; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.system_limits IS 'System-wide rate limits and retention policies';


--
-- Name: telemetry; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    trip_id uuid,
    latitude numeric(10,8),
    longitude numeric(11,8),
    speed numeric(6,2),
    heading numeric(5,2),
    event_type character varying(50),
    event_time timestamp without time zone DEFAULT now()
);


ALTER TABLE public.telemetry OWNER TO fleet_user;

--
-- Name: telemetry_analytics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_analytics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    analysis_type character varying(100) NOT NULL,
    data jsonb NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    confidence numeric(3,2) NOT NULL,
    CONSTRAINT telemetry_analytics_confidence_check CHECK (((confidence >= (0)::numeric) AND (confidence <= (1)::numeric)))
);


ALTER TABLE public.telemetry_analytics OWNER TO fleet_user;

--
-- Name: TABLE telemetry_analytics; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.telemetry_analytics IS 'Stores advanced analytics results for vehicle telemetry data';


--
-- Name: COLUMN telemetry_analytics.analysis_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.telemetry_analytics.analysis_type IS 'Type of analysis performed (e.g., speed_analysis, fuel_efficiency)';


--
-- Name: COLUMN telemetry_analytics.confidence; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.telemetry_analytics.confidence IS 'Confidence score for the analysis results (0-1)';


--
-- Name: telemetry_anomalies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_anomalies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    anomaly_type character varying(100) NOT NULL,
    data jsonb NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    confidence numeric(3,2) NOT NULL,
    anomaly_score numeric(5,2) NOT NULL,
    recommendation text,
    CONSTRAINT telemetry_anomalies_confidence_check CHECK (((confidence >= (0)::numeric) AND (confidence <= (1)::numeric)))
);


ALTER TABLE public.telemetry_anomalies OWNER TO fleet_user;

--
-- Name: TABLE telemetry_anomalies; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.telemetry_anomalies IS 'Stores detected anomalies in vehicle telemetry data';


--
-- Name: COLUMN telemetry_anomalies.anomaly_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.telemetry_anomalies.anomaly_type IS 'Type of anomaly detected (e.g., unusual_speed, fuel_theft)';


--
-- Name: COLUMN telemetry_anomalies.anomaly_score; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.telemetry_anomalies.anomaly_score IS 'Numerical score representing severity of the anomaly';


--
-- Name: COLUMN telemetry_anomalies.recommendation; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.telemetry_anomalies.recommendation IS 'Suggested action for addressing the anomaly';


--
-- Name: telemetry_outbox; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_outbox (
    id bigint NOT NULL,
    partition_id integer NOT NULL,
    payload jsonb NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    attempts smallint DEFAULT 0 NOT NULL,
    last_attempt timestamp with time zone,
    error_msg text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT telemetry_outbox_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processed'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.telemetry_outbox OWNER TO fleet_user;

--
-- Name: TABLE telemetry_outbox; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.telemetry_outbox IS 'Transactional outbox for reliable NATS JetStream publishing';


--
-- Name: telemetry_outbox_id_seq; Type: SEQUENCE; Schema: public; Owner: fleet_user
--

CREATE SEQUENCE public.telemetry_outbox_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.telemetry_outbox_id_seq OWNER TO fleet_user;

--
-- Name: telemetry_outbox_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleet_user
--

ALTER SEQUENCE public.telemetry_outbox_id_seq OWNED BY public.telemetry_outbox.id;


--
-- Name: telemetry_points; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_points (
    id bigint NOT NULL,
    event_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    tenant_id uuid NOT NULL,
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    speed real DEFAULT 0 NOT NULL,
    heading smallint DEFAULT 0 NOT NULL,
    ignition boolean DEFAULT false NOT NULL,
    fuel_level real,
    odometer double precision,
    event_type character varying(20) DEFAULT 'GPS'::character varying NOT NULL,
    sequence_no bigint DEFAULT 0 NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    geo public.geometry(Point,4326),
    CONSTRAINT check_coords CHECK ((((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)) AND ((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision))))
)
PARTITION BY RANGE (recorded_at);


ALTER TABLE public.telemetry_points OWNER TO fleet_user;

--
-- Name: TABLE telemetry_points; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.telemetry_points IS 'Monthly-partitioned AIS-140 telemetry — hot store (30-90 day retention)';


--
-- Name: telemetry_points_id_seq; Type: SEQUENCE; Schema: public; Owner: fleet_user
--

CREATE SEQUENCE public.telemetry_points_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.telemetry_points_id_seq OWNER TO fleet_user;

--
-- Name: telemetry_points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleet_user
--

ALTER SEQUENCE public.telemetry_points_id_seq OWNED BY public.telemetry_points.id;


--
-- Name: telemetry_points_y2026m01; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_points_y2026m01 (
    id bigint DEFAULT nextval('public.telemetry_points_id_seq'::regclass) NOT NULL,
    event_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    tenant_id uuid NOT NULL,
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    speed real DEFAULT 0 NOT NULL,
    heading smallint DEFAULT 0 NOT NULL,
    ignition boolean DEFAULT false NOT NULL,
    fuel_level real,
    odometer double precision,
    event_type character varying(20) DEFAULT 'GPS'::character varying NOT NULL,
    sequence_no bigint DEFAULT 0 NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    geo public.geometry(Point,4326),
    CONSTRAINT check_coords CHECK ((((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)) AND ((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision))))
);


ALTER TABLE public.telemetry_points_y2026m01 OWNER TO fleet_user;

--
-- Name: telemetry_points_y2026m02; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_points_y2026m02 (
    id bigint DEFAULT nextval('public.telemetry_points_id_seq'::regclass) NOT NULL,
    event_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    tenant_id uuid NOT NULL,
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    speed real DEFAULT 0 NOT NULL,
    heading smallint DEFAULT 0 NOT NULL,
    ignition boolean DEFAULT false NOT NULL,
    fuel_level real,
    odometer double precision,
    event_type character varying(20) DEFAULT 'GPS'::character varying NOT NULL,
    sequence_no bigint DEFAULT 0 NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    geo public.geometry(Point,4326),
    CONSTRAINT check_coords CHECK ((((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)) AND ((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision))))
);


ALTER TABLE public.telemetry_points_y2026m02 OWNER TO fleet_user;

--
-- Name: telemetry_points_y2026m03; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_points_y2026m03 (
    id bigint DEFAULT nextval('public.telemetry_points_id_seq'::regclass) NOT NULL,
    event_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    tenant_id uuid NOT NULL,
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    speed real DEFAULT 0 NOT NULL,
    heading smallint DEFAULT 0 NOT NULL,
    ignition boolean DEFAULT false NOT NULL,
    fuel_level real,
    odometer double precision,
    event_type character varying(20) DEFAULT 'GPS'::character varying NOT NULL,
    sequence_no bigint DEFAULT 0 NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    geo public.geometry(Point,4326),
    CONSTRAINT check_coords CHECK ((((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)) AND ((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision))))
);


ALTER TABLE public.telemetry_points_y2026m03 OWNER TO fleet_user;

--
-- Name: telemetry_points_y2026m04; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_points_y2026m04 (
    id bigint DEFAULT nextval('public.telemetry_points_id_seq'::regclass) NOT NULL,
    event_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    tenant_id uuid NOT NULL,
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    speed real DEFAULT 0 NOT NULL,
    heading smallint DEFAULT 0 NOT NULL,
    ignition boolean DEFAULT false NOT NULL,
    fuel_level real,
    odometer double precision,
    event_type character varying(20) DEFAULT 'GPS'::character varying NOT NULL,
    sequence_no bigint DEFAULT 0 NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    geo public.geometry(Point,4326),
    CONSTRAINT check_coords CHECK ((((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)) AND ((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision))))
);


ALTER TABLE public.telemetry_points_y2026m04 OWNER TO fleet_user;

--
-- Name: telemetry_points_y2026m05; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_points_y2026m05 (
    id bigint DEFAULT nextval('public.telemetry_points_id_seq'::regclass) NOT NULL,
    event_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    tenant_id uuid NOT NULL,
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    speed real DEFAULT 0 NOT NULL,
    heading smallint DEFAULT 0 NOT NULL,
    ignition boolean DEFAULT false NOT NULL,
    fuel_level real,
    odometer double precision,
    event_type character varying(20) DEFAULT 'GPS'::character varying NOT NULL,
    sequence_no bigint DEFAULT 0 NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    geo public.geometry(Point,4326),
    CONSTRAINT check_coords CHECK ((((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)) AND ((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision))))
);


ALTER TABLE public.telemetry_points_y2026m05 OWNER TO fleet_user;

--
-- Name: telemetry_points_y2026m06; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_points_y2026m06 (
    id bigint DEFAULT nextval('public.telemetry_points_id_seq'::regclass) NOT NULL,
    event_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    tenant_id uuid NOT NULL,
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    speed real DEFAULT 0 NOT NULL,
    heading smallint DEFAULT 0 NOT NULL,
    ignition boolean DEFAULT false NOT NULL,
    fuel_level real,
    odometer double precision,
    event_type character varying(20) DEFAULT 'GPS'::character varying NOT NULL,
    sequence_no bigint DEFAULT 0 NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    geo public.geometry(Point,4326),
    CONSTRAINT check_coords CHECK ((((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)) AND ((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision))))
);


ALTER TABLE public.telemetry_points_y2026m06 OWNER TO fleet_user;

--
-- Name: telemetry_points_y2026m07; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_points_y2026m07 (
    id bigint DEFAULT nextval('public.telemetry_points_id_seq'::regclass) NOT NULL,
    event_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    tenant_id uuid NOT NULL,
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    speed real DEFAULT 0 NOT NULL,
    heading smallint DEFAULT 0 NOT NULL,
    ignition boolean DEFAULT false NOT NULL,
    fuel_level real,
    odometer double precision,
    event_type character varying(20) DEFAULT 'GPS'::character varying NOT NULL,
    sequence_no bigint DEFAULT 0 NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    geo public.geometry(Point,4326),
    CONSTRAINT check_coords CHECK ((((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)) AND ((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision))))
);


ALTER TABLE public.telemetry_points_y2026m07 OWNER TO fleet_user;

--
-- Name: telemetry_points_y2026m08; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_points_y2026m08 (
    id bigint DEFAULT nextval('public.telemetry_points_id_seq'::regclass) NOT NULL,
    event_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    tenant_id uuid NOT NULL,
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    speed real DEFAULT 0 NOT NULL,
    heading smallint DEFAULT 0 NOT NULL,
    ignition boolean DEFAULT false NOT NULL,
    fuel_level real,
    odometer double precision,
    event_type character varying(20) DEFAULT 'GPS'::character varying NOT NULL,
    sequence_no bigint DEFAULT 0 NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    geo public.geometry(Point,4326),
    CONSTRAINT check_coords CHECK ((((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)) AND ((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision))))
);


ALTER TABLE public.telemetry_points_y2026m08 OWNER TO fleet_user;

--
-- Name: telemetry_points_y2026m09; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_points_y2026m09 (
    id bigint DEFAULT nextval('public.telemetry_points_id_seq'::regclass) NOT NULL,
    event_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    tenant_id uuid NOT NULL,
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    speed real DEFAULT 0 NOT NULL,
    heading smallint DEFAULT 0 NOT NULL,
    ignition boolean DEFAULT false NOT NULL,
    fuel_level real,
    odometer double precision,
    event_type character varying(20) DEFAULT 'GPS'::character varying NOT NULL,
    sequence_no bigint DEFAULT 0 NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    geo public.geometry(Point,4326),
    CONSTRAINT check_coords CHECK ((((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)) AND ((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision))))
);


ALTER TABLE public.telemetry_points_y2026m09 OWNER TO fleet_user;

--
-- Name: telemetry_points_y2026m10; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_points_y2026m10 (
    id bigint DEFAULT nextval('public.telemetry_points_id_seq'::regclass) NOT NULL,
    event_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    tenant_id uuid NOT NULL,
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    speed real DEFAULT 0 NOT NULL,
    heading smallint DEFAULT 0 NOT NULL,
    ignition boolean DEFAULT false NOT NULL,
    fuel_level real,
    odometer double precision,
    event_type character varying(20) DEFAULT 'GPS'::character varying NOT NULL,
    sequence_no bigint DEFAULT 0 NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    geo public.geometry(Point,4326),
    CONSTRAINT check_coords CHECK ((((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)) AND ((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision))))
);


ALTER TABLE public.telemetry_points_y2026m10 OWNER TO fleet_user;

--
-- Name: telemetry_points_y2026m11; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_points_y2026m11 (
    id bigint DEFAULT nextval('public.telemetry_points_id_seq'::regclass) NOT NULL,
    event_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    tenant_id uuid NOT NULL,
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    speed real DEFAULT 0 NOT NULL,
    heading smallint DEFAULT 0 NOT NULL,
    ignition boolean DEFAULT false NOT NULL,
    fuel_level real,
    odometer double precision,
    event_type character varying(20) DEFAULT 'GPS'::character varying NOT NULL,
    sequence_no bigint DEFAULT 0 NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    geo public.geometry(Point,4326),
    CONSTRAINT check_coords CHECK ((((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)) AND ((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision))))
);


ALTER TABLE public.telemetry_points_y2026m11 OWNER TO fleet_user;

--
-- Name: telemetry_points_y2026m12; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_points_y2026m12 (
    id bigint DEFAULT nextval('public.telemetry_points_id_seq'::regclass) NOT NULL,
    event_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    tenant_id uuid NOT NULL,
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    speed real DEFAULT 0 NOT NULL,
    heading smallint DEFAULT 0 NOT NULL,
    ignition boolean DEFAULT false NOT NULL,
    fuel_level real,
    odometer double precision,
    event_type character varying(20) DEFAULT 'GPS'::character varying NOT NULL,
    sequence_no bigint DEFAULT 0 NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    geo public.geometry(Point,4326),
    CONSTRAINT check_coords CHECK ((((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)) AND ((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision))))
);


ALTER TABLE public.telemetry_points_y2026m12 OWNER TO fleet_user;

--
-- Name: telemetry_points_y2027m01; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry_points_y2027m01 (
    id bigint DEFAULT nextval('public.telemetry_points_id_seq'::regclass) NOT NULL,
    event_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    tenant_id uuid NOT NULL,
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    speed real DEFAULT 0 NOT NULL,
    heading smallint DEFAULT 0 NOT NULL,
    ignition boolean DEFAULT false NOT NULL,
    fuel_level real,
    odometer double precision,
    event_type character varying(20) DEFAULT 'GPS'::character varying NOT NULL,
    sequence_no bigint DEFAULT 0 NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    geo public.geometry(Point,4326),
    CONSTRAINT check_coords CHECK ((((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)) AND ((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision))))
);


ALTER TABLE public.telemetry_points_y2027m01 OWNER TO fleet_user;

--
-- Name: templates; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.templates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    template_key character varying(100) NOT NULL,
    channel character varying(50) NOT NULL,
    subject character varying(500),
    body text NOT NULL,
    variables text[] DEFAULT '{}'::text[],
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by uuid NOT NULL
);


ALTER TABLE public.templates OWNER TO fleet_user;

--
-- Name: TABLE templates; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.templates IS 'Communication templates (Email/SMS)';


--
-- Name: threat_alerts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.threat_alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    ip character varying(45),
    user_id uuid,
    description text,
    status character varying(20) DEFAULT 'open'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.threat_alerts OWNER TO fleet_user;

--
-- Name: ticket_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.ticket_events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ticket_id uuid NOT NULL,
    author_id uuid,
    author_name text,
    event_type text NOT NULL,
    message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ticket_events OWNER TO fleet_user;

--
-- Name: toll_transactions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.toll_transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    vehicle_id uuid NOT NULL,
    fastag_id character varying(100) NOT NULL,
    toll_plaza character varying(255) NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'INR'::character varying,
    transaction_time timestamp with time zone NOT NULL,
    external_transaction_id character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    org_id uuid,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.toll_transactions OWNER TO fleet_user;

--
-- Name: TABLE toll_transactions; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.toll_transactions IS 'Toll transactions ingested from FASTag providers';


--
-- Name: tracking_config; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.tracking_config (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    target_id uuid NOT NULL,
    target_type character varying(20) NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tracking_config_target_type_check CHECK (((target_type)::text = ANY ((ARRAY['vehicle'::character varying, 'tenant'::character varying])::text[])))
);


ALTER TABLE public.tracking_config OWNER TO fleet_user;

--
-- Name: TABLE tracking_config; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.tracking_config IS 'Custom thresholds for anomaly detection per vehicle/tenant';


--
-- Name: trip_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.trip_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    retention_period integer DEFAULT 36,
    policies jsonb DEFAULT '{}'::jsonb,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.trip_settings OWNER TO fleet_user;

--
-- Name: trips; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.trips (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    vehicle_id uuid,
    driver_id uuid,
    status character varying(50) DEFAULT 'planned'::character varying NOT NULL,
    title character varying(255),
    description text,
    planned_route jsonb,
    actual_route jsonb,
    waypoints jsonb,
    start_location jsonb,
    end_location jsonb,
    estimated_distance_km numeric(10,2),
    actual_distance_km numeric(10,2),
    estimated_duration_min integer,
    actual_duration_min integer,
    fuel_consumed_liters numeric(10,2) DEFAULT 0,
    idling_time_minutes integer DEFAULT 0,
    cargo_details jsonb,
    pod_documents jsonb,
    scheduled_start timestamp with time zone,
    started_at timestamp with time zone,
    ended_at timestamp with time zone,
    customer_name character varying(255),
    customer_phone character varying(50),
    customer_email character varying(255),
    cancellation_reason text,
    events jsonb,
    is_deleted boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.trips OWNER TO fleet_user;

--
-- Name: usage_meters; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.usage_meters (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    unit character varying(20) NOT NULL,
    unit_price numeric(15,4) DEFAULT 0.0000 NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.usage_meters OWNER TO fleet_user;

--
-- Name: user_invoice_access; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.user_invoice_access (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    override_role boolean DEFAULT false,
    can_create_invoice boolean DEFAULT false,
    can_edit_invoice boolean DEFAULT false,
    can_delete_invoice boolean DEFAULT false,
    can_issue_invoice boolean DEFAULT false,
    can_cancel_invoice boolean DEFAULT false,
    can_record_payment boolean DEFAULT false,
    can_approve_invoices boolean DEFAULT false,
    approval_limit numeric(12,2),
    max_invoice_amount numeric(12,2),
    require_approval_above numeric(12,2),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    deleted_at timestamp with time zone
);


ALTER TABLE public.user_invoice_access OWNER TO fleet_user;

--
-- Name: TABLE user_invoice_access; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.user_invoice_access IS 'Per-user invoice access overrides';


--
-- Name: user_notes; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.user_notes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    agent_name text NOT NULL,
    note text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_notes OWNER TO fleet_user;

--
-- Name: user_notification_preferences; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.user_notification_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    email_enabled boolean DEFAULT true NOT NULL,
    sms_enabled boolean DEFAULT false NOT NULL,
    push_enabled boolean DEFAULT true NOT NULL,
    in_app_enabled boolean DEFAULT true NOT NULL,
    last_modified_by uuid,
    last_modified_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_notification_preferences OWNER TO fleet_user;

--
-- Name: user_oidc_links; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.user_oidc_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    provider_id uuid,
    provider_user_id text NOT NULL,
    email text,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_oidc_links OWNER TO fleet_user;

--
-- Name: user_organizations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.user_organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    role character varying(50) DEFAULT 'member'::character varying,
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_organizations OWNER TO fleet_user;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    session_id character varying(100) NOT NULL,
    ip_address character varying(45),
    user_agent text,
    device_info jsonb,
    login_time timestamp with time zone DEFAULT now(),
    last_activity timestamp with time zone DEFAULT now(),
    logout_time timestamp with time zone,
    is_active boolean DEFAULT true,
    location jsonb
);


ALTER TABLE public.user_sessions OWNER TO fleet_user;

--
-- Name: TABLE user_sessions; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.user_sessions IS 'User session tracking for support investigations';


--
-- Name: users; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash text NOT NULL,
    name character varying(255),
    phone character varying(50),
    mfa_enabled boolean DEFAULT false,
    mfa_secret text,
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    theme_updated_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    role_id uuid,
    mfa_methods text[] DEFAULT '{}'::text[],
    last_password_change timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    last_login_at timestamp with time zone,
    data_retention_until timestamp with time zone
);


ALTER TABLE public.users OWNER TO fleet_user;

--
-- Name: COLUMN users.failed_login_attempts; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.users.failed_login_attempts IS 'Count of consecutive failed login attempts';


--
-- Name: COLUMN users.locked_until; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.users.locked_until IS 'Account lockout expiry time';


--
-- Name: v_analytics_capacity_stats; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.v_analytics_capacity_stats AS
 SELECT pg_stat_user_tables.schemaname,
    pg_stat_user_tables.relname AS table_name,
    pg_size_pretty(pg_total_relation_size((pg_stat_user_tables.relid)::regclass)) AS total_size,
    pg_relation_size((pg_stat_user_tables.relid)::regclass) AS data_size,
    ( SELECT count(*) AS count
           FROM pg_inherits
          WHERE (pg_inherits.inhparent = pg_stat_user_tables.relid)) AS partition_count
   FROM pg_stat_user_tables
  WHERE (pg_stat_user_tables.relname = ANY (ARRAY['vehicle_daily_stats'::name, 'prediction_results'::name, 'ml_feature_store'::name, 'analytics_query_logs'::name]));


ALTER VIEW public.v_analytics_capacity_stats OWNER TO fleet_user;

--
-- Name: v_live_locations; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.v_live_locations AS
 SELECT DISTINCT ON (telemetry_points.vehicle_id) telemetry_points.vehicle_id,
    telemetry_points.device_id,
    telemetry_points.lat,
    telemetry_points.lng,
    telemetry_points.speed,
    telemetry_points.heading,
    telemetry_points.ignition,
    telemetry_points.recorded_at AS last_seen
   FROM public.telemetry_points
  WHERE (telemetry_points.received_at > (now() - '00:10:00'::interval))
  ORDER BY telemetry_points.vehicle_id, telemetry_points.recorded_at DESC;


ALTER VIEW public.v_live_locations OWNER TO fleet_user;

--
-- Name: VIEW v_live_locations; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON VIEW public.v_live_locations IS 'Latest GPS point per vehicle within last 10 minutes';


--
-- Name: vehicle_assignments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicle_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid,
    driver_id uuid,
    device_id uuid,
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    ended_at timestamp with time zone,
    is_active boolean DEFAULT true
);


ALTER TABLE public.vehicle_assignments OWNER TO fleet_user;

--
-- Name: vehicle_compliance; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicle_compliance (
    vehicle_id uuid NOT NULL,
    rc_expiry_date date,
    insurance_expiry_date date,
    puc_expiry_date date,
    fitness_expiry_date date,
    permit_expiry_date date,
    permit_type character varying(50),
    insurance_policy_no character varying(100),
    is_blacklisted boolean DEFAULT false NOT NULL,
    legal_hold boolean DEFAULT false NOT NULL,
    last_verified_at timestamp with time zone,
    verified_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.vehicle_compliance OWNER TO fleet_user;

--
-- Name: TABLE vehicle_compliance; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.vehicle_compliance IS 'India-regulatory compliance dates and flags (RC, Insurance, PUC, Fitness, Permit)';


--
-- Name: vehicle_daily_stats; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicle_daily_stats (
    vehicle_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    date date NOT NULL,
    total_distance numeric(15,2) DEFAULT 0,
    total_fuel_consumed numeric(15,2) DEFAULT 0,
    total_engine_hours numeric(15,2) DEFAULT 0,
    total_idle_hours numeric(15,2) DEFAULT 0,
    max_speed numeric(10,2) DEFAULT 0,
    avg_speed numeric(10,2) DEFAULT 0,
    harsh_braking_count integer DEFAULT 0,
    rapid_acceleration_count integer DEFAULT 0,
    sharp_turn_count integer DEFAULT 0,
    overspeeding_count integer DEFAULT 0,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.vehicle_daily_stats OWNER TO fleet_user;

--
-- Name: TABLE vehicle_daily_stats; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.vehicle_daily_stats IS 'Pre-aggregated daily metrics per vehicle';


--
-- Name: vehicle_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicle_events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    vehicle_id uuid NOT NULL,
    event_type character varying(50) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    hash character varying(64) NOT NULL,
    prev_hash character varying(64),
    actor_id uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.vehicle_events OWNER TO fleet_user;

--
-- Name: TABLE vehicle_events; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.vehicle_events IS 'Append-only, hash-chained audit event log';


--
-- Name: vehicle_financials; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicle_financials (
    vehicle_id uuid NOT NULL,
    acquisition_cost numeric(15,2),
    depreciation_method character varying(20),
    depreciation_rate numeric(5,2),
    residual_value numeric(15,2),
    emi_amount numeric(15,2),
    lease_end_date date,
    insurance_premium numeric(15,2),
    total_maintenance_cost numeric(15,2) DEFAULT 0 NOT NULL,
    total_fuel_cost numeric(15,2) DEFAULT 0 NOT NULL,
    total_toll_cost numeric(15,2) DEFAULT 0 NOT NULL,
    tco_cached numeric(15,2),
    tco_calculated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT vehicle_financials_depreciation_method_check CHECK (((depreciation_method)::text = ANY ((ARRAY['STRAIGHT_LINE'::character varying, 'DECLINING_BALANCE'::character varying, 'UNITS_OF_PRODUCTION'::character varying])::text[])))
);


ALTER TABLE public.vehicle_financials OWNER TO fleet_user;

--
-- Name: TABLE vehicle_financials; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.vehicle_financials IS 'Acquisition cost, depreciation, EMI, lease, and TCO aggregates';


--
-- Name: vehicle_inspections; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicle_inspections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    template_id uuid,
    inspector_id uuid NOT NULL,
    status character varying(20) DEFAULT 'COMPLETED'::character varying,
    results jsonb DEFAULT '[]'::jsonb NOT NULL,
    notes text,
    odometer_at_inspection bigint,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.vehicle_inspections OWNER TO fleet_user;

--
-- Name: TABLE vehicle_inspections; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.vehicle_inspections IS 'Completed vehicle inspection reports';


--
-- Name: vehicle_specs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicle_specs (
    vehicle_id uuid NOT NULL,
    fuel_type character varying(50),
    tank_capacity_liters numeric(10,2) NOT NULL,
    efficiency_expected_km_l numeric(10,2),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.vehicle_specs OWNER TO fleet_user;

--
-- Name: TABLE vehicle_specs; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.vehicle_specs IS 'Technical specifications for vehicles used for validation';


--
-- Name: COLUMN vehicle_specs.tank_capacity_liters; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.vehicle_specs.tank_capacity_liters IS 'Maximum fuel tank capacity in liters';


--
-- Name: vehicle_telemetry; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicle_telemetry (
    "time" timestamp with time zone NOT NULL,
    vehicle_id uuid NOT NULL,
    latitude double precision,
    longitude double precision,
    speed_kph double precision,
    heading double precision,
    odometer_km double precision,
    fuel_level_percent double precision,
    engine_temp_celsius double precision,
    alerts jsonb DEFAULT '[]'::jsonb
);


ALTER TABLE public.vehicle_telemetry OWNER TO fleet_user;

--
-- Name: TABLE vehicle_telemetry; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.vehicle_telemetry IS 'Aggregated telemetry data for trip reporting';


--
-- Name: vehicle_verifications; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicle_verifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    registration_number character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    verification_date timestamp with time zone NOT NULL,
    chassis_number character varying(50),
    engine_number character varying(50),
    model character varying(100),
    manufacturer character varying(100),
    fuel_type character varying(30),
    body_type character varying(50),
    cubic_capacity integer,
    seating_capacity integer,
    color character varying(30),
    manufacturing_year integer,
    owner_name character varying(200),
    owner_address text,
    owner_city character varying(100),
    owner_district character varying(100),
    owner_state character varying(100),
    owner_pin character varying(10),
    rc_status character varying(20),
    insurance_company character varying(100),
    insurance_policy character varying(100),
    insurance_expiry timestamp with time zone,
    puc_number character varying(50),
    puc_expiry timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid NOT NULL,
    CONSTRAINT vehicle_verifications_rc_status_check CHECK (((rc_status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'suspended'::character varying])::text[]))),
    CONSTRAINT vehicle_verifications_status_check CHECK (((status)::text = ANY ((ARRAY['verified'::character varying, 'pending'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.vehicle_verifications OWNER TO fleet_user;

--
-- Name: TABLE vehicle_verifications; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.vehicle_verifications IS 'VAHAN vehicle registration verification records';


--
-- Name: COLUMN vehicle_verifications.rc_status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.vehicle_verifications.rc_status IS 'Registration Certificate status: active, inactive, suspended';


--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    registration_number character varying(50) NOT NULL,
    chassis_number text,
    engine_number text,
    vin_number character varying(50),
    vehicle_type character varying(30) DEFAULT 'TRUCK'::character varying NOT NULL,
    capacity_tonnage numeric(10,2),
    fuel_type character varying(20) DEFAULT 'DIESEL'::character varying NOT NULL,
    fuel_tank_capacity numeric(10,2),
    ownership_type character varying(20) DEFAULT 'OWNED'::character varying NOT NULL,
    parent_vehicle_id uuid,
    branch_id uuid,
    cost_center_id uuid,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    gps_device_id character varying(100),
    immobilizer_enabled boolean DEFAULT false NOT NULL,
    ais140_compliant boolean DEFAULT false NOT NULL,
    make character varying(100),
    model character varying(100),
    year integer,
    color character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    CONSTRAINT vehicles_fuel_type_check CHECK (((fuel_type)::text = ANY ((ARRAY['PETROL'::character varying, 'DIESEL'::character varying, 'CNG'::character varying, 'ELECTRIC'::character varying, 'HYBRID'::character varying, 'LPG'::character varying])::text[]))),
    CONSTRAINT vehicles_ownership_type_check CHECK (((ownership_type)::text = ANY ((ARRAY['OWNED'::character varying, 'LEASED'::character varying, 'FINANCED'::character varying, 'VENDOR'::character varying])::text[]))),
    CONSTRAINT vehicles_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'MAINTENANCE'::character varying, 'SUSPENDED'::character varying, 'DECOMMISSIONED'::character varying])::text[]))),
    CONSTRAINT vehicles_vehicle_type_check CHECK (((vehicle_type)::text = ANY ((ARRAY['TRUCK'::character varying, 'BUS'::character varying, 'VAN'::character varying, 'CAR'::character varying, 'TRAILER'::character varying, 'TANKER'::character varying, 'TIPPER'::character varying, 'CRANE'::character varying, 'OTHER'::character varying])::text[])))
);


ALTER TABLE public.vehicles OWNER TO fleet_user;

--
-- Name: TABLE vehicles; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.vehicles IS 'Vehicle aggregate root — enterprise master';


--
-- Name: COLUMN vehicles.chassis_number; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.vehicles.chassis_number IS 'AES-256 encrypted at application layer';


--
-- Name: COLUMN vehicles.engine_number; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.vehicles.engine_number IS 'AES-256 encrypted at application layer';


--
-- Name: COLUMN vehicles.version; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.vehicles.version IS 'Optimistic concurrency control version counter';


--
-- Name: vehicles_due_for_compliance; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.vehicles_due_for_compliance AS
 SELECT v.id AS vehicle_id,
    v.tenant_id,
    v.registration_number,
    v.status,
    c.rc_expiry_date,
    c.insurance_expiry_date,
    c.puc_expiry_date,
    c.fitness_expiry_date,
    c.permit_expiry_date,
    LEAST(c.rc_expiry_date, c.insurance_expiry_date, c.puc_expiry_date, c.fitness_expiry_date, c.permit_expiry_date) AS earliest_expiry,
    (LEAST(c.rc_expiry_date, c.insurance_expiry_date, c.puc_expiry_date, c.fitness_expiry_date, c.permit_expiry_date) - CURRENT_DATE) AS days_to_expiry
   FROM (public.vehicles v
     JOIN public.vehicle_compliance c ON ((c.vehicle_id = v.id)))
  WHERE ((v.deleted_at IS NULL) AND ((v.status)::text <> 'DECOMMISSIONED'::text) AND (LEAST(c.rc_expiry_date, c.insurance_expiry_date, c.puc_expiry_date, c.fitness_expiry_date, c.permit_expiry_date) IS NOT NULL))
  ORDER BY LEAST(c.rc_expiry_date, c.insurance_expiry_date, c.puc_expiry_date, c.fitness_expiry_date, c.permit_expiry_date);


ALTER VIEW public.vehicles_due_for_compliance OWNER TO fleet_user;

--
-- Name: vehicles_legacy; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicles_legacy (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    license_plate character varying(20) NOT NULL,
    model character varying(50) NOT NULL,
    make character varying(50) NOT NULL,
    year integer NOT NULL,
    color character varying(30),
    status character varying(20) DEFAULT 'active'::character varying,
    capacity integer DEFAULT 1,
    fuel_type character varying(20),
    vin character varying(50),
    registration character varying(50),
    insurance character varying(50),
    odometer bigint DEFAULT 0,
    last_service timestamp with time zone,
    current_driver_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    vehicle_no character varying(50),
    service_due timestamp with time zone,
    notes text,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.vehicles_legacy OWNER TO fleet_user;

--
-- Name: vendor_payments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vendor_payments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    vendor_id uuid NOT NULL,
    org_id uuid NOT NULL,
    invoice_number character varying(50) NOT NULL,
    amount numeric(15,2) NOT NULL,
    tds_deducted numeric(15,2) DEFAULT 0,
    net_payable numeric(15,2) NOT NULL,
    currency character varying(3) DEFAULT 'INR'::character varying,
    payment_status character varying(20) DEFAULT 'PENDING'::character varying,
    payment_mode character varying(30),
    payment_reference character varying(100),
    bank_account character varying(30),
    ifsc_code character varying(11),
    payment_date date,
    paid_at timestamp with time zone,
    gst_invoice_id uuid,
    tds_record_id uuid,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.vendor_payments OWNER TO fleet_user;

--
-- Name: TABLE vendor_payments; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.vendor_payments IS 'Vendor payment ledger tracking all payments to fuel stations and providers';


--
-- Name: video_analytics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.video_analytics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    recording_id uuid NOT NULL,
    stream_id uuid,
    objects_detected jsonb DEFAULT '[]'::jsonb NOT NULL,
    behavior_events jsonb DEFAULT '[]'::jsonb NOT NULL,
    traffic_signs jsonb DEFAULT '[]'::jsonb NOT NULL,
    incidents jsonb DEFAULT '[]'::jsonb NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    confidence numeric(3,2) NOT NULL,
    processed_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT video_analytics_confidence_check CHECK (((confidence >= (0)::numeric) AND (confidence <= (1)::numeric)))
);


ALTER TABLE public.video_analytics OWNER TO fleet_user;

--
-- Name: TABLE video_analytics; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.video_analytics IS 'Stores AI-powered insights extracted from video analysis';


--
-- Name: COLUMN video_analytics.objects_detected; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_analytics.objects_detected IS 'List of objects detected in the video';


--
-- Name: COLUMN video_analytics.behavior_events; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_analytics.behavior_events IS 'List of behavioral events detected in the video';


--
-- Name: COLUMN video_analytics.incidents; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_analytics.incidents IS 'List of incidents detected in the video';


--
-- Name: COLUMN video_analytics.confidence; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_analytics.confidence IS 'Confidence score for the analytics results (0-1)';


--
-- Name: video_recordings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.video_recordings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    stream_id uuid NOT NULL,
    camera_id character varying(255) NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    filename character varying(500) NOT NULL,
    filepath text NOT NULL,
    file_size bigint NOT NULL,
    duration integer NOT NULL,
    resolution character varying(20),
    framerate integer,
    bitrate integer,
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone NOT NULL,
    location_start jsonb NOT NULL,
    location_end jsonb NOT NULL,
    status character varying(50) DEFAULT 'processing'::character varying NOT NULL,
    thumbnail_path text,
    tags jsonb DEFAULT '[]'::jsonb,
    event_type character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.video_recordings OWNER TO fleet_user;

--
-- Name: TABLE video_recordings; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.video_recordings IS 'Stores information about recorded video clips';


--
-- Name: COLUMN video_recordings.status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_recordings.status IS 'Status of the video recording (recorded, processing, available, archived, deleted)';


--
-- Name: COLUMN video_recordings.event_type; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_recordings.event_type IS 'Type of event that triggered the recording (sudden_stop, harsh_acceleration, etc.)';


--
-- Name: video_retention_policies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.video_retention_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    event_type character varying(100),
    retention_period integer NOT NULL,
    auto_archive boolean DEFAULT false,
    auto_delete boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.video_retention_policies OWNER TO fleet_user;

--
-- Name: TABLE video_retention_policies; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.video_retention_policies IS 'Stores retention policies for video data';


--
-- Name: COLUMN video_retention_policies.retention_period; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_retention_policies.retention_period IS 'Number of days to retain videos before archiving/deletion';


--
-- Name: COLUMN video_retention_policies.auto_archive; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_retention_policies.auto_archive IS 'Flag to automatically archive videos after retention period';


--
-- Name: COLUMN video_retention_policies.auto_delete; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_retention_policies.auto_delete IS 'Flag to automatically delete videos after retention period';


--
-- Name: video_streams; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.video_streams (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    camera_id character varying(255) NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    url text NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    resolution character varying(20),
    framerate integer,
    bitrate integer,
    protocol character varying(20),
    location jsonb NOT NULL,
    started_at timestamp with time zone NOT NULL,
    ended_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    analytics_enabled boolean DEFAULT false
);


ALTER TABLE public.video_streams OWNER TO fleet_user;

--
-- Name: TABLE video_streams; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.video_streams IS 'Stores information about live video streams from vehicles';


--
-- Name: COLUMN video_streams.status; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_streams.status IS 'Status of the video stream (active, inactive, error)';


--
-- Name: COLUMN video_streams.analytics_enabled; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.video_streams.analytics_enabled IS 'Flag to enable AI-powered analytics on this stream';


--
-- Name: webhook_event_types; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.webhook_event_types (
    event_type character varying(100) NOT NULL,
    description text,
    category character varying(50),
    is_active boolean DEFAULT true
);


ALTER TABLE public.webhook_event_types OWNER TO fleet_user;

--
-- Name: TABLE webhook_event_types; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.webhook_event_types IS 'Available webhook event types';


--
-- Name: webhook_subscriptions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.webhook_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    url text NOT NULL,
    secret character varying(255) NOT NULL,
    is_active boolean DEFAULT true,
    events text[] NOT NULL,
    custom_headers jsonb DEFAULT '{}'::jsonb,
    max_retries integer DEFAULT 3,
    retry_delay_seconds integer DEFAULT 60,
    timeout_seconds integer DEFAULT 30,
    rate_limit_per_minute integer DEFAULT 60,
    total_deliveries integer DEFAULT 0,
    successful_deliveries integer DEFAULT 0,
    failed_deliveries integer DEFAULT 0,
    last_delivery_at timestamp with time zone,
    last_success_at timestamp with time zone,
    last_failure_at timestamp with time zone,
    description text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT chk_webhook_max_retries CHECK (((max_retries >= 0) AND (max_retries <= 10))),
    CONSTRAINT chk_webhook_rate_limit CHECK (((rate_limit_per_minute >= 1) AND (rate_limit_per_minute <= 1000))),
    CONSTRAINT chk_webhook_retry_delay CHECK (((retry_delay_seconds >= 10) AND (retry_delay_seconds <= 3600))),
    CONSTRAINT chk_webhook_timeout CHECK (((timeout_seconds >= 5) AND (timeout_seconds <= 300)))
);


ALTER TABLE public.webhook_subscriptions OWNER TO fleet_user;

--
-- Name: TABLE webhook_subscriptions; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.webhook_subscriptions IS 'Webhook subscription configuration for external integrations';


--
-- Name: COLUMN webhook_subscriptions.secret; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.webhook_subscriptions.secret IS 'HMAC secret for request signature verification';


--
-- Name: COLUMN webhook_subscriptions.events; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.webhook_subscriptions.events IS 'Array of event types to subscribe to';


--
-- Name: webhook_subscription_stats; Type: VIEW; Schema: public; Owner: fleet_user
--

CREATE VIEW public.webhook_subscription_stats AS
 SELECT ws.id,
    ws.org_id,
    ws.name,
    ws.url,
    ws.is_active,
    ws.total_deliveries,
    ws.successful_deliveries,
    ws.failed_deliveries,
        CASE
            WHEN (ws.total_deliveries > 0) THEN round((((ws.successful_deliveries)::numeric / (ws.total_deliveries)::numeric) * (100)::numeric), 2)
            ELSE (0)::numeric
        END AS success_rate,
    ws.last_delivery_at,
    ws.last_success_at,
    ws.last_failure_at
   FROM public.webhook_subscriptions ws
  WHERE (ws.deleted_at IS NULL);


ALTER VIEW public.webhook_subscription_stats OWNER TO fleet_user;

--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    url text NOT NULL,
    events text[] DEFAULT '{}'::text[],
    secret character varying(255),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.webhooks OWNER TO fleet_user;

--
-- Name: work_order_parts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.work_order_parts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    work_order_id uuid NOT NULL,
    part_id uuid NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_cost numeric(10,2) NOT NULL,
    total_cost numeric(10,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.work_order_parts OWNER TO fleet_user;

--
-- Name: work_orders; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.work_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    vehicle_id uuid,
    title text NOT NULL,
    description text,
    maintenance_type text DEFAULT 'PREVENTIVE'::text NOT NULL,
    priority text DEFAULT 'MEDIUM'::text NOT NULL,
    status text DEFAULT 'OPEN'::text NOT NULL,
    assigned_to uuid,
    scheduled_date timestamp with time zone,
    completed_date timestamp with time zone,
    estimated_cost double precision DEFAULT 0 NOT NULL,
    actual_cost double precision DEFAULT 0 NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    vendor_id uuid,
    approval_status text DEFAULT 'PENDING'::text NOT NULL,
    cost_breakdown jsonb DEFAULT '{}'::jsonb NOT NULL,
    inspection_id uuid,
    updated_by uuid
);


ALTER TABLE public.work_orders OWNER TO fleet_user;

--
-- Name: telemetry_points_y2026m01; Type: TABLE ATTACH; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points ATTACH PARTITION public.telemetry_points_y2026m01 FOR VALUES FROM ('2026-01-01 00:00:00+00') TO ('2026-02-01 00:00:00+00');


--
-- Name: telemetry_points_y2026m02; Type: TABLE ATTACH; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points ATTACH PARTITION public.telemetry_points_y2026m02 FOR VALUES FROM ('2026-02-01 00:00:00+00') TO ('2026-03-01 00:00:00+00');


--
-- Name: telemetry_points_y2026m03; Type: TABLE ATTACH; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points ATTACH PARTITION public.telemetry_points_y2026m03 FOR VALUES FROM ('2026-03-01 00:00:00+00') TO ('2026-04-01 00:00:00+00');


--
-- Name: telemetry_points_y2026m04; Type: TABLE ATTACH; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points ATTACH PARTITION public.telemetry_points_y2026m04 FOR VALUES FROM ('2026-04-01 00:00:00+00') TO ('2026-05-01 00:00:00+00');


--
-- Name: telemetry_points_y2026m05; Type: TABLE ATTACH; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points ATTACH PARTITION public.telemetry_points_y2026m05 FOR VALUES FROM ('2026-05-01 00:00:00+00') TO ('2026-06-01 00:00:00+00');


--
-- Name: telemetry_points_y2026m06; Type: TABLE ATTACH; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points ATTACH PARTITION public.telemetry_points_y2026m06 FOR VALUES FROM ('2026-06-01 00:00:00+00') TO ('2026-07-01 00:00:00+00');


--
-- Name: telemetry_points_y2026m07; Type: TABLE ATTACH; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points ATTACH PARTITION public.telemetry_points_y2026m07 FOR VALUES FROM ('2026-07-01 00:00:00+00') TO ('2026-08-01 00:00:00+00');


--
-- Name: telemetry_points_y2026m08; Type: TABLE ATTACH; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points ATTACH PARTITION public.telemetry_points_y2026m08 FOR VALUES FROM ('2026-08-01 00:00:00+00') TO ('2026-09-01 00:00:00+00');


--
-- Name: telemetry_points_y2026m09; Type: TABLE ATTACH; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points ATTACH PARTITION public.telemetry_points_y2026m09 FOR VALUES FROM ('2026-09-01 00:00:00+00') TO ('2026-10-01 00:00:00+00');


--
-- Name: telemetry_points_y2026m10; Type: TABLE ATTACH; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points ATTACH PARTITION public.telemetry_points_y2026m10 FOR VALUES FROM ('2026-10-01 00:00:00+00') TO ('2026-11-01 00:00:00+00');


--
-- Name: telemetry_points_y2026m11; Type: TABLE ATTACH; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points ATTACH PARTITION public.telemetry_points_y2026m11 FOR VALUES FROM ('2026-11-01 00:00:00+00') TO ('2026-12-01 00:00:00+00');


--
-- Name: telemetry_points_y2026m12; Type: TABLE ATTACH; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points ATTACH PARTITION public.telemetry_points_y2026m12 FOR VALUES FROM ('2026-12-01 00:00:00+00') TO ('2027-01-01 00:00:00+00');


--
-- Name: telemetry_points_y2027m01; Type: TABLE ATTACH; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points ATTACH PARTITION public.telemetry_points_y2027m01 FOR VALUES FROM ('2027-01-01 00:00:00+00') TO ('2027-02-01 00:00:00+00');


--
-- Name: device_alerts id; Type: DEFAULT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_alerts ALTER COLUMN id SET DEFAULT nextval('public.device_alerts_id_seq'::regclass);


--
-- Name: diagnostics_audit_logs id; Type: DEFAULT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.diagnostics_audit_logs ALTER COLUMN id SET DEFAULT nextval('public.diagnostics_audit_logs_id_seq'::regclass);


--
-- Name: rollout_device_status id; Type: DEFAULT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.rollout_device_status ALTER COLUMN id SET DEFAULT nextval('public.rollout_device_status_id_seq'::regclass);


--
-- Name: telemetry_outbox id; Type: DEFAULT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_outbox ALTER COLUMN id SET DEFAULT nextval('public.telemetry_outbox_id_seq'::regclass);


--
-- Name: telemetry_points id; Type: DEFAULT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points ALTER COLUMN id SET DEFAULT nextval('public.telemetry_points_id_seq'::regclass);


--
-- Data for Name: hypertable; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.hypertable (id, schema_name, table_name, associated_schema_name, associated_table_prefix, num_dimensions, chunk_sizing_func_schema, chunk_sizing_func_name, chunk_target_size, compression_state, compressed_hypertable_id, status) FROM stdin;
3	public	gps_locations	_timescaledb_internal	_hyper_3	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
4	public	obd_readings	_timescaledb_internal	_hyper_4	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
5	public	vehicle_telemetry	_timescaledb_internal	_hyper_5	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
6	public	consumption_events	_timescaledb_internal	_hyper_6	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
7	public	sla_metrics	_timescaledb_internal	_hyper_7	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
10	public	geofence_events	_timescaledb_internal	_hyper_10	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
\.


--
-- Data for Name: bgw_job; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.bgw_job (id, application_name, schedule_interval, max_runtime, max_retries, retry_period, proc_schema, proc_name, owner, scheduled, fixed_schedule, initial_start, hypertable_id, config, check_schema, check_name, timezone) FROM stdin;
1000	Retention Policy [1000]	1 day	00:05:00	-1	00:05:00	_timescaledb_functions	policy_retention	fleet_user	t	f	\N	3	{"drop_after": "90 days", "hypertable_id": 3}	_timescaledb_functions	policy_retention_check	\N
1001	Retention Policy [1001]	1 day	00:05:00	-1	00:05:00	_timescaledb_functions	policy_retention	fleet_user	t	f	\N	4	{"drop_after": "90 days", "hypertable_id": 4}	_timescaledb_functions	policy_retention_check	\N
1002	Retention Policy [1002]	1 day	00:05:00	-1	00:05:00	_timescaledb_functions	policy_retention	fleet_user	t	f	\N	10	{"drop_after": "180 days", "hypertable_id": 10}	_timescaledb_functions	policy_retention_check	\N
\.


--
-- Data for Name: chunk; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.chunk (id, hypertable_id, schema_name, table_name, compressed_chunk_id, dropped, status, osm_chunk, creation_time) FROM stdin;
\.


--
-- Data for Name: chunk_column_stats; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.chunk_column_stats (id, hypertable_id, chunk_id, column_name, range_start, range_end, valid) FROM stdin;
\.


--
-- Data for Name: dimension; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.dimension (id, hypertable_id, column_name, column_type, aligned, num_slices, partitioning_func_schema, partitioning_func, interval_length, compress_interval_length, integer_now_func_schema, integer_now_func) FROM stdin;
3	3	time	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
4	4	time	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
5	5	time	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
6	6	time	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
7	7	time	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
10	10	time	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
\.


--
-- Data for Name: dimension_slice; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.dimension_slice (id, dimension_id, range_start, range_end) FROM stdin;
\.


--
-- Data for Name: chunk_constraint; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.chunk_constraint (chunk_id, dimension_slice_id, constraint_name, hypertable_constraint_name) FROM stdin;
\.


--
-- Data for Name: compression_chunk_size; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.compression_chunk_size (chunk_id, compressed_chunk_id, uncompressed_heap_size, uncompressed_toast_size, uncompressed_index_size, compressed_heap_size, compressed_toast_size, compressed_index_size, numrows_pre_compression, numrows_post_compression, numrows_frozen_immediately) FROM stdin;
\.


--
-- Data for Name: compression_settings; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.compression_settings (relid, compress_relid, segmentby, orderby, orderby_desc, orderby_nullsfirst, index) FROM stdin;
\.


--
-- Data for Name: continuous_agg; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_agg (mat_hypertable_id, raw_hypertable_id, parent_mat_hypertable_id, user_view_schema, user_view_name, partial_view_schema, partial_view_name, direct_view_schema, direct_view_name, materialized_only) FROM stdin;
\.


--
-- Data for Name: continuous_agg_migrate_plan; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_agg_migrate_plan (mat_hypertable_id, start_ts, end_ts, user_view_definition) FROM stdin;
\.


--
-- Data for Name: continuous_agg_migrate_plan_step; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_agg_migrate_plan_step (mat_hypertable_id, step_id, status, start_ts, end_ts, type, config) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_bucket_function; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_aggs_bucket_function (mat_hypertable_id, bucket_func, bucket_width, bucket_origin, bucket_offset, bucket_timezone, bucket_fixed_width) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_hypertable_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_aggs_hypertable_invalidation_log (hypertable_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_invalidation_threshold; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_aggs_invalidation_threshold (hypertable_id, watermark) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_aggs_materialization_invalidation_log (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_aggs_materialization_ranges (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_watermark; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.continuous_aggs_watermark (mat_hypertable_id, watermark) FROM stdin;
\.


--
-- Data for Name: metadata; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.metadata (key, value, include_in_telemetry) FROM stdin;
install_timestamp	2026-03-08 17:11:46.825242+00	t
timescaledb_version	2.25.2	f
exported_uuid	5043b269-77b8-4f0d-89ed-25b9edc089a3	t
\.


--
-- Data for Name: tablespace; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: fleet_user
--

COPY _timescaledb_catalog.tablespace (id, hypertable_id, tablespace_name) FROM stdin;
\.


--
-- Data for Name: ab_test_experiments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.ab_test_experiments (id, name, start_date, end_date, status, variants, metrics, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: access_reviews; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.access_reviews (id, org_id, title, status, due_date, total_users, reviewed_users, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: admin_audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.admin_audit_logs (id, actor_id, action, resource_type, resource_id, before_state, after_state, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: admin_operation_approvals; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.admin_operation_approvals (id, operation_type, target_id, payload, requested_by, status, approved_by, created_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: admin_permissions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.admin_permissions (id, name) FROM stdin;
27065261-d0df-4edb-b733-f3bab8f98b31	org.manage
52c8660d-b93e-4722-a8d2-041b943a9c90	ticket.manage
a2050b87-d6bb-4f8e-8404-bc50ec10d14e	incident.manage
b89188d7-5b96-4b41-ba76-f22795e24582	system.override
73e9b202-1635-46b7-8ca7-6059727e687e	dr.execute
\.


--
-- Data for Name: admin_role_permissions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.admin_role_permissions (role, permission) FROM stdin;
SUPER_ADMIN	org.manage
SUPER_ADMIN	ticket.manage
SUPER_ADMIN	incident.manage
SUPER_ADMIN	system.override
SUPER_ADMIN	dr.execute
PLATFORM_ADMIN	org.manage
PLATFORM_ADMIN	ticket.manage
PLATFORM_ADMIN	incident.manage
SUPPORT_AGENT	ticket.manage
\.


--
-- Data for Name: admin_search_sync_state; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.admin_search_sync_state (domain, last_synced_at) FROM stdin;
organizations	2026-03-08 17:12:35.101342
users	2026-03-08 17:12:35.101342
tickets	2026-03-08 17:12:35.101342
incidents	2026-03-08 17:12:35.101342
\.


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.admin_users (id, email, role, mfa_enabled, created_at) FROM stdin;
\.


--
-- Data for Name: alert_rules; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.alert_rules (id, org_id, name, type, description, severity, conditions, actions, vehicles, driver_ids, enabled, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alert_thresholds; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.alert_thresholds (component, metric, threshold, operator, severity, enabled, notification_channels, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.alerts (id, org_id, rule_id, type, severity, vehicle_id, driver_id, "timestamp", location, details, status, notes, acknowledged_by, acknowledged_at, resolved_by, resolved_at, created_at, updated_at, dedup_key, escalation_level, last_escalated_at, escalated_to, sla_deadline) FROM stdin;
\.


--
-- Data for Name: alerts_v2_dlq; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.alerts_v2_dlq (id, log_id, reason, payload, created_at) FROM stdin;
\.


--
-- Data for Name: alerts_v2_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.alerts_v2_logs (id, user_id, recipient, channel, alert_type, subject, body, status, retry_count, max_retries, provider, provider_response, error_message, metadata, scheduled_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alerts_v2_templates; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.alerts_v2_templates (id, name, channel, language, subject, body, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alerts_v2_user_preferences; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.alerts_v2_user_preferences (user_id, channel, enabled, updated_at) FROM stdin;
\.


--
-- Data for Name: analytics_access_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.analytics_access_logs (id, organization_id, user_id, resource_id, resource_type, access_context, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_jobs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.analytics_jobs (id, name, type, description, status, job_type, parameters, input_source, output_destination, start_time, end_time, progress, error_details, organization_id, created_by, created_at, updated_at, idempotency_key) FROM stdin;
\.


--
-- Data for Name: analytics_query_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.analytics_query_logs (id, organization_id, user_id, query_type, parameters, duration_ms, row_count, cache_hit, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_query_plans; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.analytics_query_plans (id, organization_id, query_type, query_params, execution_duration_ms, query_plan, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_quotas; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.analytics_quotas (organization_id, daily_limit, used_credits, last_reset_at) FROM stdin;
\.


--
-- Data for Name: api_clients; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.api_clients (id, org_id, client_id, client_secret_hash, name, scopes, expiry, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.api_keys (id, org_id, name, prefix, secret_hash, permissions, last_used_at, expires_at, created_at, revoked) FROM stdin;
\.


--
-- Data for Name: approval_actions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.approval_actions (id, instance_id, approver_id, action, level_index, comments, action_time) FROM stdin;
35b69050-2ec1-4bb8-9502-c5bcc0782da9	eceea7d4-8815-4829-8194-d05d37a23120	00000000-0000-0000-0000-000000000003	APPROVED	0	Approved via service	2026-03-08 17:14:57.318753+00
\.


--
-- Data for Name: approval_configs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.approval_configs (id, organization_id, entity_type, min_amount, max_amount, levels, is_active, created_at, updated_at) FROM stdin;
8c1d0d27-a68c-4cd7-9ae6-520c5854f95b	00000000-0000-0000-0000-000000000001	EXPENSE_REPORT	0.00	10000.00	[{"role": "MANAGER", "index": 0}]	t	2026-03-08 17:14:43.245628+00	2026-03-08 17:14:43.245628+00
\.


--
-- Data for Name: approval_instances; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.approval_instances (id, entity_id, entity_type, config_id, current_level_index, status, created_at, updated_at) FROM stdin;
eceea7d4-8815-4829-8194-d05d37a23120	7b179237-627e-4730-83f7-89e4ad4b594a	EXPENSE_REPORT	8c1d0d27-a68c-4cd7-9ae6-520c5854f95b	0	APPROVED	2026-03-08 17:14:49.01784+00	2026-03-08 17:14:57.322499+00
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.audit_logs (id, user_id, action, resource, details, ip_address, user_agent, created_at, severity, status, org_id, module, entity_id, before_state, after_state, metadata) FROM stdin;
\.


--
-- Data for Name: audit_policies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.audit_policies (id, org_id, retention_years, archive_policy, masking_rules, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.audit_settings (id, org_id, retention_days_online, retention_days_archival, masking_rules, tracked_event_types, alert_on_critical, updated_at) FROM stdin;
\.


--
-- Data for Name: auth_audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.auth_audit_logs (id, actor_id, actor_type, action, entity_type, entity_id, org_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: auth_tokens; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.auth_tokens (id, user_id, access_token, refresh_token, device_id, expires_at, created_at, ip_address, user_agent, last_active, is_active) FROM stdin;
\.


--
-- Data for Name: backup_verifications; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.backup_verifications (id, backup_id, status, checksum, verified_at, verified_by, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.backups (id, type, status, s3_key, size_bytes, created_by, created_at, completed_at, metadata) FROM stdin;
\.


--
-- Data for Name: bank_transactions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.bank_transactions (id, org_id, bank_account_id, transaction_id, amount, currency, transaction_date, description, category, status, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: behavior_score_updates; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.behavior_score_updates (id, driver_id, score_change, reason, event_type, details, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: billing_accounting_exports; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_accounting_exports (id, org_id, external_system, export_type, status, file_key, records_count, error_message, created_at, completed_at, created_by) FROM stdin;
\.


--
-- Data for Name: billing_configurations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_configurations (id, org_id, company_name, company_address, company_gstin, company_pan, company_email, company_phone, company_website, company_logo_url, primary_color, secondary_color, theme, bank_name, bank_account_name, bank_account_number, bank_ifsc, bank_branch, bank_upi, invoice_prefix, invoice_terms, invoice_notes, show_hsn, show_qr_code, show_payment_info, default_currency, default_tax_calculation, default_payment_terms_days, is_active, created_at, created_by, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: billing_coupons; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_coupons (id, code, name, discount_type, discount_value, currency, max_redemptions, redeemed_count, valid_from, valid_until, status, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: billing_credit_transactions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_credit_transactions (id, balance_id, transaction_type, amount, currency, reference_type, reference_id, description, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: billing_customer_balances; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_customer_balances (id, org_id, currency, balance, credit_limit, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: billing_hardware_products; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_hardware_products (id, name, model_code, category, one_time_price, lease_monthly_price, currency, metadata, created_at, updated_at) FROM stdin;
7612e2d6-ae4c-45ef-9ae3-a2e6fa42963d	FlyFleet Vision Pro Dashcam	FF-CAM-V2	DASHCAM	399.00	25.00	USD	{}	2026-03-08 17:12:09.26786+00	2026-03-08 17:12:09.26786+00
cc3ac516-2636-473c-801d-224df413623a	FlyFleet Standard GPS Tracker	FF-GPS-100	TRACKER	99.00	10.00	USD	{}	2026-03-08 17:12:09.26786+00	2026-03-08 17:12:09.26786+00
dc9a2041-be70-4b79-a98b-da9f87652969	FlyFleet OBD-II Telematics Node	FF-OBD-V1	TRACKER	149.00	15.00	USD	{}	2026-03-08 17:12:09.26786+00	2026-03-08 17:12:09.26786+00
\.


--
-- Data for Name: billing_invoice_documents; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_invoice_documents (id, invoice_id, template_id, file_url, storage_key, generated_at, template_version, snapshot, checksum) FROM stdin;
\.


--
-- Data for Name: billing_invoice_sequences; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_invoice_sequences (org_id, prefix, next_value, suffix, updated_at) FROM stdin;
\.


--
-- Data for Name: billing_invoice_templates; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_invoice_templates (id, name, version, html_content, is_default, created_at) FROM stdin;
\.


--
-- Data for Name: billing_plans; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_plans (id, name, description, is_active, created_at, updated_at) FROM stdin;
dc68bc71-09c7-4a6a-8d49-be9f36e443e1	Starter	Basic fleet tracking for up to 5 vehicles	t	2026-03-08 17:12:36.287408+00	2026-03-08 17:12:36.287408+00
cd3b1ccc-cbed-4212-b575-fde8cb867947	Growth	Advanced features for growing fleets	t	2026-03-08 17:12:36.287408+00	2026-03-08 17:12:36.287408+00
d0e4b966-3023-4cea-8499-d8fe067c8b8a	Enterprise	Custom scale solutions with premium support	t	2026-03-08 17:12:36.287408+00	2026-03-08 17:12:36.287408+00
\.


--
-- Data for Name: billing_pricing_components; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_pricing_components (id, plan_id, name, type, unit_price, currency, meter_event_name, frequency, created_at, updated_at) FROM stdin;
37871e68-41d7-492c-b148-a14177c3170a	dc68bc71-09c7-4a6a-8d49-be9f36e443e1	Platform Fee	FLAT	49.0000	USD	\N	MONTHLY	2026-03-08 17:12:36.290194+00	2026-03-08 17:12:36.290194+00
4b07de65-a9c4-4819-b685-2f6d43627fca	cd3b1ccc-cbed-4212-b575-fde8cb867947	Base Platform Fee	FLAT	199.0000	USD	\N	MONTHLY	2026-03-08 17:12:36.290194+00	2026-03-08 17:12:36.290194+00
ace0e09c-b71d-491c-9e90-98043af23e53	cd3b1ccc-cbed-4212-b575-fde8cb867947	Vehicle Fee	PER_UNIT	15.0000	USD	\N	MONTHLY	2026-03-08 17:12:36.290194+00	2026-03-08 17:12:36.290194+00
dae918f1-f023-4c77-a6b8-9d4b1da6709b	cd3b1ccc-cbed-4212-b575-fde8cb867947	Telemetry Ingestion	USAGE	0.0100	USD	telemetry_event	MONTHLY	2026-03-08 17:12:36.290194+00	2026-03-08 17:12:36.290194+00
4d2852a5-3b1e-4843-9679-fe0494188fe5	d0e4b966-3023-4cea-8499-d8fe067c8b8a	Custom Platform Fee	FLAT	999.0000	USD	\N	MONTHLY	2026-03-08 17:12:36.290194+00	2026-03-08 17:12:36.290194+00
\.


--
-- Data for Name: billing_recognized_revenue; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_recognized_revenue (id, schedule_id, amount, recognized_at, created_at) FROM stdin;
\.


--
-- Data for Name: billing_revenue_schedules; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_revenue_schedules (id, org_id, invoice_line_item_id, total_amount, currency, start_date, end_date, status, created_at) FROM stdin;
\.


--
-- Data for Name: billing_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_settings (org_id, default_tax_rate, base_currency, grace_period_days, auto_invoicing_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: billing_subscriptions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_subscriptions (id, org_id, plan_id, status, current_period_start, current_period_end, trial_end, cancel_at_period_end, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: billing_tax_rates; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_tax_rates (id, region_id, name, percentage, tax_type, is_default, created_at) FROM stdin;
\.


--
-- Data for Name: billing_tax_regions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.billing_tax_regions (id, name, country_code, state_code, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: blocked_ips; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.blocked_ips (ip_address, reason, expires_at) FROM stdin;
\.


--
-- Data for Name: booking_requests; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.booking_requests (id, customer_id, request_type, origin, destination, requested_pickup_time, cargo_details, status, notes, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bulk_config; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.bulk_config (organization_id, max_records_per_file, concurrent_threads, retention_months, mandatory_fields, updated_at) FROM stdin;
\.


--
-- Data for Name: bulk_job_records; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.bulk_job_records (id, job_id, row_number, record_data, status, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: bulk_jobs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.bulk_jobs (id, organization_id, file_name, status, total_records, success_count, failed_count, created_by, created_at, updated_at, retry_count) FROM stdin;
\.


--
-- Data for Name: compliance_reviews; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.compliance_reviews (id, org_id, review_type, review_date, review_location, fmcsa_representative, overall_rating, acute_violations, serious_violations, other_violations, unsafe_driving_score, hos_compliance_score, driver_fitness_score, controlled_substances_score, vehicle_maintenance_score, hazmat_score, crash_indicator_score, corrective_action_required, corrective_action_plan, follow_up_date, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: consumption_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.consumption_events ("time", org_id, vehicle_id, meter_code, amount, metadata, processed_invoice_id) FROM stdin;
\.


--
-- Data for Name: currency_rates; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.currency_rates (id, from_currency, to_currency, rate, provider, last_updated, currency_code, org_id, created_at, updated_at) FROM stdin;
4d9094f6-c33f-4b90-b25e-f789f834f73f	USD	INR	83.000000	MOCK	2026-03-08 17:12:38.724328+00	USD	\N	2026-03-08 17:12:39.305757+00	2026-03-08 17:12:39.305757+00
c124937b-3261-4c65-b4e5-0f4a4facdebf	INR	USD	0.012000	MOCK	2026-03-08 17:12:38.727631+00	INR	\N	2026-03-08 17:12:39.305757+00	2026-03-08 17:12:39.305757+00
\.


--
-- Data for Name: customer_audit_log; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_audit_log (id, org_id, entity_type, entity_id, action, old_value, new_value, user_id, user_type, user_email, ip_address, user_agent, reason, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_booking_approvals; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_booking_approvals (id, booking_id, approver_user_id, approval_status, approved_at, comments, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_booking_quotes; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_booking_quotes (id, booking_id, quote_amount, currency, valid_until, status, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_booking_requests; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_booking_requests (id, customer_id, pickup_location, drop_location, cargo_type, weight, volume, vehicle_type, requested_pickup_time, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_booking_shipments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_booking_shipments (id, booking_id, shipment_id, sequence_number, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_booking_status_history; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_booking_status_history (id, booking_id, previous_status, new_status, changed_by, changed_at, reason) FROM stdin;
\.


--
-- Data for Name: customer_v2_booking_validations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_booking_validations (id, booking_id, validation_type, status, details, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_credit_limits; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_credit_limits (id, customer_id, max_limit, currency, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_credit_transactions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_credit_transactions (id, wallet_id, transaction_type, amount, currency, reference_id, description, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_customer_addresses; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_customer_addresses (id, customer_id, address_type, address, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_customer_api_keys; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_customer_api_keys (id, customer_id, key_name, api_key_hash, expires_at, status, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_customer_api_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_customer_api_logs (id, api_key_id, endpoint, method, status_code, response_time_ms, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_customer_audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_customer_audit_logs (id, customer_id, user_id, event_type, resource_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_customer_contacts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_customer_contacts (id, customer_id, name, email, phone, role, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_customer_contracts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_customer_contracts (id, customer_id, contract_number, valid_from, valid_to, terms, status, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_customer_credit_limits; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_customer_credit_limits (id, customer_id, credit_limit, available_credit, currency, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_customer_invoice_views; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_customer_invoice_views (id, invoice_id, customer_id, downloaded_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_customer_sessions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_customer_sessions (id, user_id, token_hash, expires_at, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_customer_users; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_customer_users (id, customer_id, email, phone, role, password_hash, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_customer_wallets; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_customer_wallets (id, customer_id, balance, currency, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_customers; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_customers (id, organization_id, company_name, gst_number, billing_address, contact_email, contact_phone, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_delivery_proofs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_delivery_proofs (id, shipment_id, receiver_name, receiver_phone, signature_url, photo_url, delivered_at, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_dispute_attachments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_dispute_attachments (id, dispute_id, message_id, file_url, uploaded_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_dispute_messages; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_dispute_messages (id, dispute_id, sender_id, sender_type, message, sent_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_disputes; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_disputes (id, customer_id, shipment_id, invoice_id, status, reason, description, created_at, updated_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_pod_images; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_pod_images (id, delivery_proof_id, photo_url, uploaded_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_pod_signatures; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_pod_signatures (id, delivery_proof_id, signature_url, signed_by, signed_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_pricing_components; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_pricing_components (id, rule_id, component_type, value, is_percentage, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_pricing_contracts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_pricing_contracts (id, customer_id, contract_name, valid_from, valid_to, status, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_pricing_quotes; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_pricing_quotes (id, booking_id, total_amount, currency, breakdown, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_pricing_rules; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_pricing_rules (id, contract_id, pricing_model, base_rate, currency, conditions, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_shipment_document_versions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_shipment_document_versions (id, document_id, version_number, file_url, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_shipment_documents; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_shipment_documents (id, shipment_id, document_type, file_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_shipment_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_shipment_events (id, shipment_id, event_type, "timestamp", location, metadata) FROM stdin;
\.


--
-- Data for Name: customer_v2_shipment_sla_rules; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_shipment_sla_rules (id, customer_id, rule_name, metric, target_value, unit, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_shipment_sla_violations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_shipment_sla_violations (id, shipment_id, rule_id, actual_value, violated_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_shipment_status_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_shipment_status_logs (id, shipment_id, old_status, new_status, changed_by, changed_at, reason) FROM stdin;
\.


--
-- Data for Name: customer_v2_shipment_stops; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_shipment_stops (id, shipment_id, stop_type, sequence, location, expected_arrival, actual_arrival, created_at) FROM stdin;
\.


--
-- Data for Name: customer_v2_shipments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customer_v2_shipments (id, customer_id, trip_id, booking_id, status, origin, destination, distance_km, created_at, updated_at, eway_bill_number, eway_bill_expiry, eway_bill_document) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.customers (id, org_id, name, email, phone, api_key, api_secret_hash, address, billing_info, status, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: device_alerts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_alerts (id, device_id, alert_type, severity, alert_message, created_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: device_auth_tokens; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_auth_tokens (device_id, device_token, created_at) FROM stdin;
\.


--
-- Data for Name: device_commands; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_commands (id, device_id, org_id, command, category, params, status, result, error_message, created_by, sent_at, executed_at, created_at) FROM stdin;
\.


--
-- Data for Name: device_diagnostics_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_diagnostics_logs (id, device_id, org_id, log_type, source, message, metadata, "timestamp") FROM stdin;
\.


--
-- Data for Name: device_firmware_status; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_firmware_status (id, device_id, rollout_id, status, progress, error_message, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: device_registry; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_registry (device_id, vehicle_id, firmware_version, sim_iccid, carrier, last_heartbeat, status, certificate_hash, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: device_telemetry; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_telemetry (id, device_id, org_id, payload, packet_type, raw_hex, "timestamp") FROM stdin;
\.


--
-- Data for Name: device_twins; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_twins (device_id, org_id, desired_state, reported_state, last_seen, drift_status, drift_reason, last_command_id, last_command_status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.devices (id, org_id, vehicle_id, serial_number, type, status, last_ping_at, is_deleted, created_at, updated_at, firmware_version, battery_level, signal_strength, hardware_revision, last_heartbeat, model, manufacturer) FROM stdin;
\.


--
-- Data for Name: diagnostics_audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.diagnostics_audit_logs (id, entity_type, entity_id, action, actor_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.documents (id, vehicle_id, type, doc_number, issue_date, expiry_date, file_url, status, metadata, created_at, updated_at, org_id, title, file_name, file_size_bytes, mime_type, storage_path, reminder_days, uploaded_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: dot_inspection_mode; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.dot_inspection_mode (id, org_id, is_enabled, active_inspection_id, default_roc_template, default_violation_codes, safety_director_name, safety_director_phone, safety_director_email, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: dot_inspections; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.dot_inspections (id, driver_id, vehicle_id, inspection_date, inspection_level, inspection_location, inspector_name, inspector_agency, inspector_id, overall_status, violations_found, oos_violations, violation_details, was_eligible_for_time_credit, time_credit_minutes, roc_provided, medical_certificate_provided, cdl_provided, skill_performance_eval_provided, vehicle_oos, driver_oos, fine_amount, created_at, created_by, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: dr_test_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.dr_test_logs (id, test_id, ts, level, message) FROM stdin;
\.


--
-- Data for Name: dr_test_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.dr_test_settings (id, schedule_enabled, frequency, schedule_day, schedule_time, intensity, notification_emails, updated_at) FROM stdin;
t	f	WEEKLY	SATURDAY	02:00	NORMAL	[]	2026-03-08 17:12:09.063176+00
\.


--
-- Data for Name: dr_test_steps; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.dr_test_steps (id, test_id, step_order, step_name, status, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: dr_tests; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.dr_tests (id, test_id, name, description, test_type, target_env, status, progress_percent, initiated_by, success_criteria, scheduled_at, started_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_audit_logs (id, driver_id, org_id, action, old_value, new_value, user_id, user_type, user_email, reason, metadata, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: driver_behavior; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_behavior (id, driver_id, org_id, period_start, period_end, score, safety_score, efficiency_score, compliance_score, harsh_accelerations, harsh_brakings, harsh_cornerings, speeding_incidents, phone_usage, seatbelt_violations, fuel_consumption, distance_driven, idle_time, eco_driving_score, hours_of_service, rest_periods, document_compliance, maintenance_adherence, night_driving_hours, highway_percentage, city_driving_percentage, risk_level, risk_factors, improvement_areas, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_behavior_analytics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_behavior_analytics (id, driver_id, organization_id, analysis_period_start, analysis_period_end, total_driving_hours, aggressive_acceleration_count, hard_braking_count, sharp_turn_count, over_speeding_count, idling_time, average_speed, max_speed, fuel_efficiency, safety_score, efficiency_score, comfort_score, ranking, improvement_suggestions, behavior_trend, generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_daily_stats; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_daily_stats (driver_id, organization_id, date, total_driving_hours, total_distance, total_idle_hours, safety_score, eco_score, violation_count, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_expenses; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_expenses (id, driver_id, trip_id, type, amount, currency, receipt_url, notes, status, transaction_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_fuel_limits; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_fuel_limits (id, organization_id, driver_id, daily_liters_limit, monthly_liters_limit, daily_amount_limit, monthly_amount_limit, currency, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_incidents; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_incidents (id, driver_id, org_id, type, severity, "timestamp", location, speed, details, resolved, resolution_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_messages; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_messages (id, driver_id, trip_id, direction, type, content, attachment_url, is_read, created_at) FROM stdin;
\.


--
-- Data for Name: driver_mobile_sync_queue; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_mobile_sync_queue (id, driver_id, action_type, payload, status, created_at) FROM stdin;
\.


--
-- Data for Name: driver_onboarding_steps; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_onboarding_steps (id, driver_id, step, status, remarks, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: driver_payouts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_payouts (id, driver_id, period_start, period_end, total_amount, status, paid_at, created_at) FROM stdin;
\.


--
-- Data for Name: driver_ratings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_ratings (id, driver_id, trip_id, punctuality_score, behavior_score, driving_score, overall_rating, comments, created_at) FROM stdin;
\.


--
-- Data for Name: driver_risk_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_risk_events (id, driver_id, organization_id, risk_type, score_delta, metadata, event_time, created_at) FROM stdin;
\.


--
-- Data for Name: driver_safety_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_safety_events (id, driver_id, trip_id, event_type, severity, gps_lat, gps_lng, "timestamp", created_at) FROM stdin;
\.


--
-- Data for Name: driver_salary; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_salary (id, driver_id, base_salary, per_km_rate, daily_allowance, night_allowance, effective_from, created_at) FROM stdin;
\.


--
-- Data for Name: driver_shift_assignments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_shift_assignments (id, shift_id, vehicle_id, assigned_at) FROM stdin;
\.


--
-- Data for Name: driver_shifts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_shifts (id, driver_id, shift_start, shift_end, shift_type, status, created_at) FROM stdin;
\.


--
-- Data for Name: driver_training_modules; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_training_modules (id, name, description) FROM stdin;
\.


--
-- Data for Name: driver_training_records; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_training_records (id, driver_id, module_id, completed_at, certificate_url, created_at) FROM stdin;
\.


--
-- Data for Name: driver_trip_earnings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_trip_earnings (id, driver_id, trip_id, distance_km, earnings, bonus, penalty, created_at) FROM stdin;
\.


--
-- Data for Name: driver_verifications; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_verifications (id, driver_id, organization_id, license_number, status, verification_date, name, father_name, date_of_birth, gender, address, city, district, state, pin, license_class, issue_date, validity_from, validity_to, last_transaction, enrollment_number, created_at, created_by, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.drivers (id, org_id, first_name, last_name, email, phone, license_number, license_type, license_expiry, license_authority, date_of_birth, address, emergency_contact, status, current_vehicle_id, current_trip_id, joining_date, resignation_date, experience_years, rating, total_trips, total_distance_km, total_hours_driven, behavior_score, documents, attendance_records, schedules, metadata, created_at, updated_at, deleted_at, created_by, updated_by, last_known_location, last_location_update, employee_code, aadhaar_number, pan_number, license_issue_date, employment_type) FROM stdin;
\.


--
-- Data for Name: duty_status_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.duty_status_logs (id, driver_id, status, location, started_at, ended_at, duration_minutes, remarks, created_at, updated_at, is_edit, edit_reason, original_log_id, edit_approved_by, edit_approved_at) FROM stdin;
\.


--
-- Data for Name: e_way_bills; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.e_way_bills (id, eway_bill_number, eway_bill_date, eway_bill_valid_till, document_number, document_date, document_type, goods_description, goods_value, goods_tax_rate, goods_unit, goods_quantity, from_place, from_pincode, from_state_code, to_place, to_pincode, to_state_code, transporter_id, transporter_name, transport_mode, transport_document_number, transport_document_date, transit_type, vehicle_number, vehicle_type, remaining_distance, user_gstin, recipient_gstin, generated_by, generated_at, cancelled, cancelled_by, cancelled_on, cancelled_reason, created_at, created_by, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: einvoice_config; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.einvoice_config (id, org_id, app_key, secret_key, username, password, is_enabled, environment, gstin, mandatory_above, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: einvoice_irn; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.einvoice_irn (id, invoice_id, org_id, irn, irn_status, ack_no, ack_dt, signed_response, qr_code_str, qr_code_image, cancelled, cancelled_at, cancellation_reason, retry_count, last_retry_at, error_message, created_at, created_by, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: einvoice_item_mapping; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.einvoice_item_mapping (id, org_id, product_id, hsn_code, sac_code, nic_code, gst_rate, exemption_reason, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: eld_diagnostic_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.eld_diagnostic_events (id, vehicle_id, event_type, event_code, event_description, detected_at, resolved_at, created_at) FROM stdin;
\.


--
-- Data for Name: eld_malfunctions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.eld_malfunctions (id, vehicle_id, driver_id, malfunction_type, malfunction_code, description, status, detected_at, acknowledged_at, acknowledged_by, resolved_at, resolved_by, reported_to_carrier, reported_at, carrier_reference, paper_logs_required, paper_logs_start, paper_logs_end, created_at, created_by, malfunction_category, is_power_failure, is_engine_sync_failure, is_timing_failure, is_position_failure, is_data_transfer_failure, reported_to_fmcsa, fmcsa_reference) FROM stdin;
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.email_verification_tokens (id, user_id, token, expires_at, used, created_at) FROM stdin;
\.


--
-- Data for Name: emergency_audit_log; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.emergency_audit_log (id, command_id, action, actor, details, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: emergency_commands; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.emergency_commands (id, command_id, command_type, reason, issued_by, cleared_by, issued_at, cleared_at, status, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: emergency_contacts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.emergency_contacts (id, org_id, name, role, phone, email, priority, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: emergency_escalations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.emergency_escalations (id, incident_id, contact_id, notification_channel, status, attempted_at, responded_at, created_at) FROM stdin;
\.


--
-- Data for Name: emergency_response_units; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.emergency_response_units (id, org_id, unit_type, name, phone, coverage_city, coverage_state, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: emergency_status; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.emergency_status (id, is_active, current_command_id, last_halt_at, last_clear_at, halt_reason, halt_issued_by, clear_issued_by, updated_at) FROM stdin;
1	f	\N	\N	\N	\N	\N	\N	2026-03-08 17:12:29.309049+00
\.


--
-- Data for Name: emergency_vehicle_state; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.emergency_vehicle_state (vehicle_id, org_id, halted, last_updated) FROM stdin;
\.


--
-- Data for Name: entity_audit_history; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.entity_audit_history (id, entity_type, entity_id, change_data, actor, "timestamp") FROM stdin;
\.


--
-- Data for Name: erp_configs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.erp_configs (id, organization_id, name, type, endpoint_url, auth_config, settings, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: evidence_exports; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.evidence_exports (id, org_id, module, date_range_start, date_range_end, format, status, requested_by, file_url, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: expense_items; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.expense_items (id, report_id, category, amount, gst_amount, gst_rate, receipt_url, description, vendor_name, vendor_gstin, transaction_date, ocr_processed, ocr_confidence, created_at, org_id, invoice_number, updated_at) FROM stdin;
\.


--
-- Data for Name: expense_policies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.expense_policies (id, org_id, category, limit_amount, currency, requires_approval, receipt_required, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: expense_reports; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.expense_reports (id, org_id, submitter_id, period_start, period_end, total_amount, currency, status, approved_by, approval_date, rejection_reason, metadata, created_at, updated_at, gst_number, gst_rate, gst_amount, invoice_number, vendor_gstin, trip_id, route_id) FROM stdin;
62183241-3f2b-4f18-95cb-a2a84baa290b	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000002	\N	\N	1500.50	INR	SUBMITTED	\N	\N	\N	{"reason": "Business trip to Mumbai"}	2026-03-08 17:14:03.748562+00	2026-03-08 17:14:03.748562+00	\N	\N	\N	\N	\N	\N	\N
7b179237-627e-4730-83f7-89e4ad4b594a	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000002	\N	\N	500.00	INR	APPROVED	00000000-0000-0000-0000-000000000003	2026-03-08 17:14:57.324722+00	\N	{"reason": "Test approval"}	2026-03-08 17:14:49.012348+00	2026-03-08 17:14:57.324722+00	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: fastag_transactions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.fastag_transactions (id, tag_number, vehicle_id, driver_id, organization_id, transaction_id, transaction_type, amount, toll_plaza, toll_plaza_id, lane_id, transaction_time, transaction_date, settlement_date, status, error_code, error_description, reconciled, reconciliation_date, created_at, created_by, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.feature_flags (id, key, description, scope, enabled, tags, created_at, created_by, updated_at, updated_by) FROM stdin;
b86af247-9f9b-4a9e-82b3-0006affaff62	dark_mode	Enable dark mode theme	GLOBAL	f	{}	2026-03-08 17:12:33.131652+00	00000000-0000-0000-0000-000000000000	2026-03-08 17:12:33.131652+00	00000000-0000-0000-0000-000000000000
441f90f4-a3bb-47d5-ab51-78a275190164	advanced_analytics	Enable advanced analytics dashboard	GLOBAL	f	{}	2026-03-08 17:12:33.131652+00	00000000-0000-0000-0000-000000000000	2026-03-08 17:12:33.131652+00	00000000-0000-0000-0000-000000000000
281e7aec-03a0-4925-8edb-e047d0acef1b	export_import	Enable settings export/import functionality	GLOBAL	t	{}	2026-03-08 17:12:33.131652+00	00000000-0000-0000-0000-000000000000	2026-03-08 17:12:33.131652+00	00000000-0000-0000-0000-000000000000
\.


--
-- Data for Name: finance_audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.finance_audit_logs (id, org_id, entity_id, entity_type, action, actor_id, old_values, new_values, "timestamp") FROM stdin;
6c3c2a31-f7ab-4bae-90cf-6fa74a56b344	00000000-0000-0000-0000-000000000001	62183241-3f2b-4f18-95cb-a2a84baa290b	EXPENSE_REPORT	submitted	00000000-0000-0000-0000-000000000002	null	{"amount": 1500.5}	2026-03-08 17:14:03.754527+00
e342067a-7c59-46e2-bbe3-194a994c8bfb	00000000-0000-0000-0000-000000000001	7b179237-627e-4730-83f7-89e4ad4b594a	EXPENSE_REPORT	submitted	00000000-0000-0000-0000-000000000002	null	{"amount": 500}	2026-03-08 17:14:49.0205+00
\.


--
-- Data for Name: finance_retention_policies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.finance_retention_policies (organization_id, fuel_logs_retention_days, expense_reports_retention_days, audit_logs_retention_days, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: firmware_packages; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.firmware_packages (id, version, hardware_target, file_url, file_size, checksum, release_notes, status, is_critical, released_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: firmware_rollout_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.firmware_rollout_events (id, rollout_id, org_id, event_type, from_status, to_status, actor_user_id, message, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: firmware_rollouts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.firmware_rollouts (id, firmware_id, org_id, name, device_group, target_filter, total_devices, completed_devices, failed_devices, status, rollout_strategy, max_concurrent, created_by, started_at, completed_at, created_at, failure_threshold, batch_size, rollback_enabled) FROM stdin;
\.


--
-- Data for Name: fleet_analytics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.fleet_analytics (id, organization_id, start_date, end_date, total_vehicles, active_vehicles, total_distance, average_speed, total_fuel_consumption, average_fuel_efficiency, total_trips, completed_trips, cancelled_trips, average_trip_duration, idle_time_percentage, routing_efficiency, fuel_cost, maintenance_cost, revenue, profit_margin, safety_score, accidents_count, incidents_count, emergency_stops, geofence_violations, alerts_triggered, data_points_collected, processing_time, generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fleet_hourly_stats; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.fleet_hourly_stats (organization_id, "timestamp", active_vehicles, total_distance, total_fuel_consumed, average_utilization, updated_at) FROM stdin;
\.


--
-- Data for Name: fraud_incidents; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.fraud_incidents (id, entity_type, entity_id, org_id, vehicle_id, driver_id, fraud_score, risk_level, signals, status, investigated_by, resolved_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: fuel_audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.fuel_audit_logs (id, fuel_log_id, action, changed_by, changed_at, old_values, new_values, diff, organization_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fuel_card_reconciliation; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.fuel_card_reconciliation (id, card_transaction_id, internal_transaction_id, org_id, status, variance, card_amount, internal_amount, reconciled_by, reconciled_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: fuel_card_transactions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.fuel_card_transactions (id, vehicle_id, card_id, provider, station, liters, amount, currency, transaction_time, synced_at, external_transaction_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: fuel_efficiency_history; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.fuel_efficiency_history (id, vehicle_id, distance, fuel_used, km_per_l, recorded_at, anomaly_flag, anomaly_reason) FROM stdin;
\.


--
-- Data for Name: fuel_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.fuel_logs (id, organization_id, vehicle_id, driver_id, station_name, fuel_type, quantity, unit_price, total_cost, odometer, transaction_date, status, receipt_url, notes, created_by, created_at, updated_at, gst_number, gst_rate, gst_amount, invoice_number, vendor_gstin, trip_id, route_id, vendor_id, anomaly_flag, anomaly_reason, fraud_score, risk_level, fraud_flags) FROM stdin;
\.


--
-- Data for Name: fuel_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.fuel_settings (organization_id, default_currency, allowed_fuel_types, validation_rules, auto_sync_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fuel_transactions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.fuel_transactions (id, vehicle_id, driver_id, card_id, station_location, liters, amount, currency, odometer_reading, efficiency_calculation, anomaly_flag, transaction_date, created_at, updated_at, gst_number, gst_rate, gst_amount, invoice_number, vendor_gstin, trip_id, route_id, vendor_id, fraud_score, risk_level, organization_id, metadata, fraud_flags) FROM stdin;
\.


--
-- Data for Name: fuel_vendors; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.fuel_vendors (id, organization_id, name, gstin, address, contact_phone, email, status, rating, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: geofence_assignments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.geofence_assignments (id, geofence_id, vehicle_id, assignment_type, dwell_minutes, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: geofence_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.geofence_events (id, "time", vehicle_id, geofence_id, event_type, location, duration_minutes, speed_kmh, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: geofences; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.geofences (id, org_id, name, type, center, radius_meters, coordinates, route_polyline, buffer_meters, entry_alert, exit_alert, speed_limit, vehicles, enabled, created_by, created_at, updated_at, metadata, active_hours, active) FROM stdin;
\.


--
-- Data for Name: global_notification_defaults; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.global_notification_defaults (id, email_enabled, sms_enabled, push_enabled, in_app_enabled, updated_by, updated_at) FROM stdin;
ca618241-d18e-4e4f-a798-12c4b5674caa	t	f	t	t	\N	2026-03-08 17:12:08.522177+00
\.


--
-- Data for Name: governance_audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.governance_audit_logs (id, organization_id, user_id, action, module, change_detail, ip_address, created_at) FROM stdin;
1ac5ee58-e5fc-4981-820b-e63ca7fa2b77	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	CREATE_REQUEST	DATA_REQUESTS	\N	\N	2026-03-08 18:51:05.722036+00
14e50a36-656a-46fe-87e5-8e816e30675d	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	CREATE_REQUEST	DATA_REQUESTS	\N	\N	2026-03-08 18:51:05.737452+00
9b792eea-286d-442b-8746-aa50524e6693	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	CREATE_REQUEST	DATA_REQUESTS	\N	\N	2026-03-08 18:51:05.750356+00
a88fb8a4-ee85-4029-9302-4bbe6650e67d	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	CREATE_REQUEST	DATA_REQUESTS	\N	\N	2026-03-08 18:51:05.763734+00
a255be37-60e0-460e-a3af-d4684cb5538f	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	CREATE_REQUEST	DATA_REQUESTS	\N	\N	2026-03-08 18:51:05.777097+00
c28edf3f-744a-4c42-be12-1c56bb8be8d4	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	CREATE_REQUEST	DATA_REQUESTS	\N	\N	2026-03-08 18:51:05.791137+00
d2979bef-2fc5-415f-a4c4-ef2d45a52b2a	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	CREATE_REQUEST	DATA_REQUESTS	\N	\N	2026-03-08 18:51:31.828443+00
d092782c-c079-42b1-8e76-2ca752d8194a	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	APPROVE_REQUEST	DATA_REQUESTS	testing	\N	2026-03-08 18:51:41.744554+00
a695c3c0-a284-4572-8cee-c46f6ed04faa	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	CREATE_REQUEST	DATA_REQUESTS	\N	\N	2026-03-08 19:01:15.143242+00
da6b9fd9-731c-4deb-9157-070d6e584294	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	APPROVE_REQUEST	DATA_REQUESTS	testing	\N	2026-03-08 19:01:26.163299+00
85c81fae-02d2-42d7-9ad8-de23ee12c2c9	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	CREATE_REQUEST	DATA_REQUESTS	\N	\N	2026-03-09 10:08:08.071752+00
38e85075-1947-4731-a600-cc00ba7cfbb4	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	APPROVE_REQUEST	DATA_REQUESTS	testing	\N	2026-03-09 10:08:15.848203+00
\.


--
-- Data for Name: governance_compliance_reports; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.governance_compliance_reports (id, request_id, export_checksum, export_size_bytes, processing_time_ms, tables_accessed, created_at) FROM stdin;
\.


--
-- Data for Name: governance_download_tokens; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.governance_download_tokens (token, export_id, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: governance_export_lineage; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.governance_export_lineage (id, request_id, table_name, record_count, export_size_bytes, created_at) FROM stdin;
\.


--
-- Data for Name: governance_exports; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.governance_exports (id, request_id, file_path, file_size, checksum, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: governance_requests; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.governance_requests (id, organization_id, requester_id, request_type, data_scope, purpose, format, delivery_method, status, expiry_date, comments, created_at, updated_at, verification_status, verified_at, verified_by, created_by, updated_by) FROM stdin;
78161ca0-d143-41ef-96f1-a3faf867f30f	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	EXPORT	user	testing			PENDING	\N	\N	2026-03-08 18:51:05.71859+00	2026-03-08 18:51:05.71859+00	PENDING	\N	\N	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001
8d34a03b-d8ae-41a4-ac99-f2b780821bef	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	EXPORT	user	testing			PENDING	\N	\N	2026-03-08 18:51:05.733865+00	2026-03-08 18:51:05.733865+00	PENDING	\N	\N	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001
c8b42b45-048c-4664-8e8b-22e20fb851e6	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	EXPORT	user	testing			PENDING	\N	\N	2026-03-08 18:51:05.746808+00	2026-03-08 18:51:05.746808+00	PENDING	\N	\N	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001
93b380f7-15e9-445e-a655-148833dfcfb9	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	EXPORT	user	testing			PENDING	\N	\N	2026-03-08 18:51:05.760063+00	2026-03-08 18:51:05.760063+00	PENDING	\N	\N	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001
283cbafe-dc69-4ad8-9d88-6b64a7e2b658	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	EXPORT	user	testing			PENDING	\N	\N	2026-03-08 18:51:05.773533+00	2026-03-08 18:51:05.773533+00	PENDING	\N	\N	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001
79dfb27b-0fc8-4c94-adc8-642a0351fdb3	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	EXPORT	user	testing			PENDING	\N	\N	2026-03-08 18:51:05.787531+00	2026-03-08 18:51:05.787531+00	PENDING	\N	\N	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001
f6fe232f-ae3e-43ac-ab23-49738f360d7d	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	DELETION	user	testing			APPROVED	2026-03-10 18:51:41.739798+00	testing	2026-03-08 18:51:31.824885+00	2026-03-08 18:51:41.739979+00	PENDING	\N	\N	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001
c7048a23-86de-4b99-bc37-dfc06d42d572	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	EXPORT	user	testing			APPROVED	2026-03-10 19:01:26.159017+00	testing	2026-03-08 19:01:15.124395+00	2026-03-08 19:01:26.15921+00	PENDING	\N	\N	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001
0efd6513-2d03-46eb-9f07-a39f8a6c8df1	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	EXPORT	user	testing			APPROVED	2026-03-11 10:08:15.844437+00	testing	2026-03-09 10:08:08.068728+00	2026-03-09 10:08:15.844603+00	PENDING	\N	\N	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: governance_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.governance_settings (organization_id, retention_policies, masking_rules, auto_expiry_enabled, download_ttl_hours, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: gps_locations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.gps_locations ("time", vehicle_id, latitude, longitude, altitude, speed, heading, accuracy, ignition, odometer, battery_level, satellites, raw_data) FROM stdin;
\.


--
-- Data for Name: gst_compliances; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.gst_compliances (id, organization_id, gstin, status, legal_name, trade_name, address, centre_jurisdiction, state_jurisdiction, date_of_registration, date_of_cancellation, last_updated, return_filing_frequency, return_filing_status, payment_status, created_at, created_by, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: gst_invoices; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.gst_invoices (id, invoice_number, irn, ack_number, ack_date, qr_code, signed_invoice, status, entity_type, entity_id, org_id, gstin, buyer_gstin, total_amount, taxable_amount, cgst_amount, sgst_amount, igst_amount, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: health_alerts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.health_alerts (id, alert_type, component, metric, current_value, threshold, severity, message, status, triggered_at, acknowledged_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: health_history; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.health_history (id, "timestamp", component, status, response_time_ms, error, created_at) FROM stdin;
\.


--
-- Data for Name: historical_demand; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.historical_demand (id, route_id, date, hour, demand_count, avg_price, weather_condition, is_holiday, created_at) FROM stdin;
\.


--
-- Data for Name: hos_annotations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.hos_annotations (id, duty_status_log_id, annotation_type, reason, original_data, new_data, requires_approval, approved_by, approved_at, approval_status, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: hos_daily_limits; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.hos_daily_limits (id, driver_id, date, driving_used_minutes, driving_limit_minutes, on_duty_used_minutes, on_duty_limit_minutes, seventy_hour_used_minutes, seventy_hour_limit_minutes, last_break_duration_minutes, last_break_start, hours_since_break, break_required, restart_available, restart_taken_at, restart_eligible_at, is_violation, violation_details, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: id_mappings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.id_mappings (id, organization_id, erp_config_id, entity_type, local_id, remote_id, last_synced_at) FROM stdin;
\.


--
-- Data for Name: impersonation_sessions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.impersonation_sessions (id, admin_id, user_id, started_at, expires_at, audit_log_id) FROM stdin;
\.


--
-- Data for Name: incident_comments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.incident_comments (id, ticket_id, author_id, author_name, comment_type, content, is_private, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: incident_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.incident_logs (id, incident_id, user_id, action, notes, "timestamp") FROM stdin;
\.


--
-- Data for Name: incident_media; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.incident_media (id, incident_id, media_type, file_url, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: incident_timeline; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.incident_timeline (id, incident_id, event_type, actor, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: incident_updates; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.incident_updates (id, incident_id, update_message, created_at) FROM stdin;
\.


--
-- Data for Name: incident_vehicle_snapshot; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.incident_vehicle_snapshot (incident_id, speed, heading, engine_status, fuel_level, battery_voltage, gps_accuracy, device_signal_strength, created_at) FROM stdin;
\.


--
-- Data for Name: incidents; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.incidents (id, severity, status, description, detected_at, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inspection_documents; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.inspection_documents (id, inspection_id, document_type, document_url, document_data, provided_at, created_at) FROM stdin;
\.


--
-- Data for Name: inspection_templates; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.inspection_templates (id, organization_id, name, description, applicable_vehicle_types, checklist_items, is_active, created_at, updated_at) FROM stdin;
e3c54900-57f3-41d9-8052-fe12190cd7ec	00000000-0000-0000-0000-000000000001	Standard Safety Inspection	Routine safety check for all fleet vehicles	{TRUCK,VAN,CAR}	[{"text": "Brake pad thickness & fluid level", "type": "pass_fail", "item_id": "brakes", "required": true}, {"text": "Tire pressure & tread depth", "type": "pass_fail", "item_id": "tires", "required": true}, {"text": "Headlights, tail lights & signals", "type": "pass_fail", "item_id": "lights", "required": true}, {"text": "Oil, coolant & washer fluid", "type": "pass_fail", "item_id": "fluids", "required": false}, {"text": "Engine noise & diagnostic codes", "type": "pass_fail", "item_id": "engine", "required": true}]	t	2026-03-08 17:12:08.221792+00	2026-03-08 17:12:08.221792+00
ebba8c64-a048-4aab-b04c-eaa201515cba	00000000-0000-0000-0000-000000000001	Standard Safety Inspection	Routine safety check for all fleet vehicles	{TRUCK,VAN,CAR}	[{"text": "Brake pad thickness & fluid level", "type": "pass_fail", "item_id": "brakes", "required": true}, {"text": "Tire pressure & tread depth", "type": "pass_fail", "item_id": "tires", "required": true}, {"text": "Headlights, tail lights & signals", "type": "pass_fail", "item_id": "lights", "required": true}, {"text": "Oil, coolant & washer fluid", "type": "pass_fail", "item_id": "fluids", "required": false}, {"text": "Engine noise & diagnostic codes", "type": "pass_fail", "item_id": "engine", "required": true}]	t	2026-03-08 17:12:27.065897+00	2026-03-08 17:12:27.065897+00
\.


--
-- Data for Name: integration_configs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.integration_configs (id, organization_id, service_type, api_endpoint, api_key, username, password, client_id, client_secret, environment, active, last_sync_at, next_sync_at, sync_interval, created_at, created_by, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: integration_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.integration_logs (id, org_id, integration_id, method, endpoint, request_body, response_body, status_code, status, duration_ms, "timestamp") FROM stdin;
\.


--
-- Data for Name: integrations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.integrations (id, org_id, name, type, provider, status, config, last_sync, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inventory_parts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.inventory_parts (id, organization_id, part_number, name, description, stock_location, quantity_available, reorder_level, unit_cost, category, compatible_vehicles, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoice_approval_matrix; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.invoice_approval_matrix (id, org_id, min_amount, max_amount, required_role, required_approvals, is_active, priority, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_approval_policies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.invoice_approval_policies (id, org_id, name, description, min_amount, max_amount, required_approvals, approver_roles, specific_approvers, approval_type, priority, auto_approve_below, auto_approve_roles, is_active, created_at, created_by, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: invoice_approvals; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.invoice_approvals (id, invoice_id, approver_id, approver_role, approval_status, approval_comments, requested_at, decided_at, ip_address, user_agent, approval_level, is_required) FROM stdin;
\.


--
-- Data for Name: invoice_audit_log; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.invoice_audit_log (id, invoice_id, action, old_value, new_value, changed_by, changed_by_email, changed_at, ip_address, user_agent, reason) FROM stdin;
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.invoice_items (id, invoice_id, description, quantity, unit_price, tax_percent, total, created_at, updated_at, org_id, amount, is_deleted, deleted_at) FROM stdin;
\.


--
-- Data for Name: invoice_permissions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.invoice_permissions (id, org_id, role_name, can_create_invoice, can_edit_invoice, can_delete_invoice, can_issue_invoice, can_cancel_invoice, can_record_payment, can_refund_payment, can_create_credit_note, can_approve_credit_note, can_view_invoices, can_export_invoices, can_approve_invoices, approval_limit, created_at, updated_at) FROM stdin;
802142e8-3504-4562-843d-815a33134c42	00000000-0000-0000-0000-000000000000	admin	t	t	t	t	t	t	f	f	f	t	t	t	\N	2026-03-08 17:12:29.952172+00	2026-03-08 17:12:29.952172+00
7e33a3f0-24ea-47aa-9eae-b83d9d41836d	00000000-0000-0000-0000-000000000000	manager	t	t	f	t	f	t	f	f	f	t	t	t	\N	2026-03-08 17:12:29.952172+00	2026-03-08 17:12:29.952172+00
3f0327a1-64ed-4d17-a3d8-ffccf5356dd2	00000000-0000-0000-0000-000000000000	accountant	t	t	f	f	f	t	f	f	f	t	t	f	\N	2026-03-08 17:12:29.952172+00	2026-03-08 17:12:29.952172+00
3b194eea-552f-4418-af0a-c6972cee57ad	00000000-0000-0000-0000-000000000000	viewer	f	f	f	f	f	f	f	f	f	t	f	f	\N	2026-03-08 17:12:29.952172+00	2026-03-08 17:12:29.952172+00
\.


--
-- Data for Name: invoice_sequence; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.invoice_sequence (id, current_value, prefix, year, updated_at) FROM stdin;
1	1	INV	2026	2026-03-08 17:12:29.549107+00
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.invoices (id, org_id, customer_name, invoice_date, due_date, status, currency, total_amount, amount_paid, balance_due, created_at, updated_at, invoice_number, customer_email, billing_address, subtotal, tax_amount, amount_remaining, notes, is_deleted, deleted_at, custom_fields, discount_type, discount_value, discount_reason, discount_amount, approval_status, approval_required_at, approval_completed_at, subscription_id) FROM stdin;
\.


--
-- Data for Name: ip_rules; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.ip_rules (id, org_id, cidr, action, description, added_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: legal_holds; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.legal_holds (id, organization_id, entity_type, entity_id, reason, created_by, created_at, expires_at) FROM stdin;
ee3553f4-fd2a-4444-a589-ac024e08a3d4	00000000-0000-0000-0000-000000000001	user	00000000-0000-0000-0000-000000000001	testing legal hold	\N	2026-03-08 18:51:21.418549+00	\N
\.


--
-- Data for Name: local_permits; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.local_permits (id, vehicle_id, driver_id, organization_id, permit_number, permit_type, permit_category, permit_sub_category, valid_from, valid_to, issuing_authority, jurisdiction, route_details, number_of_trips, max_load_capacity, number_of_seats, fare, status, remarks, created_at, created_by, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: localization_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.localization_settings (id, language_code, is_active, is_default, created_at, created_by, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: login_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.login_events (id, org_id, user_id, email, ip_address, device, browser, location, status, risk_level, created_at) FROM stdin;
\.


--
-- Data for Name: login_history; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.login_history (id, user_id, ip_address, user_agent, country, success, risk_score, created_at) FROM stdin;
\.


--
-- Data for Name: maintenance_schedule; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.maintenance_schedule (vehicle_id, next_service_date, next_service_odometer, engine_hours, predictive_score, last_service_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: maintenance_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.maintenance_settings (organization_id, sla_p1_hours, sla_p2_hours, sla_p3_hours, low_stock_threshold, approval_threshold, auto_assign_enabled, notification_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: maintenance_vendors; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.maintenance_vendors (id, organization_id, name, specialization, rating, contact_info, payment_terms, status, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: maintenance_windows; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.maintenance_windows (id, service, start_time, end_time, description, created_at) FROM stdin;
\.


--
-- Data for Name: materialized_fleet_reports; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.materialized_fleet_reports (id, organization_id, report_type, metric_key, metric_value, period, generated_at) FROM stdin;
\.


--
-- Data for Name: mfa_codes; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_codes (id, user_id, code, method, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_events (id, user_id, org_id, event_type, status, method, ip_address, user_agent, location, details, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_exceptions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_exceptions (id, user_id, org_id, reason, granted_by, expires_at, created_at, start_date) FROM stdin;
\.


--
-- Data for Name: mfa_failures; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_failures (id, user_id, org_id, method, failure_reason, ip_address, location, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_lockouts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_lockouts (id, user_id, org_id, reason, locked_at, expires_at, unlocked_at, unlocked_by) FROM stdin;
\.


--
-- Data for Name: mfa_org_overrides; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_org_overrides (id, org_id, enabled, allowed_methods, max_attempts, lockout_minutes, remember_device_days, grace_period_days, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_policies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_policies (id, org_id, require_mfa, allowed_methods, max_attempts, lockout_minutes, created_at, updated_at, grace_period_days, remember_device_days, enforce_at_login, admin_only_mode, remember_device_allowed, mfa_challenge_timeout, version) FROM stdin;
\.


--
-- Data for Name: mfa_policy_history; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_policy_history (id, policy_id, org_id, snapshot, changed_by, change_reason, version, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_recovery_codes; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_recovery_codes (id, user_id, code_hash, used, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_users; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_users (user_id, org_id, status, method, trusted_devices_count, last_reset, updated_at) FROM stdin;
\.


--
-- Data for Name: model_deployments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.model_deployments (id, model_id, organization_id, deployment_strategy, traffic_split, is_active, deployed_at, created_at) FROM stdin;
\.


--
-- Data for Name: model_predictions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.model_predictions (id, model_version, route_id, forecast_date, forecast_hour, predicted_demand, confidence_interval_lower, confidence_interval_upper, created_at) FROM stdin;
\.


--
-- Data for Name: notification_channels; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.notification_channels (id, channel_type, provider, config, enabled, created_at, created_by, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: notification_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.notification_events (id, notification_id, event_type, message, created_at) FROM stdin;
\.


--
-- Data for Name: notification_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.notification_logs (id, correlation_id, user_id, user_email, channel, type, subject, body, status, provider, provider_response, retry_count, max_retries, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_preference_audit; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.notification_preference_audit (id, user_id, changed_by, old_values, new_values, change_reason, created_at) FROM stdin;
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.notification_settings (id, channel, enabled, max_retries, priority, retention_months, updated_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.oauth_clients (id, client_id, client_secret_hash, redirect_uris, grant_types, created_at) FROM stdin;
\.


--
-- Data for Name: obd_readings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.obd_readings ("time", vehicle_id, rpm, coolant_temp, engine_load, throttle_pos, fuel_level, dtcs, vin, raw_data) FROM stdin;
\.


--
-- Data for Name: oidc_providers; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.oidc_providers (id, name, issuer, client_id, client_secret_hash, enabled, created_at, updated_at) FROM stdin;
8b03f08b-06ef-4504-a16a-1553b615dfeb	google	https://accounts.google.com	google-client-id	google-mock-secret	t	2026-03-08 17:12:36.209081+00	2026-03-08 17:12:36.209081+00
\.


--
-- Data for Name: org_budgets; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.org_budgets (id, organization_id, category, limit_amount, spent_amount, currency, period_start, period_end, alert_threshold_pct, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: org_fuel_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.org_fuel_settings (organization_id, default_daily_liters_limit, default_monthly_liters_limit, default_daily_amount_limit, default_monthly_amount_limit, currency, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: org_support_metrics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.org_support_metrics (org_id, open_tickets, resolved_tickets, avg_resolution_time, sla_breaches, critical_issues, last_calculated, updated_at) FROM stdin;
\.


--
-- Data for Name: organization_memberships; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.organization_memberships (id, org_id, user_id, role, created_at) FROM stdin;
\.


--
-- Data for Name: organization_users; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.organization_users (id, organization_id, email, role, status, created_at) FROM stdin;
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.organizations (id, name, domain, status, created_at, updated_at, default_theme, is_deleted, contact_email, plan, max_users_limit, max_api_keys_limit) FROM stdin;
00000000-0000-0000-0000-000000000001	Test Org	\N	active	2026-03-08 18:50:57.862187+00	2026-03-08 18:50:57.862187+00	light	f	\N	enterprise	10	5
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.password_reset_tokens (id, user_id, token, expires_at, created_at, used, used_at) FROM stdin;
\.


--
-- Data for Name: payment_records; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.payment_records (id, invoice_id, amount, payment_method, payment_reference, payment_date, notes, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.permissions (id, role_id, resource, action, created_at) FROM stdin;
\.


--
-- Data for Name: platform_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.platform_settings (id, system_name, support_email, default_timezone, default_currency, default_language, white_label_enabled, smtp_config_id, created_at, created_by, updated_at, updated_by) FROM stdin;
00000000-0000-0000-0000-000000000001	Enterprise Fleet Manager	support@fleet-system.com	UTC	USD	en-US	f	\N	2026-03-08 17:12:33.126771+00	00000000-0000-0000-0000-000000000000	2026-03-08 17:12:33.126771+00	00000000-0000-0000-0000-000000000000
\.


--
-- Data for Name: prediction_results; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.prediction_results (id, model_id, prediction_input, predicted_value, confidence_score, probability_scores, feature_importance, anomaly_detected, anomaly_score, explanation, organization_id, request_id, predicted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: predictive_maintenance_analytics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.predictive_maintenance_analytics (id, vehicle_id, organization_id, analysis_date, next_service_due, service_priority, component_risks, failure_prediction, maintenance_schedule, parts_needed, cost_estimation, uptime_prediction, reliability_score, recommendations, generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: predictive_models; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.predictive_models (id, name, version, model_type, description, algorithm, input_features, output_variable, training_data_start, training_data_end, accuracy, "precision", recall, f1_score, status, trained_at, expires_at, created_at, updated_at, organization_id) FROM stdin;
\.


--
-- Data for Name: pricing_rules; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.pricing_rules (id, name, description, condition_json, action_json, priority, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: proof_of_delivery; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.proof_of_delivery (id, trip_id, type, url, metadata, uploaded_by, verified, created_at) FROM stdin;
\.


--
-- Data for Name: receipt_ocr_jobs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.receipt_ocr_jobs (id, org_id, expense_item_id, status, attempts, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.refresh_tokens (id, user_id, token, expires_at, created_at, revoked, revoked_at, used_at, ip_address, user_agent, last_used_at, device_id) FROM stdin;
\.


--
-- Data for Name: restore_jobs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.restore_jobs (id, backup_id, status, target_environment, started_at, completed_at, performed_by, logs) FROM stdin;
\.


--
-- Data for Name: review_items; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.review_items (id, review_id, user_id, role_id, current_status, reviewer_id, reviewed_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.roles (id, name, description, is_system, created_at, updated_at) FROM stdin;
e20a9854-afb8-4953-b691-9ef4f3d8df81	super_admin	Full platform access	t	2026-03-08 17:12:05.208565+00	2026-03-08 17:12:05.208565+00
490c6c81-8fb2-40f4-826f-806d89a4ab6d	org_admin	Organization level administrator	t	2026-03-08 17:12:05.208565+00	2026-03-08 17:12:05.208565+00
fdb0e1c1-6cd6-452c-9887-d762ca91b5c9	fleet_manager	Manages vehicles and drivers	t	2026-03-08 17:12:05.208565+00	2026-03-08 17:12:05.208565+00
329e417d-5494-4faa-8bc9-80ac7590f073	driver	Driver app access only	t	2026-03-08 17:12:05.208565+00	2026-03-08 17:12:05.208565+00
\.


--
-- Data for Name: rollout_device_status; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.rollout_device_status (id, rollout_id, device_id, status, updated_at) FROM stdin;
\.


--
-- Data for Name: route_optimization_jobs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.route_optimization_jobs (id, request_id, status, worker_id, started_at, completed_at, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: route_optimization_requests; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.route_optimization_requests (id, organization_id, status, constraints, stops, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: route_optimization_results; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.route_optimization_results (id, request_id, routes, total_distance, total_duration, total_cost, created_at) FROM stdin;
\.


--
-- Data for Name: security_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.security_events (id, user_id, event_type, ip_address, user_agent, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: security_history; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.security_history (id, user_id, event_type, ip_address, location, user_agent, risk_score, result, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: service_accounts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.service_accounts (id, org_id, name, secret_hash, permissions, created_at) FROM stdin;
\.


--
-- Data for Name: settings_audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.settings_audit_logs (id, entity_type, entity_id, action, actor_id, actor_ip, changes, created_at) FROM stdin;
\.


--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.shipments (id, customer_id, trip_id, tracking_number, status, origin, destination, current_location, estimated_delivery, actual_delivery, cargo_details, pod_url, pod_uploaded_at, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: signing_keys; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.signing_keys (kid, private_key_enc, public_key, status, algorithm, created_at, activated_at, expires_at) FROM stdin;
9c06d777-0333-462d-8788-fa09349d0672	-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEAxbZ46PVATWJANcqUw0ZP4YKAOEww8581v/qifXOfr9Iicztb\nTqCc0XSZVnt9/drBq1h4hsHc9t/nrqzZhTzOP6OXM5OcfkHVR5/7rR+p+t9Qyi7j\nQ47AqutUrh186DHYvsuEF+bfgYz7Y+9ekxZfiCX+QWKSdpq0va1Y0EBma8JO2eIL\nzo9GrGzbzR6i7KjBJLMTFWW4Y1HdtCah0Ka3gWU4bIMpMm19Hx2+3n5IGzRe/680\nG1D6xitqsriarkqNX/AVzVfrR5uBCF+hX0MgOikf0marLFMsfPwjtedLOeJdUdPk\nEaZ72fKR7lVW+5wYQRc1TAT9ruBEHIQMAlg3PwIDAQABAoIBAFnCWqggV54KIe6J\n1vnEXRWbQozMgljICgXrSoO7z15p/vvjkbNjlW4+CjNKA0wRWWVp1+YN8zwdMLiL\nfoFPtq8LnORselqTlrlat07Elk3vvmTb3o9YKr4t8pbNilx77NPJ32Fejk/pamPX\nU09hk+NipEiY8Ldpyu5l2XFKG3WFx/jVdo6J31tzt/c97GevNPOSehOc44SD0/lC\nwtqIRigOzrv631VxCSbaUMqLY8Z1f3UNH5uS0X9h57zeXzELhl1lNPG7SFpZdDPG\nyNgXS9tOCG4t0Wh1CQk/36UtoGRnQ3rWnJIwJHjtSpdSvq+Lgr6gN9EjSL22/PV1\nFYIRSEECgYEA67httA3takoXprk03h/t7mBG0b6n0qHj0Q2selV75nu3VKA/EePK\n7LQs9VNEww3DOi0LAY206jeWjonC+OeKA6Vrvkv/wOEfUB8HFHpIAj4nAAp+nvOE\n8vJ23e6os++yqklbJAYqjtBtj36RZaPazU6WsRt1rRAp2wEACMQOZB8CgYEA1rjz\n+UdTsV56PqVeIEP2Dr2CkaHZEX7odPDT/364PMT3sr9R8Omi02TCPeQEqVrVi/Ke\nPNrfFzBlj9NhpfIg0LAZ2oe31+O0DZ+xvGP8ZkwdNl1x4a40qW1lcCLeNfEgomrk\n4BR18LpPwy6YMMDI1gy+vOn4ZhQrovvi6I1GyOECgYEA5TmFHQpKLQl+NHh4i+U6\n6IuhcshXxQH/W8VTS+ejREBcyKPIkWoWZNbVvX/LJ29TwVgaEtmt6/JAq74V5xyq\nXt9Xhke7nuKNI8n4hZZgPiYYoPaTqZkgWW0l4K38Sna3JNePFNoWOqk/UcKAO/n6\nhZp9+h688Z39ReaUFPIrGHsCgYAi49C4668cvgZNEZ/WzFQ6Fu8VbOARqLZq8grw\nlA2pyjOZdt8Ar2YGxXOOjPN49UqHv/eYWdQwN2v5T9apGUvdvQ+mY7EqwlQqdo1x\n2ClWEf4ZLFvp2N2zvhPigbfrue+clJP2GT0EzbFSPMr7+QdpSI7hsX7sT1C73gQD\n15jt4QKBgAvLOm/7mB/cf/HP8/0gAfIhHS2GhPp1RxvK4p9W2PjW2XCXYFkscmd7\n/kpGcDcsNghTGk3CTk9u56U+z9CFTG2vLQxzrfTnvy0+UHt43KO/XSbLGrN4otBW\n3B6aANtWCLjldXCX3v9H8qASZDktcSPvaxynMAIsLiUfci9z4mD7\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxbZ46PVATWJANcqUw0ZP\n4YKAOEww8581v/qifXOfr9IicztbTqCc0XSZVnt9/drBq1h4hsHc9t/nrqzZhTzO\nP6OXM5OcfkHVR5/7rR+p+t9Qyi7jQ47AqutUrh186DHYvsuEF+bfgYz7Y+9ekxZf\niCX+QWKSdpq0va1Y0EBma8JO2eILzo9GrGzbzR6i7KjBJLMTFWW4Y1HdtCah0Ka3\ngWU4bIMpMm19Hx2+3n5IGzRe/680G1D6xitqsriarkqNX/AVzVfrR5uBCF+hX0Mg\nOikf0marLFMsfPwjtedLOeJdUdPkEaZ72fKR7lVW+5wYQRc1TAT9ruBEHIQMAlg3\nPwIDAQAB\n-----END PUBLIC KEY-----\n	active	RS256	2026-03-08 17:13:03.462921+00	2026-03-08 17:13:03.462921+00	\N
\.


--
-- Data for Name: sla_metrics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.sla_metrics ("time", org_id, metric_name, value, metadata) FROM stdin;
\.


--
-- Data for Name: sos_incidents; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.sos_incidents (id, vehicle_id, driver_id, trip_id, "timestamp", latitude, longitude, location_address, status, severity, metadata, created_at, updated_at, incident_type, device_id, panic_source, speed, heading, acknowledged_by, resolved_by, high_risk_location, simulation_mode, driver_feedback, feedback_notes, org_id, acknowledged_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: storage_pools; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.storage_pools (id, name, status, total_bytes, used_bytes, available_bytes, location, backup_count, created_at, updated_at) FROM stdin;
a1b2c3d4-0001-0001-0001-000000000001	Primary Storage	ACTIVE	1073741824000	375809638400	697932185600	us-east-1	24	2025-12-08 17:12:07.838231+00	2026-03-08 17:12:07.838231+00
a1b2c3d4-0002-0002-0002-000000000002	DR Storage	ACTIVE	2147483648000	858993459200	1288490188800	us-west-2	48	2025-09-09 17:12:07.838231+00	2026-03-08 17:12:07.838231+00
a1b2c3d4-0003-0003-0003-000000000003	Archive Storage	WARNING	5368709120000	4509715660800	858993459200	eu-central-1	120	2025-03-08 17:12:07.838231+00	2026-03-07 17:12:07.838231+00
\.


--
-- Data for Name: support_audit_log; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.support_audit_log (id, ticket_id, user_id, action, old_value, new_value, details, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: support_ticket_attachments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.support_ticket_attachments (id, ticket_id, file_url, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: support_ticket_messages; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.support_ticket_messages (id, ticket_id, sender_id, message, created_at) FROM stdin;
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.support_tickets (id, ticket_id, org_id, title, description, status, priority, category, assigned_to, reporter_id, created_at, updated_at, resolved_at, sla_deadline, tags, metadata) FROM stdin;
\.


--
-- Data for Name: sync_jobs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.sync_jobs (id, organization_id, erp_config_id, entity_type, direction, status, started_at, completed_at, records_processed, error_log, created_at) FROM stdin;
\.


--
-- Data for Name: system_audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.system_audit_logs (id, organization_id, user_id, action, target_user_id, ip_address, user_agent, status, error_message, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: system_flags; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.system_flags (key, value, updated_at) FROM stdin;
\.


--
-- Data for Name: system_limits; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.system_limits (id, api_rate_limit, burst_limit, audit_retention, activity_retention, created_at, created_by, updated_at, updated_by) FROM stdin;
ecdbc07b-6443-480e-bc22-96a9a391eede	10000	500	1y	180d	2026-03-08 17:12:33.129176+00	00000000-0000-0000-0000-000000000000	2026-03-08 17:12:33.129176+00	00000000-0000-0000-0000-000000000000
\.


--
-- Data for Name: tds_records; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.tds_records (id, entity_type, entity_id, vendor_id, org_id, pan_number, tds_section, gross_amount, tds_rate, tds_amount, net_amount, deducted_at, deposited, deposit_challan, financial_year, quarter, created_at) FROM stdin;
\.


--
-- Data for Name: telemetry; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry (id, trip_id, latitude, longitude, speed, heading, event_type, event_time) FROM stdin;
\.


--
-- Data for Name: telemetry_analytics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_analytics (id, vehicle_id, analysis_type, data, "timestamp", confidence) FROM stdin;
\.


--
-- Data for Name: telemetry_anomalies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_anomalies (id, vehicle_id, anomaly_type, data, "timestamp", confidence, anomaly_score, recommendation) FROM stdin;
\.


--
-- Data for Name: telemetry_outbox; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_outbox (id, partition_id, payload, status, attempts, last_attempt, error_msg, created_at) FROM stdin;
\.


--
-- Data for Name: telemetry_points_y2026m01; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_points_y2026m01 (id, event_id, vehicle_id, device_id, tenant_id, lat, lng, speed, heading, ignition, fuel_level, odometer, event_type, sequence_no, recorded_at, received_at, geo) FROM stdin;
\.


--
-- Data for Name: telemetry_points_y2026m02; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_points_y2026m02 (id, event_id, vehicle_id, device_id, tenant_id, lat, lng, speed, heading, ignition, fuel_level, odometer, event_type, sequence_no, recorded_at, received_at, geo) FROM stdin;
\.


--
-- Data for Name: telemetry_points_y2026m03; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_points_y2026m03 (id, event_id, vehicle_id, device_id, tenant_id, lat, lng, speed, heading, ignition, fuel_level, odometer, event_type, sequence_no, recorded_at, received_at, geo) FROM stdin;
\.


--
-- Data for Name: telemetry_points_y2026m04; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_points_y2026m04 (id, event_id, vehicle_id, device_id, tenant_id, lat, lng, speed, heading, ignition, fuel_level, odometer, event_type, sequence_no, recorded_at, received_at, geo) FROM stdin;
\.


--
-- Data for Name: telemetry_points_y2026m05; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_points_y2026m05 (id, event_id, vehicle_id, device_id, tenant_id, lat, lng, speed, heading, ignition, fuel_level, odometer, event_type, sequence_no, recorded_at, received_at, geo) FROM stdin;
\.


--
-- Data for Name: telemetry_points_y2026m06; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_points_y2026m06 (id, event_id, vehicle_id, device_id, tenant_id, lat, lng, speed, heading, ignition, fuel_level, odometer, event_type, sequence_no, recorded_at, received_at, geo) FROM stdin;
\.


--
-- Data for Name: telemetry_points_y2026m07; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_points_y2026m07 (id, event_id, vehicle_id, device_id, tenant_id, lat, lng, speed, heading, ignition, fuel_level, odometer, event_type, sequence_no, recorded_at, received_at, geo) FROM stdin;
\.


--
-- Data for Name: telemetry_points_y2026m08; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_points_y2026m08 (id, event_id, vehicle_id, device_id, tenant_id, lat, lng, speed, heading, ignition, fuel_level, odometer, event_type, sequence_no, recorded_at, received_at, geo) FROM stdin;
\.


--
-- Data for Name: telemetry_points_y2026m09; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_points_y2026m09 (id, event_id, vehicle_id, device_id, tenant_id, lat, lng, speed, heading, ignition, fuel_level, odometer, event_type, sequence_no, recorded_at, received_at, geo) FROM stdin;
\.


--
-- Data for Name: telemetry_points_y2026m10; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_points_y2026m10 (id, event_id, vehicle_id, device_id, tenant_id, lat, lng, speed, heading, ignition, fuel_level, odometer, event_type, sequence_no, recorded_at, received_at, geo) FROM stdin;
\.


--
-- Data for Name: telemetry_points_y2026m11; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_points_y2026m11 (id, event_id, vehicle_id, device_id, tenant_id, lat, lng, speed, heading, ignition, fuel_level, odometer, event_type, sequence_no, recorded_at, received_at, geo) FROM stdin;
\.


--
-- Data for Name: telemetry_points_y2026m12; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_points_y2026m12 (id, event_id, vehicle_id, device_id, tenant_id, lat, lng, speed, heading, ignition, fuel_level, odometer, event_type, sequence_no, recorded_at, received_at, geo) FROM stdin;
\.


--
-- Data for Name: telemetry_points_y2027m01; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry_points_y2027m01 (id, event_id, vehicle_id, device_id, tenant_id, lat, lng, speed, heading, ignition, fuel_level, odometer, event_type, sequence_no, recorded_at, received_at, geo) FROM stdin;
\.


--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.templates (id, template_key, channel, subject, body, variables, created_at, created_by, updated_at, updated_by) FROM stdin;
6d12c8d5-1c13-49c1-a2cf-41cbf9b5dbae	welcome_email	EMAIL	Welcome to {{system_name}}	Welcome {{user_name}}! Your account has been created. Please verify your email address.	{user_name,verification_link}	2026-03-08 17:12:33.134155+00	00000000-0000-0000-0000-000000000000	2026-03-08 17:12:33.134155+00	00000000-0000-0000-0000-000000000000
50a04999-5a51-4164-a415-efaaae280a99	password_reset_email	EMAIL	Password Reset Request	You requested a password reset. Click here to reset: {{reset_link}}	{reset_link,expiry_time}	2026-03-08 17:12:33.134155+00	00000000-0000-0000-0000-000000000000	2026-03-08 17:12:33.134155+00	00000000-0000-0000-0000-000000000000
\.


--
-- Data for Name: threat_alerts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.threat_alerts (id, org_id, type, severity, ip, user_id, description, status, created_at) FROM stdin;
\.


--
-- Data for Name: ticket_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.ticket_events (id, ticket_id, author_id, author_name, event_type, message, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: toll_transactions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.toll_transactions (id, vehicle_id, fastag_id, toll_plaza, amount, currency, transaction_time, external_transaction_id, metadata, created_at, org_id, updated_at) FROM stdin;
\.


--
-- Data for Name: tracking_config; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.tracking_config (id, target_id, target_type, config, updated_at) FROM stdin;
\.


--
-- Data for Name: trip_profitability; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.trip_profitability (id, trip_id, org_id, vehicle_id, driver_id, trip_revenue, fuel_cost, toll_cost, driver_cost, maintenance_cost, other_cost, profit_margin, distance_km, cost_per_km, calculated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: trip_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.trip_settings (id, organization_id, retention_period, policies, updated_at) FROM stdin;
\.


--
-- Data for Name: trips; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.trips (id, org_id, vehicle_id, driver_id, status, title, description, planned_route, actual_route, waypoints, start_location, end_location, estimated_distance_km, actual_distance_km, estimated_duration_min, actual_duration_min, fuel_consumed_liters, idling_time_minutes, cargo_details, pod_documents, scheduled_start, started_at, ended_at, customer_name, customer_phone, customer_email, cancellation_reason, events, is_deleted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: usage_meters; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.usage_meters (id, code, name, description, unit, unit_price, currency, status, created_at) FROM stdin;
bb7737a8-af2d-4f1f-839a-2446e879e557	DISTANCE_KM	Mileage	\N	km	0.1500	USD	active	2026-03-08 17:12:08.738869+00
1d75df3f-620f-4a40-a50e-7a29aaaf25c0	HEARTBEAT_COUNT	Device Connectivity	\N	count	0.0100	USD	active	2026-03-08 17:12:08.738869+00
\.


--
-- Data for Name: user_invoice_access; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.user_invoice_access (id, org_id, user_id, override_role, can_create_invoice, can_edit_invoice, can_delete_invoice, can_issue_invoice, can_cancel_invoice, can_record_payment, can_approve_invoices, approval_limit, max_invoice_amount, require_approval_above, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: user_notes; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.user_notes (id, user_id, agent_name, note, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: user_notification_preferences; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.user_notification_preferences (id, user_id, email_enabled, sms_enabled, push_enabled, in_app_enabled, last_modified_by, last_modified_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_oidc_links; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.user_oidc_links (id, user_id, provider_id, provider_user_id, email, last_login_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_organizations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.user_organizations (id, user_id, org_id, role, status, created_at) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.user_sessions (id, user_id, session_id, ip_address, user_agent, device_info, login_time, last_activity, logout_time, is_active, location) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.users (id, email, password_hash, name, phone, mfa_enabled, mfa_secret, status, created_at, updated_at, theme_updated_at, is_deleted, role_id, mfa_methods, last_password_change, failed_login_attempts, locked_until, last_login_at, data_retention_until) FROM stdin;
\.


--
-- Data for Name: vehicle_assignments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicle_assignments (id, vehicle_id, driver_id, device_id, started_at, ended_at, is_active) FROM stdin;
\.


--
-- Data for Name: vehicle_compliance; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicle_compliance (vehicle_id, rc_expiry_date, insurance_expiry_date, puc_expiry_date, fitness_expiry_date, permit_expiry_date, permit_type, insurance_policy_no, is_blacklisted, legal_hold, last_verified_at, verified_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vehicle_daily_stats; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicle_daily_stats (vehicle_id, organization_id, date, total_distance, total_fuel_consumed, total_engine_hours, total_idle_hours, max_speed, avg_speed, harsh_braking_count, rapid_acceleration_count, sharp_turn_count, overspeeding_count, updated_at) FROM stdin;
\.


--
-- Data for Name: vehicle_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicle_events (id, vehicle_id, event_type, payload, hash, prev_hash, actor_id, created_at) FROM stdin;
\.


--
-- Data for Name: vehicle_financials; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicle_financials (vehicle_id, acquisition_cost, depreciation_method, depreciation_rate, residual_value, emi_amount, lease_end_date, insurance_premium, total_maintenance_cost, total_fuel_cost, total_toll_cost, tco_cached, tco_calculated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vehicle_inspections; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicle_inspections (id, organization_id, vehicle_id, template_id, inspector_id, status, results, notes, odometer_at_inspection, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: vehicle_specs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicle_specs (vehicle_id, fuel_type, tank_capacity_liters, efficiency_expected_km_l, created_at, updated_at) FROM stdin;
f1111111-1111-1111-1111-111111111111	\N	250.00	\N	2026-03-08 17:15:30.529597+00	2026-03-08 17:15:30.529597+00
\.


--
-- Data for Name: vehicle_telemetry; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicle_telemetry ("time", vehicle_id, latitude, longitude, speed_kph, heading, odometer_km, fuel_level_percent, engine_temp_celsius, alerts) FROM stdin;
\.


--
-- Data for Name: vehicle_verifications; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicle_verifications (id, vehicle_id, organization_id, registration_number, status, verification_date, chassis_number, engine_number, model, manufacturer, fuel_type, body_type, cubic_capacity, seating_capacity, color, manufacturing_year, owner_name, owner_address, owner_city, owner_district, owner_state, owner_pin, rc_status, insurance_company, insurance_policy, insurance_expiry, puc_number, puc_expiry, created_at, created_by, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicles (id, tenant_id, registration_number, chassis_number, engine_number, vin_number, vehicle_type, capacity_tonnage, fuel_type, fuel_tank_capacity, ownership_type, parent_vehicle_id, branch_id, cost_center_id, status, gps_device_id, immobilizer_enabled, ais140_compliant, make, model, year, color, created_at, updated_at, deleted_at, version) FROM stdin;
\.


--
-- Data for Name: vehicles_legacy; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicles_legacy (id, org_id, license_plate, model, make, year, color, status, capacity, fuel_type, vin, registration, insurance, odometer, last_service, current_driver_id, created_at, updated_at, deleted_at, vehicle_no, service_due, notes, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: vendor_payments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vendor_payments (id, vendor_id, org_id, invoice_number, amount, tds_deducted, net_payable, currency, payment_status, payment_mode, payment_reference, bank_account, ifsc_code, payment_date, paid_at, gst_invoice_id, tds_record_id, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: video_analytics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.video_analytics (id, recording_id, stream_id, objects_detected, behavior_events, traffic_signs, incidents, "timestamp", confidence, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: video_recordings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.video_recordings (id, stream_id, camera_id, vehicle_id, driver_id, organization_id, filename, filepath, file_size, duration, resolution, framerate, bitrate, start_time, end_time, location_start, location_end, status, thumbnail_path, tags, event_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: video_retention_policies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.video_retention_policies (id, organization_id, name, description, event_type, retention_period, auto_archive, auto_delete, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: video_streams; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.video_streams (id, camera_id, vehicle_id, driver_id, organization_id, url, status, resolution, framerate, bitrate, protocol, location, started_at, ended_at, created_at, updated_at, analytics_enabled) FROM stdin;
\.


--
-- Data for Name: webhook_event_types; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.webhook_event_types (event_type, description, category, is_active) FROM stdin;
invoice.created	Triggered when a new invoice is created	invoice	t
invoice.updated	Triggered when an invoice is updated	invoice	t
invoice.issued	Triggered when an invoice is issued	invoice	t
invoice.cancelled	Triggered when an invoice is cancelled	invoice	t
invoice.paid	Triggered when an invoice is fully paid	invoice	t
invoice.overdue	Triggered when an invoice becomes overdue	invoice	t
payment.recorded	Triggered when a payment is recorded	payment	t
payment.refunded	Triggered when a payment is refunded	payment	t
credit_note.created	Triggered when a credit note is created	credit_note	t
credit_note.issued	Triggered when a credit note is issued	credit_note	t
credit_note.applied	Triggered when a credit note is applied	credit_note	t
approval.requested	Triggered when an invoice approval is requested	approval	t
approval.approved	Triggered when an invoice is approved	approval	t
approval.rejected	Triggered when an invoice is rejected	approval	t
\.


--
-- Data for Name: webhook_subscriptions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.webhook_subscriptions (id, org_id, name, url, secret, is_active, events, custom_headers, max_retries, retry_delay_seconds, timeout_seconds, rate_limit_per_minute, total_deliveries, successful_deliveries, failed_deliveries, last_delivery_at, last_success_at, last_failure_at, description, metadata, created_at, created_by, updated_at, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.webhooks (id, org_id, url, events, secret, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: work_order_parts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.work_order_parts (id, work_order_id, part_id, quantity, unit_cost, total_cost, created_at) FROM stdin;
\.


--
-- Data for Name: work_orders; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.work_orders (id, organization_id, vehicle_id, title, description, maintenance_type, priority, status, assigned_to, scheduled_date, completed_date, estimated_cost, actual_cost, created_by, created_at, updated_at, vendor_id, approval_status, cost_breakdown, inspection_id, updated_by) FROM stdin;
\.


--
-- Name: bgw_job_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.bgw_job_id_seq', 1002, true);


--
-- Name: chunk_column_stats_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_column_stats_id_seq', 1, false);


--
-- Name: chunk_constraint_name; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_constraint_name', 1, false);


--
-- Name: chunk_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_id_seq', 1, false);


--
-- Name: continuous_agg_migrate_plan_step_step_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.continuous_agg_migrate_plan_step_step_id_seq', 1, false);


--
-- Name: dimension_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_id_seq', 10, true);


--
-- Name: dimension_slice_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_slice_id_seq', 1, false);


--
-- Name: hypertable_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: fleet_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.hypertable_id_seq', 10, true);


--
-- Name: device_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fleet_user
--

SELECT pg_catalog.setval('public.device_alerts_id_seq', 1, false);


--
-- Name: diagnostics_audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fleet_user
--

SELECT pg_catalog.setval('public.diagnostics_audit_logs_id_seq', 1, false);


--
-- Name: rollout_device_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fleet_user
--

SELECT pg_catalog.setval('public.rollout_device_status_id_seq', 1, false);


--
-- Name: support_tickets_ticket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fleet_user
--

SELECT pg_catalog.setval('public.support_tickets_ticket_id_seq', 1000, false);


--
-- Name: telemetry_outbox_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fleet_user
--

SELECT pg_catalog.setval('public.telemetry_outbox_id_seq', 1, false);


--
-- Name: telemetry_points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fleet_user
--

SELECT pg_catalog.setval('public.telemetry_points_id_seq', 1, false);


--
-- Name: ab_test_experiments ab_test_experiments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.ab_test_experiments
    ADD CONSTRAINT ab_test_experiments_pkey PRIMARY KEY (id);


--
-- Name: access_reviews access_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.access_reviews
    ADD CONSTRAINT access_reviews_pkey PRIMARY KEY (id);


--
-- Name: admin_audit_logs admin_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.admin_audit_logs
    ADD CONSTRAINT admin_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: admin_operation_approvals admin_operation_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.admin_operation_approvals
    ADD CONSTRAINT admin_operation_approvals_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions admin_permissions_name_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_name_key UNIQUE (name);


--
-- Name: admin_permissions admin_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_pkey PRIMARY KEY (id);


--
-- Name: admin_role_permissions admin_role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.admin_role_permissions
    ADD CONSTRAINT admin_role_permissions_pkey PRIMARY KEY (role, permission);


--
-- Name: admin_search_sync_state admin_search_sync_state_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.admin_search_sync_state
    ADD CONSTRAINT admin_search_sync_state_pkey PRIMARY KEY (domain);


--
-- Name: admin_users admin_users_email_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_email_key UNIQUE (email);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: alert_rules alert_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alert_rules
    ADD CONSTRAINT alert_rules_pkey PRIMARY KEY (id);


--
-- Name: alert_thresholds alert_thresholds_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alert_thresholds
    ADD CONSTRAINT alert_thresholds_pkey PRIMARY KEY (component, metric);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: alerts_v2_dlq alerts_v2_dlq_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts_v2_dlq
    ADD CONSTRAINT alerts_v2_dlq_pkey PRIMARY KEY (id);


--
-- Name: alerts_v2_logs alerts_v2_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts_v2_logs
    ADD CONSTRAINT alerts_v2_logs_pkey PRIMARY KEY (id);


--
-- Name: alerts_v2_templates alerts_v2_templates_name_channel_language_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts_v2_templates
    ADD CONSTRAINT alerts_v2_templates_name_channel_language_key UNIQUE (name, channel, language);


--
-- Name: alerts_v2_templates alerts_v2_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts_v2_templates
    ADD CONSTRAINT alerts_v2_templates_pkey PRIMARY KEY (id);


--
-- Name: alerts_v2_user_preferences alerts_v2_user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts_v2_user_preferences
    ADD CONSTRAINT alerts_v2_user_preferences_pkey PRIMARY KEY (user_id, channel);


--
-- Name: analytics_access_logs analytics_access_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.analytics_access_logs
    ADD CONSTRAINT analytics_access_logs_pkey PRIMARY KEY (id);


--
-- Name: analytics_jobs analytics_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.analytics_jobs
    ADD CONSTRAINT analytics_jobs_pkey PRIMARY KEY (id);


--
-- Name: analytics_query_logs analytics_query_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.analytics_query_logs
    ADD CONSTRAINT analytics_query_logs_pkey PRIMARY KEY (id);


--
-- Name: analytics_query_plans analytics_query_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.analytics_query_plans
    ADD CONSTRAINT analytics_query_plans_pkey PRIMARY KEY (id);


--
-- Name: analytics_quotas analytics_quotas_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.analytics_quotas
    ADD CONSTRAINT analytics_quotas_pkey PRIMARY KEY (organization_id);


--
-- Name: api_clients api_clients_client_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT api_clients_client_id_key UNIQUE (client_id);


--
-- Name: api_clients api_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT api_clients_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: approval_actions approval_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.approval_actions
    ADD CONSTRAINT approval_actions_pkey PRIMARY KEY (id);


--
-- Name: approval_configs approval_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.approval_configs
    ADD CONSTRAINT approval_configs_pkey PRIMARY KEY (id);


--
-- Name: approval_instances approval_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.approval_instances
    ADD CONSTRAINT approval_instances_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: audit_policies audit_policies_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_org_id_key UNIQUE (org_id);


--
-- Name: audit_policies audit_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_pkey PRIMARY KEY (id);


--
-- Name: audit_settings audit_settings_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_settings
    ADD CONSTRAINT audit_settings_org_id_key UNIQUE (org_id);


--
-- Name: audit_settings audit_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_settings
    ADD CONSTRAINT audit_settings_pkey PRIMARY KEY (id);


--
-- Name: auth_audit_logs auth_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.auth_audit_logs
    ADD CONSTRAINT auth_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: auth_tokens auth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_pkey PRIMARY KEY (id);


--
-- Name: backup_verifications backup_verifications_backup_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backup_verifications
    ADD CONSTRAINT backup_verifications_backup_id_key UNIQUE (backup_id);


--
-- Name: backup_verifications backup_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backup_verifications
    ADD CONSTRAINT backup_verifications_pkey PRIMARY KEY (id);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: bank_transactions bank_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bank_transactions
    ADD CONSTRAINT bank_transactions_pkey PRIMARY KEY (id);


--
-- Name: bank_transactions bank_transactions_transaction_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bank_transactions
    ADD CONSTRAINT bank_transactions_transaction_id_key UNIQUE (transaction_id);


--
-- Name: behavior_score_updates behavior_score_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.behavior_score_updates
    ADD CONSTRAINT behavior_score_updates_pkey PRIMARY KEY (id);


--
-- Name: billing_accounting_exports billing_accounting_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_accounting_exports
    ADD CONSTRAINT billing_accounting_exports_pkey PRIMARY KEY (id);


--
-- Name: billing_configurations billing_configurations_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_configurations
    ADD CONSTRAINT billing_configurations_org_id_key UNIQUE (org_id);


--
-- Name: billing_configurations billing_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_configurations
    ADD CONSTRAINT billing_configurations_pkey PRIMARY KEY (id);


--
-- Name: billing_coupons billing_coupons_code_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_coupons
    ADD CONSTRAINT billing_coupons_code_key UNIQUE (code);


--
-- Name: billing_coupons billing_coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_coupons
    ADD CONSTRAINT billing_coupons_pkey PRIMARY KEY (id);


--
-- Name: billing_credit_transactions billing_credit_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_credit_transactions
    ADD CONSTRAINT billing_credit_transactions_pkey PRIMARY KEY (id);


--
-- Name: billing_customer_balances billing_customer_balances_org_id_currency_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_customer_balances
    ADD CONSTRAINT billing_customer_balances_org_id_currency_key UNIQUE (org_id, currency);


--
-- Name: billing_customer_balances billing_customer_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_customer_balances
    ADD CONSTRAINT billing_customer_balances_pkey PRIMARY KEY (id);


--
-- Name: billing_hardware_products billing_hardware_products_model_code_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_hardware_products
    ADD CONSTRAINT billing_hardware_products_model_code_key UNIQUE (model_code);


--
-- Name: billing_hardware_products billing_hardware_products_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_hardware_products
    ADD CONSTRAINT billing_hardware_products_pkey PRIMARY KEY (id);


--
-- Name: billing_invoice_documents billing_invoice_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_invoice_documents
    ADD CONSTRAINT billing_invoice_documents_pkey PRIMARY KEY (id);


--
-- Name: billing_invoice_sequences billing_invoice_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_invoice_sequences
    ADD CONSTRAINT billing_invoice_sequences_pkey PRIMARY KEY (org_id);


--
-- Name: billing_invoice_templates billing_invoice_templates_name_version_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_invoice_templates
    ADD CONSTRAINT billing_invoice_templates_name_version_key UNIQUE (name, version);


--
-- Name: billing_invoice_templates billing_invoice_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_invoice_templates
    ADD CONSTRAINT billing_invoice_templates_pkey PRIMARY KEY (id);


--
-- Name: billing_plans billing_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_plans
    ADD CONSTRAINT billing_plans_pkey PRIMARY KEY (id);


--
-- Name: billing_pricing_components billing_pricing_components_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_pricing_components
    ADD CONSTRAINT billing_pricing_components_pkey PRIMARY KEY (id);


--
-- Name: billing_recognized_revenue billing_recognized_revenue_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_recognized_revenue
    ADD CONSTRAINT billing_recognized_revenue_pkey PRIMARY KEY (id);


--
-- Name: billing_revenue_schedules billing_revenue_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_revenue_schedules
    ADD CONSTRAINT billing_revenue_schedules_pkey PRIMARY KEY (id);


--
-- Name: billing_settings billing_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_settings
    ADD CONSTRAINT billing_settings_pkey PRIMARY KEY (org_id);


--
-- Name: billing_subscriptions billing_subscriptions_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_subscriptions
    ADD CONSTRAINT billing_subscriptions_org_id_key UNIQUE (org_id);


--
-- Name: billing_subscriptions billing_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_subscriptions
    ADD CONSTRAINT billing_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: billing_tax_rates billing_tax_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_tax_rates
    ADD CONSTRAINT billing_tax_rates_pkey PRIMARY KEY (id);


--
-- Name: billing_tax_regions billing_tax_regions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_tax_regions
    ADD CONSTRAINT billing_tax_regions_pkey PRIMARY KEY (id);


--
-- Name: blocked_ips blocked_ips_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.blocked_ips
    ADD CONSTRAINT blocked_ips_pkey PRIMARY KEY (ip_address);


--
-- Name: booking_requests booking_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.booking_requests
    ADD CONSTRAINT booking_requests_pkey PRIMARY KEY (id);


--
-- Name: bulk_config bulk_config_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_config
    ADD CONSTRAINT bulk_config_pkey PRIMARY KEY (organization_id);


--
-- Name: bulk_job_records bulk_job_records_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_job_records
    ADD CONSTRAINT bulk_job_records_pkey PRIMARY KEY (id);


--
-- Name: bulk_jobs bulk_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_jobs
    ADD CONSTRAINT bulk_jobs_pkey PRIMARY KEY (id);


--
-- Name: compliance_reviews compliance_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.compliance_reviews
    ADD CONSTRAINT compliance_reviews_pkey PRIMARY KEY (id);


--
-- Name: currency_rates currency_rates_from_currency_to_currency_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.currency_rates
    ADD CONSTRAINT currency_rates_from_currency_to_currency_key UNIQUE (from_currency, to_currency);


--
-- Name: currency_rates currency_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.currency_rates
    ADD CONSTRAINT currency_rates_pkey PRIMARY KEY (id);


--
-- Name: customer_audit_log customer_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_audit_log
    ADD CONSTRAINT customer_audit_log_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_booking_approvals customer_v2_booking_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_booking_approvals
    ADD CONSTRAINT customer_v2_booking_approvals_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_booking_quotes customer_v2_booking_quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_booking_quotes
    ADD CONSTRAINT customer_v2_booking_quotes_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_booking_requests customer_v2_booking_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_booking_requests
    ADD CONSTRAINT customer_v2_booking_requests_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_booking_shipments customer_v2_booking_shipments_booking_id_shipment_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_booking_shipments
    ADD CONSTRAINT customer_v2_booking_shipments_booking_id_shipment_id_key UNIQUE (booking_id, shipment_id);


--
-- Name: customer_v2_booking_shipments customer_v2_booking_shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_booking_shipments
    ADD CONSTRAINT customer_v2_booking_shipments_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_booking_status_history customer_v2_booking_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_booking_status_history
    ADD CONSTRAINT customer_v2_booking_status_history_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_booking_validations customer_v2_booking_validations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_booking_validations
    ADD CONSTRAINT customer_v2_booking_validations_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_credit_limits customer_v2_credit_limits_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_credit_limits
    ADD CONSTRAINT customer_v2_credit_limits_customer_id_key UNIQUE (customer_id);


--
-- Name: customer_v2_credit_limits customer_v2_credit_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_credit_limits
    ADD CONSTRAINT customer_v2_credit_limits_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_credit_transactions customer_v2_credit_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_credit_transactions
    ADD CONSTRAINT customer_v2_credit_transactions_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_customer_addresses customer_v2_customer_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_addresses
    ADD CONSTRAINT customer_v2_customer_addresses_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_customer_api_keys customer_v2_customer_api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_api_keys
    ADD CONSTRAINT customer_v2_customer_api_keys_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_customer_api_logs customer_v2_customer_api_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_api_logs
    ADD CONSTRAINT customer_v2_customer_api_logs_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_customer_audit_logs customer_v2_customer_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_audit_logs
    ADD CONSTRAINT customer_v2_customer_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_customer_contacts customer_v2_customer_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_contacts
    ADD CONSTRAINT customer_v2_customer_contacts_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_customer_contracts customer_v2_customer_contracts_contract_number_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_contracts
    ADD CONSTRAINT customer_v2_customer_contracts_contract_number_key UNIQUE (contract_number);


--
-- Name: customer_v2_customer_contracts customer_v2_customer_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_contracts
    ADD CONSTRAINT customer_v2_customer_contracts_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_customer_credit_limits customer_v2_customer_credit_limits_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_credit_limits
    ADD CONSTRAINT customer_v2_customer_credit_limits_customer_id_key UNIQUE (customer_id);


--
-- Name: customer_v2_customer_credit_limits customer_v2_customer_credit_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_credit_limits
    ADD CONSTRAINT customer_v2_customer_credit_limits_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_customer_invoice_views customer_v2_customer_invoice_views_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_invoice_views
    ADD CONSTRAINT customer_v2_customer_invoice_views_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_customer_sessions customer_v2_customer_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_sessions
    ADD CONSTRAINT customer_v2_customer_sessions_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_customer_users customer_v2_customer_users_email_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_users
    ADD CONSTRAINT customer_v2_customer_users_email_key UNIQUE (email);


--
-- Name: customer_v2_customer_users customer_v2_customer_users_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_users
    ADD CONSTRAINT customer_v2_customer_users_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_customer_wallets customer_v2_customer_wallets_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_wallets
    ADD CONSTRAINT customer_v2_customer_wallets_customer_id_key UNIQUE (customer_id);


--
-- Name: customer_v2_customer_wallets customer_v2_customer_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_wallets
    ADD CONSTRAINT customer_v2_customer_wallets_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_customers customer_v2_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customers
    ADD CONSTRAINT customer_v2_customers_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_delivery_proofs customer_v2_delivery_proofs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_delivery_proofs
    ADD CONSTRAINT customer_v2_delivery_proofs_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_delivery_proofs customer_v2_delivery_proofs_shipment_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_delivery_proofs
    ADD CONSTRAINT customer_v2_delivery_proofs_shipment_id_key UNIQUE (shipment_id);


--
-- Name: customer_v2_dispute_attachments customer_v2_dispute_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_dispute_attachments
    ADD CONSTRAINT customer_v2_dispute_attachments_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_dispute_messages customer_v2_dispute_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_dispute_messages
    ADD CONSTRAINT customer_v2_dispute_messages_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_disputes customer_v2_disputes_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_disputes
    ADD CONSTRAINT customer_v2_disputes_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_pod_images customer_v2_pod_images_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_pod_images
    ADD CONSTRAINT customer_v2_pod_images_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_pod_signatures customer_v2_pod_signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_pod_signatures
    ADD CONSTRAINT customer_v2_pod_signatures_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_pricing_components customer_v2_pricing_components_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_pricing_components
    ADD CONSTRAINT customer_v2_pricing_components_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_pricing_contracts customer_v2_pricing_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_pricing_contracts
    ADD CONSTRAINT customer_v2_pricing_contracts_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_pricing_quotes customer_v2_pricing_quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_pricing_quotes
    ADD CONSTRAINT customer_v2_pricing_quotes_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_pricing_rules customer_v2_pricing_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_pricing_rules
    ADD CONSTRAINT customer_v2_pricing_rules_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_shipment_document_versions customer_v2_shipment_document_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipment_document_versions
    ADD CONSTRAINT customer_v2_shipment_document_versions_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_shipment_documents customer_v2_shipment_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipment_documents
    ADD CONSTRAINT customer_v2_shipment_documents_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_shipment_events customer_v2_shipment_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipment_events
    ADD CONSTRAINT customer_v2_shipment_events_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_shipment_sla_rules customer_v2_shipment_sla_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipment_sla_rules
    ADD CONSTRAINT customer_v2_shipment_sla_rules_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_shipment_sla_violations customer_v2_shipment_sla_violations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipment_sla_violations
    ADD CONSTRAINT customer_v2_shipment_sla_violations_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_shipment_status_logs customer_v2_shipment_status_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipment_status_logs
    ADD CONSTRAINT customer_v2_shipment_status_logs_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_shipment_stops customer_v2_shipment_stops_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipment_stops
    ADD CONSTRAINT customer_v2_shipment_stops_pkey PRIMARY KEY (id);


--
-- Name: customer_v2_shipments customer_v2_shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipments
    ADD CONSTRAINT customer_v2_shipments_pkey PRIMARY KEY (id);


--
-- Name: customers customers_api_key_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_api_key_key UNIQUE (api_key);


--
-- Name: customers customers_email_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_email_key UNIQUE (email);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: device_alerts device_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_alerts
    ADD CONSTRAINT device_alerts_pkey PRIMARY KEY (id);


--
-- Name: device_auth_tokens device_auth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_auth_tokens
    ADD CONSTRAINT device_auth_tokens_pkey PRIMARY KEY (device_id);


--
-- Name: device_commands device_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_commands
    ADD CONSTRAINT device_commands_pkey PRIMARY KEY (id);


--
-- Name: device_diagnostics_logs device_diagnostics_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_diagnostics_logs
    ADD CONSTRAINT device_diagnostics_logs_pkey PRIMARY KEY (id);


--
-- Name: device_firmware_status device_firmware_status_device_id_rollout_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_firmware_status
    ADD CONSTRAINT device_firmware_status_device_id_rollout_id_key UNIQUE (device_id, rollout_id);


--
-- Name: device_firmware_status device_firmware_status_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_firmware_status
    ADD CONSTRAINT device_firmware_status_pkey PRIMARY KEY (id);


--
-- Name: device_registry device_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_registry
    ADD CONSTRAINT device_registry_pkey PRIMARY KEY (device_id);


--
-- Name: device_telemetry device_telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_telemetry
    ADD CONSTRAINT device_telemetry_pkey PRIMARY KEY (id);


--
-- Name: device_twins device_twins_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_twins
    ADD CONSTRAINT device_twins_pkey PRIMARY KEY (device_id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: devices devices_serial_number_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_serial_number_key UNIQUE (serial_number);


--
-- Name: diagnostics_audit_logs diagnostics_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.diagnostics_audit_logs
    ADD CONSTRAINT diagnostics_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: dot_inspection_mode dot_inspection_mode_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dot_inspection_mode
    ADD CONSTRAINT dot_inspection_mode_org_id_key UNIQUE (org_id);


--
-- Name: dot_inspection_mode dot_inspection_mode_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dot_inspection_mode
    ADD CONSTRAINT dot_inspection_mode_pkey PRIMARY KEY (id);


--
-- Name: dot_inspections dot_inspections_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dot_inspections
    ADD CONSTRAINT dot_inspections_pkey PRIMARY KEY (id);


--
-- Name: dr_test_logs dr_test_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_test_logs
    ADD CONSTRAINT dr_test_logs_pkey PRIMARY KEY (id);


--
-- Name: dr_test_settings dr_test_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_test_settings
    ADD CONSTRAINT dr_test_settings_pkey PRIMARY KEY (id);


--
-- Name: dr_test_steps dr_test_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_test_steps
    ADD CONSTRAINT dr_test_steps_pkey PRIMARY KEY (id);


--
-- Name: dr_tests dr_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_tests
    ADD CONSTRAINT dr_tests_pkey PRIMARY KEY (id);


--
-- Name: dr_tests dr_tests_test_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_tests
    ADD CONSTRAINT dr_tests_test_id_key UNIQUE (test_id);


--
-- Name: driver_audit_logs driver_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_audit_logs
    ADD CONSTRAINT driver_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: driver_behavior_analytics driver_behavior_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_behavior_analytics
    ADD CONSTRAINT driver_behavior_analytics_pkey PRIMARY KEY (id);


--
-- Name: driver_behavior driver_behavior_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_behavior
    ADD CONSTRAINT driver_behavior_pkey PRIMARY KEY (id);


--
-- Name: driver_daily_stats driver_daily_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_daily_stats
    ADD CONSTRAINT driver_daily_stats_pkey PRIMARY KEY (driver_id, date);


--
-- Name: driver_expenses driver_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_expenses
    ADD CONSTRAINT driver_expenses_pkey PRIMARY KEY (id);


--
-- Name: driver_fuel_limits driver_fuel_limits_organization_id_driver_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_fuel_limits
    ADD CONSTRAINT driver_fuel_limits_organization_id_driver_id_key UNIQUE (organization_id, driver_id);


--
-- Name: driver_fuel_limits driver_fuel_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_fuel_limits
    ADD CONSTRAINT driver_fuel_limits_pkey PRIMARY KEY (id);


--
-- Name: driver_incidents driver_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_incidents
    ADD CONSTRAINT driver_incidents_pkey PRIMARY KEY (id);


--
-- Name: driver_messages driver_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_messages
    ADD CONSTRAINT driver_messages_pkey PRIMARY KEY (id);


--
-- Name: driver_mobile_sync_queue driver_mobile_sync_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_mobile_sync_queue
    ADD CONSTRAINT driver_mobile_sync_queue_pkey PRIMARY KEY (id);


--
-- Name: driver_onboarding_steps driver_onboarding_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_onboarding_steps
    ADD CONSTRAINT driver_onboarding_steps_pkey PRIMARY KEY (id);


--
-- Name: driver_payouts driver_payouts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_payouts
    ADD CONSTRAINT driver_payouts_pkey PRIMARY KEY (id);


--
-- Name: driver_ratings driver_ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_ratings
    ADD CONSTRAINT driver_ratings_pkey PRIMARY KEY (id);


--
-- Name: driver_risk_events driver_risk_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_risk_events
    ADD CONSTRAINT driver_risk_events_pkey PRIMARY KEY (id);


--
-- Name: driver_safety_events driver_safety_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_safety_events
    ADD CONSTRAINT driver_safety_events_pkey PRIMARY KEY (id);


--
-- Name: driver_salary driver_salary_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_salary
    ADD CONSTRAINT driver_salary_pkey PRIMARY KEY (id);


--
-- Name: driver_shift_assignments driver_shift_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_shift_assignments
    ADD CONSTRAINT driver_shift_assignments_pkey PRIMARY KEY (id);


--
-- Name: driver_shifts driver_shifts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_shifts
    ADD CONSTRAINT driver_shifts_pkey PRIMARY KEY (id);


--
-- Name: driver_training_modules driver_training_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_training_modules
    ADD CONSTRAINT driver_training_modules_pkey PRIMARY KEY (id);


--
-- Name: driver_training_records driver_training_records_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_training_records
    ADD CONSTRAINT driver_training_records_pkey PRIMARY KEY (id);


--
-- Name: driver_trip_earnings driver_trip_earnings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_trip_earnings
    ADD CONSTRAINT driver_trip_earnings_pkey PRIMARY KEY (id);


--
-- Name: driver_verifications driver_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_verifications
    ADD CONSTRAINT driver_verifications_pkey PRIMARY KEY (id);


--
-- Name: drivers drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pkey PRIMARY KEY (id);


--
-- Name: duty_status_logs duty_status_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.duty_status_logs
    ADD CONSTRAINT duty_status_logs_pkey PRIMARY KEY (id);


--
-- Name: e_way_bills e_way_bills_eway_bill_number_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.e_way_bills
    ADD CONSTRAINT e_way_bills_eway_bill_number_key UNIQUE (eway_bill_number);


--
-- Name: e_way_bills e_way_bills_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.e_way_bills
    ADD CONSTRAINT e_way_bills_pkey PRIMARY KEY (id);


--
-- Name: einvoice_config einvoice_config_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.einvoice_config
    ADD CONSTRAINT einvoice_config_org_id_key UNIQUE (org_id);


--
-- Name: einvoice_config einvoice_config_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.einvoice_config
    ADD CONSTRAINT einvoice_config_pkey PRIMARY KEY (id);


--
-- Name: einvoice_irn einvoice_irn_irn_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.einvoice_irn
    ADD CONSTRAINT einvoice_irn_irn_key UNIQUE (irn);


--
-- Name: einvoice_irn einvoice_irn_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.einvoice_irn
    ADD CONSTRAINT einvoice_irn_pkey PRIMARY KEY (id);


--
-- Name: einvoice_item_mapping einvoice_item_mapping_org_id_hsn_code_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.einvoice_item_mapping
    ADD CONSTRAINT einvoice_item_mapping_org_id_hsn_code_key UNIQUE (org_id, hsn_code);


--
-- Name: einvoice_item_mapping einvoice_item_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.einvoice_item_mapping
    ADD CONSTRAINT einvoice_item_mapping_pkey PRIMARY KEY (id);


--
-- Name: eld_diagnostic_events eld_diagnostic_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.eld_diagnostic_events
    ADD CONSTRAINT eld_diagnostic_events_pkey PRIMARY KEY (id);


--
-- Name: eld_malfunctions eld_malfunctions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.eld_malfunctions
    ADD CONSTRAINT eld_malfunctions_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_token_key UNIQUE (token);


--
-- Name: emergency_audit_log emergency_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_audit_log
    ADD CONSTRAINT emergency_audit_log_pkey PRIMARY KEY (id);


--
-- Name: emergency_commands emergency_commands_command_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_commands
    ADD CONSTRAINT emergency_commands_command_id_key UNIQUE (command_id);


--
-- Name: emergency_commands emergency_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_commands
    ADD CONSTRAINT emergency_commands_pkey PRIMARY KEY (id);


--
-- Name: emergency_contacts emergency_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_contacts
    ADD CONSTRAINT emergency_contacts_pkey PRIMARY KEY (id);


--
-- Name: emergency_escalations emergency_escalations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_escalations
    ADD CONSTRAINT emergency_escalations_pkey PRIMARY KEY (id);


--
-- Name: emergency_response_units emergency_response_units_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_response_units
    ADD CONSTRAINT emergency_response_units_pkey PRIMARY KEY (id);


--
-- Name: emergency_status emergency_status_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_status
    ADD CONSTRAINT emergency_status_pkey PRIMARY KEY (id);


--
-- Name: emergency_vehicle_state emergency_vehicle_state_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_vehicle_state
    ADD CONSTRAINT emergency_vehicle_state_pkey PRIMARY KEY (vehicle_id);


--
-- Name: entity_audit_history entity_audit_history_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.entity_audit_history
    ADD CONSTRAINT entity_audit_history_pkey PRIMARY KEY (id);


--
-- Name: erp_configs erp_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.erp_configs
    ADD CONSTRAINT erp_configs_pkey PRIMARY KEY (id);


--
-- Name: evidence_exports evidence_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.evidence_exports
    ADD CONSTRAINT evidence_exports_pkey PRIMARY KEY (id);


--
-- Name: expense_items expense_items_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.expense_items
    ADD CONSTRAINT expense_items_pkey PRIMARY KEY (id);


--
-- Name: expense_policies expense_policies_org_id_category_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.expense_policies
    ADD CONSTRAINT expense_policies_org_id_category_key UNIQUE (org_id, category);


--
-- Name: expense_policies expense_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.expense_policies
    ADD CONSTRAINT expense_policies_pkey PRIMARY KEY (id);


--
-- Name: expense_reports expense_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.expense_reports
    ADD CONSTRAINT expense_reports_pkey PRIMARY KEY (id);


--
-- Name: fastag_transactions fastag_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fastag_transactions
    ADD CONSTRAINT fastag_transactions_pkey PRIMARY KEY (id);


--
-- Name: fastag_transactions fastag_transactions_transaction_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fastag_transactions
    ADD CONSTRAINT fastag_transactions_transaction_id_key UNIQUE (transaction_id);


--
-- Name: feature_flags feature_flags_key_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_key_key UNIQUE (key);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (id);


--
-- Name: finance_audit_logs finance_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.finance_audit_logs
    ADD CONSTRAINT finance_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: finance_retention_policies finance_retention_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.finance_retention_policies
    ADD CONSTRAINT finance_retention_policies_pkey PRIMARY KEY (organization_id);


--
-- Name: firmware_packages firmware_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_packages
    ADD CONSTRAINT firmware_packages_pkey PRIMARY KEY (id);


--
-- Name: firmware_rollout_events firmware_rollout_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollout_events
    ADD CONSTRAINT firmware_rollout_events_pkey PRIMARY KEY (id);


--
-- Name: firmware_rollouts firmware_rollouts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_pkey PRIMARY KEY (id);


--
-- Name: fleet_analytics fleet_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fleet_analytics
    ADD CONSTRAINT fleet_analytics_pkey PRIMARY KEY (id);


--
-- Name: fleet_hourly_stats fleet_hourly_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fleet_hourly_stats
    ADD CONSTRAINT fleet_hourly_stats_pkey PRIMARY KEY (organization_id, "timestamp");


--
-- Name: fraud_incidents fraud_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fraud_incidents
    ADD CONSTRAINT fraud_incidents_pkey PRIMARY KEY (id);


--
-- Name: fuel_audit_logs fuel_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fuel_audit_logs
    ADD CONSTRAINT fuel_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: fuel_card_reconciliation fuel_card_reconciliation_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fuel_card_reconciliation
    ADD CONSTRAINT fuel_card_reconciliation_pkey PRIMARY KEY (id);


--
-- Name: fuel_card_transactions fuel_card_transactions_external_transaction_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fuel_card_transactions
    ADD CONSTRAINT fuel_card_transactions_external_transaction_id_key UNIQUE (external_transaction_id);


--
-- Name: fuel_card_transactions fuel_card_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fuel_card_transactions
    ADD CONSTRAINT fuel_card_transactions_pkey PRIMARY KEY (id);


--
-- Name: fuel_efficiency_history fuel_efficiency_history_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fuel_efficiency_history
    ADD CONSTRAINT fuel_efficiency_history_pkey PRIMARY KEY (id);


--
-- Name: fuel_logs fuel_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fuel_logs
    ADD CONSTRAINT fuel_logs_pkey PRIMARY KEY (id);


--
-- Name: fuel_settings fuel_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fuel_settings
    ADD CONSTRAINT fuel_settings_pkey PRIMARY KEY (organization_id);


--
-- Name: fuel_transactions fuel_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fuel_transactions
    ADD CONSTRAINT fuel_transactions_pkey PRIMARY KEY (id);


--
-- Name: fuel_vendors fuel_vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fuel_vendors
    ADD CONSTRAINT fuel_vendors_pkey PRIMARY KEY (id);


--
-- Name: geofence_assignments geofence_assignments_geofence_id_vehicle_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofence_assignments
    ADD CONSTRAINT geofence_assignments_geofence_id_vehicle_id_key UNIQUE (geofence_id, vehicle_id);


--
-- Name: geofence_assignments geofence_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofence_assignments
    ADD CONSTRAINT geofence_assignments_pkey PRIMARY KEY (id);


--
-- Name: geofences geofences_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofences
    ADD CONSTRAINT geofences_pkey PRIMARY KEY (id);


--
-- Name: global_notification_defaults global_notification_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.global_notification_defaults
    ADD CONSTRAINT global_notification_defaults_pkey PRIMARY KEY (id);


--
-- Name: governance_audit_logs governance_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_audit_logs
    ADD CONSTRAINT governance_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: governance_compliance_reports governance_compliance_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_compliance_reports
    ADD CONSTRAINT governance_compliance_reports_pkey PRIMARY KEY (id);


--
-- Name: governance_download_tokens governance_download_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_download_tokens
    ADD CONSTRAINT governance_download_tokens_pkey PRIMARY KEY (token);


--
-- Name: governance_export_lineage governance_export_lineage_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_export_lineage
    ADD CONSTRAINT governance_export_lineage_pkey PRIMARY KEY (id);


--
-- Name: governance_exports governance_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_exports
    ADD CONSTRAINT governance_exports_pkey PRIMARY KEY (id);


--
-- Name: governance_requests governance_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_requests
    ADD CONSTRAINT governance_requests_pkey PRIMARY KEY (id);


--
-- Name: governance_settings governance_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_settings
    ADD CONSTRAINT governance_settings_pkey PRIMARY KEY (organization_id);


--
-- Name: gps_locations gps_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.gps_locations
    ADD CONSTRAINT gps_locations_pkey PRIMARY KEY ("time", vehicle_id);


--
-- Name: gst_compliances gst_compliances_gstin_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.gst_compliances
    ADD CONSTRAINT gst_compliances_gstin_key UNIQUE (gstin);


--
-- Name: gst_compliances gst_compliances_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.gst_compliances
    ADD CONSTRAINT gst_compliances_pkey PRIMARY KEY (id);


--
-- Name: gst_invoices gst_invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.gst_invoices
    ADD CONSTRAINT gst_invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: gst_invoices gst_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.gst_invoices
    ADD CONSTRAINT gst_invoices_pkey PRIMARY KEY (id);


--
-- Name: health_alerts health_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.health_alerts
    ADD CONSTRAINT health_alerts_pkey PRIMARY KEY (id);


--
-- Name: health_history health_history_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.health_history
    ADD CONSTRAINT health_history_pkey PRIMARY KEY (id);


--
-- Name: historical_demand historical_demand_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.historical_demand
    ADD CONSTRAINT historical_demand_pkey PRIMARY KEY (id);


--
-- Name: historical_demand historical_demand_route_id_date_hour_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.historical_demand
    ADD CONSTRAINT historical_demand_route_id_date_hour_key UNIQUE (route_id, date, hour);


--
-- Name: hos_annotations hos_annotations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.hos_annotations
    ADD CONSTRAINT hos_annotations_pkey PRIMARY KEY (id);


--
-- Name: hos_daily_limits hos_daily_limits_driver_id_date_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.hos_daily_limits
    ADD CONSTRAINT hos_daily_limits_driver_id_date_key UNIQUE (driver_id, date);


--
-- Name: hos_daily_limits hos_daily_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.hos_daily_limits
    ADD CONSTRAINT hos_daily_limits_pkey PRIMARY KEY (id);


--
-- Name: id_mappings id_mappings_erp_config_id_entity_type_local_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.id_mappings
    ADD CONSTRAINT id_mappings_erp_config_id_entity_type_local_id_key UNIQUE (erp_config_id, entity_type, local_id);


--
-- Name: id_mappings id_mappings_erp_config_id_entity_type_remote_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.id_mappings
    ADD CONSTRAINT id_mappings_erp_config_id_entity_type_remote_id_key UNIQUE (erp_config_id, entity_type, remote_id);


--
-- Name: id_mappings id_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.id_mappings
    ADD CONSTRAINT id_mappings_pkey PRIMARY KEY (id);


--
-- Name: impersonation_sessions impersonation_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.impersonation_sessions
    ADD CONSTRAINT impersonation_sessions_pkey PRIMARY KEY (id);


--
-- Name: incident_comments incident_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_comments
    ADD CONSTRAINT incident_comments_pkey PRIMARY KEY (id);


--
-- Name: incident_logs incident_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_logs
    ADD CONSTRAINT incident_logs_pkey PRIMARY KEY (id);


--
-- Name: incident_media incident_media_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_media
    ADD CONSTRAINT incident_media_pkey PRIMARY KEY (id);


--
-- Name: incident_timeline incident_timeline_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_timeline
    ADD CONSTRAINT incident_timeline_pkey PRIMARY KEY (id);


--
-- Name: incident_updates incident_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_updates
    ADD CONSTRAINT incident_updates_pkey PRIMARY KEY (id);


--
-- Name: incident_vehicle_snapshot incident_vehicle_snapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_vehicle_snapshot
    ADD CONSTRAINT incident_vehicle_snapshot_pkey PRIMARY KEY (incident_id);


--
-- Name: incidents incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT incidents_pkey PRIMARY KEY (id);


--
-- Name: inspection_documents inspection_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.inspection_documents
    ADD CONSTRAINT inspection_documents_pkey PRIMARY KEY (id);


--
-- Name: inspection_templates inspection_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.inspection_templates
    ADD CONSTRAINT inspection_templates_pkey PRIMARY KEY (id);


--
-- Name: integration_configs integration_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integration_configs
    ADD CONSTRAINT integration_configs_pkey PRIMARY KEY (id);


--
-- Name: integration_logs integration_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);


--
-- Name: inventory_parts inventory_parts_organization_id_part_number_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.inventory_parts
    ADD CONSTRAINT inventory_parts_organization_id_part_number_key UNIQUE (organization_id, part_number);


--
-- Name: inventory_parts inventory_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.inventory_parts
    ADD CONSTRAINT inventory_parts_pkey PRIMARY KEY (id);


--
-- Name: invoice_approval_matrix invoice_approval_matrix_org_id_min_amount_max_amount_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_approval_matrix
    ADD CONSTRAINT invoice_approval_matrix_org_id_min_amount_max_amount_key UNIQUE (org_id, min_amount, max_amount);


--
-- Name: invoice_approval_matrix invoice_approval_matrix_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_approval_matrix
    ADD CONSTRAINT invoice_approval_matrix_pkey PRIMARY KEY (id);


--
-- Name: invoice_approval_policies invoice_approval_policies_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_approval_policies
    ADD CONSTRAINT invoice_approval_policies_org_id_name_key UNIQUE (org_id, name);


--
-- Name: invoice_approval_policies invoice_approval_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_approval_policies
    ADD CONSTRAINT invoice_approval_policies_pkey PRIMARY KEY (id);


--
-- Name: invoice_approvals invoice_approvals_invoice_id_approver_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_approvals
    ADD CONSTRAINT invoice_approvals_invoice_id_approver_id_key UNIQUE (invoice_id, approver_id);


--
-- Name: invoice_approvals invoice_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_approvals
    ADD CONSTRAINT invoice_approvals_pkey PRIMARY KEY (id);


--
-- Name: invoice_audit_log invoice_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_audit_log
    ADD CONSTRAINT invoice_audit_log_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoice_permissions invoice_permissions_org_id_role_name_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_permissions
    ADD CONSTRAINT invoice_permissions_org_id_role_name_key UNIQUE (org_id, role_name);


--
-- Name: invoice_permissions invoice_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_permissions
    ADD CONSTRAINT invoice_permissions_pkey PRIMARY KEY (id);


--
-- Name: invoice_sequence invoice_sequence_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_sequence
    ADD CONSTRAINT invoice_sequence_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: ip_rules ip_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.ip_rules
    ADD CONSTRAINT ip_rules_pkey PRIMARY KEY (id);


--
-- Name: legal_holds legal_holds_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.legal_holds
    ADD CONSTRAINT legal_holds_pkey PRIMARY KEY (id);


--
-- Name: local_permits local_permits_permit_number_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.local_permits
    ADD CONSTRAINT local_permits_permit_number_key UNIQUE (permit_number);


--
-- Name: local_permits local_permits_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.local_permits
    ADD CONSTRAINT local_permits_pkey PRIMARY KEY (id);


--
-- Name: localization_settings localization_settings_language_code_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.localization_settings
    ADD CONSTRAINT localization_settings_language_code_key UNIQUE (language_code);


--
-- Name: localization_settings localization_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.localization_settings
    ADD CONSTRAINT localization_settings_pkey PRIMARY KEY (id);


--
-- Name: login_events login_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.login_events
    ADD CONSTRAINT login_events_pkey PRIMARY KEY (id);


--
-- Name: login_history login_history_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_pkey PRIMARY KEY (id);


--
-- Name: maintenance_schedule maintenance_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.maintenance_schedule
    ADD CONSTRAINT maintenance_schedule_pkey PRIMARY KEY (vehicle_id);


--
-- Name: maintenance_settings maintenance_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.maintenance_settings
    ADD CONSTRAINT maintenance_settings_pkey PRIMARY KEY (organization_id);


--
-- Name: maintenance_vendors maintenance_vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.maintenance_vendors
    ADD CONSTRAINT maintenance_vendors_pkey PRIMARY KEY (id);


--
-- Name: maintenance_windows maintenance_windows_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.maintenance_windows
    ADD CONSTRAINT maintenance_windows_pkey PRIMARY KEY (id);


--
-- Name: materialized_fleet_reports materialized_fleet_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.materialized_fleet_reports
    ADD CONSTRAINT materialized_fleet_reports_pkey PRIMARY KEY (id);


--
-- Name: mfa_codes mfa_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_codes
    ADD CONSTRAINT mfa_codes_pkey PRIMARY KEY (id);


--
-- Name: mfa_events mfa_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_events
    ADD CONSTRAINT mfa_events_pkey PRIMARY KEY (id);


--
-- Name: mfa_exceptions mfa_exceptions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_pkey PRIMARY KEY (id);


--
-- Name: mfa_failures mfa_failures_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_failures
    ADD CONSTRAINT mfa_failures_pkey PRIMARY KEY (id);


--
-- Name: mfa_lockouts mfa_lockouts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_pkey PRIMARY KEY (id);


--
-- Name: mfa_org_overrides mfa_org_overrides_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_org_overrides
    ADD CONSTRAINT mfa_org_overrides_org_id_key UNIQUE (org_id);


--
-- Name: mfa_org_overrides mfa_org_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_org_overrides
    ADD CONSTRAINT mfa_org_overrides_pkey PRIMARY KEY (id);


--
-- Name: mfa_policies mfa_policies_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policies
    ADD CONSTRAINT mfa_policies_org_id_key UNIQUE (org_id);


--
-- Name: mfa_policies mfa_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policies
    ADD CONSTRAINT mfa_policies_pkey PRIMARY KEY (id);


--
-- Name: mfa_policy_history mfa_policy_history_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policy_history
    ADD CONSTRAINT mfa_policy_history_pkey PRIMARY KEY (id);


--
-- Name: mfa_recovery_codes mfa_recovery_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_recovery_codes
    ADD CONSTRAINT mfa_recovery_codes_pkey PRIMARY KEY (id);


--
-- Name: mfa_users mfa_users_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_users
    ADD CONSTRAINT mfa_users_pkey PRIMARY KEY (user_id);


--
-- Name: model_deployments model_deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.model_deployments
    ADD CONSTRAINT model_deployments_pkey PRIMARY KEY (id);


--
-- Name: model_predictions model_predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.model_predictions
    ADD CONSTRAINT model_predictions_pkey PRIMARY KEY (id);


--
-- Name: notification_channels notification_channels_channel_type_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_channels
    ADD CONSTRAINT notification_channels_channel_type_key UNIQUE (channel_type);


--
-- Name: notification_channels notification_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_channels
    ADD CONSTRAINT notification_channels_pkey PRIMARY KEY (id);


--
-- Name: notification_events notification_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_events
    ADD CONSTRAINT notification_events_pkey PRIMARY KEY (id);


--
-- Name: notification_logs notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_pkey PRIMARY KEY (id);


--
-- Name: notification_preference_audit notification_preference_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_preference_audit
    ADD CONSTRAINT notification_preference_audit_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_channel_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_channel_key UNIQUE (channel);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_client_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.oauth_clients
    ADD CONSTRAINT oauth_clients_client_id_key UNIQUE (client_id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: obd_readings obd_readings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.obd_readings
    ADD CONSTRAINT obd_readings_pkey PRIMARY KEY ("time", vehicle_id);


--
-- Name: oidc_providers oidc_providers_name_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.oidc_providers
    ADD CONSTRAINT oidc_providers_name_key UNIQUE (name);


--
-- Name: oidc_providers oidc_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.oidc_providers
    ADD CONSTRAINT oidc_providers_pkey PRIMARY KEY (id);


--
-- Name: org_budgets org_budgets_organization_id_category_period_start_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.org_budgets
    ADD CONSTRAINT org_budgets_organization_id_category_period_start_key UNIQUE (organization_id, category, period_start);


--
-- Name: org_budgets org_budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.org_budgets
    ADD CONSTRAINT org_budgets_pkey PRIMARY KEY (id);


--
-- Name: org_fuel_settings org_fuel_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.org_fuel_settings
    ADD CONSTRAINT org_fuel_settings_pkey PRIMARY KEY (organization_id);


--
-- Name: org_support_metrics org_support_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.org_support_metrics
    ADD CONSTRAINT org_support_metrics_pkey PRIMARY KEY (org_id);


--
-- Name: organization_memberships organization_memberships_org_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organization_memberships
    ADD CONSTRAINT organization_memberships_org_id_user_id_key UNIQUE (org_id, user_id);


--
-- Name: organization_memberships organization_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organization_memberships
    ADD CONSTRAINT organization_memberships_pkey PRIMARY KEY (id);


--
-- Name: organization_users organization_users_organization_id_email_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_organization_id_email_key UNIQUE (organization_id, email);


--
-- Name: organization_users organization_users_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_domain_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_domain_key UNIQUE (domain);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


--
-- Name: payment_records payment_records_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.payment_records
    ADD CONSTRAINT payment_records_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_role_id_resource_action_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_role_id_resource_action_key UNIQUE (role_id, resource, action);


--
-- Name: platform_settings platform_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_pkey PRIMARY KEY (id);


--
-- Name: prediction_results prediction_results_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.prediction_results
    ADD CONSTRAINT prediction_results_pkey PRIMARY KEY (id);


--
-- Name: predictive_maintenance_analytics predictive_maintenance_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.predictive_maintenance_analytics
    ADD CONSTRAINT predictive_maintenance_analytics_pkey PRIMARY KEY (id);


--
-- Name: predictive_models predictive_models_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.predictive_models
    ADD CONSTRAINT predictive_models_pkey PRIMARY KEY (id);


--
-- Name: pricing_rules pricing_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.pricing_rules
    ADD CONSTRAINT pricing_rules_pkey PRIMARY KEY (id);


--
-- Name: proof_of_delivery proof_of_delivery_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.proof_of_delivery
    ADD CONSTRAINT proof_of_delivery_pkey PRIMARY KEY (id);


--
-- Name: receipt_ocr_jobs receipt_ocr_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.receipt_ocr_jobs
    ADD CONSTRAINT receipt_ocr_jobs_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_key UNIQUE (token);


--
-- Name: restore_jobs restore_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.restore_jobs
    ADD CONSTRAINT restore_jobs_pkey PRIMARY KEY (id);


--
-- Name: review_items review_items_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: rollout_device_status rollout_device_status_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.rollout_device_status
    ADD CONSTRAINT rollout_device_status_pkey PRIMARY KEY (id);


--
-- Name: route_optimization_jobs route_optimization_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_jobs
    ADD CONSTRAINT route_optimization_jobs_pkey PRIMARY KEY (id);


--
-- Name: route_optimization_requests route_optimization_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_requests
    ADD CONSTRAINT route_optimization_requests_pkey PRIMARY KEY (id);


--
-- Name: route_optimization_results route_optimization_results_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_results
    ADD CONSTRAINT route_optimization_results_pkey PRIMARY KEY (id);


--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);


--
-- Name: security_history security_history_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.security_history
    ADD CONSTRAINT security_history_pkey PRIMARY KEY (id);


--
-- Name: service_accounts service_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.service_accounts
    ADD CONSTRAINT service_accounts_pkey PRIMARY KEY (id);


--
-- Name: settings_audit_logs settings_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.settings_audit_logs
    ADD CONSTRAINT settings_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (id);


--
-- Name: shipments shipments_tracking_number_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_tracking_number_key UNIQUE (tracking_number);


--
-- Name: signing_keys signing_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.signing_keys
    ADD CONSTRAINT signing_keys_pkey PRIMARY KEY (kid);


--
-- Name: sos_incidents sos_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.sos_incidents
    ADD CONSTRAINT sos_incidents_pkey PRIMARY KEY (id);


--
-- Name: storage_pools storage_pools_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.storage_pools
    ADD CONSTRAINT storage_pools_pkey PRIMARY KEY (id);


--
-- Name: support_audit_log support_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_audit_log
    ADD CONSTRAINT support_audit_log_pkey PRIMARY KEY (id);


--
-- Name: support_ticket_attachments support_ticket_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_ticket_attachments
    ADD CONSTRAINT support_ticket_attachments_pkey PRIMARY KEY (id);


--
-- Name: support_ticket_messages support_ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_ticket_messages
    ADD CONSTRAINT support_ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_ticket_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_ticket_id_key UNIQUE (ticket_id);


--
-- Name: sync_jobs sync_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.sync_jobs
    ADD CONSTRAINT sync_jobs_pkey PRIMARY KEY (id);


--
-- Name: system_audit_logs system_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.system_audit_logs
    ADD CONSTRAINT system_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: system_flags system_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.system_flags
    ADD CONSTRAINT system_flags_pkey PRIMARY KEY (key);


--
-- Name: system_limits system_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.system_limits
    ADD CONSTRAINT system_limits_pkey PRIMARY KEY (id);


--
-- Name: tds_records tds_records_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.tds_records
    ADD CONSTRAINT tds_records_pkey PRIMARY KEY (id);


--
-- Name: telemetry_analytics telemetry_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_analytics
    ADD CONSTRAINT telemetry_analytics_pkey PRIMARY KEY (id);


--
-- Name: telemetry_anomalies telemetry_anomalies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_anomalies
    ADD CONSTRAINT telemetry_anomalies_pkey PRIMARY KEY (id);


--
-- Name: telemetry_outbox telemetry_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_outbox
    ADD CONSTRAINT telemetry_outbox_pkey PRIMARY KEY (id);


--
-- Name: telemetry telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry
    ADD CONSTRAINT telemetry_pkey PRIMARY KEY (id);


--
-- Name: telemetry_points telemetry_points_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points
    ADD CONSTRAINT telemetry_points_pkey PRIMARY KEY (id, recorded_at);


--
-- Name: telemetry_points_y2026m01 telemetry_points_y2026m01_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points_y2026m01
    ADD CONSTRAINT telemetry_points_y2026m01_pkey PRIMARY KEY (id, recorded_at);


--
-- Name: telemetry_points_y2026m02 telemetry_points_y2026m02_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points_y2026m02
    ADD CONSTRAINT telemetry_points_y2026m02_pkey PRIMARY KEY (id, recorded_at);


--
-- Name: telemetry_points_y2026m03 telemetry_points_y2026m03_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points_y2026m03
    ADD CONSTRAINT telemetry_points_y2026m03_pkey PRIMARY KEY (id, recorded_at);


--
-- Name: telemetry_points_y2026m04 telemetry_points_y2026m04_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points_y2026m04
    ADD CONSTRAINT telemetry_points_y2026m04_pkey PRIMARY KEY (id, recorded_at);


--
-- Name: telemetry_points_y2026m05 telemetry_points_y2026m05_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points_y2026m05
    ADD CONSTRAINT telemetry_points_y2026m05_pkey PRIMARY KEY (id, recorded_at);


--
-- Name: telemetry_points_y2026m06 telemetry_points_y2026m06_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points_y2026m06
    ADD CONSTRAINT telemetry_points_y2026m06_pkey PRIMARY KEY (id, recorded_at);


--
-- Name: telemetry_points_y2026m07 telemetry_points_y2026m07_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points_y2026m07
    ADD CONSTRAINT telemetry_points_y2026m07_pkey PRIMARY KEY (id, recorded_at);


--
-- Name: telemetry_points_y2026m08 telemetry_points_y2026m08_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points_y2026m08
    ADD CONSTRAINT telemetry_points_y2026m08_pkey PRIMARY KEY (id, recorded_at);


--
-- Name: telemetry_points_y2026m09 telemetry_points_y2026m09_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points_y2026m09
    ADD CONSTRAINT telemetry_points_y2026m09_pkey PRIMARY KEY (id, recorded_at);


--
-- Name: telemetry_points_y2026m10 telemetry_points_y2026m10_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points_y2026m10
    ADD CONSTRAINT telemetry_points_y2026m10_pkey PRIMARY KEY (id, recorded_at);


--
-- Name: telemetry_points_y2026m11 telemetry_points_y2026m11_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points_y2026m11
    ADD CONSTRAINT telemetry_points_y2026m11_pkey PRIMARY KEY (id, recorded_at);


--
-- Name: telemetry_points_y2026m12 telemetry_points_y2026m12_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points_y2026m12
    ADD CONSTRAINT telemetry_points_y2026m12_pkey PRIMARY KEY (id, recorded_at);


--
-- Name: telemetry_points_y2027m01 telemetry_points_y2027m01_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry_points_y2027m01
    ADD CONSTRAINT telemetry_points_y2027m01_pkey PRIMARY KEY (id, recorded_at);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: templates templates_template_key_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_template_key_key UNIQUE (template_key);


--
-- Name: threat_alerts threat_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.threat_alerts
    ADD CONSTRAINT threat_alerts_pkey PRIMARY KEY (id);


--
-- Name: ticket_events ticket_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.ticket_events
    ADD CONSTRAINT ticket_events_pkey PRIMARY KEY (id);


--
-- Name: toll_transactions toll_transactions_external_transaction_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.toll_transactions
    ADD CONSTRAINT toll_transactions_external_transaction_id_key UNIQUE (external_transaction_id);


--
-- Name: toll_transactions toll_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.toll_transactions
    ADD CONSTRAINT toll_transactions_pkey PRIMARY KEY (id);


--
-- Name: tracking_config tracking_config_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.tracking_config
    ADD CONSTRAINT tracking_config_pkey PRIMARY KEY (id);


--
-- Name: tracking_config tracking_config_target_id_target_type_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.tracking_config
    ADD CONSTRAINT tracking_config_target_id_target_type_key UNIQUE (target_id, target_type);


--
-- Name: trip_profitability trip_profitability_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trip_profitability
    ADD CONSTRAINT trip_profitability_pkey PRIMARY KEY (id);


--
-- Name: trip_profitability trip_profitability_trip_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trip_profitability
    ADD CONSTRAINT trip_profitability_trip_id_key UNIQUE (trip_id);


--
-- Name: trip_settings trip_settings_organization_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trip_settings
    ADD CONSTRAINT trip_settings_organization_id_key UNIQUE (organization_id);


--
-- Name: trip_settings trip_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trip_settings
    ADD CONSTRAINT trip_settings_pkey PRIMARY KEY (id);


--
-- Name: trips trips_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_pkey PRIMARY KEY (id);


--
-- Name: driver_verifications unique_license_number; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_verifications
    ADD CONSTRAINT unique_license_number UNIQUE (license_number);


--
-- Name: integration_configs unique_org_service; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integration_configs
    ADD CONSTRAINT unique_org_service UNIQUE (organization_id, service_type);


--
-- Name: vehicle_verifications unique_registration; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_verifications
    ADD CONSTRAINT unique_registration UNIQUE (registration_number);


--
-- Name: maintenance_vendors unique_vendor_per_org; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.maintenance_vendors
    ADD CONSTRAINT unique_vendor_per_org UNIQUE (organization_id, name);


--
-- Name: drivers uq_drivers_aadhaar; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT uq_drivers_aadhaar UNIQUE (aadhaar_number);


--
-- Name: drivers uq_drivers_employee_code; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT uq_drivers_employee_code UNIQUE (org_id, employee_code);


--
-- Name: drivers uq_drivers_pan; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT uq_drivers_pan UNIQUE (pan_number);


--
-- Name: vehicles uq_vehicles_tenant_reg; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT uq_vehicles_tenant_reg UNIQUE (tenant_id, registration_number);


--
-- Name: usage_meters usage_meters_code_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.usage_meters
    ADD CONSTRAINT usage_meters_code_key UNIQUE (code);


--
-- Name: usage_meters usage_meters_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.usage_meters
    ADD CONSTRAINT usage_meters_pkey PRIMARY KEY (id);


--
-- Name: user_invoice_access user_invoice_access_org_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_invoice_access
    ADD CONSTRAINT user_invoice_access_org_id_user_id_key UNIQUE (org_id, user_id);


--
-- Name: user_invoice_access user_invoice_access_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_invoice_access
    ADD CONSTRAINT user_invoice_access_pkey PRIMARY KEY (id);


--
-- Name: user_notes user_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_notes
    ADD CONSTRAINT user_notes_pkey PRIMARY KEY (id);


--
-- Name: user_notification_preferences user_notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_notification_preferences user_notification_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_user_id_key UNIQUE (user_id);


--
-- Name: user_oidc_links user_oidc_links_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_oidc_links
    ADD CONSTRAINT user_oidc_links_pkey PRIMARY KEY (id);


--
-- Name: user_oidc_links user_oidc_links_provider_id_provider_user_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_oidc_links
    ADD CONSTRAINT user_oidc_links_provider_id_provider_user_id_key UNIQUE (provider_id, provider_user_id);


--
-- Name: user_organizations user_organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_pkey PRIMARY KEY (id);


--
-- Name: user_organizations user_organizations_user_id_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_user_id_org_id_key UNIQUE (user_id, org_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_session_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_session_id_key UNIQUE (session_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vehicle_assignments vehicle_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_assignments
    ADD CONSTRAINT vehicle_assignments_pkey PRIMARY KEY (id);


--
-- Name: vehicle_compliance vehicle_compliance_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_compliance
    ADD CONSTRAINT vehicle_compliance_pkey PRIMARY KEY (vehicle_id);


--
-- Name: vehicle_daily_stats vehicle_daily_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_daily_stats
    ADD CONSTRAINT vehicle_daily_stats_pkey PRIMARY KEY (vehicle_id, date);


--
-- Name: vehicle_events vehicle_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_events
    ADD CONSTRAINT vehicle_events_pkey PRIMARY KEY (id);


--
-- Name: vehicle_financials vehicle_financials_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_financials
    ADD CONSTRAINT vehicle_financials_pkey PRIMARY KEY (vehicle_id);


--
-- Name: vehicle_inspections vehicle_inspections_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_inspections
    ADD CONSTRAINT vehicle_inspections_pkey PRIMARY KEY (id);


--
-- Name: vehicle_specs vehicle_specs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_specs
    ADD CONSTRAINT vehicle_specs_pkey PRIMARY KEY (vehicle_id);


--
-- Name: vehicle_telemetry vehicle_telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_telemetry
    ADD CONSTRAINT vehicle_telemetry_pkey PRIMARY KEY ("time", vehicle_id);


--
-- Name: vehicle_verifications vehicle_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_verifications
    ADD CONSTRAINT vehicle_verifications_pkey PRIMARY KEY (id);


--
-- Name: vehicles_legacy vehicles_license_plate_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles_legacy
    ADD CONSTRAINT vehicles_license_plate_key UNIQUE (license_plate);


--
-- Name: vehicles_legacy vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles_legacy
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_pkey1; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey1 PRIMARY KEY (id);


--
-- Name: vehicles_legacy vehicles_vehicle_no_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles_legacy
    ADD CONSTRAINT vehicles_vehicle_no_key UNIQUE (vehicle_no);


--
-- Name: vendor_payments vendor_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vendor_payments
    ADD CONSTRAINT vendor_payments_pkey PRIMARY KEY (id);


--
-- Name: video_analytics video_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_analytics
    ADD CONSTRAINT video_analytics_pkey PRIMARY KEY (id);


--
-- Name: video_recordings video_recordings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_recordings
    ADD CONSTRAINT video_recordings_pkey PRIMARY KEY (id);


--
-- Name: video_retention_policies video_retention_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_retention_policies
    ADD CONSTRAINT video_retention_policies_pkey PRIMARY KEY (id);


--
-- Name: video_streams video_streams_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_streams
    ADD CONSTRAINT video_streams_pkey PRIMARY KEY (id);


--
-- Name: webhook_event_types webhook_event_types_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.webhook_event_types
    ADD CONSTRAINT webhook_event_types_pkey PRIMARY KEY (event_type);


--
-- Name: webhook_subscriptions webhook_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.webhook_subscriptions
    ADD CONSTRAINT webhook_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: work_order_parts work_order_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.work_order_parts
    ADD CONSTRAINT work_order_parts_pkey PRIMARY KEY (id);


--
-- Name: work_orders work_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT work_orders_pkey PRIMARY KEY (id);


--
-- Name: consumption_events_time_idx; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX consumption_events_time_idx ON public.consumption_events USING btree ("time" DESC);


--
-- Name: geofence_events_time_idx; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX geofence_events_time_idx ON public.geofence_events USING btree ("time" DESC);


--
-- Name: gps_locations_time_idx; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX gps_locations_time_idx ON public.gps_locations USING btree ("time" DESC);


--
-- Name: idx_access_reviews_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_access_reviews_org ON public.access_reviews USING btree (org_id);


--
-- Name: idx_access_reviews_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_access_reviews_status ON public.access_reviews USING btree (org_id, status);


--
-- Name: idx_accounting_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_accounting_org_id ON public.billing_accounting_exports USING btree (org_id);


--
-- Name: idx_accounting_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_accounting_status ON public.billing_accounting_exports USING btree (status);


--
-- Name: idx_admin_op_approvals_req_by; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_admin_op_approvals_req_by ON public.admin_operation_approvals USING btree (requested_by);


--
-- Name: idx_admin_op_approvals_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_admin_op_approvals_status ON public.admin_operation_approvals USING btree (status);


--
-- Name: idx_alerts_dedup_active; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_dedup_active ON public.alerts USING btree (dedup_key) WHERE ((status)::text = 'new'::text);


--
-- Name: idx_alerts_escalation_worker; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_escalation_worker ON public.alerts USING btree (status, sla_deadline) WHERE ((status)::text = 'new'::text);


--
-- Name: idx_alerts_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_org_id ON public.alerts USING btree (org_id);


--
-- Name: idx_alerts_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_status ON public.alerts USING btree (status);


--
-- Name: idx_alerts_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_timestamp ON public.alerts USING btree ("timestamp");


--
-- Name: idx_alerts_v2_logs_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_v2_logs_status ON public.alerts_v2_logs USING btree (status) WHERE ((status)::text = 'QUEUED'::text);


--
-- Name: idx_alerts_v2_logs_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_v2_logs_user_id ON public.alerts_v2_logs USING btree (user_id);


--
-- Name: idx_alerts_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_vehicle_id ON public.alerts USING btree (vehicle_id);


--
-- Name: idx_analytics_access_logs_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_analytics_access_logs_org ON public.analytics_access_logs USING btree (organization_id, created_at DESC);


--
-- Name: idx_analytics_access_logs_user; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_analytics_access_logs_user ON public.analytics_access_logs USING btree (user_id, created_at DESC);


--
-- Name: idx_analytics_jobs_dedup; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE UNIQUE INDEX idx_analytics_jobs_dedup ON public.analytics_jobs USING btree (organization_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: idx_analytics_jobs_org_status_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_analytics_jobs_org_status_time ON public.analytics_jobs USING btree (organization_id, status, created_at DESC);


--
-- Name: idx_analytics_jobs_org_status_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_analytics_jobs_org_status_type ON public.analytics_jobs USING btree (organization_id, status, job_type);


--
-- Name: idx_analytics_query_logs_org_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_analytics_query_logs_org_created ON public.analytics_query_logs USING btree (organization_id, created_at DESC);


--
-- Name: idx_analytics_query_logs_org_type_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_analytics_query_logs_org_type_time ON public.analytics_query_logs USING btree (organization_id, query_type, created_at DESC);


--
-- Name: idx_analytics_query_logs_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_analytics_query_logs_type ON public.analytics_query_logs USING btree (query_type);


--
-- Name: idx_api_clients_client_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_api_clients_client_id ON public.api_clients USING btree (client_id);


--
-- Name: idx_api_clients_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_api_clients_org ON public.api_clients USING btree (org_id);


--
-- Name: idx_api_keys_prefix; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_api_keys_prefix ON public.api_keys USING btree (prefix);


--
-- Name: idx_approval_configs_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_approval_configs_org ON public.approval_configs USING btree (organization_id);


--
-- Name: idx_approval_instances_entity; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_approval_instances_entity ON public.approval_instances USING btree (entity_id, entity_type);


--
-- Name: idx_assignments_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_assignments_vehicle ON public.vehicle_assignments USING btree (vehicle_id);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_created ON public.settings_audit_logs USING btree (created_at DESC);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: idx_audit_logs_entity; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_entity ON public.settings_audit_logs USING btree (entity_type, entity_id);


--
-- Name: idx_audit_logs_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_org_id ON public.audit_logs USING btree (org_id);


--
-- Name: idx_audit_logs_severity; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_severity ON public.audit_logs USING btree (severity);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_auth_tokens_refresh_token; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_auth_tokens_refresh_token ON public.auth_tokens USING btree (refresh_token);


--
-- Name: idx_auth_tokens_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_auth_tokens_user_id ON public.auth_tokens USING btree (user_id);


--
-- Name: idx_backup_verifications_backup_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_backup_verifications_backup_id ON public.backup_verifications USING btree (backup_id);


--
-- Name: idx_backup_verifications_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_backup_verifications_status ON public.backup_verifications USING btree (status);


--
-- Name: idx_backups_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_backups_created_at ON public.backups USING btree (created_at);


--
-- Name: idx_backups_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_backups_status ON public.backups USING btree (status);


--
-- Name: idx_bank_transactions_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_bank_transactions_date ON public.bank_transactions USING btree (transaction_date);


--
-- Name: idx_bank_transactions_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_bank_transactions_org_id ON public.bank_transactions USING btree (org_id);


--
-- Name: idx_bank_transactions_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_bank_transactions_status ON public.bank_transactions USING btree (status);


--
-- Name: idx_behavior_driver_period; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_behavior_driver_period ON public.driver_behavior USING btree (driver_id, period_start);


--
-- Name: idx_behavior_score_updates_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_behavior_score_updates_created ON public.behavior_score_updates USING btree (created_at DESC);


--
-- Name: idx_behavior_score_updates_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_behavior_score_updates_driver ON public.behavior_score_updates USING btree (driver_id);


--
-- Name: idx_billing_config_active; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_billing_config_active ON public.billing_configurations USING btree (is_active);


--
-- Name: idx_billing_config_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_billing_config_org_id ON public.billing_configurations USING btree (org_id);


--
-- Name: idx_billing_invoice_docs_snapshot; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_billing_invoice_docs_snapshot ON public.billing_invoice_documents USING gin (snapshot);


--
-- Name: idx_billing_plans_is_active; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_billing_plans_is_active ON public.billing_plans USING btree (is_active);


--
-- Name: idx_billing_pricing_components_plan_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_billing_pricing_components_plan_id ON public.billing_pricing_components USING btree (plan_id);


--
-- Name: idx_billing_subscriptions_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_billing_subscriptions_org_id ON public.billing_subscriptions USING btree (org_id);


--
-- Name: idx_billing_subscriptions_plan_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_billing_subscriptions_plan_id ON public.billing_subscriptions USING btree (plan_id);


--
-- Name: idx_billing_subscriptions_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_billing_subscriptions_status ON public.billing_subscriptions USING btree (status);


--
-- Name: idx_booking_requests_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_booking_requests_created ON public.booking_requests USING btree (created_at DESC);


--
-- Name: idx_booking_requests_customer_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_booking_requests_customer_id ON public.booking_requests USING btree (customer_id);


--
-- Name: idx_booking_requests_customer_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_booking_requests_customer_status ON public.booking_requests USING btree (customer_id, status);


--
-- Name: idx_booking_requests_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_booking_requests_status ON public.booking_requests USING btree (status);


--
-- Name: idx_bulk_job_records_job_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_bulk_job_records_job_id ON public.bulk_job_records USING btree (job_id);


--
-- Name: idx_bulk_jobs_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_bulk_jobs_org ON public.bulk_jobs USING btree (organization_id);


--
-- Name: idx_bulk_jobs_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_bulk_jobs_status ON public.bulk_jobs USING btree (status);


--
-- Name: idx_card_recon_card_tx; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_card_recon_card_tx ON public.fuel_card_reconciliation USING btree (card_transaction_id) WHERE (card_transaction_id IS NOT NULL);


--
-- Name: idx_card_recon_internal_tx; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_card_recon_internal_tx ON public.fuel_card_reconciliation USING btree (internal_transaction_id) WHERE (internal_transaction_id IS NOT NULL);


--
-- Name: idx_card_recon_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_card_recon_org ON public.fuel_card_reconciliation USING btree (org_id);


--
-- Name: idx_card_recon_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_card_recon_status ON public.fuel_card_reconciliation USING btree (status);


--
-- Name: idx_compliance_blacklisted; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_compliance_blacklisted ON public.vehicle_compliance USING btree (is_blacklisted) WHERE (is_blacklisted = true);


--
-- Name: idx_compliance_fitness_expiry; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_compliance_fitness_expiry ON public.vehicle_compliance USING btree (fitness_expiry_date) WHERE (fitness_expiry_date IS NOT NULL);


--
-- Name: idx_compliance_insurance_expiry; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_compliance_insurance_expiry ON public.vehicle_compliance USING btree (insurance_expiry_date) WHERE (insurance_expiry_date IS NOT NULL);


--
-- Name: idx_compliance_legal_hold; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_compliance_legal_hold ON public.vehicle_compliance USING btree (legal_hold) WHERE (legal_hold = true);


--
-- Name: idx_compliance_permit_expiry; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_compliance_permit_expiry ON public.vehicle_compliance USING btree (permit_expiry_date) WHERE (permit_expiry_date IS NOT NULL);


--
-- Name: idx_compliance_puc_expiry; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_compliance_puc_expiry ON public.vehicle_compliance USING btree (puc_expiry_date) WHERE (puc_expiry_date IS NOT NULL);


--
-- Name: idx_compliance_rc_expiry; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_compliance_rc_expiry ON public.vehicle_compliance USING btree (rc_expiry_date) WHERE (rc_expiry_date IS NOT NULL);


--
-- Name: idx_compliance_reviews_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_compliance_reviews_date ON public.compliance_reviews USING btree (review_date);


--
-- Name: idx_compliance_reviews_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_compliance_reviews_org ON public.compliance_reviews USING btree (org_id);


--
-- Name: idx_components_plan_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_components_plan_id ON public.billing_pricing_components USING btree (plan_id);


--
-- Name: idx_config_active; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_config_active ON public.integration_configs USING btree (active);


--
-- Name: idx_config_environment; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_config_environment ON public.integration_configs USING btree (environment);


--
-- Name: idx_config_organization_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_config_organization_id ON public.integration_configs USING btree (organization_id);


--
-- Name: idx_config_service_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_config_service_type ON public.integration_configs USING btree (service_type);


--
-- Name: idx_consumption_aggregation; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_consumption_aggregation ON public.consumption_events USING btree (org_id, meter_code, "time" DESC) WHERE (processed_invoice_id IS NULL);


--
-- Name: idx_coupons_code; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_coupons_code ON public.billing_coupons USING btree (code);


--
-- Name: idx_credit_txn_balance_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_credit_txn_balance_id ON public.billing_credit_transactions USING btree (balance_id);


--
-- Name: idx_currency_rates_code; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_currency_rates_code ON public.currency_rates USING btree (currency_code);


--
-- Name: idx_currency_rates_pair; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_currency_rates_pair ON public.currency_rates USING btree (from_currency, to_currency);


--
-- Name: idx_cust_v2_bookings_cust_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_cust_v2_bookings_cust_id ON public.customer_v2_booking_requests USING btree (customer_id);


--
-- Name: idx_cust_v2_cust_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_cust_v2_cust_org_id ON public.customer_v2_customers USING btree (organization_id);


--
-- Name: idx_cust_v2_events_shipment_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_cust_v2_events_shipment_id ON public.customer_v2_shipment_events USING btree (shipment_id);


--
-- Name: idx_cust_v2_shipments_cust_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_cust_v2_shipments_cust_id ON public.customer_v2_shipments USING btree (customer_id);


--
-- Name: idx_cust_v2_shipments_trip_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_cust_v2_shipments_trip_id ON public.customer_v2_shipments USING btree (trip_id);


--
-- Name: idx_cust_v2_users_cust_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_cust_v2_users_cust_id ON public.customer_v2_customer_users USING btree (customer_id);


--
-- Name: idx_customer_audit_log_action; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_customer_audit_log_action ON public.customer_audit_log USING btree (action);


--
-- Name: idx_customer_audit_log_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_customer_audit_log_created ON public.customer_audit_log USING btree (created_at);


--
-- Name: idx_customer_audit_log_entity; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_customer_audit_log_entity ON public.customer_audit_log USING btree (entity_type, entity_id);


--
-- Name: idx_customer_audit_log_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_customer_audit_log_org ON public.customer_audit_log USING btree (org_id);


--
-- Name: idx_customer_audit_log_user; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_customer_audit_log_user ON public.customer_audit_log USING btree (user_id);


--
-- Name: idx_customers_api_key; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_customers_api_key ON public.customers USING btree (api_key);


--
-- Name: idx_customers_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_customers_created ON public.customers USING btree (created_at DESC);


--
-- Name: idx_customers_email; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_customers_email ON public.customers USING btree (email);


--
-- Name: idx_customers_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_customers_org_id ON public.customers USING btree (org_id);


--
-- Name: idx_customers_org_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_customers_org_status ON public.customers USING btree (org_id, status);


--
-- Name: idx_customers_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_customers_status ON public.customers USING btree (status);


--
-- Name: idx_device_alerts_device_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_alerts_device_id ON public.device_alerts USING btree (device_id);


--
-- Name: idx_device_alerts_unresolved; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_alerts_unresolved ON public.device_alerts USING btree (alert_type) WHERE (resolved_at IS NULL);


--
-- Name: idx_device_commands_device; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_commands_device ON public.device_commands USING btree (device_id);


--
-- Name: idx_device_commands_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_commands_status ON public.device_commands USING btree (status);


--
-- Name: idx_device_diagnostics_logs_device; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_diagnostics_logs_device ON public.device_diagnostics_logs USING btree (device_id);


--
-- Name: idx_device_diagnostics_logs_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_diagnostics_logs_timestamp ON public.device_diagnostics_logs USING btree ("timestamp" DESC);


--
-- Name: idx_device_firmware_status_rollout; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_firmware_status_rollout ON public.device_firmware_status USING btree (rollout_id);


--
-- Name: idx_device_telemetry_device; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_telemetry_device ON public.device_telemetry USING btree (device_id);


--
-- Name: idx_device_telemetry_device_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_telemetry_device_timestamp ON public.device_telemetry USING btree (device_id, "timestamp");


--
-- Name: idx_device_telemetry_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_telemetry_timestamp ON public.device_telemetry USING btree ("timestamp" DESC);


--
-- Name: idx_device_twins_drift_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_twins_drift_status ON public.device_twins USING btree (drift_status);


--
-- Name: idx_device_twins_last_seen; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_twins_last_seen ON public.device_twins USING btree (last_seen DESC);


--
-- Name: idx_device_twins_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_twins_org ON public.device_twins USING btree (org_id);


--
-- Name: idx_devices_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_devices_org ON public.devices USING btree (org_id);


--
-- Name: idx_devices_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_devices_org_id ON public.devices USING btree (org_id);


--
-- Name: idx_devices_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_devices_vehicle_id ON public.devices USING btree (vehicle_id);


--
-- Name: idx_doc_invoice_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_doc_invoice_id ON public.billing_invoice_documents USING btree (invoice_id);


--
-- Name: idx_documents_expiry_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_expiry_date ON public.documents USING btree (expiry_date);


--
-- Name: idx_documents_org_expiry; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_org_expiry ON public.documents USING btree (org_id, expiry_date) WHERE ((deleted_at IS NULL) AND ((status)::text <> 'expired'::text));


--
-- Name: idx_documents_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_org_id ON public.documents USING btree (org_id);


--
-- Name: idx_documents_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_status ON public.documents USING btree (status);


--
-- Name: idx_documents_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_type ON public.documents USING btree (type);


--
-- Name: idx_documents_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_vehicle_id ON public.documents USING btree (vehicle_id);


--
-- Name: idx_documents_vehicle_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_vehicle_status ON public.documents USING btree (vehicle_id, status) WHERE (deleted_at IS NULL);


--
-- Name: idx_dot_inspections_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dot_inspections_date ON public.dot_inspections USING btree (inspection_date);


--
-- Name: idx_dot_inspections_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dot_inspections_driver ON public.dot_inspections USING btree (driver_id);


--
-- Name: idx_dot_inspections_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dot_inspections_status ON public.dot_inspections USING btree (overall_status);


--
-- Name: idx_dot_inspections_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dot_inspections_vehicle ON public.dot_inspections USING btree (vehicle_id);


--
-- Name: idx_dr_test_logs_test_id_ts; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dr_test_logs_test_id_ts ON public.dr_test_logs USING btree (test_id, ts DESC);


--
-- Name: idx_dr_test_steps_test_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dr_test_steps_test_id ON public.dr_test_steps USING btree (test_id, step_order);


--
-- Name: idx_dr_tests_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dr_tests_created_at ON public.dr_tests USING btree (created_at DESC);


--
-- Name: idx_dr_tests_scheduled_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dr_tests_scheduled_at ON public.dr_tests USING btree (scheduled_at);


--
-- Name: idx_dr_tests_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dr_tests_status ON public.dr_tests USING btree (status);


--
-- Name: idx_dreg_heartbeat; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dreg_heartbeat ON public.device_registry USING btree (last_heartbeat DESC) WHERE ((status)::text = 'active'::text);


--
-- Name: idx_dreg_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dreg_vehicle ON public.device_registry USING btree (vehicle_id) WHERE (vehicle_id IS NOT NULL);


--
-- Name: idx_driver_audit_logs_action; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_audit_logs_action ON public.driver_audit_logs USING btree (action);


--
-- Name: idx_driver_audit_logs_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_audit_logs_created ON public.driver_audit_logs USING btree (created_at DESC);


--
-- Name: idx_driver_audit_logs_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_audit_logs_driver ON public.driver_audit_logs USING btree (driver_id);


--
-- Name: idx_driver_audit_logs_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_audit_logs_org ON public.driver_audit_logs USING btree (org_id);


--
-- Name: idx_driver_audit_logs_user; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_audit_logs_user ON public.driver_audit_logs USING btree (user_id);


--
-- Name: idx_driver_behavior_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_behavior_driver ON public.driver_behavior_analytics USING btree (driver_id, analysis_period_start, analysis_period_end);


--
-- Name: idx_driver_behavior_org_dates; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_behavior_org_dates ON public.driver_behavior_analytics USING btree (organization_id, analysis_period_start, analysis_period_end);


--
-- Name: idx_driver_behavior_period; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_behavior_period ON public.driver_behavior USING btree (period_start, period_end);


--
-- Name: idx_driver_behavior_risk; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_behavior_risk ON public.driver_behavior USING btree (risk_level);


--
-- Name: idx_driver_daily_stats_org_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_daily_stats_org_date ON public.driver_daily_stats USING btree (organization_id, date);


--
-- Name: idx_driver_driver_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_driver_id ON public.driver_verifications USING btree (driver_id);


--
-- Name: idx_driver_expenses_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_expenses_driver ON public.driver_expenses USING btree (driver_id);


--
-- Name: idx_driver_expenses_driver_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_expenses_driver_id ON public.driver_expenses USING btree (driver_id);


--
-- Name: idx_driver_expenses_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_expenses_status ON public.driver_expenses USING btree (status);


--
-- Name: idx_driver_expenses_trip; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_expenses_trip ON public.driver_expenses USING btree (trip_id);


--
-- Name: idx_driver_expenses_trip_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_expenses_trip_id ON public.driver_expenses USING btree (trip_id);


--
-- Name: idx_driver_expenses_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_expenses_type ON public.driver_expenses USING btree (type);


--
-- Name: idx_driver_fuel_limits_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_fuel_limits_driver ON public.driver_fuel_limits USING btree (driver_id);


--
-- Name: idx_driver_incidents_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_incidents_driver ON public.driver_incidents USING btree (driver_id);


--
-- Name: idx_driver_incidents_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_incidents_timestamp ON public.driver_incidents USING btree ("timestamp" DESC);


--
-- Name: idx_driver_incidents_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_incidents_type ON public.driver_incidents USING btree (type);


--
-- Name: idx_driver_license_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_license_number ON public.driver_verifications USING btree (license_number);


--
-- Name: idx_driver_messages_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_messages_created ON public.driver_messages USING btree (created_at DESC);


--
-- Name: idx_driver_messages_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_messages_driver ON public.driver_messages USING btree (driver_id);


--
-- Name: idx_driver_messages_driver_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_messages_driver_id ON public.driver_messages USING btree (driver_id);


--
-- Name: idx_driver_messages_trip; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_messages_trip ON public.driver_messages USING btree (trip_id);


--
-- Name: idx_driver_messages_trip_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_messages_trip_id ON public.driver_messages USING btree (trip_id);


--
-- Name: idx_driver_organization_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_organization_id ON public.driver_verifications USING btree (organization_id);


--
-- Name: idx_driver_risk_events_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_risk_events_time ON public.driver_risk_events USING btree (driver_id, organization_id, event_time DESC);


--
-- Name: idx_driver_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_status ON public.driver_verifications USING btree (status);


--
-- Name: idx_driver_validity_to; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_driver_validity_to ON public.driver_verifications USING btree (validity_to);


--
-- Name: idx_drivers_aadhaar; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_aadhaar ON public.drivers USING btree (aadhaar_number);


--
-- Name: idx_drivers_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_created ON public.drivers USING btree (created_at DESC);


--
-- Name: idx_drivers_created_by; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_created_by ON public.drivers USING btree (created_by);


--
-- Name: idx_drivers_current_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_current_vehicle ON public.drivers USING btree (current_vehicle_id);


--
-- Name: idx_drivers_deleted; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_deleted ON public.drivers USING btree (deleted_at);


--
-- Name: idx_drivers_email; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_email ON public.drivers USING btree (email);


--
-- Name: idx_drivers_employee_code; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_employee_code ON public.drivers USING btree (employee_code);


--
-- Name: idx_drivers_license; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_license ON public.drivers USING btree (license_number);


--
-- Name: idx_drivers_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_org ON public.drivers USING btree (org_id);


--
-- Name: idx_drivers_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_org_id ON public.drivers USING btree (org_id);


--
-- Name: idx_drivers_org_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_org_status ON public.drivers USING btree (org_id, status);


--
-- Name: idx_drivers_pan; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_pan ON public.drivers USING btree (pan_number);


--
-- Name: idx_drivers_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_status ON public.drivers USING btree (status);


--
-- Name: idx_drivers_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_vehicle ON public.drivers USING btree (current_vehicle_id);


--
-- Name: idx_duty_status_logs_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_duty_status_logs_driver ON public.duty_status_logs USING btree (driver_id);


--
-- Name: idx_duty_status_logs_driver_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_duty_status_logs_driver_id ON public.duty_status_logs USING btree (driver_id);


--
-- Name: idx_duty_status_logs_is_edit; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_duty_status_logs_is_edit ON public.duty_status_logs USING btree (is_edit);


--
-- Name: idx_duty_status_logs_original; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_duty_status_logs_original ON public.duty_status_logs USING btree (original_log_id);


--
-- Name: idx_duty_status_logs_started; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_duty_status_logs_started ON public.duty_status_logs USING btree (started_at DESC);


--
-- Name: idx_duty_status_logs_started_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_duty_status_logs_started_at ON public.duty_status_logs USING btree (started_at);


--
-- Name: idx_duty_status_logs_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_duty_status_logs_status ON public.duty_status_logs USING btree (status);


--
-- Name: idx_earnings_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_earnings_driver ON public.driver_trip_earnings USING btree (driver_id);


--
-- Name: idx_einvoice_config_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_einvoice_config_org ON public.einvoice_config USING btree (org_id);


--
-- Name: idx_einvoice_irn_invoice; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_einvoice_irn_invoice ON public.einvoice_irn USING btree (invoice_id);


--
-- Name: idx_einvoice_irn_irn; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_einvoice_irn_irn ON public.einvoice_irn USING btree (irn);


--
-- Name: idx_einvoice_irn_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_einvoice_irn_org ON public.einvoice_irn USING btree (org_id);


--
-- Name: idx_einvoice_irn_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_einvoice_irn_status ON public.einvoice_irn USING btree (irn_status);


--
-- Name: idx_eld_malfunctions_detected; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_eld_malfunctions_detected ON public.eld_malfunctions USING btree (detected_at);


--
-- Name: idx_eld_malfunctions_reported; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_eld_malfunctions_reported ON public.eld_malfunctions USING btree (reported_to_fmcsa);


--
-- Name: idx_emergency_audit_log_command_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_emergency_audit_log_command_id ON public.emergency_audit_log USING btree (command_id);


--
-- Name: idx_emergency_audit_log_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_emergency_audit_log_created_at ON public.emergency_audit_log USING btree (created_at);


--
-- Name: idx_emergency_commands_command_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_emergency_commands_command_id ON public.emergency_commands USING btree (command_id);


--
-- Name: idx_emergency_commands_issued_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_emergency_commands_issued_at ON public.emergency_commands USING btree (issued_at);


--
-- Name: idx_emergency_commands_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_emergency_commands_status ON public.emergency_commands USING btree (status);


--
-- Name: idx_emergency_commands_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_emergency_commands_type ON public.emergency_commands USING btree (command_type);


--
-- Name: idx_emergency_contacts_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_emergency_contacts_org_id ON public.emergency_contacts USING btree (org_id);


--
-- Name: idx_entity_history_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_entity_history_id ON public.entity_audit_history USING btree (entity_id);


--
-- Name: idx_entity_history_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_entity_history_type ON public.entity_audit_history USING btree (entity_type);


--
-- Name: idx_eru_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_eru_org_id ON public.emergency_response_units USING btree (org_id);


--
-- Name: idx_escalations_incident_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_escalations_incident_id ON public.emergency_escalations USING btree (incident_id);


--
-- Name: idx_evs_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_evs_org_id ON public.emergency_vehicle_state USING btree (org_id);


--
-- Name: idx_eway_bill_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_eway_bill_number ON public.e_way_bills USING btree (eway_bill_number);


--
-- Name: idx_eway_cancelled; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_eway_cancelled ON public.e_way_bills USING btree (cancelled);


--
-- Name: idx_eway_generated_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_eway_generated_at ON public.e_way_bills USING btree (generated_at DESC);


--
-- Name: idx_eway_gstin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_eway_gstin ON public.e_way_bills USING btree (user_gstin);


--
-- Name: idx_eway_transporter; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_eway_transporter ON public.e_way_bills USING btree (transporter_id);


--
-- Name: idx_eway_valid_till; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_eway_valid_till ON public.e_way_bills USING btree (eway_bill_valid_till);


--
-- Name: idx_eway_vehicle_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_eway_vehicle_number ON public.e_way_bills USING btree (vehicle_number);


--
-- Name: idx_expense_items_category; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_expense_items_category ON public.expense_items USING btree (category);


--
-- Name: idx_expense_items_ocr_pending; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_expense_items_ocr_pending ON public.expense_items USING btree (ocr_processed, created_at);


--
-- Name: idx_expense_items_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_expense_items_org_id ON public.expense_items USING btree (org_id);


--
-- Name: idx_expense_items_report; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_expense_items_report ON public.expense_items USING btree (report_id);


--
-- Name: idx_expense_items_report_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_expense_items_report_id ON public.expense_items USING btree (report_id);


--
-- Name: idx_expense_reports_org_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_expense_reports_org_status ON public.expense_reports USING btree (org_id, status);


--
-- Name: idx_expense_reports_submitter; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_expense_reports_submitter ON public.expense_reports USING btree (submitter_id);


--
-- Name: idx_expense_reports_trip; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_expense_reports_trip ON public.expense_reports USING btree (trip_id);


--
-- Name: idx_fastag_organization_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fastag_organization_id ON public.fastag_transactions USING btree (organization_id);


--
-- Name: idx_fastag_reconciled; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fastag_reconciled ON public.fastag_transactions USING btree (reconciled);


--
-- Name: idx_fastag_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fastag_status ON public.fastag_transactions USING btree (status);


--
-- Name: idx_fastag_tag_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fastag_tag_number ON public.fastag_transactions USING btree (tag_number);


--
-- Name: idx_fastag_transaction_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fastag_transaction_date ON public.fastag_transactions USING btree (transaction_date);


--
-- Name: idx_fastag_transaction_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fastag_transaction_time ON public.fastag_transactions USING btree (transaction_time DESC);


--
-- Name: idx_fastag_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fastag_vehicle_id ON public.fastag_transactions USING btree (vehicle_id);


--
-- Name: idx_feature_flags_enabled; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_feature_flags_enabled ON public.feature_flags USING btree (enabled);


--
-- Name: idx_feature_flags_key; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_feature_flags_key ON public.feature_flags USING btree (key);


--
-- Name: idx_finance_audit_entity; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_finance_audit_entity ON public.finance_audit_logs USING btree (entity_id, entity_type);


--
-- Name: idx_finance_audit_logs_entity; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_finance_audit_logs_entity ON public.finance_audit_logs USING btree (entity_id, entity_type);


--
-- Name: idx_finance_audit_logs_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_finance_audit_logs_org_id ON public.finance_audit_logs USING btree (org_id);


--
-- Name: idx_finance_audit_logs_ts; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_finance_audit_logs_ts ON public.finance_audit_logs USING btree ("timestamp");


--
-- Name: idx_finance_audit_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_finance_audit_org ON public.finance_audit_logs USING btree (org_id);


--
-- Name: idx_finance_audit_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_finance_audit_time ON public.finance_audit_logs USING btree ("timestamp");


--
-- Name: idx_finance_dashboard_metrics_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE UNIQUE INDEX idx_finance_dashboard_metrics_org ON public.finance_dashboard_metrics USING btree (org_id);


--
-- Name: idx_finance_summary_org_month; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE UNIQUE INDEX idx_finance_summary_org_month ON public.finance_dashboard_summary USING btree (org_id, month);


--
-- Name: idx_firmware_rollout_events_org_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_firmware_rollout_events_org_created ON public.firmware_rollout_events USING btree (org_id, created_at DESC);


--
-- Name: idx_firmware_rollout_events_rollout_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_firmware_rollout_events_rollout_created ON public.firmware_rollout_events USING btree (rollout_id, created_at DESC);


--
-- Name: idx_firmware_rollouts_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_firmware_rollouts_org ON public.firmware_rollouts USING btree (org_id);


--
-- Name: idx_firmware_rollouts_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_firmware_rollouts_status ON public.firmware_rollouts USING btree (status);


--
-- Name: idx_fleet_analytics_org_dates; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fleet_analytics_org_dates ON public.fleet_analytics USING btree (organization_id, start_date, end_date);


--
-- Name: idx_fleet_hourly_stats_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fleet_hourly_stats_timestamp ON public.fleet_hourly_stats USING btree ("timestamp");


--
-- Name: idx_fraud_incidents_entity; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fraud_incidents_entity ON public.fraud_incidents USING btree (entity_type, entity_id);


--
-- Name: idx_fraud_incidents_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fraud_incidents_org ON public.fraud_incidents USING btree (org_id);


--
-- Name: idx_fraud_incidents_risk; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fraud_incidents_risk ON public.fraud_incidents USING btree (risk_level, status);


--
-- Name: idx_fraud_incidents_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fraud_incidents_vehicle ON public.fraud_incidents USING btree (vehicle_id) WHERE (vehicle_id IS NOT NULL);


--
-- Name: idx_fuel_audit_log_action; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_audit_log_action ON public.fuel_audit_logs USING btree (action);


--
-- Name: idx_fuel_audit_log_changed_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_audit_log_changed_at ON public.fuel_audit_logs USING btree (changed_at);


--
-- Name: idx_fuel_audit_log_fuel_log; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_audit_log_fuel_log ON public.fuel_audit_logs USING btree (fuel_log_id);


--
-- Name: idx_fuel_audit_logs_organization_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_audit_logs_organization_id ON public.fuel_audit_logs USING btree (organization_id);


--
-- Name: idx_fuel_card_reconciliation_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_card_reconciliation_org_id ON public.fuel_card_reconciliation USING btree (org_id);


--
-- Name: idx_fuel_card_reconciliation_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_card_reconciliation_status ON public.fuel_card_reconciliation USING btree (status);


--
-- Name: idx_fuel_card_tx_card_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_card_tx_card_id ON public.fuel_card_transactions USING btree (card_id);


--
-- Name: idx_fuel_card_tx_provider; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_card_tx_provider ON public.fuel_card_transactions USING btree (provider);


--
-- Name: idx_fuel_card_tx_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_card_tx_time ON public.fuel_card_transactions USING btree (transaction_time);


--
-- Name: idx_fuel_card_tx_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_card_tx_vehicle_id ON public.fuel_card_transactions USING btree (vehicle_id);


--
-- Name: idx_fuel_eff_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_eff_date ON public.fuel_efficiency_history USING btree (recorded_at);


--
-- Name: idx_fuel_eff_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_eff_vehicle ON public.fuel_efficiency_history USING btree (vehicle_id);


--
-- Name: idx_fuel_logs_anomaly; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_logs_anomaly ON public.fuel_logs USING btree (anomaly_flag) WHERE (anomaly_flag = true);


--
-- Name: idx_fuel_logs_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_logs_driver ON public.fuel_logs USING btree (driver_id);


--
-- Name: idx_fuel_logs_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_logs_org ON public.fuel_logs USING btree (organization_id);


--
-- Name: idx_fuel_logs_org_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_logs_org_status ON public.fuel_logs USING btree (organization_id, status);


--
-- Name: idx_fuel_logs_org_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_logs_org_vehicle ON public.fuel_logs USING btree (organization_id, vehicle_id);


--
-- Name: idx_fuel_logs_organization_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_logs_organization_id ON public.fuel_logs USING btree (organization_id);


--
-- Name: idx_fuel_logs_risk_level; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_logs_risk_level ON public.fuel_logs USING btree (risk_level);


--
-- Name: idx_fuel_logs_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_logs_status ON public.fuel_logs USING btree (status);


--
-- Name: idx_fuel_logs_transaction_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_logs_transaction_date ON public.fuel_logs USING btree (transaction_date);


--
-- Name: idx_fuel_logs_trip; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_logs_trip ON public.fuel_logs USING btree (trip_id);


--
-- Name: idx_fuel_logs_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_logs_vehicle ON public.fuel_logs USING btree (vehicle_id);


--
-- Name: idx_fuel_transactions_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_transactions_date ON public.fuel_transactions USING btree (transaction_date);


--
-- Name: idx_fuel_transactions_organization_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_transactions_organization_id ON public.fuel_transactions USING btree (organization_id);


--
-- Name: idx_fuel_transactions_risk_level; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_transactions_risk_level ON public.fuel_transactions USING btree (risk_level);


--
-- Name: idx_fuel_transactions_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_transactions_vehicle ON public.fuel_transactions USING btree (vehicle_id);


--
-- Name: idx_fuel_vendors_gstin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_vendors_gstin ON public.fuel_vendors USING btree (gstin);


--
-- Name: idx_fuel_vendors_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_fuel_vendors_org ON public.fuel_vendors USING btree (organization_id);


--
-- Name: idx_geofence_assignments_active; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_geofence_assignments_active ON public.geofence_assignments USING btree (is_active);


--
-- Name: idx_geofence_assignments_geofence; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_geofence_assignments_geofence ON public.geofence_assignments USING btree (geofence_id);


--
-- Name: idx_geofence_assignments_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_geofence_assignments_vehicle ON public.geofence_assignments USING btree (vehicle_id);


--
-- Name: idx_geofence_events_geofence_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_geofence_events_geofence_time ON public.geofence_events USING btree (geofence_id, "time" DESC);


--
-- Name: idx_geofence_events_type_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_geofence_events_type_time ON public.geofence_events USING btree (event_type, "time" DESC);


--
-- Name: idx_geofence_events_vehicle_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_geofence_events_vehicle_time ON public.geofence_events USING btree (vehicle_id, "time" DESC);


--
-- Name: idx_geofences_enabled; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_geofences_enabled ON public.geofences USING btree (enabled);


--
-- Name: idx_geofences_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_geofences_org ON public.geofences USING btree (org_id);


--
-- Name: idx_geofences_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_geofences_type ON public.geofences USING btree (type);


--
-- Name: idx_governance_audit_action; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_governance_audit_action ON public.governance_audit_logs USING btree (action);


--
-- Name: idx_governance_audit_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_governance_audit_created_at ON public.governance_audit_logs USING btree (created_at DESC);


--
-- Name: idx_governance_audit_module; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_governance_audit_module ON public.governance_audit_logs USING btree (module);


--
-- Name: idx_governance_audit_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_governance_audit_org_id ON public.governance_audit_logs USING btree (organization_id);


--
-- Name: idx_governance_audit_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_governance_audit_user_id ON public.governance_audit_logs USING btree (user_id);


--
-- Name: idx_governance_download_tokens_export; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_governance_download_tokens_export ON public.governance_download_tokens USING btree (export_id);


--
-- Name: idx_governance_exports_request; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_governance_exports_request ON public.governance_exports USING btree (request_id);


--
-- Name: idx_governance_requests_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_governance_requests_created_at ON public.governance_requests USING btree (created_at DESC);


--
-- Name: idx_governance_requests_expiry; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_governance_requests_expiry ON public.governance_requests USING btree (expiry_date) WHERE (status = 'APPROVED'::public.governance_request_status);


--
-- Name: idx_governance_requests_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_governance_requests_org_id ON public.governance_requests USING btree (organization_id);


--
-- Name: idx_governance_requests_requester; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_governance_requests_requester ON public.governance_requests USING btree (requester_id);


--
-- Name: idx_governance_requests_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_governance_requests_status ON public.governance_requests USING btree (status);


--
-- Name: idx_governance_requests_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_governance_requests_type ON public.governance_requests USING btree (request_type);


--
-- Name: idx_gps_locations_vehicle_time_desc; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gps_locations_vehicle_time_desc ON public.gps_locations USING btree (vehicle_id, "time" DESC);


--
-- Name: idx_gps_raw_data_gin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gps_raw_data_gin ON public.gps_locations USING gin (raw_data);


--
-- Name: idx_gps_vehicle_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gps_vehicle_time ON public.gps_locations USING btree (vehicle_id, "time" DESC);


--
-- Name: idx_gps_vehicle_time_brin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gps_vehicle_time_brin ON public.gps_locations USING brin (vehicle_id, "time");


--
-- Name: idx_gst_gstin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gst_gstin ON public.gst_compliances USING btree (gstin);


--
-- Name: idx_gst_invoices_entity; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gst_invoices_entity ON public.gst_invoices USING btree (entity_type, entity_id);


--
-- Name: idx_gst_invoices_irn; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gst_invoices_irn ON public.gst_invoices USING btree (irn) WHERE (irn IS NOT NULL);


--
-- Name: idx_gst_invoices_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gst_invoices_org ON public.gst_invoices USING btree (org_id);


--
-- Name: idx_gst_invoices_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gst_invoices_org_id ON public.gst_invoices USING btree (org_id);


--
-- Name: idx_gst_invoices_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gst_invoices_status ON public.gst_invoices USING btree (status);


--
-- Name: idx_gst_organization_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gst_organization_id ON public.gst_compliances USING btree (organization_id);


--
-- Name: idx_gst_return_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gst_return_status ON public.gst_compliances USING btree (return_filing_status);


--
-- Name: idx_gst_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_gst_status ON public.gst_compliances USING btree (status);


--
-- Name: idx_health_alerts_component; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_health_alerts_component ON public.health_alerts USING btree (component);


--
-- Name: idx_health_alerts_severity; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_health_alerts_severity ON public.health_alerts USING btree (severity);


--
-- Name: idx_health_alerts_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_health_alerts_status ON public.health_alerts USING btree (status);


--
-- Name: idx_health_alerts_triggered_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_health_alerts_triggered_at ON public.health_alerts USING btree (triggered_at DESC);


--
-- Name: idx_health_history_component; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_health_history_component ON public.health_history USING btree (component);


--
-- Name: idx_health_history_component_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_health_history_component_timestamp ON public.health_history USING btree (component, "timestamp" DESC);


--
-- Name: idx_health_history_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_health_history_timestamp ON public.health_history USING btree ("timestamp");


--
-- Name: idx_id_mappings_local; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_id_mappings_local ON public.id_mappings USING btree (local_id);


--
-- Name: idx_id_mappings_remote; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_id_mappings_remote ON public.id_mappings USING btree (remote_id);


--
-- Name: idx_incident_comments_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_incident_comments_created_at ON public.incident_comments USING btree (created_at);


--
-- Name: idx_incident_comments_ticket_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_incident_comments_ticket_id ON public.incident_comments USING btree (ticket_id);


--
-- Name: idx_incident_logs_incident_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_incident_logs_incident_id ON public.incident_logs USING btree (incident_id);


--
-- Name: idx_incident_media_incident_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_incident_media_incident_id ON public.incident_media USING btree (incident_id);


--
-- Name: idx_incident_timeline_incident_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_incident_timeline_incident_id ON public.incident_timeline USING btree (incident_id);


--
-- Name: idx_incidents_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_incidents_driver ON public.driver_incidents USING btree (driver_id);


--
-- Name: idx_inspection_templates_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_inspection_templates_org ON public.inspection_templates USING btree (organization_id);


--
-- Name: idx_inspections_created_by; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_inspections_created_by ON public.vehicle_inspections USING btree (created_by);


--
-- Name: idx_integration_logs_integration; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_logs_integration ON public.integration_logs USING btree (integration_id);


--
-- Name: idx_integration_logs_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_logs_org ON public.integration_logs USING btree (org_id);


--
-- Name: idx_integration_logs_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_logs_timestamp ON public.integration_logs USING btree ("timestamp" DESC);


--
-- Name: idx_integrations_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integrations_org ON public.integrations USING btree (org_id);


--
-- Name: idx_integrations_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integrations_status ON public.integrations USING btree (status);


--
-- Name: idx_inventory_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_inventory_org ON public.inventory_parts USING btree (organization_id);


--
-- Name: idx_invoice_approval_matrix_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_approval_matrix_org ON public.invoice_approval_matrix USING btree (org_id);


--
-- Name: idx_invoice_approval_policies_active; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_approval_policies_active ON public.invoice_approval_policies USING btree (is_active);


--
-- Name: idx_invoice_approval_policies_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_approval_policies_org ON public.invoice_approval_policies USING btree (org_id);


--
-- Name: idx_invoice_approvals_approver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_approvals_approver ON public.invoice_approvals USING btree (approver_id);


--
-- Name: idx_invoice_approvals_invoice; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_approvals_invoice ON public.invoice_approvals USING btree (invoice_id);


--
-- Name: idx_invoice_approvals_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_approvals_status ON public.invoice_approvals USING btree (approval_status);


--
-- Name: idx_invoice_audit_log_action; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_audit_log_action ON public.invoice_audit_log USING btree (action);


--
-- Name: idx_invoice_audit_log_changed_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_audit_log_changed_at ON public.invoice_audit_log USING btree (changed_at);


--
-- Name: idx_invoice_audit_log_changed_by; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_audit_log_changed_by ON public.invoice_audit_log USING btree (changed_by);


--
-- Name: idx_invoice_audit_log_invoice_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_audit_log_invoice_id ON public.invoice_audit_log USING btree (invoice_id);


--
-- Name: idx_invoice_items_invoice_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_items_invoice_id ON public.invoice_items USING btree (invoice_id);


--
-- Name: idx_invoice_items_org_deleted; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_items_org_deleted ON public.invoice_items USING btree (org_id, is_deleted);


--
-- Name: idx_invoice_permissions_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoice_permissions_org ON public.invoice_permissions USING btree (org_id);


--
-- Name: idx_invoices_approval_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoices_approval_status ON public.invoices USING btree (approval_status);


--
-- Name: idx_invoices_deleted_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoices_deleted_at ON public.invoices USING btree (deleted_at);


--
-- Name: idx_invoices_discount; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoices_discount ON public.invoices USING btree (discount_type, discount_value);


--
-- Name: idx_invoices_due_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoices_due_date ON public.invoices USING btree (due_date);


--
-- Name: idx_invoices_due_date_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoices_due_date_status ON public.invoices USING btree (due_date, status) WHERE (status = ANY (ARRAY['issued'::text, 'overdue'::text]));


--
-- Name: idx_invoices_invoice_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoices_invoice_date ON public.invoices USING btree (invoice_date);


--
-- Name: idx_invoices_invoice_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoices_invoice_number ON public.invoices USING btree (invoice_number);


--
-- Name: idx_invoices_org_deleted; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoices_org_deleted ON public.invoices USING btree (org_id, is_deleted);


--
-- Name: idx_invoices_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoices_org_id ON public.invoices USING btree (org_id);


--
-- Name: idx_invoices_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoices_status ON public.invoices USING btree (status);


--
-- Name: idx_invoices_subscription_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_invoices_subscription_id ON public.invoices USING btree (subscription_id);


--
-- Name: idx_ip_rules_action; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_ip_rules_action ON public.ip_rules USING btree (org_id, action);


--
-- Name: idx_ip_rules_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_ip_rules_org ON public.ip_rules USING btree (org_id);


--
-- Name: idx_legal_holds_entity; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_legal_holds_entity ON public.legal_holds USING btree (entity_type, entity_id);


--
-- Name: idx_localization_settings_code; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_localization_settings_code ON public.localization_settings USING btree (language_code);


--
-- Name: idx_login_events_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_login_events_created_at ON public.login_events USING btree (created_at);


--
-- Name: idx_login_events_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_login_events_org_id ON public.login_events USING btree (org_id);


--
-- Name: idx_login_events_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_login_events_status ON public.login_events USING btree (status);


--
-- Name: idx_login_events_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_login_events_user_id ON public.login_events USING btree (user_id);


--
-- Name: idx_maint_next_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_maint_next_date ON public.maintenance_schedule USING btree (next_service_date) WHERE (next_service_date IS NOT NULL);


--
-- Name: idx_maint_pred_score; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_maint_pred_score ON public.maintenance_schedule USING btree (predictive_score DESC) WHERE (predictive_score IS NOT NULL);


--
-- Name: idx_maintenance_vendors_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_maintenance_vendors_org ON public.maintenance_vendors USING btree (organization_id);


--
-- Name: idx_materialized_fleet_reports_unique; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE UNIQUE INDEX idx_materialized_fleet_reports_unique ON public.materialized_fleet_reports USING btree (organization_id, report_type, metric_key, period);


--
-- Name: idx_mfa_codes_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_codes_user_id ON public.mfa_codes USING btree (user_id);


--
-- Name: idx_mfa_events_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_events_created_at ON public.mfa_events USING btree (created_at);


--
-- Name: idx_mfa_events_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_events_org_id ON public.mfa_events USING btree (org_id);


--
-- Name: idx_mfa_events_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_events_user_id ON public.mfa_events USING btree (user_id);


--
-- Name: idx_mfa_exceptions_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_exceptions_user_id ON public.mfa_exceptions USING btree (user_id);


--
-- Name: idx_mfa_failures_location; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_failures_location ON public.mfa_failures USING btree (location);


--
-- Name: idx_mfa_failures_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_failures_user_id ON public.mfa_failures USING btree (user_id);


--
-- Name: idx_mfa_lockouts_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_lockouts_user_id ON public.mfa_lockouts USING btree (user_id);


--
-- Name: idx_mfa_org_overrides_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_org_overrides_org_id ON public.mfa_org_overrides USING btree (org_id);


--
-- Name: idx_mfa_policy_history_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_policy_history_org_id ON public.mfa_policy_history USING btree (org_id);


--
-- Name: idx_model_deployments_active; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_model_deployments_active ON public.model_deployments USING btree (organization_id, model_id) WHERE (is_active = true);


--
-- Name: idx_notification_channels_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_notification_channels_type ON public.notification_channels USING btree (channel_type);


--
-- Name: idx_notification_events_notification_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_notification_events_notification_id ON public.notification_events USING btree (notification_id, created_at);


--
-- Name: idx_notification_logs_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_notification_logs_created_at ON public.notification_logs USING btree (created_at DESC);


--
-- Name: idx_notification_logs_status_channel; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_notification_logs_status_channel ON public.notification_logs USING btree (status, channel);


--
-- Name: idx_notification_pref_audit_user; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_notification_pref_audit_user ON public.notification_preference_audit USING btree (user_id, created_at DESC);


--
-- Name: idx_obd_dtcs_gin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_obd_dtcs_gin ON public.obd_readings USING gin (dtcs);


--
-- Name: idx_obd_raw_data_gin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_obd_raw_data_gin ON public.obd_readings USING gin (raw_data);


--
-- Name: idx_obd_vehicle_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_obd_vehicle_time ON public.obd_readings USING btree (vehicle_id, "time" DESC);


--
-- Name: idx_obd_vehicle_time_brin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_obd_vehicle_time_brin ON public.obd_readings USING brin (vehicle_id, "time");


--
-- Name: idx_onboarding_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_onboarding_driver ON public.driver_onboarding_steps USING btree (driver_id);


--
-- Name: idx_org_budgets_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_org_budgets_org ON public.org_budgets USING btree (organization_id);


--
-- Name: idx_org_budgets_period; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_org_budgets_period ON public.org_budgets USING btree (period_start, period_end);


--
-- Name: idx_org_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_org_created ON public.organizations USING btree (created_at);


--
-- Name: idx_org_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_org_status ON public.organizations USING btree (status);


--
-- Name: idx_password_reset_tokens_expires_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_password_reset_tokens_expires_at ON public.password_reset_tokens USING btree (expires_at);


--
-- Name: idx_password_reset_tokens_token; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_password_reset_tokens_token ON public.password_reset_tokens USING btree (token);


--
-- Name: idx_password_reset_tokens_used; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_password_reset_tokens_used ON public.password_reset_tokens USING btree (used);


--
-- Name: idx_password_reset_tokens_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_password_reset_tokens_user_id ON public.password_reset_tokens USING btree (user_id);


--
-- Name: idx_payment_records_invoice_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_payment_records_invoice_id ON public.payment_records USING btree (invoice_id);


--
-- Name: idx_payment_records_payment_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_payment_records_payment_date ON public.payment_records USING btree (payment_date);


--
-- Name: idx_payroll_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_payroll_driver ON public.driver_salary USING btree (driver_id);


--
-- Name: idx_permissions_role_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_permissions_role_id ON public.permissions USING btree (role_id);


--
-- Name: idx_permit_driver_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_permit_driver_id ON public.local_permits USING btree (driver_id);


--
-- Name: idx_permit_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_permit_number ON public.local_permits USING btree (permit_number);


--
-- Name: idx_permit_organization_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_permit_organization_id ON public.local_permits USING btree (organization_id);


--
-- Name: idx_permit_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_permit_status ON public.local_permits USING btree (status);


--
-- Name: idx_permit_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_permit_type ON public.local_permits USING btree (permit_type);


--
-- Name: idx_permit_valid_to; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_permit_valid_to ON public.local_permits USING btree (valid_to);


--
-- Name: idx_permit_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_permit_vehicle_id ON public.local_permits USING btree (vehicle_id);


--
-- Name: idx_pod_trip_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_pod_trip_id ON public.proof_of_delivery USING btree (trip_id);


--
-- Name: idx_pred_maint_analysis_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_pred_maint_analysis_date ON public.predictive_maintenance_analytics USING btree (analysis_date);


--
-- Name: idx_pred_maint_org_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_pred_maint_org_vehicle ON public.predictive_maintenance_analytics USING btree (organization_id, vehicle_id);


--
-- Name: idx_prediction_results_anomaly; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_prediction_results_anomaly ON public.prediction_results USING btree (anomaly_detected, created_at);


--
-- Name: idx_prediction_results_model_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_prediction_results_model_created ON public.prediction_results USING btree (model_id, created_at);


--
-- Name: idx_prediction_results_org_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_prediction_results_org_created ON public.prediction_results USING btree (organization_id, created_at);


--
-- Name: idx_prediction_results_org_model_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_prediction_results_org_model_time ON public.prediction_results USING btree (organization_id, model_id, created_at DESC);


--
-- Name: idx_predictive_models_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_predictive_models_org_id ON public.predictive_models USING btree (organization_id);


--
-- Name: idx_predictive_models_org_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_predictive_models_org_status ON public.predictive_models USING btree (organization_id, status);


--
-- Name: idx_receipt_ocr_jobs_expense_item; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_receipt_ocr_jobs_expense_item ON public.receipt_ocr_jobs USING btree (expense_item_id);


--
-- Name: idx_receipt_ocr_jobs_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_receipt_ocr_jobs_status ON public.receipt_ocr_jobs USING btree (status, created_at);


--
-- Name: idx_refresh_tokens_expires_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_refresh_tokens_expires_at ON public.refresh_tokens USING btree (expires_at);


--
-- Name: idx_refresh_tokens_revoked; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_refresh_tokens_revoked ON public.refresh_tokens USING btree (revoked);


--
-- Name: idx_refresh_tokens_token; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_refresh_tokens_token ON public.refresh_tokens USING btree (token);


--
-- Name: idx_refresh_tokens_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_refresh_tokens_user_id ON public.refresh_tokens USING btree (user_id);


--
-- Name: idx_refresh_tokens_user_last_used; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_refresh_tokens_user_last_used ON public.refresh_tokens USING btree (user_id, last_used_at DESC);


--
-- Name: idx_restore_jobs_backup_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_restore_jobs_backup_id ON public.restore_jobs USING btree (backup_id);


--
-- Name: idx_restore_jobs_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_restore_jobs_status ON public.restore_jobs USING btree (status);


--
-- Name: idx_revenue_sch_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_revenue_sch_org ON public.billing_revenue_schedules USING btree (org_id);


--
-- Name: idx_review_items_review; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_review_items_review ON public.review_items USING btree (review_id);


--
-- Name: idx_review_items_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_review_items_status ON public.review_items USING btree (review_id, current_status);


--
-- Name: idx_review_items_user; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_review_items_user ON public.review_items USING btree (user_id);


--
-- Name: idx_rollout_device_status_device; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_rollout_device_status_device ON public.rollout_device_status USING btree (device_id);


--
-- Name: idx_rollout_device_status_rollout; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_rollout_device_status_rollout ON public.rollout_device_status USING btree (rollout_id);


--
-- Name: idx_rollout_device_status_state; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_rollout_device_status_state ON public.rollout_device_status USING btree (rollout_id, status);


--
-- Name: idx_route_jobs_request; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_jobs_request ON public.route_optimization_jobs USING btree (request_id);


--
-- Name: idx_route_jobs_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_jobs_status ON public.route_optimization_jobs USING btree (status);


--
-- Name: idx_route_opt_jobs_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_opt_jobs_status ON public.route_optimization_jobs USING btree (status);


--
-- Name: idx_route_opt_req_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_opt_req_org ON public.route_optimization_requests USING btree (organization_id);


--
-- Name: idx_route_opt_req_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_opt_req_status ON public.route_optimization_requests USING btree (status);


--
-- Name: idx_route_opt_res_req; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_opt_res_req ON public.route_optimization_results USING btree (request_id);


--
-- Name: idx_route_requests_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_requests_created ON public.route_optimization_requests USING btree (created_at DESC);


--
-- Name: idx_route_requests_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_requests_org ON public.route_optimization_requests USING btree (organization_id);


--
-- Name: idx_route_requests_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_requests_status ON public.route_optimization_requests USING btree (status);


--
-- Name: idx_route_results_request; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_route_results_request ON public.route_optimization_results USING btree (request_id);


--
-- Name: idx_safety_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_safety_driver ON public.driver_safety_events USING btree (driver_id);


--
-- Name: idx_security_history_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_security_history_created_at ON public.security_history USING btree (created_at);


--
-- Name: idx_security_history_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_security_history_user_id ON public.security_history USING btree (user_id);


--
-- Name: idx_shifts_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_shifts_driver ON public.driver_shifts USING btree (driver_id);


--
-- Name: idx_shifts_start; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_shifts_start ON public.driver_shifts USING btree (shift_start);


--
-- Name: idx_shipments_customer_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_shipments_customer_id ON public.shipments USING btree (customer_id);


--
-- Name: idx_shipments_customer_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_shipments_customer_status ON public.shipments USING btree (customer_id, status);


--
-- Name: idx_shipments_estimated_delivery; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_shipments_estimated_delivery ON public.shipments USING btree (estimated_delivery) WHERE ((status)::text = 'in_transit'::text);


--
-- Name: idx_shipments_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_shipments_status ON public.shipments USING btree (status);


--
-- Name: idx_shipments_status_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_shipments_status_created ON public.shipments USING btree (status, created_at DESC);


--
-- Name: idx_shipments_tracking_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_shipments_tracking_number ON public.shipments USING btree (tracking_number);


--
-- Name: idx_shipments_trip_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_shipments_trip_id ON public.shipments USING btree (trip_id);


--
-- Name: idx_sos_device; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_sos_device ON public.sos_incidents USING btree (device_id);


--
-- Name: idx_sos_incident_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_sos_incident_type ON public.sos_incidents USING btree (incident_type);


--
-- Name: idx_sos_incidents_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_sos_incidents_org_id ON public.sos_incidents USING btree (org_id);


--
-- Name: idx_sos_incidents_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_sos_incidents_status ON public.sos_incidents USING btree (status);


--
-- Name: idx_sos_incidents_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_sos_incidents_vehicle_id ON public.sos_incidents USING btree (vehicle_id);


--
-- Name: idx_sos_trip; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_sos_trip ON public.sos_incidents USING btree (trip_id);


--
-- Name: idx_storage_pools_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_storage_pools_status ON public.storage_pools USING btree (status);


--
-- Name: idx_subs_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_subs_org_id ON public.billing_subscriptions USING btree (org_id);


--
-- Name: idx_subs_plan_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_subs_plan_id ON public.billing_subscriptions USING btree (plan_id);


--
-- Name: idx_support_audit_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_audit_created_at ON public.support_audit_log USING btree (created_at);


--
-- Name: idx_support_audit_log_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_audit_log_created_at ON public.support_audit_log USING btree (created_at);


--
-- Name: idx_support_audit_log_ticket_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_audit_log_ticket_id ON public.support_audit_log USING btree (ticket_id);


--
-- Name: idx_support_audit_log_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_audit_log_user_id ON public.support_audit_log USING btree (user_id);


--
-- Name: idx_support_audit_ticket_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_audit_ticket_id ON public.support_audit_log USING btree (ticket_id);


--
-- Name: idx_support_tickets_assigned; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_assigned ON public.support_tickets USING btree (assigned_to);


--
-- Name: idx_support_tickets_assigned_to; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_assigned_to ON public.support_tickets USING btree (assigned_to);


--
-- Name: idx_support_tickets_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_created_at ON public.support_tickets USING btree (created_at);


--
-- Name: idx_support_tickets_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_org_id ON public.support_tickets USING btree (org_id);


--
-- Name: idx_support_tickets_priority; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_priority ON public.support_tickets USING btree (priority);


--
-- Name: idx_support_tickets_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_status ON public.support_tickets USING btree (status);


--
-- Name: idx_support_tickets_ticket_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_ticket_id ON public.support_tickets USING btree (ticket_id);


--
-- Name: idx_sync_queue_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_sync_queue_status ON public.driver_mobile_sync_queue USING btree (status);


--
-- Name: idx_system_audit_logs_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_system_audit_logs_org ON public.system_audit_logs USING btree (organization_id);


--
-- Name: idx_system_audit_logs_target; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_system_audit_logs_target ON public.system_audit_logs USING btree (target_user_id);


--
-- Name: idx_system_audit_logs_user; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_system_audit_logs_user ON public.system_audit_logs USING btree (user_id);


--
-- Name: idx_tax_rates_region; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_tax_rates_region ON public.billing_tax_rates USING btree (region_id);


--
-- Name: idx_tds_records_entity; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_tds_records_entity ON public.tds_records USING btree (entity_type, entity_id);


--
-- Name: idx_tds_records_fy; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_tds_records_fy ON public.tds_records USING btree (financial_year, quarter);


--
-- Name: idx_tds_records_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_tds_records_org ON public.tds_records USING btree (org_id);


--
-- Name: idx_tds_records_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_tds_records_org_id ON public.tds_records USING btree (org_id);


--
-- Name: idx_tds_records_vendor; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_tds_records_vendor ON public.tds_records USING btree (vendor_id) WHERE (vendor_id IS NOT NULL);


--
-- Name: idx_tds_records_vendor_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_tds_records_vendor_id ON public.tds_records USING btree (vendor_id);


--
-- Name: idx_telem_outbox_pending; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telem_outbox_pending ON public.telemetry_outbox USING btree (created_at) WHERE ((status)::text = 'pending'::text);


--
-- Name: idx_telemetry_analytics_composite; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_analytics_composite ON public.telemetry_analytics USING btree (vehicle_id, analysis_type, "timestamp" DESC);


--
-- Name: idx_telemetry_analytics_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_analytics_timestamp ON public.telemetry_analytics USING btree ("timestamp");


--
-- Name: idx_telemetry_analytics_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_analytics_type ON public.telemetry_analytics USING btree (analysis_type);


--
-- Name: idx_telemetry_analytics_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_analytics_vehicle_id ON public.telemetry_analytics USING btree (vehicle_id);


--
-- Name: idx_telemetry_anomalies_composite; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_anomalies_composite ON public.telemetry_anomalies USING btree (vehicle_id, anomaly_type, "timestamp" DESC);


--
-- Name: idx_telemetry_anomalies_score; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_anomalies_score ON public.telemetry_anomalies USING btree (anomaly_score DESC);


--
-- Name: idx_telemetry_anomalies_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_anomalies_timestamp ON public.telemetry_anomalies USING btree ("timestamp");


--
-- Name: idx_telemetry_anomalies_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_anomalies_type ON public.telemetry_anomalies USING btree (anomaly_type);


--
-- Name: idx_telemetry_anomalies_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_anomalies_vehicle_id ON public.telemetry_anomalies USING btree (vehicle_id);


--
-- Name: idx_telemetry_event_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_event_time ON public.telemetry USING btree (event_time);


--
-- Name: idx_telemetry_points_y2026m03_geo; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_points_y2026m03_geo ON public.telemetry_points_y2026m03 USING gist (geo);


--
-- Name: idx_telemetry_points_y2026m03_recorded_at_brin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_points_y2026m03_recorded_at_brin ON public.telemetry_points_y2026m03 USING brin (recorded_at);


--
-- Name: idx_telemetry_points_y2026m04_geo; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_points_y2026m04_geo ON public.telemetry_points_y2026m04 USING gist (geo);


--
-- Name: idx_telemetry_points_y2026m04_recorded_at_brin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_points_y2026m04_recorded_at_brin ON public.telemetry_points_y2026m04 USING brin (recorded_at);


--
-- Name: idx_telemetry_points_y2026m05_geo; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_points_y2026m05_geo ON public.telemetry_points_y2026m05 USING gist (geo);


--
-- Name: idx_telemetry_points_y2026m05_recorded_at_brin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_points_y2026m05_recorded_at_brin ON public.telemetry_points_y2026m05 USING brin (recorded_at);


--
-- Name: idx_telemetry_trip_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_trip_id ON public.telemetry USING btree (trip_id);


--
-- Name: idx_template_name; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_template_name ON public.billing_invoice_templates USING btree (name);


--
-- Name: idx_templates_key; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_templates_key ON public.templates USING btree (template_key);


--
-- Name: idx_threat_alerts_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_threat_alerts_org_id ON public.threat_alerts USING btree (org_id);


--
-- Name: idx_threat_alerts_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_threat_alerts_status ON public.threat_alerts USING btree (status);


--
-- Name: idx_ticket_events_ticket; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_ticket_events_ticket ON public.ticket_events USING btree (ticket_id);


--
-- Name: idx_ticket_priority; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_ticket_priority ON public.support_tickets USING btree (priority);


--
-- Name: idx_ticket_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_ticket_status ON public.support_tickets USING btree (status);


--
-- Name: idx_toll_fastag_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_toll_fastag_id ON public.toll_transactions USING btree (fastag_id);


--
-- Name: idx_toll_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_toll_time ON public.toll_transactions USING btree (transaction_time);


--
-- Name: idx_toll_transactions_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_toll_transactions_org_id ON public.toll_transactions USING btree (org_id);


--
-- Name: idx_toll_transactions_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_toll_transactions_vehicle ON public.toll_transactions USING btree (vehicle_id);


--
-- Name: idx_toll_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_toll_vehicle_id ON public.toll_transactions USING btree (vehicle_id);


--
-- Name: idx_trip_profit_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trip_profit_org ON public.trip_profitability USING btree (org_id);


--
-- Name: idx_trip_profit_trip; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trip_profit_trip ON public.trip_profitability USING btree (trip_id);


--
-- Name: idx_trip_profit_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trip_profit_vehicle ON public.trip_profitability USING btree (vehicle_id) WHERE (vehicle_id IS NOT NULL);


--
-- Name: idx_trips_driver_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_driver_id ON public.trips USING btree (driver_id);


--
-- Name: idx_trips_driver_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_driver_status ON public.trips USING btree (driver_id, status);


--
-- Name: idx_trips_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_org_id ON public.trips USING btree (org_id);


--
-- Name: idx_trips_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_status ON public.trips USING btree (status);


--
-- Name: idx_trips_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_vehicle_id ON public.trips USING btree (vehicle_id);


--
-- Name: idx_trips_vehicle_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_vehicle_status ON public.trips USING btree (vehicle_id, status);


--
-- Name: idx_user_invoice_access_user; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_invoice_access_user ON public.user_invoice_access USING btree (user_id);


--
-- Name: idx_user_notes_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_notes_user_id ON public.user_notes USING btree (user_id);


--
-- Name: idx_user_org_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_org_org_id ON public.user_organizations USING btree (org_id);


--
-- Name: idx_user_org_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_org_user_id ON public.user_organizations USING btree (user_id);


--
-- Name: idx_user_sessions_is_active; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_sessions_is_active ON public.user_sessions USING btree (is_active);


--
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: idx_users_locked_until; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_users_locked_until ON public.users USING btree (locked_until);


--
-- Name: idx_users_role_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_users_role_id ON public.users USING btree (role_id);


--
-- Name: idx_vehicle_daily_stats_org_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_daily_stats_org_date ON public.vehicle_daily_stats USING btree (organization_id, date);


--
-- Name: idx_vehicle_inspections_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_inspections_vehicle ON public.vehicle_inspections USING btree (vehicle_id);


--
-- Name: idx_vehicle_organization_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_organization_id ON public.vehicle_verifications USING btree (organization_id);


--
-- Name: idx_vehicle_rc_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_rc_status ON public.vehicle_verifications USING btree (rc_status);


--
-- Name: idx_vehicle_reg_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_reg_number ON public.vehicle_verifications USING btree (registration_number);


--
-- Name: idx_vehicle_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_status ON public.vehicle_verifications USING btree (status);


--
-- Name: idx_vehicle_telemetry_alerts_gin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_telemetry_alerts_gin ON public.vehicle_telemetry USING gin (alerts);


--
-- Name: idx_vehicle_telemetry_vehicle_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_telemetry_vehicle_time ON public.vehicle_telemetry USING btree (vehicle_id, "time" DESC);


--
-- Name: idx_vehicle_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicle_vehicle_id ON public.vehicle_verifications USING btree (vehicle_id);


--
-- Name: idx_vehicles_ais140; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_ais140 ON public.vehicles USING btree (ais140_compliant) WHERE (ais140_compliant = true);


--
-- Name: idx_vehicles_branch; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_branch ON public.vehicles USING btree (branch_id);


--
-- Name: idx_vehicles_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_created ON public.vehicles USING btree (created_at DESC);


--
-- Name: idx_vehicles_created_by; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_created_by ON public.vehicles_legacy USING btree (created_by);


--
-- Name: idx_vehicles_deleted; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_deleted ON public.vehicles USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_vehicles_gps_device; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_gps_device ON public.vehicles USING btree (gps_device_id) WHERE (gps_device_id IS NOT NULL);


--
-- Name: idx_vehicles_license; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_license ON public.vehicles_legacy USING btree (license_plate);


--
-- Name: idx_vehicles_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_org_id ON public.vehicles_legacy USING btree (org_id);


--
-- Name: idx_vehicles_parent; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_parent ON public.vehicles USING btree (parent_vehicle_id);


--
-- Name: idx_vehicles_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_status ON public.vehicles_legacy USING btree (status);


--
-- Name: idx_vehicles_tenant; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_tenant ON public.vehicles USING btree (tenant_id);


--
-- Name: idx_vehicles_tenant_reg; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_tenant_reg ON public.vehicles USING btree (tenant_id, registration_number);


--
-- Name: idx_vehicles_vehicle_no; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_vehicle_no ON public.vehicles_legacy USING btree (vehicle_no);


--
-- Name: idx_vehicles_vin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_vin ON public.vehicles_legacy USING btree (vin);


--
-- Name: idx_vendor_payments_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vendor_payments_date ON public.vendor_payments USING btree (payment_date);


--
-- Name: idx_vendor_payments_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vendor_payments_org ON public.vendor_payments USING btree (org_id);


--
-- Name: idx_vendor_payments_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vendor_payments_org_id ON public.vendor_payments USING btree (org_id);


--
-- Name: idx_vendor_payments_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vendor_payments_status ON public.vendor_payments USING btree (payment_status);


--
-- Name: idx_vendor_payments_vendor; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vendor_payments_vendor ON public.vendor_payments USING btree (vendor_id);


--
-- Name: idx_vendor_payments_vendor_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vendor_payments_vendor_id ON public.vendor_payments USING btree (vendor_id);


--
-- Name: idx_vevt_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vevt_created ON public.vehicle_events USING btree (created_at DESC);


--
-- Name: idx_vevt_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vevt_type ON public.vehicle_events USING btree (event_type);


--
-- Name: idx_vevt_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vevt_vehicle ON public.vehicle_events USING btree (vehicle_id);


--
-- Name: idx_video_analytics_recording_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_analytics_recording_id ON public.video_analytics USING btree (recording_id);


--
-- Name: idx_video_analytics_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_analytics_timestamp ON public.video_analytics USING btree ("timestamp");


--
-- Name: idx_video_recordings_start_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_start_time ON public.video_recordings USING btree (start_time);


--
-- Name: idx_video_recordings_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_status ON public.video_recordings USING btree (status);


--
-- Name: idx_video_recordings_stream_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_stream_id ON public.video_recordings USING btree (stream_id);


--
-- Name: idx_video_recordings_stream_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_stream_status ON public.video_recordings USING btree (stream_id, status);


--
-- Name: idx_video_recordings_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_vehicle_id ON public.video_recordings USING btree (vehicle_id);


--
-- Name: idx_video_recordings_vehicle_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_recordings_vehicle_time ON public.video_recordings USING btree (vehicle_id, start_time);


--
-- Name: idx_video_retention_policies_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_retention_policies_org_id ON public.video_retention_policies USING btree (organization_id);


--
-- Name: idx_video_streams_started_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_streams_started_at ON public.video_streams USING btree (started_at);


--
-- Name: idx_video_streams_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_streams_status ON public.video_streams USING btree (status);


--
-- Name: idx_video_streams_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_streams_vehicle_id ON public.video_streams USING btree (vehicle_id);


--
-- Name: idx_video_streams_vehicle_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_video_streams_vehicle_status ON public.video_streams USING btree (vehicle_id, status);


--
-- Name: idx_webhook_subscriptions_active; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_webhook_subscriptions_active ON public.webhook_subscriptions USING btree (is_active);


--
-- Name: idx_webhook_subscriptions_events; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_webhook_subscriptions_events ON public.webhook_subscriptions USING gin (events);


--
-- Name: idx_webhook_subscriptions_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_webhook_subscriptions_org ON public.webhook_subscriptions USING btree (org_id);


--
-- Name: idx_webhooks_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_webhooks_org ON public.webhooks USING btree (org_id);


--
-- Name: idx_work_orders_approval; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_approval ON public.work_orders USING btree (approval_status);


--
-- Name: idx_work_orders_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_created_at ON public.work_orders USING btree (created_at DESC);


--
-- Name: idx_work_orders_created_by; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_created_by ON public.work_orders USING btree (created_by);


--
-- Name: idx_work_orders_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_org ON public.work_orders USING btree (organization_id);


--
-- Name: idx_work_orders_org_priority; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_org_priority ON public.work_orders USING btree (organization_id, priority);


--
-- Name: idx_work_orders_org_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_org_status ON public.work_orders USING btree (organization_id, status);


--
-- Name: idx_work_orders_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_status ON public.work_orders USING btree (status);


--
-- Name: idx_work_orders_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_vehicle ON public.work_orders USING btree (vehicle_id);


--
-- Name: idx_work_orders_vendor; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_vendor ON public.work_orders USING btree (vendor_id);


--
-- Name: obd_readings_time_idx; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX obd_readings_time_idx ON public.obd_readings USING btree ("time" DESC);


--
-- Name: sla_metrics_time_idx; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX sla_metrics_time_idx ON public.sla_metrics USING btree ("time" DESC);


--
-- Name: uniq_geofence_event; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE UNIQUE INDEX uniq_geofence_event ON public.geofence_events USING btree ("time", vehicle_id, geofence_id, event_type);


--
-- Name: vehicle_telemetry_time_idx; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX vehicle_telemetry_time_idx ON public.vehicle_telemetry USING btree ("time" DESC);


--
-- Name: telemetry_points_y2026m01_pkey; Type: INDEX ATTACH; Schema: public; Owner: fleet_user
--

ALTER INDEX public.telemetry_points_pkey ATTACH PARTITION public.telemetry_points_y2026m01_pkey;


--
-- Name: telemetry_points_y2026m02_pkey; Type: INDEX ATTACH; Schema: public; Owner: fleet_user
--

ALTER INDEX public.telemetry_points_pkey ATTACH PARTITION public.telemetry_points_y2026m02_pkey;


--
-- Name: telemetry_points_y2026m03_pkey; Type: INDEX ATTACH; Schema: public; Owner: fleet_user
--

ALTER INDEX public.telemetry_points_pkey ATTACH PARTITION public.telemetry_points_y2026m03_pkey;


--
-- Name: telemetry_points_y2026m04_pkey; Type: INDEX ATTACH; Schema: public; Owner: fleet_user
--

ALTER INDEX public.telemetry_points_pkey ATTACH PARTITION public.telemetry_points_y2026m04_pkey;


--
-- Name: telemetry_points_y2026m05_pkey; Type: INDEX ATTACH; Schema: public; Owner: fleet_user
--

ALTER INDEX public.telemetry_points_pkey ATTACH PARTITION public.telemetry_points_y2026m05_pkey;


--
-- Name: telemetry_points_y2026m06_pkey; Type: INDEX ATTACH; Schema: public; Owner: fleet_user
--

ALTER INDEX public.telemetry_points_pkey ATTACH PARTITION public.telemetry_points_y2026m06_pkey;


--
-- Name: telemetry_points_y2026m07_pkey; Type: INDEX ATTACH; Schema: public; Owner: fleet_user
--

ALTER INDEX public.telemetry_points_pkey ATTACH PARTITION public.telemetry_points_y2026m07_pkey;


--
-- Name: telemetry_points_y2026m08_pkey; Type: INDEX ATTACH; Schema: public; Owner: fleet_user
--

ALTER INDEX public.telemetry_points_pkey ATTACH PARTITION public.telemetry_points_y2026m08_pkey;


--
-- Name: telemetry_points_y2026m09_pkey; Type: INDEX ATTACH; Schema: public; Owner: fleet_user
--

ALTER INDEX public.telemetry_points_pkey ATTACH PARTITION public.telemetry_points_y2026m09_pkey;


--
-- Name: telemetry_points_y2026m10_pkey; Type: INDEX ATTACH; Schema: public; Owner: fleet_user
--

ALTER INDEX public.telemetry_points_pkey ATTACH PARTITION public.telemetry_points_y2026m10_pkey;


--
-- Name: telemetry_points_y2026m11_pkey; Type: INDEX ATTACH; Schema: public; Owner: fleet_user
--

ALTER INDEX public.telemetry_points_pkey ATTACH PARTITION public.telemetry_points_y2026m11_pkey;


--
-- Name: telemetry_points_y2026m12_pkey; Type: INDEX ATTACH; Schema: public; Owner: fleet_user
--

ALTER INDEX public.telemetry_points_pkey ATTACH PARTITION public.telemetry_points_y2026m12_pkey;


--
-- Name: telemetry_points_y2027m01_pkey; Type: INDEX ATTACH; Schema: public; Owner: fleet_user
--

ALTER INDEX public.telemetry_points_pkey ATTACH PARTITION public.telemetry_points_y2027m01_pkey;


--
-- Name: vehicle_events vehicle_events_no_delete; Type: RULE; Schema: public; Owner: fleet_user
--

CREATE RULE vehicle_events_no_delete AS
    ON DELETE TO public.vehicle_events DO INSTEAD NOTHING;


--
-- Name: vehicle_events vehicle_events_no_update; Type: RULE; Schema: public; Owner: fleet_user
--

CREATE RULE vehicle_events_no_update AS
    ON UPDATE TO public.vehicle_events DO INSTEAD NOTHING;


--
-- Name: device_commands trg_audit_device_commands; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_audit_device_commands AFTER INSERT OR DELETE OR UPDATE ON public.device_commands FOR EACH ROW EXECUTE FUNCTION public.trigger_insert_diagnostics_audit_log();


--
-- Name: devices trg_audit_devices; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_audit_devices AFTER INSERT OR DELETE OR UPDATE ON public.devices FOR EACH ROW EXECUTE FUNCTION public.trigger_insert_diagnostics_audit_log();


--
-- Name: firmware_packages trg_audit_firmware_packages; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_audit_firmware_packages AFTER INSERT OR DELETE OR UPDATE ON public.firmware_packages FOR EACH ROW EXECUTE FUNCTION public.trigger_insert_diagnostics_audit_log();


--
-- Name: firmware_rollouts trg_audit_firmware_rollouts; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_audit_firmware_rollouts AFTER INSERT OR DELETE OR UPDATE ON public.firmware_rollouts FOR EACH ROW EXECUTE FUNCTION public.trigger_insert_diagnostics_audit_log();


--
-- Name: bank_transactions trg_bank_transactions_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_bank_transactions_updated_at BEFORE UPDATE ON public.bank_transactions FOR EACH ROW EXECUTE FUNCTION public.set_finance_fuel_updated_at();


--
-- Name: currency_rates trg_currency_rates_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_currency_rates_updated_at BEFORE UPDATE ON public.currency_rates FOR EACH ROW EXECUTE FUNCTION public.set_finance_fuel_updated_at();


--
-- Name: customers trg_customer_audit; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_customer_audit AFTER INSERT OR DELETE OR UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.log_customer_audit();


--
-- Name: expense_items trg_expense_items_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_expense_items_updated_at BEFORE UPDATE ON public.expense_items FOR EACH ROW EXECUTE FUNCTION public.set_finance_fuel_updated_at();


--
-- Name: finance_audit_logs trg_finance_audit_logs_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_finance_audit_logs_updated_at BEFORE UPDATE ON public.finance_audit_logs FOR EACH ROW EXECUTE FUNCTION public.set_finance_fuel_updated_at();


--
-- Name: fuel_card_reconciliation trg_fuel_card_reconciliation_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_fuel_card_reconciliation_updated_at BEFORE UPDATE ON public.fuel_card_reconciliation FOR EACH ROW EXECUTE FUNCTION public.set_finance_fuel_updated_at();


--
-- Name: invoices trg_generate_invoice_number; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_generate_invoice_number BEFORE INSERT ON public.invoices FOR EACH ROW WHEN ((new.invoice_number IS NULL)) EXECUTE FUNCTION public.generate_invoice_number();


--
-- Name: gst_invoices trg_gst_invoices_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_gst_invoices_updated_at BEFORE UPDATE ON public.gst_invoices FOR EACH ROW EXECUTE FUNCTION public.set_finance_fuel_updated_at();


--
-- Name: invoices trg_invoice_audit_log; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_invoice_audit_log AFTER INSERT OR DELETE OR UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.log_invoice_change();


--
-- Name: eld_diagnostic_events trg_malfunction_from_diagnostic; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_malfunction_from_diagnostic AFTER INSERT ON public.eld_diagnostic_events FOR EACH ROW EXECUTE FUNCTION public.create_malfunction_from_diagnostic();


--
-- Name: admin_audit_logs trg_protect_audit_logs; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_protect_audit_logs BEFORE DELETE OR UPDATE ON public.admin_audit_logs FOR EACH ROW EXECUTE FUNCTION public.protect_audit_logs();


--
-- Name: receipt_ocr_jobs trg_receipt_ocr_jobs_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_receipt_ocr_jobs_updated_at BEFORE UPDATE ON public.receipt_ocr_jobs FOR EACH ROW EXECUTE FUNCTION public.set_finance_fuel_updated_at();


--
-- Name: shipments trg_shipment_status_audit; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_shipment_status_audit AFTER UPDATE ON public.shipments FOR EACH ROW WHEN (((old.status)::text IS DISTINCT FROM (new.status)::text)) EXECUTE FUNCTION public.log_shipment_status_change();


--
-- Name: tds_records trg_tds_records_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_tds_records_updated_at BEFORE UPDATE ON public.tds_records FOR EACH ROW EXECUTE FUNCTION public.set_finance_fuel_updated_at();


--
-- Name: telemetry_points trg_tp_set_geo; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_tp_set_geo BEFORE INSERT OR UPDATE ON public.telemetry_points FOR EACH ROW EXECUTE FUNCTION public.tp_set_geo();


--
-- Name: vehicles trg_vehicles_gps_uniqueness; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_vehicles_gps_uniqueness BEFORE INSERT OR UPDATE ON public.vehicles FOR EACH ROW EXECUTE FUNCTION public.check_gps_device_uniqueness();


--
-- Name: vendor_payments trg_vendor_payments_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trg_vendor_payments_updated_at BEFORE UPDATE ON public.vendor_payments FOR EACH ROW EXECUTE FUNCTION public.set_finance_fuel_updated_at();


--
-- Name: integration_configs trigger_update_config; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trigger_update_config BEFORE UPDATE ON public.integration_configs FOR EACH ROW EXECUTE FUNCTION public.update_config_timestamp();


--
-- Name: driver_verifications trigger_update_driver_verification; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trigger_update_driver_verification BEFORE UPDATE ON public.driver_verifications FOR EACH ROW EXECUTE FUNCTION public.update_driver_verification_timestamp();


--
-- Name: e_way_bills trigger_update_ewaybill; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trigger_update_ewaybill BEFORE UPDATE ON public.e_way_bills FOR EACH ROW EXECUTE FUNCTION public.update_ewaybill_timestamp();


--
-- Name: fastag_transactions trigger_update_fastag; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trigger_update_fastag BEFORE UPDATE ON public.fastag_transactions FOR EACH ROW EXECUTE FUNCTION public.update_fastag_timestamp();


--
-- Name: governance_requests trigger_update_governance_requests; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trigger_update_governance_requests BEFORE UPDATE ON public.governance_requests FOR EACH ROW EXECUTE FUNCTION public.update_governance_requests_updated_at();


--
-- Name: governance_settings trigger_update_governance_settings; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trigger_update_governance_settings BEFORE UPDATE ON public.governance_settings FOR EACH ROW EXECUTE FUNCTION public.update_governance_settings_updated_at();


--
-- Name: gst_compliances trigger_update_gst; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trigger_update_gst BEFORE UPDATE ON public.gst_compliances FOR EACH ROW EXECUTE FUNCTION public.update_gst_timestamp();


--
-- Name: local_permits trigger_update_permit; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trigger_update_permit BEFORE UPDATE ON public.local_permits FOR EACH ROW EXECUTE FUNCTION public.update_permit_timestamp();


--
-- Name: vehicle_verifications trigger_update_vehicle_verification; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trigger_update_vehicle_verification BEFORE UPDATE ON public.vehicle_verifications FOR EACH ROW EXECUTE FUNCTION public.update_vehicle_verification_timestamp();


--
-- Name: analytics_jobs update_analytics_jobs_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_analytics_jobs_updated_at BEFORE UPDATE ON public.analytics_jobs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: driver_behavior_analytics update_driver_behavior_analytics_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_driver_behavior_analytics_updated_at BEFORE UPDATE ON public.driver_behavior_analytics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: emergency_contacts update_emergency_contacts_modtime; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_emergency_contacts_modtime BEFORE UPDATE ON public.emergency_contacts FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: fleet_analytics update_fleet_analytics_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_fleet_analytics_updated_at BEFORE UPDATE ON public.fleet_analytics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: fuel_logs update_fuel_logs_modtime; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_fuel_logs_modtime BEFORE UPDATE ON public.fuel_logs FOR EACH ROW EXECUTE FUNCTION public.update_fuel_logs_timestamp();


--
-- Name: fuel_settings update_fuel_settings_modtime; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_fuel_settings_modtime BEFORE UPDATE ON public.fuel_settings FOR EACH ROW EXECUTE FUNCTION public.update_fuel_logs_timestamp();


--
-- Name: geofence_assignments update_geofence_assignments_modtime; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_geofence_assignments_modtime BEFORE UPDATE ON public.geofence_assignments FOR EACH ROW EXECUTE FUNCTION public.update_geofencing_timestamp();


--
-- Name: geofences update_geofences_modtime; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_geofences_modtime BEFORE UPDATE ON public.geofences FOR EACH ROW EXECUTE FUNCTION public.update_geofencing_timestamp();


--
-- Name: incident_comments update_incident_comments_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_incident_comments_updated_at BEFORE UPDATE ON public.incident_comments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: org_support_metrics update_org_support_metrics_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_org_support_metrics_updated_at BEFORE UPDATE ON public.org_support_metrics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: prediction_results update_prediction_results_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_prediction_results_updated_at BEFORE UPDATE ON public.prediction_results FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: predictive_maintenance_analytics update_predictive_maintenance_analytics_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_predictive_maintenance_analytics_updated_at BEFORE UPDATE ON public.predictive_maintenance_analytics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: predictive_models update_predictive_models_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_predictive_models_updated_at BEFORE UPDATE ON public.predictive_models FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: sos_incidents update_sos_incidents_modtime; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_sos_incidents_modtime BEFORE UPDATE ON public.sos_incidents FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: support_tickets update_support_tickets_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_support_tickets_updated_at BEFORE UPDATE ON public.support_tickets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: access_reviews access_reviews_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.access_reviews
    ADD CONSTRAINT access_reviews_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: access_reviews access_reviews_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.access_reviews
    ADD CONSTRAINT access_reviews_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: admin_role_permissions admin_role_permissions_permission_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.admin_role_permissions
    ADD CONSTRAINT admin_role_permissions_permission_fkey FOREIGN KEY (permission) REFERENCES public.admin_permissions(name);


--
-- Name: alert_rules alert_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alert_rules
    ADD CONSTRAINT alert_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: alert_rules alert_rules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alert_rules
    ADD CONSTRAINT alert_rules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: alerts alerts_acknowledged_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_acknowledged_by_fkey FOREIGN KEY (acknowledged_by) REFERENCES public.users(id);


--
-- Name: alerts alerts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: alerts alerts_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: alerts alerts_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.alert_rules(id);


--
-- Name: alerts_v2_dlq alerts_v2_dlq_log_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts_v2_dlq
    ADD CONSTRAINT alerts_v2_dlq_log_id_fkey FOREIGN KEY (log_id) REFERENCES public.alerts_v2_logs(id);


--
-- Name: api_clients api_clients_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT api_clients_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: api_keys api_keys_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: approval_actions approval_actions_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.approval_actions
    ADD CONSTRAINT approval_actions_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES public.approval_instances(id);


--
-- Name: approval_instances approval_instances_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.approval_instances
    ADD CONSTRAINT approval_instances_config_id_fkey FOREIGN KEY (config_id) REFERENCES public.approval_configs(id);


--
-- Name: audit_logs audit_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_policies audit_policies_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_policies audit_policies_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_settings audit_settings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_settings
    ADD CONSTRAINT audit_settings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: auth_audit_logs auth_audit_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.auth_audit_logs
    ADD CONSTRAINT auth_audit_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: auth_tokens auth_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: backup_verifications backup_verifications_backup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backup_verifications
    ADD CONSTRAINT backup_verifications_backup_id_fkey FOREIGN KEY (backup_id) REFERENCES public.backups(id) ON DELETE CASCADE;


--
-- Name: backup_verifications backup_verifications_verified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backup_verifications
    ADD CONSTRAINT backup_verifications_verified_by_fkey FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: behavior_score_updates behavior_score_updates_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.behavior_score_updates
    ADD CONSTRAINT behavior_score_updates_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON DELETE CASCADE;


--
-- Name: billing_accounting_exports billing_accounting_exports_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_accounting_exports
    ADD CONSTRAINT billing_accounting_exports_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: billing_credit_transactions billing_credit_transactions_balance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_credit_transactions
    ADD CONSTRAINT billing_credit_transactions_balance_id_fkey FOREIGN KEY (balance_id) REFERENCES public.billing_customer_balances(id);


--
-- Name: billing_customer_balances billing_customer_balances_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_customer_balances
    ADD CONSTRAINT billing_customer_balances_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: billing_invoice_documents billing_invoice_documents_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_invoice_documents
    ADD CONSTRAINT billing_invoice_documents_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: billing_invoice_documents billing_invoice_documents_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_invoice_documents
    ADD CONSTRAINT billing_invoice_documents_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.billing_invoice_templates(id);


--
-- Name: billing_invoice_sequences billing_invoice_sequences_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_invoice_sequences
    ADD CONSTRAINT billing_invoice_sequences_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: billing_pricing_components billing_pricing_components_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_pricing_components
    ADD CONSTRAINT billing_pricing_components_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.billing_plans(id) ON DELETE CASCADE;


--
-- Name: billing_recognized_revenue billing_recognized_revenue_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_recognized_revenue
    ADD CONSTRAINT billing_recognized_revenue_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.billing_revenue_schedules(id);


--
-- Name: billing_revenue_schedules billing_revenue_schedules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_revenue_schedules
    ADD CONSTRAINT billing_revenue_schedules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: billing_subscriptions billing_subscriptions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_subscriptions
    ADD CONSTRAINT billing_subscriptions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: billing_subscriptions billing_subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_subscriptions
    ADD CONSTRAINT billing_subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.billing_plans(id);


--
-- Name: billing_tax_rates billing_tax_rates_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.billing_tax_rates
    ADD CONSTRAINT billing_tax_rates_region_id_fkey FOREIGN KEY (region_id) REFERENCES public.billing_tax_regions(id);


--
-- Name: booking_requests booking_requests_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.booking_requests
    ADD CONSTRAINT booking_requests_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: bulk_job_records bulk_job_records_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_job_records
    ADD CONSTRAINT bulk_job_records_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.bulk_jobs(id) ON DELETE CASCADE;


--
-- Name: consumption_events consumption_events_meter_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.consumption_events
    ADD CONSTRAINT consumption_events_meter_code_fkey FOREIGN KEY (meter_code) REFERENCES public.usage_meters(code);


--
-- Name: consumption_events consumption_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.consumption_events
    ADD CONSTRAINT consumption_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: customer_v2_booking_approvals customer_v2_booking_approvals_approver_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_booking_approvals
    ADD CONSTRAINT customer_v2_booking_approvals_approver_user_id_fkey FOREIGN KEY (approver_user_id) REFERENCES public.customer_v2_customer_users(id);


--
-- Name: customer_v2_booking_approvals customer_v2_booking_approvals_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_booking_approvals
    ADD CONSTRAINT customer_v2_booking_approvals_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.customer_v2_booking_requests(id) ON DELETE CASCADE;


--
-- Name: customer_v2_booking_quotes customer_v2_booking_quotes_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_booking_quotes
    ADD CONSTRAINT customer_v2_booking_quotes_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.customer_v2_booking_requests(id) ON DELETE CASCADE;


--
-- Name: customer_v2_booking_requests customer_v2_booking_requests_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_booking_requests
    ADD CONSTRAINT customer_v2_booking_requests_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_v2_customers(id) ON DELETE CASCADE;


--
-- Name: customer_v2_booking_shipments customer_v2_booking_shipments_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_booking_shipments
    ADD CONSTRAINT customer_v2_booking_shipments_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.customer_v2_booking_requests(id) ON DELETE CASCADE;


--
-- Name: customer_v2_booking_shipments customer_v2_booking_shipments_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_booking_shipments
    ADD CONSTRAINT customer_v2_booking_shipments_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.customer_v2_shipments(id) ON DELETE CASCADE;


--
-- Name: customer_v2_booking_status_history customer_v2_booking_status_history_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_booking_status_history
    ADD CONSTRAINT customer_v2_booking_status_history_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.customer_v2_booking_requests(id) ON DELETE CASCADE;


--
-- Name: customer_v2_booking_validations customer_v2_booking_validations_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_booking_validations
    ADD CONSTRAINT customer_v2_booking_validations_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.customer_v2_booking_requests(id) ON DELETE CASCADE;


--
-- Name: customer_v2_credit_limits customer_v2_credit_limits_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_credit_limits
    ADD CONSTRAINT customer_v2_credit_limits_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_v2_customers(id) ON DELETE CASCADE;


--
-- Name: customer_v2_credit_transactions customer_v2_credit_transactions_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_credit_transactions
    ADD CONSTRAINT customer_v2_credit_transactions_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.customer_v2_customer_wallets(id) ON DELETE CASCADE;


--
-- Name: customer_v2_customer_addresses customer_v2_customer_addresses_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_addresses
    ADD CONSTRAINT customer_v2_customer_addresses_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_v2_customers(id) ON DELETE CASCADE;


--
-- Name: customer_v2_customer_api_keys customer_v2_customer_api_keys_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_api_keys
    ADD CONSTRAINT customer_v2_customer_api_keys_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_v2_customers(id) ON DELETE CASCADE;


--
-- Name: customer_v2_customer_api_logs customer_v2_customer_api_logs_api_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_api_logs
    ADD CONSTRAINT customer_v2_customer_api_logs_api_key_id_fkey FOREIGN KEY (api_key_id) REFERENCES public.customer_v2_customer_api_keys(id);


--
-- Name: customer_v2_customer_audit_logs customer_v2_customer_audit_logs_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_audit_logs
    ADD CONSTRAINT customer_v2_customer_audit_logs_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_v2_customers(id) ON DELETE CASCADE;


--
-- Name: customer_v2_customer_audit_logs customer_v2_customer_audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_audit_logs
    ADD CONSTRAINT customer_v2_customer_audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.customer_v2_customer_users(id);


--
-- Name: customer_v2_customer_contacts customer_v2_customer_contacts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_contacts
    ADD CONSTRAINT customer_v2_customer_contacts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_v2_customers(id) ON DELETE CASCADE;


--
-- Name: customer_v2_customer_contracts customer_v2_customer_contracts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_contracts
    ADD CONSTRAINT customer_v2_customer_contracts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_v2_customers(id) ON DELETE CASCADE;


--
-- Name: customer_v2_customer_credit_limits customer_v2_customer_credit_limits_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_credit_limits
    ADD CONSTRAINT customer_v2_customer_credit_limits_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_v2_customers(id) ON DELETE CASCADE;


--
-- Name: customer_v2_customer_invoice_views customer_v2_customer_invoice_views_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_invoice_views
    ADD CONSTRAINT customer_v2_customer_invoice_views_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_v2_customers(id) ON DELETE CASCADE;


--
-- Name: customer_v2_customer_sessions customer_v2_customer_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_sessions
    ADD CONSTRAINT customer_v2_customer_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.customer_v2_customer_users(id) ON DELETE CASCADE;


--
-- Name: customer_v2_customer_users customer_v2_customer_users_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_users
    ADD CONSTRAINT customer_v2_customer_users_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_v2_customers(id) ON DELETE CASCADE;


--
-- Name: customer_v2_customer_wallets customer_v2_customer_wallets_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_customer_wallets
    ADD CONSTRAINT customer_v2_customer_wallets_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_v2_customers(id) ON DELETE CASCADE;


--
-- Name: customer_v2_delivery_proofs customer_v2_delivery_proofs_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_delivery_proofs
    ADD CONSTRAINT customer_v2_delivery_proofs_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.customer_v2_shipments(id) ON DELETE CASCADE;


--
-- Name: customer_v2_dispute_attachments customer_v2_dispute_attachments_dispute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_dispute_attachments
    ADD CONSTRAINT customer_v2_dispute_attachments_dispute_id_fkey FOREIGN KEY (dispute_id) REFERENCES public.customer_v2_disputes(id) ON DELETE CASCADE;


--
-- Name: customer_v2_dispute_attachments customer_v2_dispute_attachments_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_dispute_attachments
    ADD CONSTRAINT customer_v2_dispute_attachments_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.customer_v2_dispute_messages(id);


--
-- Name: customer_v2_dispute_messages customer_v2_dispute_messages_dispute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_dispute_messages
    ADD CONSTRAINT customer_v2_dispute_messages_dispute_id_fkey FOREIGN KEY (dispute_id) REFERENCES public.customer_v2_disputes(id) ON DELETE CASCADE;


--
-- Name: customer_v2_disputes customer_v2_disputes_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_disputes
    ADD CONSTRAINT customer_v2_disputes_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_v2_customers(id) ON DELETE CASCADE;


--
-- Name: customer_v2_disputes customer_v2_disputes_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_disputes
    ADD CONSTRAINT customer_v2_disputes_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.customer_v2_shipments(id);


--
-- Name: customer_v2_pod_images customer_v2_pod_images_delivery_proof_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_pod_images
    ADD CONSTRAINT customer_v2_pod_images_delivery_proof_id_fkey FOREIGN KEY (delivery_proof_id) REFERENCES public.customer_v2_delivery_proofs(id) ON DELETE CASCADE;


--
-- Name: customer_v2_pod_signatures customer_v2_pod_signatures_delivery_proof_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_pod_signatures
    ADD CONSTRAINT customer_v2_pod_signatures_delivery_proof_id_fkey FOREIGN KEY (delivery_proof_id) REFERENCES public.customer_v2_delivery_proofs(id) ON DELETE CASCADE;


--
-- Name: customer_v2_pricing_components customer_v2_pricing_components_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_pricing_components
    ADD CONSTRAINT customer_v2_pricing_components_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.customer_v2_pricing_rules(id) ON DELETE CASCADE;


--
-- Name: customer_v2_pricing_contracts customer_v2_pricing_contracts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_pricing_contracts
    ADD CONSTRAINT customer_v2_pricing_contracts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_v2_customers(id) ON DELETE CASCADE;


--
-- Name: customer_v2_pricing_quotes customer_v2_pricing_quotes_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_pricing_quotes
    ADD CONSTRAINT customer_v2_pricing_quotes_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.customer_v2_booking_requests(id) ON DELETE CASCADE;


--
-- Name: customer_v2_pricing_rules customer_v2_pricing_rules_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_pricing_rules
    ADD CONSTRAINT customer_v2_pricing_rules_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.customer_v2_pricing_contracts(id) ON DELETE CASCADE;


--
-- Name: customer_v2_shipment_document_versions customer_v2_shipment_document_versions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipment_document_versions
    ADD CONSTRAINT customer_v2_shipment_document_versions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.customer_v2_shipment_documents(id) ON DELETE CASCADE;


--
-- Name: customer_v2_shipment_documents customer_v2_shipment_documents_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipment_documents
    ADD CONSTRAINT customer_v2_shipment_documents_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.customer_v2_shipments(id) ON DELETE CASCADE;


--
-- Name: customer_v2_shipment_events customer_v2_shipment_events_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipment_events
    ADD CONSTRAINT customer_v2_shipment_events_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.customer_v2_shipments(id) ON DELETE CASCADE;


--
-- Name: customer_v2_shipment_sla_rules customer_v2_shipment_sla_rules_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipment_sla_rules
    ADD CONSTRAINT customer_v2_shipment_sla_rules_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_v2_customers(id) ON DELETE CASCADE;


--
-- Name: customer_v2_shipment_sla_violations customer_v2_shipment_sla_violations_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipment_sla_violations
    ADD CONSTRAINT customer_v2_shipment_sla_violations_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.customer_v2_shipment_sla_rules(id);


--
-- Name: customer_v2_shipment_sla_violations customer_v2_shipment_sla_violations_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipment_sla_violations
    ADD CONSTRAINT customer_v2_shipment_sla_violations_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.customer_v2_shipments(id) ON DELETE CASCADE;


--
-- Name: customer_v2_shipment_status_logs customer_v2_shipment_status_logs_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipment_status_logs
    ADD CONSTRAINT customer_v2_shipment_status_logs_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.customer_v2_shipments(id) ON DELETE CASCADE;


--
-- Name: customer_v2_shipment_stops customer_v2_shipment_stops_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipment_stops
    ADD CONSTRAINT customer_v2_shipment_stops_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.customer_v2_shipments(id) ON DELETE CASCADE;


--
-- Name: customer_v2_shipments customer_v2_shipments_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipments
    ADD CONSTRAINT customer_v2_shipments_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.customer_v2_booking_requests(id);


--
-- Name: customer_v2_shipments customer_v2_shipments_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.customer_v2_shipments
    ADD CONSTRAINT customer_v2_shipments_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_v2_customers(id);


--
-- Name: device_alerts device_alerts_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_alerts
    ADD CONSTRAINT device_alerts_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id);


--
-- Name: device_auth_tokens device_auth_tokens_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_auth_tokens
    ADD CONSTRAINT device_auth_tokens_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id);


--
-- Name: device_commands device_commands_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_commands
    ADD CONSTRAINT device_commands_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: device_commands device_commands_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_commands
    ADD CONSTRAINT device_commands_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: device_commands device_commands_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_commands
    ADD CONSTRAINT device_commands_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: device_diagnostics_logs device_diagnostics_logs_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_diagnostics_logs
    ADD CONSTRAINT device_diagnostics_logs_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: device_diagnostics_logs device_diagnostics_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_diagnostics_logs
    ADD CONSTRAINT device_diagnostics_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: device_firmware_status device_firmware_status_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_firmware_status
    ADD CONSTRAINT device_firmware_status_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: device_firmware_status device_firmware_status_rollout_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_firmware_status
    ADD CONSTRAINT device_firmware_status_rollout_id_fkey FOREIGN KEY (rollout_id) REFERENCES public.firmware_rollouts(id) ON DELETE CASCADE;


--
-- Name: device_telemetry device_telemetry_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_telemetry
    ADD CONSTRAINT device_telemetry_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: device_telemetry device_telemetry_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_telemetry
    ADD CONSTRAINT device_telemetry_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: device_twins device_twins_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_twins
    ADD CONSTRAINT device_twins_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: device_twins device_twins_last_command_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_twins
    ADD CONSTRAINT device_twins_last_command_id_fkey FOREIGN KEY (last_command_id) REFERENCES public.device_commands(id) ON DELETE SET NULL;


--
-- Name: device_twins device_twins_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_twins
    ADD CONSTRAINT device_twins_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: devices devices_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: documents documents_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: documents documents_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: dot_inspection_mode dot_inspection_mode_active_inspection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dot_inspection_mode
    ADD CONSTRAINT dot_inspection_mode_active_inspection_id_fkey FOREIGN KEY (active_inspection_id) REFERENCES public.dot_inspections(id);


--
-- Name: dr_test_logs dr_test_logs_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_test_logs
    ADD CONSTRAINT dr_test_logs_test_id_fkey FOREIGN KEY (test_id) REFERENCES public.dr_tests(id) ON DELETE CASCADE;


--
-- Name: dr_test_steps dr_test_steps_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_test_steps
    ADD CONSTRAINT dr_test_steps_test_id_fkey FOREIGN KEY (test_id) REFERENCES public.dr_tests(id) ON DELETE CASCADE;


--
-- Name: driver_audit_logs driver_audit_logs_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_audit_logs
    ADD CONSTRAINT driver_audit_logs_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON DELETE CASCADE;


--
-- Name: driver_shift_assignments driver_shift_assignments_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_shift_assignments
    ADD CONSTRAINT driver_shift_assignments_shift_id_fkey FOREIGN KEY (shift_id) REFERENCES public.driver_shifts(id) ON DELETE CASCADE;


--
-- Name: driver_training_records driver_training_records_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_training_records
    ADD CONSTRAINT driver_training_records_module_id_fkey FOREIGN KEY (module_id) REFERENCES public.driver_training_modules(id);


--
-- Name: drivers drivers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: drivers drivers_current_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_current_vehicle_id_fkey FOREIGN KEY (current_vehicle_id) REFERENCES public.vehicles_legacy(id);


--
-- Name: drivers drivers_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: duty_status_logs duty_status_logs_original_log_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.duty_status_logs
    ADD CONSTRAINT duty_status_logs_original_log_id_fkey FOREIGN KEY (original_log_id) REFERENCES public.duty_status_logs(id);


--
-- Name: einvoice_irn einvoice_irn_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.einvoice_irn
    ADD CONSTRAINT einvoice_irn_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: email_verification_tokens email_verification_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: emergency_audit_log emergency_audit_log_command_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_audit_log
    ADD CONSTRAINT emergency_audit_log_command_id_fkey FOREIGN KEY (command_id) REFERENCES public.emergency_commands(id) ON DELETE CASCADE;


--
-- Name: emergency_contacts emergency_contacts_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_contacts
    ADD CONSTRAINT emergency_contacts_organization_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: emergency_escalations emergency_escalations_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_escalations
    ADD CONSTRAINT emergency_escalations_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.emergency_contacts(id);


--
-- Name: emergency_escalations emergency_escalations_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_escalations
    ADD CONSTRAINT emergency_escalations_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.sos_incidents(id) ON DELETE CASCADE;


--
-- Name: emergency_response_units emergency_response_units_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_response_units
    ADD CONSTRAINT emergency_response_units_organization_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: emergency_status emergency_status_current_command_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_status
    ADD CONSTRAINT emergency_status_current_command_id_fkey FOREIGN KEY (current_command_id) REFERENCES public.emergency_commands(id);


--
-- Name: emergency_vehicle_state emergency_vehicle_state_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_vehicle_state
    ADD CONSTRAINT emergency_vehicle_state_organization_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: emergency_vehicle_state emergency_vehicle_state_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.emergency_vehicle_state
    ADD CONSTRAINT emergency_vehicle_state_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: entity_audit_history entity_audit_history_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.entity_audit_history
    ADD CONSTRAINT entity_audit_history_actor_fkey FOREIGN KEY (actor) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: evidence_exports evidence_exports_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.evidence_exports
    ADD CONSTRAINT evidence_exports_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: evidence_exports evidence_exports_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.evidence_exports
    ADD CONSTRAINT evidence_exports_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: expense_items expense_items_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.expense_items
    ADD CONSTRAINT expense_items_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.expense_reports(id) ON DELETE CASCADE;


--
-- Name: firmware_rollout_events firmware_rollout_events_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollout_events
    ADD CONSTRAINT firmware_rollout_events_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id);


--
-- Name: firmware_rollout_events firmware_rollout_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollout_events
    ADD CONSTRAINT firmware_rollout_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: firmware_rollout_events firmware_rollout_events_rollout_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollout_events
    ADD CONSTRAINT firmware_rollout_events_rollout_id_fkey FOREIGN KEY (rollout_id) REFERENCES public.firmware_rollouts(id) ON DELETE CASCADE;


--
-- Name: firmware_rollouts firmware_rollouts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: firmware_rollouts firmware_rollouts_firmware_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_firmware_id_fkey FOREIGN KEY (firmware_id) REFERENCES public.firmware_packages(id) ON DELETE CASCADE;


--
-- Name: firmware_rollouts firmware_rollouts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: governance_audit_logs fk_governance_audit_org; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_audit_logs
    ADD CONSTRAINT fk_governance_audit_org FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: governance_requests fk_governance_requests_org; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_requests
    ADD CONSTRAINT fk_governance_requests_org FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: governance_settings fk_governance_settings_org; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_settings
    ADD CONSTRAINT fk_governance_settings_org FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: video_analytics fk_video_analytics_recording; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_analytics
    ADD CONSTRAINT fk_video_analytics_recording FOREIGN KEY (recording_id) REFERENCES public.video_recordings(id);


--
-- Name: video_analytics fk_video_analytics_stream; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_analytics
    ADD CONSTRAINT fk_video_analytics_stream FOREIGN KEY (stream_id) REFERENCES public.video_streams(id);


--
-- Name: video_recordings fk_video_recordings_organization; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_recordings
    ADD CONSTRAINT fk_video_recordings_organization FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: video_recordings fk_video_recordings_stream; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_recordings
    ADD CONSTRAINT fk_video_recordings_stream FOREIGN KEY (stream_id) REFERENCES public.video_streams(id);


--
-- Name: video_retention_policies fk_video_retention_policies_org; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_retention_policies
    ADD CONSTRAINT fk_video_retention_policies_org FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: video_streams fk_video_streams_organization; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.video_streams
    ADD CONSTRAINT fk_video_streams_organization FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: fuel_audit_logs fuel_audit_logs_fuel_log_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fuel_audit_logs
    ADD CONSTRAINT fuel_audit_logs_fuel_log_id_fkey FOREIGN KEY (fuel_log_id) REFERENCES public.fuel_logs(id) ON DELETE CASCADE;


--
-- Name: fuel_logs fuel_logs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fuel_logs
    ADD CONSTRAINT fuel_logs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: fuel_transactions fuel_transactions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.fuel_transactions
    ADD CONSTRAINT fuel_transactions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: geofence_assignments geofence_assignments_geofence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofence_assignments
    ADD CONSTRAINT geofence_assignments_geofence_id_fkey FOREIGN KEY (geofence_id) REFERENCES public.geofences(id) ON DELETE CASCADE;


--
-- Name: geofence_events geofence_events_geofence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofence_events
    ADD CONSTRAINT geofence_events_geofence_id_fkey FOREIGN KEY (geofence_id) REFERENCES public.geofences(id);


--
-- Name: geofences geofences_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofences
    ADD CONSTRAINT geofences_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: geofences geofences_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofences
    ADD CONSTRAINT geofences_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: governance_compliance_reports governance_compliance_reports_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_compliance_reports
    ADD CONSTRAINT governance_compliance_reports_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.governance_requests(id) ON DELETE CASCADE;


--
-- Name: governance_download_tokens governance_download_tokens_export_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_download_tokens
    ADD CONSTRAINT governance_download_tokens_export_id_fkey FOREIGN KEY (export_id) REFERENCES public.governance_exports(id) ON DELETE CASCADE;


--
-- Name: governance_export_lineage governance_export_lineage_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_export_lineage
    ADD CONSTRAINT governance_export_lineage_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.governance_requests(id) ON DELETE CASCADE;


--
-- Name: governance_exports governance_exports_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.governance_exports
    ADD CONSTRAINT governance_exports_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.governance_requests(id) ON DELETE CASCADE;


--
-- Name: hos_annotations hos_annotations_duty_status_log_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.hos_annotations
    ADD CONSTRAINT hos_annotations_duty_status_log_id_fkey FOREIGN KEY (duty_status_log_id) REFERENCES public.duty_status_logs(id) ON DELETE CASCADE;


--
-- Name: id_mappings id_mappings_erp_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.id_mappings
    ADD CONSTRAINT id_mappings_erp_config_id_fkey FOREIGN KEY (erp_config_id) REFERENCES public.erp_configs(id);


--
-- Name: impersonation_sessions impersonation_sessions_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.impersonation_sessions
    ADD CONSTRAINT impersonation_sessions_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admin_users(id);


--
-- Name: incident_comments incident_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_comments
    ADD CONSTRAINT incident_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: incident_comments incident_comments_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_comments
    ADD CONSTRAINT incident_comments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: incident_logs incident_logs_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_logs
    ADD CONSTRAINT incident_logs_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.sos_incidents(id);


--
-- Name: incident_media incident_media_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_media
    ADD CONSTRAINT incident_media_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.sos_incidents(id) ON DELETE CASCADE;


--
-- Name: incident_timeline incident_timeline_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_timeline
    ADD CONSTRAINT incident_timeline_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.sos_incidents(id) ON DELETE CASCADE;


--
-- Name: incident_updates incident_updates_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_updates
    ADD CONSTRAINT incident_updates_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incidents(id);


--
-- Name: incident_vehicle_snapshot incident_vehicle_snapshot_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_vehicle_snapshot
    ADD CONSTRAINT incident_vehicle_snapshot_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.sos_incidents(id) ON DELETE CASCADE;


--
-- Name: inspection_documents inspection_documents_inspection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.inspection_documents
    ADD CONSTRAINT inspection_documents_inspection_id_fkey FOREIGN KEY (inspection_id) REFERENCES public.dot_inspections(id) ON DELETE CASCADE;


--
-- Name: integration_logs integration_logs_integration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_integration_id_fkey FOREIGN KEY (integration_id) REFERENCES public.integrations(id) ON DELETE SET NULL;


--
-- Name: integration_logs integration_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: integrations integrations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: invoice_approvals invoice_approvals_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_approvals
    ADD CONSTRAINT invoice_approvals_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_audit_log invoice_audit_log_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_audit_log
    ADD CONSTRAINT invoice_audit_log_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_items invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.billing_subscriptions(id);


--
-- Name: ip_rules ip_rules_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.ip_rules
    ADD CONSTRAINT ip_rules_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id);


--
-- Name: ip_rules ip_rules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.ip_rules
    ADD CONSTRAINT ip_rules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: legal_holds legal_holds_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.legal_holds
    ADD CONSTRAINT legal_holds_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: login_events login_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.login_events
    ADD CONSTRAINT login_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: login_events login_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.login_events
    ADD CONSTRAINT login_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: login_history login_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: maintenance_schedule maintenance_schedule_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.maintenance_schedule
    ADD CONSTRAINT maintenance_schedule_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: mfa_codes mfa_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_codes
    ADD CONSTRAINT mfa_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_events mfa_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_events
    ADD CONSTRAINT mfa_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_events mfa_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_events
    ADD CONSTRAINT mfa_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_exceptions mfa_exceptions_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.users(id);


--
-- Name: mfa_exceptions mfa_exceptions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_exceptions mfa_exceptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_failures mfa_failures_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_failures
    ADD CONSTRAINT mfa_failures_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_failures mfa_failures_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_failures
    ADD CONSTRAINT mfa_failures_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_lockouts mfa_lockouts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_lockouts mfa_lockouts_unlocked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_unlocked_by_fkey FOREIGN KEY (unlocked_by) REFERENCES public.users(id);


--
-- Name: mfa_lockouts mfa_lockouts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_org_overrides mfa_org_overrides_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_org_overrides
    ADD CONSTRAINT mfa_org_overrides_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_policies mfa_policies_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policies
    ADD CONSTRAINT mfa_policies_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_policy_history mfa_policy_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policy_history
    ADD CONSTRAINT mfa_policy_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: mfa_policy_history mfa_policy_history_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policy_history
    ADD CONSTRAINT mfa_policy_history_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_recovery_codes mfa_recovery_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_recovery_codes
    ADD CONSTRAINT mfa_recovery_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_users mfa_users_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_users
    ADD CONSTRAINT mfa_users_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: mfa_users mfa_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_users
    ADD CONSTRAINT mfa_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notification_events notification_events_notification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_events
    ADD CONSTRAINT notification_events_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES public.notification_logs(id) ON DELETE CASCADE;


--
-- Name: notification_preference_audit notification_preference_audit_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_preference_audit
    ADD CONSTRAINT notification_preference_audit_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: org_support_metrics org_support_metrics_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.org_support_metrics
    ADD CONSTRAINT org_support_metrics_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_memberships organization_memberships_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organization_memberships
    ADD CONSTRAINT organization_memberships_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_memberships organization_memberships_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organization_memberships
    ADD CONSTRAINT organization_memberships_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: organization_users organization_users_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payment_records payment_records_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.payment_records
    ADD CONSTRAINT payment_records_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: permissions permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: prediction_results prediction_results_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.prediction_results
    ADD CONSTRAINT prediction_results_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.predictive_models(id) ON DELETE CASCADE;


--
-- Name: proof_of_delivery proof_of_delivery_trip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.proof_of_delivery
    ADD CONSTRAINT proof_of_delivery_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES public.trips(id);


--
-- Name: receipt_ocr_jobs receipt_ocr_jobs_expense_item_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.receipt_ocr_jobs
    ADD CONSTRAINT receipt_ocr_jobs_expense_item_fkey FOREIGN KEY (expense_item_id) REFERENCES public.expense_items(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id);


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: restore_jobs restore_jobs_backup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.restore_jobs
    ADD CONSTRAINT restore_jobs_backup_id_fkey FOREIGN KEY (backup_id) REFERENCES public.backups(id);


--
-- Name: review_items review_items_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.access_reviews(id) ON DELETE CASCADE;


--
-- Name: review_items review_items_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id);


--
-- Name: review_items review_items_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: review_items review_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: rollout_device_status rollout_device_status_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.rollout_device_status
    ADD CONSTRAINT rollout_device_status_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id);


--
-- Name: rollout_device_status rollout_device_status_rollout_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.rollout_device_status
    ADD CONSTRAINT rollout_device_status_rollout_id_fkey FOREIGN KEY (rollout_id) REFERENCES public.firmware_rollouts(id);


--
-- Name: route_optimization_jobs route_optimization_jobs_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_jobs
    ADD CONSTRAINT route_optimization_jobs_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.route_optimization_requests(id) ON DELETE CASCADE;


--
-- Name: route_optimization_requests route_optimization_requests_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_requests
    ADD CONSTRAINT route_optimization_requests_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: route_optimization_results route_optimization_results_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.route_optimization_results
    ADD CONSTRAINT route_optimization_results_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.route_optimization_requests(id) ON DELETE CASCADE;


--
-- Name: security_events security_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: security_history security_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.security_history
    ADD CONSTRAINT security_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: service_accounts service_accounts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.service_accounts
    ADD CONSTRAINT service_accounts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: shipments shipments_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: shipments shipments_trip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES public.trips(id);


--
-- Name: sla_metrics sla_metrics_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.sla_metrics
    ADD CONSTRAINT sla_metrics_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: sos_incidents sos_incidents_acknowledged_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.sos_incidents
    ADD CONSTRAINT sos_incidents_acknowledged_by_fkey FOREIGN KEY (acknowledged_by) REFERENCES public.users(id);


--
-- Name: sos_incidents sos_incidents_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.sos_incidents
    ADD CONSTRAINT sos_incidents_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id);


--
-- Name: sos_incidents sos_incidents_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.sos_incidents
    ADD CONSTRAINT sos_incidents_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: sos_incidents sos_incidents_trip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.sos_incidents
    ADD CONSTRAINT sos_incidents_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES public.trips(id);


--
-- Name: sos_incidents sos_incidents_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.sos_incidents
    ADD CONSTRAINT sos_incidents_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles_legacy(id);


--
-- Name: support_audit_log support_audit_log_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_audit_log
    ADD CONSTRAINT support_audit_log_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id);


--
-- Name: support_audit_log support_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_audit_log
    ADD CONSTRAINT support_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: support_ticket_attachments support_ticket_attachments_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_ticket_attachments
    ADD CONSTRAINT support_ticket_attachments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id);


--
-- Name: support_ticket_messages support_ticket_messages_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_ticket_messages
    ADD CONSTRAINT support_ticket_messages_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id);


--
-- Name: support_tickets support_tickets_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: support_tickets support_tickets_reporter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_reporter_id_fkey FOREIGN KEY (reporter_id) REFERENCES public.users(id);


--
-- Name: sync_jobs sync_jobs_erp_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.sync_jobs
    ADD CONSTRAINT sync_jobs_erp_config_id_fkey FOREIGN KEY (erp_config_id) REFERENCES public.erp_configs(id);


--
-- Name: telemetry telemetry_trip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry
    ADD CONSTRAINT telemetry_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES public.trips(id) ON DELETE CASCADE;


--
-- Name: threat_alerts threat_alerts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.threat_alerts
    ADD CONSTRAINT threat_alerts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: threat_alerts threat_alerts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.threat_alerts
    ADD CONSTRAINT threat_alerts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ticket_events ticket_events_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.ticket_events
    ADD CONSTRAINT ticket_events_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: trips trips_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: user_notes user_notes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_notes
    ADD CONSTRAINT user_notes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_notification_preferences user_notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_oidc_links user_oidc_links_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_oidc_links
    ADD CONSTRAINT user_oidc_links_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.oidc_providers(id) ON DELETE CASCADE;


--
-- Name: user_oidc_links user_oidc_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_oidc_links
    ADD CONSTRAINT user_oidc_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_organizations user_organizations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: user_organizations user_organizations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: vehicle_assignments vehicle_assignments_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_assignments
    ADD CONSTRAINT vehicle_assignments_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE SET NULL;


--
-- Name: vehicle_compliance vehicle_compliance_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_compliance
    ADD CONSTRAINT vehicle_compliance_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: vehicle_events vehicle_events_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_events
    ADD CONSTRAINT vehicle_events_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE RESTRICT;


--
-- Name: vehicle_financials vehicle_financials_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_financials
    ADD CONSTRAINT vehicle_financials_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: vehicle_inspections vehicle_inspections_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_inspections
    ADD CONSTRAINT vehicle_inspections_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: vehicle_inspections vehicle_inspections_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_inspections
    ADD CONSTRAINT vehicle_inspections_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.inspection_templates(id);


--
-- Name: vehicle_inspections vehicle_inspections_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_inspections
    ADD CONSTRAINT vehicle_inspections_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: vehicles_legacy vehicles_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles_legacy
    ADD CONSTRAINT vehicles_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: vehicles vehicles_parent_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_parent_vehicle_id_fkey FOREIGN KEY (parent_vehicle_id) REFERENCES public.vehicles(id) ON DELETE SET NULL;


--
-- Name: vehicles_legacy vehicles_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles_legacy
    ADD CONSTRAINT vehicles_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: vendor_payments vendor_payments_gst_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vendor_payments
    ADD CONSTRAINT vendor_payments_gst_invoice_id_fkey FOREIGN KEY (gst_invoice_id) REFERENCES public.gst_invoices(id);


--
-- Name: vendor_payments vendor_payments_tds_record_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vendor_payments
    ADD CONSTRAINT vendor_payments_tds_record_id_fkey FOREIGN KEY (tds_record_id) REFERENCES public.tds_records(id);


--
-- Name: vendor_payments vendor_payments_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vendor_payments
    ADD CONSTRAINT vendor_payments_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.fuel_vendors(id) ON DELETE RESTRICT;


--
-- Name: webhooks webhooks_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: work_order_parts work_order_parts_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.work_order_parts
    ADD CONSTRAINT work_order_parts_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.inventory_parts(id);


--
-- Name: work_order_parts work_order_parts_work_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.work_order_parts
    ADD CONSTRAINT work_order_parts_work_order_id_fkey FOREIGN KEY (work_order_id) REFERENCES public.work_orders(id) ON DELETE CASCADE;


--
-- Name: work_orders work_orders_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT work_orders_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: billing_accounting_exports accounting_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY accounting_tenant_policy ON public.billing_accounting_exports TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: analytics_access_logs; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.analytics_access_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: analytics_jobs; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.analytics_jobs ENABLE ROW LEVEL SECURITY;

--
-- Name: analytics_query_logs; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.analytics_query_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: analytics_query_plans; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.analytics_query_plans ENABLE ROW LEVEL SECURITY;

--
-- Name: analytics_quotas; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.analytics_quotas ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_customer_balances balances_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY balances_tenant_policy ON public.billing_customer_balances TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: billing_accounting_exports; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_accounting_exports ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_customer_balances; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_customer_balances ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_hardware_products; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_hardware_products ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_invoice_documents; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_invoice_documents ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_invoice_sequences; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_invoice_sequences ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_invoice_templates; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_invoice_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_revenue_schedules; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_revenue_schedules ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_subscriptions; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.billing_subscriptions ENABLE ROW LEVEL SECURITY;

--
-- Name: consumption_events; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.consumption_events ENABLE ROW LEVEL SECURITY;

--
-- Name: consumption_events consumption_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY consumption_tenant_policy ON public.consumption_events TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: billing_invoice_documents document_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY document_tenant_policy ON public.billing_invoice_documents TO flyfleet_app USING ((EXISTS ( SELECT 1
   FROM public.invoices i
  WHERE ((i.id = billing_invoice_documents.invoice_id) AND (i.org_id = public.get_current_org_id())))));


--
-- Name: driver_daily_stats; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.driver_daily_stats ENABLE ROW LEVEL SECURITY;

--
-- Name: driver_risk_events; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.driver_risk_events ENABLE ROW LEVEL SECURITY;

--
-- Name: fleet_hourly_stats; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.fleet_hourly_stats ENABLE ROW LEVEL SECURITY;

--
-- Name: gps_locations; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.gps_locations ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_hardware_products hardware_products_read_all; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY hardware_products_read_all ON public.billing_hardware_products FOR SELECT USING (true);


--
-- Name: materialized_fleet_reports; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.materialized_fleet_reports ENABLE ROW LEVEL SECURITY;

--
-- Name: model_deployments; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.model_deployments ENABLE ROW LEVEL SECURITY;

--
-- Name: obd_readings; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.obd_readings ENABLE ROW LEVEL SECURITY;

--
-- Name: organizations org_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY org_tenant_policy ON public.organizations TO flyfleet_app USING ((id = public.get_current_org_id())) WITH CHECK ((id = public.get_current_org_id()));


--
-- Name: organizations; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;

--
-- Name: prediction_results; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.prediction_results ENABLE ROW LEVEL SECURITY;

--
-- Name: predictive_models; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.predictive_models ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_revenue_schedules revenue_schedule_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY revenue_schedule_tenant_policy ON public.billing_revenue_schedules TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: billing_invoice_sequences sequences_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY sequences_tenant_policy ON public.billing_invoice_sequences TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: sla_metrics; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.sla_metrics ENABLE ROW LEVEL SECURITY;

--
-- Name: sla_metrics sla_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY sla_tenant_policy ON public.sla_metrics TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: billing_subscriptions subs_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY subs_tenant_policy ON public.billing_subscriptions TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: telemetry; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.telemetry ENABLE ROW LEVEL SECURITY;

--
-- Name: billing_invoice_templates template_read_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY template_read_policy ON public.billing_invoice_templates FOR SELECT TO flyfleet_app USING (true);


--
-- Name: analytics_access_logs tenant_isolation_access_logs; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY tenant_isolation_access_logs ON public.analytics_access_logs USING ((organization_id = (NULLIF(current_setting('app.org_id'::text, true), ''::text))::uuid));


--
-- Name: model_deployments tenant_isolation_deployments; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY tenant_isolation_deployments ON public.model_deployments USING ((organization_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: driver_daily_stats tenant_isolation_driver_stats; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY tenant_isolation_driver_stats ON public.driver_daily_stats USING ((organization_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: fleet_hourly_stats tenant_isolation_fleet_stats; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY tenant_isolation_fleet_stats ON public.fleet_hourly_stats USING ((organization_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: analytics_jobs tenant_isolation_jobs; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY tenant_isolation_jobs ON public.analytics_jobs USING ((organization_id = (NULLIF(current_setting('app.org_id'::text, true), ''::text))::uuid));


--
-- Name: materialized_fleet_reports tenant_isolation_materialized_reports; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY tenant_isolation_materialized_reports ON public.materialized_fleet_reports USING ((organization_id = (NULLIF(current_setting('app.org_id'::text, true), ''::text))::uuid));


--
-- Name: predictive_models tenant_isolation_models; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY tenant_isolation_models ON public.predictive_models USING ((organization_id = (NULLIF(current_setting('app.org_id'::text, true), ''::text))::uuid));


--
-- Name: analytics_query_logs tenant_isolation_query_logs; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY tenant_isolation_query_logs ON public.analytics_query_logs USING ((organization_id = (NULLIF(current_setting('app.org_id'::text, true), ''::text))::uuid));


--
-- Name: analytics_query_plans tenant_isolation_query_plans; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY tenant_isolation_query_plans ON public.analytics_query_plans USING ((organization_id = (NULLIF(current_setting('app.org_id'::text, true), ''::text))::uuid));


--
-- Name: analytics_quotas tenant_isolation_quotas; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY tenant_isolation_quotas ON public.analytics_quotas USING ((organization_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: prediction_results tenant_isolation_results; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY tenant_isolation_results ON public.prediction_results USING ((organization_id = (NULLIF(current_setting('app.org_id'::text, true), ''::text))::uuid));


--
-- Name: driver_risk_events tenant_isolation_risk_events; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY tenant_isolation_risk_events ON public.driver_risk_events USING ((organization_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: vehicle_daily_stats tenant_isolation_vehicle_stats; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY tenant_isolation_vehicle_stats ON public.vehicle_daily_stats USING ((organization_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: trips trip_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY trip_tenant_policy ON public.trips TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: trips; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.trips ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: vehicle_daily_stats; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.vehicle_daily_stats ENABLE ROW LEVEL SECURITY;

--
-- Name: vehicles_legacy vehicle_tenant_policy; Type: POLICY; Schema: public; Owner: fleet_user
--

CREATE POLICY vehicle_tenant_policy ON public.vehicles_legacy TO flyfleet_app USING ((org_id = public.get_current_org_id())) WITH CHECK ((org_id = public.get_current_org_id()));


--
-- Name: vehicles_legacy; Type: ROW SECURITY; Schema: public; Owner: fleet_user
--

ALTER TABLE public.vehicles_legacy ENABLE ROW LEVEL SECURITY;

--
-- Name: TABLE billing_accounting_exports; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_accounting_exports TO flyfleet_app;


--
-- Name: TABLE billing_coupons; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_coupons TO flyfleet_app;


--
-- Name: TABLE billing_credit_transactions; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT ON TABLE public.billing_credit_transactions TO flyfleet_app;


--
-- Name: TABLE billing_customer_balances; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_customer_balances TO flyfleet_app;


--
-- Name: TABLE billing_invoice_documents; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.billing_invoice_documents TO flyfleet_app;


--
-- Name: TABLE billing_invoice_sequences; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_invoice_sequences TO flyfleet_app;


--
-- Name: TABLE billing_invoice_templates; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.billing_invoice_templates TO flyfleet_app;


--
-- Name: TABLE billing_plans; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_plans TO flyfleet_app;


--
-- Name: TABLE billing_pricing_components; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_pricing_components TO flyfleet_app;


--
-- Name: TABLE billing_recognized_revenue; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT ON TABLE public.billing_recognized_revenue TO flyfleet_app;


--
-- Name: TABLE billing_revenue_schedules; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_revenue_schedules TO flyfleet_app;


--
-- Name: TABLE billing_subscriptions; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.billing_subscriptions TO flyfleet_app;


--
-- Name: TABLE billing_tax_rates; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT ON TABLE public.billing_tax_rates TO flyfleet_app;


--
-- Name: TABLE billing_tax_regions; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT ON TABLE public.billing_tax_regions TO flyfleet_app;


--
-- Name: TABLE consumption_events; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.consumption_events TO flyfleet_app;


--
-- Name: TABLE organizations; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.organizations TO flyfleet_app;


--
-- Name: TABLE sla_metrics; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT ON TABLE public.sla_metrics TO flyfleet_app;


--
-- Name: TABLE telemetry; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.telemetry TO flyfleet_app;


--
-- Name: TABLE trips; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.trips TO flyfleet_app;


--
-- Name: TABLE usage_meters; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.usage_meters TO flyfleet_app;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.users TO flyfleet_app;


--
-- Name: TABLE vehicles_legacy; Type: ACL; Schema: public; Owner: fleet_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vehicles_legacy TO flyfleet_app;


--
-- Name: finance_dashboard_metrics; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: fleet_user
--

REFRESH MATERIALIZED VIEW public.finance_dashboard_metrics;


--
-- Name: finance_dashboard_summary; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: fleet_user
--

REFRESH MATERIALIZED VIEW public.finance_dashboard_summary;


--
-- PostgreSQL database dump complete
--

\unrestrict bhuXobS3vooURxyMZT5cMTMMh8ez6NNKwziEnO1B481KlPzpkB2hSFbixrBVjol

