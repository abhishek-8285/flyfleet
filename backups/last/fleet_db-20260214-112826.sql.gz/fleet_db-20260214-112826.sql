--
-- PostgreSQL database dump
--

\restrict 41FY1SYLeJ9IvyyK4XRikSz4PFAjxd0ASrC4C7ZukZ0s2RYxjk9BP5fVrtGx5BZ

-- Dumped from database version 15.15
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: maintenance_type; Type: TYPE; Schema: public; Owner: fleet_user
--

CREATE TYPE public.maintenance_type AS ENUM (
    'preventive',
    'corrective',
    'inspection',
    'breakdown'
);


ALTER TYPE public.maintenance_type OWNER TO fleet_user;

--
-- Name: work_order_priority; Type: TYPE; Schema: public; Owner: fleet_user
--

CREATE TYPE public.work_order_priority AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'CRITICAL'
);


ALTER TYPE public.work_order_priority OWNER TO fleet_user;

--
-- Name: work_order_status; Type: TYPE; Schema: public; Owner: fleet_user
--

CREATE TYPE public.work_order_status AS ENUM (
    'OPEN',
    'IN_PROGRESS',
    'ON_HOLD',
    'COMPLETED'
);


ALTER TYPE public.work_order_status OWNER TO fleet_user;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO fleet_user;

--
-- Name: update_work_orders_updated_at(); Type: FUNCTION; Schema: public; Owner: fleet_user
--

CREATE FUNCTION public.update_work_orders_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_work_orders_updated_at() OWNER TO fleet_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_reviews; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.access_reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    due_date timestamp with time zone,
    total_users integer DEFAULT 0,
    reviewed_users integer DEFAULT 0,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT access_reviews_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'IN_PROGRESS'::character varying, 'COMPLETED'::character varying])::text[])))
);


ALTER TABLE public.access_reviews OWNER TO fleet_user;

--
-- Name: alert_rules; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.alert_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    description text,
    severity character varying(20) DEFAULT 'warning'::character varying,
    conditions jsonb NOT NULL,
    actions jsonb,
    vehicles jsonb,
    driver_ids jsonb,
    enabled boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.alert_rules OWNER TO fleet_user;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.alerts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    rule_id uuid,
    type character varying(50) NOT NULL,
    severity character varying(20) DEFAULT 'warning'::character varying,
    vehicle_id uuid,
    driver_id uuid,
    "timestamp" timestamp with time zone DEFAULT now(),
    location jsonb,
    details jsonb,
    status character varying(20) DEFAULT 'new'::character varying,
    notes text,
    acknowledged_by uuid,
    acknowledged_at timestamp with time zone,
    resolved_by uuid,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.alerts OWNER TO fleet_user;

--
-- Name: api_clients; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.api_clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    client_id character varying(100) NOT NULL,
    client_secret_hash text NOT NULL,
    name character varying(255) NOT NULL,
    scopes text[] DEFAULT '{}'::text[],
    expiry timestamp with time zone,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.api_clients OWNER TO fleet_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    resource character varying(100) NOT NULL,
    details jsonb,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    module character varying(100),
    entity_id character varying(100),
    before_state jsonb,
    after_state jsonb,
    metadata jsonb,
    severity character varying(20) DEFAULT 'info'::character varying,
    status character varying(20) DEFAULT 'success'::character varying,
    org_id uuid
);


ALTER TABLE public.audit_logs OWNER TO fleet_user;

--
-- Name: audit_policies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.audit_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    retention_years integer DEFAULT 7,
    archive_policy character varying(100) DEFAULT 'MOVE_TO_COLD_STORAGE_1Y'::character varying,
    masking_rules jsonb DEFAULT '["credit_card", "ssn", "phone", "email"]'::jsonb,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_policies OWNER TO fleet_user;

--
-- Name: audit_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.audit_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    retention_days_online integer DEFAULT 90,
    retention_days_archival integer DEFAULT 2555,
    masking_rules jsonb DEFAULT '["password", "secret", "token", "phone", "email_local"]'::jsonb,
    tracked_event_types jsonb DEFAULT '["MFA_POLICY_UPDATE", "MFA_EXCEPTION_GRANT", "MFA_OVERRIDE_TOGGLE", "LOGIN_SUCCESS", "LOGIN_FAILED"]'::jsonb,
    alert_on_critical boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_settings OWNER TO fleet_user;

--
-- Name: auth_tokens; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.auth_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    access_token text NOT NULL,
    refresh_token text NOT NULL,
    device_id character varying(255),
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    ip_address character varying(45),
    user_agent text,
    last_active timestamp with time zone DEFAULT now(),
    is_active boolean DEFAULT true
);


ALTER TABLE public.auth_tokens OWNER TO fleet_user;

--
-- Name: backup_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.backup_logs (
    id integer NOT NULL,
    backup_id uuid,
    action character varying(50) NOT NULL,
    result character varying(20) NOT NULL,
    actor character varying(255),
    message text,
    "timestamp" timestamp with time zone DEFAULT now()
);


ALTER TABLE public.backup_logs OWNER TO fleet_user;

--
-- Name: backup_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: fleet_user
--

CREATE SEQUENCE public.backup_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_logs_id_seq OWNER TO fleet_user;

--
-- Name: backup_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleet_user
--

ALTER SEQUENCE public.backup_logs_id_seq OWNED BY public.backup_logs.id;


--
-- Name: backup_storage_pools; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.backup_storage_pools (
    id integer NOT NULL,
    provider character varying(50) NOT NULL,
    bucket character varying(255) NOT NULL,
    region character varying(50),
    tier character varying(50) DEFAULT 'STANDARD'::character varying,
    encryption_enabled boolean DEFAULT true,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.backup_storage_pools OWNER TO fleet_user;

--
-- Name: backup_storage_pools_id_seq; Type: SEQUENCE; Schema: public; Owner: fleet_user
--

CREATE SEQUENCE public.backup_storage_pools_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_storage_pools_id_seq OWNER TO fleet_user;

--
-- Name: backup_storage_pools_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleet_user
--

ALTER SEQUENCE public.backup_storage_pools_id_seq OWNED BY public.backup_storage_pools.id;


--
-- Name: backups; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.backups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    backup_type character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'SCHEDULED'::character varying NOT NULL,
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    duration_seconds integer,
    size_bytes bigint,
    location character varying(255),
    retention_days integer DEFAULT 30,
    checksum character varying(255),
    initiated_by character varying(255),
    remarks text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.backups OWNER TO fleet_user;

--
-- Name: bulk_config; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.bulk_config (
    organization_id uuid NOT NULL,
    max_records_per_file integer DEFAULT 5000,
    concurrent_threads integer DEFAULT 4,
    retention_months integer DEFAULT 6,
    mandatory_fields jsonb DEFAULT '["vin", "registration_no", "make", "model_year"]'::jsonb,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.bulk_config OWNER TO fleet_user;

--
-- Name: bulk_job_records; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.bulk_job_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id uuid NOT NULL,
    row_number integer NOT NULL,
    record_data jsonb,
    status character varying(50) NOT NULL,
    error_message text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT bulk_job_records_status_check CHECK (((status)::text = ANY ((ARRAY['success'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.bulk_job_records OWNER TO fleet_user;

--
-- Name: bulk_jobs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.bulk_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    file_name character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    total_records integer DEFAULT 0,
    success_count integer DEFAULT 0,
    failed_count integer DEFAULT 0,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    retry_count integer DEFAULT 0,
    CONSTRAINT bulk_jobs_status_check CHECK (((status)::text = ANY ((ARRAY['processing'::character varying, 'completed'::character varying, 'failed'::character varying, 'partial_success'::character varying])::text[])))
);


ALTER TABLE public.bulk_jobs OWNER TO fleet_user;

--
-- Name: device_commands; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_id uuid,
    org_id uuid,
    command character varying(100) NOT NULL,
    category character varying(50),
    params jsonb,
    status character varying(20) DEFAULT 'pending'::character varying,
    result jsonb,
    error_message text,
    created_by uuid,
    sent_at timestamp with time zone,
    executed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.device_commands OWNER TO fleet_user;

--
-- Name: device_diagnostics_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_diagnostics_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_id uuid,
    org_id uuid,
    log_type character varying(50),
    source character varying(50),
    message text,
    metadata jsonb,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.device_diagnostics_logs OWNER TO fleet_user;

--
-- Name: device_firmware_status; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_firmware_status (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_id uuid,
    rollout_id uuid,
    status character varying(20) DEFAULT 'pending'::character varying,
    progress integer DEFAULT 0,
    error_message text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.device_firmware_status OWNER TO fleet_user;

--
-- Name: device_telemetry; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.device_telemetry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_id uuid,
    org_id uuid,
    payload jsonb NOT NULL,
    packet_type character varying(50),
    raw_hex text,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.device_telemetry OWNER TO fleet_user;

--
-- Name: devices; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    vehicle_id uuid,
    serial_number character varying(100) NOT NULL,
    type character varying(50) DEFAULT 'gps'::character varying,
    status character varying(20) DEFAULT 'active'::character varying,
    last_ping_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    firmware_version character varying(50),
    battery_level integer,
    signal_strength integer,
    hardware_revision character varying(20),
    last_heartbeat timestamp with time zone,
    model character varying(50),
    manufacturer character varying(50)
);


ALTER TABLE public.devices OWNER TO fleet_user;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    doc_number character varying(100) NOT NULL,
    issue_date date NOT NULL,
    expiry_date date NOT NULL,
    file_url text,
    status character varying(20) DEFAULT 'pending'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.documents OWNER TO fleet_user;

--
-- Name: TABLE documents; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.documents IS 'Stores compliance documents associated with vehicles';


--
-- Name: COLUMN documents.metadata; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON COLUMN public.documents.metadata IS 'Flexible JSON storage for document-specific attributes';


--
-- Name: dr_restore_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.dr_restore_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    restore_id uuid,
    level character varying(10),
    module character varying(50),
    message text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.dr_restore_logs OWNER TO fleet_user;

--
-- Name: dr_restores; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.dr_restores (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    backup_id uuid NOT NULL,
    restore_type character varying(20) NOT NULL,
    target_env character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    initiated_by character varying(255),
    duration_seconds integer,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.dr_restores OWNER TO fleet_user;

--
-- Name: driver_behavior; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_behavior (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    driver_id uuid NOT NULL,
    org_id uuid NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    score double precision,
    safety_score double precision,
    efficiency_score double precision,
    compliance_score double precision,
    harsh_accelerations integer DEFAULT 0,
    harsh_brakings integer DEFAULT 0,
    harsh_cornerings integer DEFAULT 0,
    speeding_incidents integer DEFAULT 0,
    phone_usage integer DEFAULT 0,
    seatbelt_violations integer DEFAULT 0,
    fuel_consumption double precision DEFAULT 0,
    distance_driven double precision DEFAULT 0,
    idle_time integer DEFAULT 0,
    eco_driving_score double precision,
    hours_of_service double precision,
    rest_periods integer,
    document_compliance boolean DEFAULT true,
    maintenance_adherence boolean DEFAULT true,
    night_driving_hours double precision DEFAULT 0,
    highway_percentage double precision DEFAULT 0,
    city_driving_percentage double precision DEFAULT 0,
    risk_level character varying(20),
    risk_factors jsonb,
    improvement_areas jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_behavior OWNER TO fleet_user;

--
-- Name: driver_incidents; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.driver_incidents (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    driver_id uuid NOT NULL,
    org_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    location jsonb,
    speed double precision,
    details jsonb,
    resolved boolean DEFAULT false,
    resolution_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.driver_incidents OWNER TO fleet_user;

--
-- Name: drivers; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.drivers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    full_name character varying(100) GENERATED ALWAYS AS ((((first_name)::text || ' '::text) || (last_name)::text)) STORED,
    email character varying(100) NOT NULL,
    phone character varying(20) NOT NULL,
    license_number character varying(50) NOT NULL,
    license_type character varying(20),
    license_expiry timestamp with time zone,
    license_authority character varying(100),
    date_of_birth timestamp with time zone,
    address jsonb,
    emergency_contact jsonb,
    status character varying(20) DEFAULT 'active'::character varying,
    current_vehicle_id uuid,
    current_trip_id uuid,
    joining_date timestamp with time zone DEFAULT now(),
    resignation_date timestamp with time zone,
    experience_years integer DEFAULT 0,
    rating double precision DEFAULT 5.0,
    total_trips integer DEFAULT 0,
    total_distance_km double precision DEFAULT 0,
    total_hours_driven double precision DEFAULT 0,
    behavior_score integer DEFAULT 100,
    documents jsonb,
    attendance_records jsonb,
    schedules jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


ALTER TABLE public.drivers OWNER TO fleet_user;

--
-- Name: entity_audit_history; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.entity_audit_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(100) NOT NULL,
    change_data jsonb NOT NULL,
    actor uuid,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.entity_audit_history OWNER TO fleet_user;

--
-- Name: evidence_exports; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.evidence_exports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    module character varying(50) NOT NULL,
    date_range_start timestamp with time zone,
    date_range_end timestamp with time zone,
    format character varying(20) DEFAULT 'pdf'::character varying,
    status character varying(20) DEFAULT 'processing'::character varying,
    requested_by uuid,
    file_url text,
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.evidence_exports OWNER TO fleet_user;

--
-- Name: firmware_packages; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.firmware_packages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    version character varying(50) NOT NULL,
    hardware_target character varying(50) NOT NULL,
    file_url text NOT NULL,
    file_size integer,
    checksum character varying(64),
    release_notes text,
    status character varying(20) DEFAULT 'draft'::character varying,
    is_critical boolean DEFAULT false,
    released_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.firmware_packages OWNER TO fleet_user;

--
-- Name: firmware_rollouts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.firmware_rollouts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    firmware_id uuid,
    org_id uuid,
    name character varying(100),
    device_group character varying(100),
    target_filter jsonb,
    total_devices integer DEFAULT 0,
    completed_devices integer DEFAULT 0,
    failed_devices integer DEFAULT 0,
    status character varying(20) DEFAULT 'scheduled'::character varying,
    rollout_strategy character varying(20) DEFAULT 'gradual'::character varying,
    max_concurrent integer DEFAULT 10,
    created_by uuid,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.firmware_rollouts OWNER TO fleet_user;

--
-- Name: geofences; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.geofences (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(20) NOT NULL,
    center jsonb,
    radius_meters integer,
    coordinates jsonb,
    route_polyline text,
    buffer_meters integer,
    entry_alert boolean DEFAULT true,
    exit_alert boolean DEFAULT true,
    speed_limit integer,
    vehicles jsonb,
    enabled boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.geofences OWNER TO fleet_user;

--
-- Name: global_notification_defaults; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.global_notification_defaults (
    id integer NOT NULL,
    email_enabled boolean DEFAULT true,
    sms_enabled boolean DEFAULT false,
    push_enabled boolean DEFAULT true,
    in_app_enabled boolean DEFAULT true,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.global_notification_defaults OWNER TO fleet_user;

--
-- Name: global_notification_defaults_id_seq; Type: SEQUENCE; Schema: public; Owner: fleet_user
--

CREATE SEQUENCE public.global_notification_defaults_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.global_notification_defaults_id_seq OWNER TO fleet_user;

--
-- Name: global_notification_defaults_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleet_user
--

ALTER SEQUENCE public.global_notification_defaults_id_seq OWNED BY public.global_notification_defaults.id;


--
-- Name: incident_comments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.incident_comments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ticket_id uuid NOT NULL,
    author_id uuid,
    author_name character varying(100),
    comment_type character varying(20) DEFAULT 'INTERNAL'::character varying,
    content text NOT NULL,
    is_private boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.incident_comments OWNER TO fleet_user;

--
-- Name: TABLE incident_comments; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.incident_comments IS 'Comments and history for support tickets';


--
-- Name: integration_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.integration_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    integration_id uuid,
    method character varying(10) NOT NULL,
    endpoint text NOT NULL,
    request_body jsonb,
    response_body jsonb,
    status_code integer,
    status character varying(20),
    duration_ms integer,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.integration_logs OWNER TO fleet_user;

--
-- Name: integrations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.integrations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(50) NOT NULL,
    provider character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    config jsonb DEFAULT '{}'::jsonb,
    last_sync timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.integrations OWNER TO fleet_user;

--
-- Name: inventory_parts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.inventory_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    part_number character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    stock_location character varying(100),
    quantity_available integer DEFAULT 0 NOT NULL,
    reorder_level integer DEFAULT 5 NOT NULL,
    unit_cost numeric(10,2) DEFAULT 0.00 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT inventory_parts_quantity_available_check CHECK ((quantity_available >= 0))
);


ALTER TABLE public.inventory_parts OWNER TO fleet_user;

--
-- Name: TABLE inventory_parts; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.inventory_parts IS 'Maintenance parts inventory';


--
-- Name: ip_rules; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.ip_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    cidr character varying(45) NOT NULL,
    action character varying(10) NOT NULL,
    description text,
    added_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT ip_rules_action_check CHECK (((action)::text = ANY ((ARRAY['ALLOW'::character varying, 'BLOCK'::character varying])::text[])))
);


ALTER TABLE public.ip_rules OWNER TO fleet_user;

--
-- Name: login_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.login_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    user_id uuid,
    email character varying(255),
    ip_address character varying(45),
    device text,
    browser text,
    location character varying(255),
    status character varying(20),
    risk_level character varying(20) DEFAULT 'low'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT login_events_status_check CHECK (((status)::text = ANY ((ARRAY['SUCCESS'::character varying, 'FAILED'::character varying, 'CHALLENGED'::character varying])::text[])))
);


ALTER TABLE public.login_events OWNER TO fleet_user;

--
-- Name: maintenance_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.maintenance_settings (
    organization_id uuid NOT NULL,
    sla_p1_hours integer DEFAULT 4 NOT NULL,
    sla_p2_hours integer DEFAULT 24 NOT NULL,
    sla_p3_hours integer DEFAULT 72 NOT NULL,
    low_stock_threshold integer DEFAULT 5 NOT NULL,
    approval_threshold numeric(10,2) DEFAULT 500.00 NOT NULL,
    auto_assign_enabled boolean DEFAULT false NOT NULL,
    notification_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.maintenance_settings OWNER TO fleet_user;

--
-- Name: TABLE maintenance_settings; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.maintenance_settings IS 'Organization maintenance configuration';


--
-- Name: mfa_codes; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    code character varying(10) NOT NULL,
    method character varying(50) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_codes OWNER TO fleet_user;

--
-- Name: mfa_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    event_type character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    method character varying(20),
    ip_address character varying(45),
    user_agent text,
    location character varying(255),
    details jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_events OWNER TO fleet_user;

--
-- Name: mfa_exceptions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_exceptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    reason text NOT NULL,
    granted_by uuid,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    start_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_exceptions OWNER TO fleet_user;

--
-- Name: mfa_failures; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_failures (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    method character varying(20),
    failure_reason text,
    ip_address character varying(45),
    location character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_failures OWNER TO fleet_user;

--
-- Name: mfa_lockouts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_lockouts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    reason character varying(255),
    locked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    unlocked_at timestamp with time zone,
    unlocked_by uuid
);


ALTER TABLE public.mfa_lockouts OWNER TO fleet_user;

--
-- Name: mfa_org_overrides; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_org_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    enabled boolean DEFAULT true,
    allowed_methods jsonb DEFAULT '["totp", "sms"]'::jsonb,
    max_attempts integer DEFAULT 5,
    lockout_minutes integer DEFAULT 30,
    remember_device_days integer DEFAULT 30,
    grace_period_days integer DEFAULT 7,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_org_overrides OWNER TO fleet_user;

--
-- Name: mfa_policies; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    require_mfa boolean DEFAULT false,
    allowed_methods jsonb DEFAULT '["totp", "sms"]'::jsonb,
    max_attempts integer DEFAULT 5,
    lockout_minutes integer DEFAULT 30,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    grace_period_days integer DEFAULT 7,
    remember_device_days integer DEFAULT 30,
    enforce_at_login boolean DEFAULT true,
    admin_only_mode boolean DEFAULT false,
    remember_device_allowed boolean DEFAULT true,
    mfa_challenge_timeout integer DEFAULT 60,
    version integer DEFAULT 1
);


ALTER TABLE public.mfa_policies OWNER TO fleet_user;

--
-- Name: mfa_policy_history; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_policy_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    policy_id uuid,
    org_id uuid,
    snapshot jsonb NOT NULL,
    changed_by uuid,
    change_reason text,
    version integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mfa_policy_history OWNER TO fleet_user;

--
-- Name: mfa_users; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.mfa_users (
    user_id uuid NOT NULL,
    org_id uuid,
    status character varying(20) DEFAULT 'DISABLED'::character varying,
    method character varying(50),
    trusted_devices_count integer DEFAULT 0,
    last_reset timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.mfa_users OWNER TO fleet_user;

--
-- Name: notification_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.notification_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    notification_id uuid NOT NULL,
    event_type character varying(50) NOT NULL,
    message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_events OWNER TO fleet_user;

--
-- Name: notification_logs; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.notification_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    correlation_id character varying(100),
    user_id uuid,
    user_email character varying(255),
    channel character varying(20) NOT NULL,
    type character varying(50) NOT NULL,
    subject text,
    body text,
    status character varying(20) NOT NULL,
    provider character varying(50),
    provider_response text,
    retry_count integer DEFAULT 0,
    max_retries integer DEFAULT 3,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_logs OWNER TO fleet_user;

--
-- Name: notification_preference_audit; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.notification_preference_audit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    changed_by uuid NOT NULL,
    old_values jsonb,
    new_values jsonb,
    change_reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.notification_preference_audit OWNER TO fleet_user;

--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.notification_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel character varying(20) NOT NULL,
    enabled boolean DEFAULT true,
    max_retries integer DEFAULT 3,
    priority character varying(20) DEFAULT 'STANDARD'::character varying,
    retention_months integer DEFAULT 6,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_settings OWNER TO fleet_user;

--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.notification_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    channel character varying(20) NOT NULL,
    language character varying(10) DEFAULT 'en'::character varying NOT NULL,
    subject text,
    body text,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_templates OWNER TO fleet_user;

--
-- Name: org_support_metrics; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.org_support_metrics (
    org_id uuid NOT NULL,
    open_tickets integer DEFAULT 0,
    resolved_tickets integer DEFAULT 0,
    avg_resolution_time interval,
    sla_breaches integer DEFAULT 0,
    critical_issues integer DEFAULT 0,
    last_calculated timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.org_support_metrics OWNER TO fleet_user;

--
-- Name: TABLE org_support_metrics; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.org_support_metrics IS 'Pre-calculated organization support metrics';


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    domain character varying(255),
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    default_theme character varying(20) DEFAULT 'light'::character varying,
    is_deleted boolean DEFAULT false,
    CONSTRAINT organizations_default_theme_check CHECK (((default_theme)::text = ANY ((ARRAY['light'::character varying, 'dark'::character varying, 'system'::character varying])::text[])))
);


ALTER TABLE public.organizations OWNER TO fleet_user;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    module character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    description text
);


ALTER TABLE public.permissions OWNER TO fleet_user;

--
-- Name: report_executions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.report_executions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    report_id uuid,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    duration_seconds integer,
    status character varying(20),
    error_message text,
    file_url text,
    file_size bigint,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.report_executions OWNER TO fleet_user;

--
-- Name: report_global_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.report_global_settings (
    id integer NOT NULL,
    max_concurrent_jobs integer DEFAULT 50,
    max_retry_attempts integer DEFAULT 3,
    retention_days integer DEFAULT 90,
    smtp_host character varying(255),
    smtp_port integer,
    smtp_user character varying(255),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.report_global_settings OWNER TO fleet_user;

--
-- Name: report_global_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: fleet_user
--

CREATE SEQUENCE public.report_global_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.report_global_settings_id_seq OWNER TO fleet_user;

--
-- Name: report_global_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleet_user
--

ALTER SEQUENCE public.report_global_settings_id_seq OWNED BY public.report_global_settings.id;


--
-- Name: report_recipients; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.report_recipients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    report_id uuid,
    email character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.report_recipients OWNER TO fleet_user;

--
-- Name: review_items; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.review_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    review_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid,
    current_status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    reviewer_id uuid,
    reviewed_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT review_items_current_status_check CHECK (((current_status)::text = ANY ((ARRAY['PENDING'::character varying, 'APPROVED'::character varying, 'REVOKED'::character varying])::text[])))
);


ALTER TABLE public.review_items OWNER TO fleet_user;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.role_permissions (
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO fleet_user;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    is_system boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    organization_id uuid
);


ALTER TABLE public.roles OWNER TO fleet_user;

--
-- Name: scheduled_reports; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.scheduled_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    report_type character varying(100) NOT NULL,
    format character varying(20) NOT NULL,
    frequency character varying(50) NOT NULL,
    cron_expression character varying(100) NOT NULL,
    delivery_time time without time zone NOT NULL,
    timezone character varying(50) NOT NULL,
    filters jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_by uuid NOT NULL,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.scheduled_reports OWNER TO fleet_user;

--
-- Name: security_events; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.security_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    event_type character varying(100) NOT NULL,
    ip_address character varying(45),
    user_agent text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.security_events OWNER TO fleet_user;

--
-- Name: support_audit_log; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.support_audit_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ticket_id uuid,
    user_id uuid,
    action character varying(100) NOT NULL,
    old_value jsonb,
    new_value jsonb,
    details text,
    created_at timestamp with time zone DEFAULT now(),
    ip_address character varying(45)
);


ALTER TABLE public.support_audit_log OWNER TO fleet_user;

--
-- Name: TABLE support_audit_log; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.support_audit_log IS 'Audit trail for all support operations';


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.support_tickets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ticket_id character varying(50) NOT NULL,
    org_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'OPEN'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'MEDIUM'::character varying NOT NULL,
    category character varying(100),
    assigned_to uuid,
    reporter_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone,
    sla_deadline timestamp with time zone,
    tags jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.support_tickets OWNER TO fleet_user;

--
-- Name: TABLE support_tickets; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.support_tickets IS 'Core support ticket records';


--
-- Name: telemetry; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.telemetry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    trip_id uuid,
    latitude numeric(10,8),
    longitude numeric(11,8),
    speed numeric(6,2),
    heading numeric(5,2),
    event_type character varying(50),
    event_time timestamp without time zone DEFAULT now()
);


ALTER TABLE public.telemetry OWNER TO fleet_user;

--
-- Name: threat_alerts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.threat_alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    ip character varying(45),
    user_id uuid,
    description text,
    status character varying(20) DEFAULT 'open'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.threat_alerts OWNER TO fleet_user;

--
-- Name: trip_settings; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.trip_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    retention_period integer DEFAULT 36,
    policies jsonb DEFAULT '{}'::jsonb,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.trip_settings OWNER TO fleet_user;

--
-- Name: trips; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.trips (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    vehicle_id uuid,
    driver_id uuid,
    status character varying(50) DEFAULT 'planned'::character varying NOT NULL,
    title character varying(255),
    description text,
    planned_route jsonb,
    actual_route jsonb,
    waypoints jsonb,
    start_location jsonb,
    end_location jsonb,
    estimated_distance_km numeric(10,2),
    distance numeric(10,2),
    estimated_duration_min integer,
    actual_duration_min integer,
    fuel_consumed_liters numeric(10,2) DEFAULT 0,
    idling_time_minutes integer DEFAULT 0,
    cargo_details jsonb,
    pod_documents jsonb,
    scheduled_start timestamp with time zone,
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    customer_name character varying(255),
    customer_phone character varying(50),
    customer_email character varying(255),
    cancellation_reason text,
    events jsonb,
    is_deleted boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    trip_id character varying(50),
    actual_distance_km double precision DEFAULT 0,
    started_at timestamp without time zone,
    ended_at timestamp without time zone
);


ALTER TABLE public.trips OWNER TO fleet_user;

--
-- Name: user_notification_preferences; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.user_notification_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    email_enabled boolean DEFAULT true NOT NULL,
    sms_enabled boolean DEFAULT false NOT NULL,
    push_enabled boolean DEFAULT true NOT NULL,
    in_app_enabled boolean DEFAULT true NOT NULL,
    last_modified_by uuid NOT NULL,
    last_modified_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_notification_preferences OWNER TO fleet_user;

--
-- Name: user_organizations; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.user_organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    role character varying(50) DEFAULT 'member'::character varying,
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_organizations OWNER TO fleet_user;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_by uuid,
    assigned_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_roles OWNER TO fleet_user;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    session_id character varying(100) NOT NULL,
    ip_address character varying(45),
    user_agent text,
    device_info jsonb,
    login_time timestamp with time zone DEFAULT now(),
    last_activity timestamp with time zone DEFAULT now(),
    logout_time timestamp with time zone,
    is_active boolean DEFAULT true,
    location jsonb
);


ALTER TABLE public.user_sessions OWNER TO fleet_user;

--
-- Name: TABLE user_sessions; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.user_sessions IS 'User session tracking for support investigations';


--
-- Name: users; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash text NOT NULL,
    name character varying(255),
    phone character varying(50),
    mfa_enabled boolean DEFAULT false,
    mfa_secret text,
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    theme character varying(20) DEFAULT 'light'::character varying,
    failed_logins integer DEFAULT 0,
    locked_until timestamp with time zone,
    verified boolean DEFAULT false,
    theme_updated_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    role_id uuid
);


ALTER TABLE public.users OWNER TO fleet_user;

--
-- Name: vehicle_assignments; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicle_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid,
    driver_id uuid,
    device_id uuid,
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    ended_at timestamp with time zone,
    is_active boolean DEFAULT true
);


ALTER TABLE public.vehicle_assignments OWNER TO fleet_user;

--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.vehicles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_id uuid NOT NULL,
    license_plate character varying(20) NOT NULL,
    model character varying(50) NOT NULL,
    make character varying(50) NOT NULL,
    year integer NOT NULL,
    color character varying(30),
    status character varying(20) DEFAULT 'active'::character varying,
    capacity integer DEFAULT 1,
    fuel_type character varying(20),
    vin character varying(50),
    registration character varying(50),
    insurance character varying(50),
    odometer bigint DEFAULT 0,
    last_service timestamp with time zone,
    current_driver_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    vehicle_no character varying(50),
    service_due timestamp with time zone,
    notes text
);


ALTER TABLE public.vehicles OWNER TO fleet_user;

--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    url text NOT NULL,
    events text[] DEFAULT '{}'::text[],
    secret character varying(255),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.webhooks OWNER TO fleet_user;

--
-- Name: work_order_parts; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.work_order_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    work_order_id uuid NOT NULL,
    part_id uuid NOT NULL,
    quantity integer NOT NULL,
    unit_cost numeric(10,2) NOT NULL,
    total_cost numeric(10,2) GENERATED ALWAYS AS (((quantity)::numeric * unit_cost)) STORED,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT work_order_parts_quantity_check CHECK ((quantity > 0))
);


ALTER TABLE public.work_order_parts OWNER TO fleet_user;

--
-- Name: TABLE work_order_parts; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.work_order_parts IS 'Parts assigned to work orders';


--
-- Name: work_orders; Type: TABLE; Schema: public; Owner: fleet_user
--

CREATE TABLE public.work_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    maintenance_type public.maintenance_type DEFAULT 'corrective'::public.maintenance_type NOT NULL,
    priority public.work_order_priority DEFAULT 'MEDIUM'::public.work_order_priority NOT NULL,
    status public.work_order_status DEFAULT 'OPEN'::public.work_order_status NOT NULL,
    assigned_to uuid,
    scheduled_date timestamp with time zone,
    completed_date timestamp with time zone,
    estimated_cost numeric(10,2) DEFAULT 0.00,
    actual_cost numeric(10,2) DEFAULT 0.00,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.work_orders OWNER TO fleet_user;

--
-- Name: TABLE work_orders; Type: COMMENT; Schema: public; Owner: fleet_user
--

COMMENT ON TABLE public.work_orders IS 'Fleet maintenance work orders';


--
-- Name: backup_logs id; Type: DEFAULT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backup_logs ALTER COLUMN id SET DEFAULT nextval('public.backup_logs_id_seq'::regclass);


--
-- Name: backup_storage_pools id; Type: DEFAULT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backup_storage_pools ALTER COLUMN id SET DEFAULT nextval('public.backup_storage_pools_id_seq'::regclass);


--
-- Name: global_notification_defaults id; Type: DEFAULT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.global_notification_defaults ALTER COLUMN id SET DEFAULT nextval('public.global_notification_defaults_id_seq'::regclass);


--
-- Name: report_global_settings id; Type: DEFAULT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.report_global_settings ALTER COLUMN id SET DEFAULT nextval('public.report_global_settings_id_seq'::regclass);


--
-- Data for Name: access_reviews; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.access_reviews (id, org_id, title, status, due_date, total_users, reviewed_users, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alert_rules; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.alert_rules (id, org_id, name, type, description, severity, conditions, actions, vehicles, driver_ids, enabled, created_by, created_at, updated_at) FROM stdin;
d61fdeee-4e24-4190-bf51-3939e9089f86	00000000-0000-0000-0000-000000000012	Max Speed Limit	overspeed	Alert when speed exceeds 80 km/h	critical	{"threshold": 80}	[{"type": "email", "delay": 0, "target": "admin@delta.io"}]	\N	\N	t	0f68a2b7-5a20-4a31-aed5-f45361818da1	2026-02-12 09:49:33.559304+00	2026-02-12 09:49:33.559304+00
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.alerts (id, org_id, rule_id, type, severity, vehicle_id, driver_id, "timestamp", location, details, status, notes, acknowledged_by, acknowledged_at, resolved_by, resolved_at, created_at, updated_at) FROM stdin;
2f6eeda7-06c9-4af1-9a7f-b1cbfa770c52	1476a987-76ad-4963-b64a-01a71eb739ca	\N	overspeed	critical	\N	\N	2026-02-07 19:21:30.775808+00	\N	{"limit": 80, "speed": 110}	new	\N	\N	\N	\N	\N	2026-02-07 19:21:30.775808+00	2026-02-07 19:21:30.775808+00
09d78e51-e841-4caa-83d3-8a97aaff8b4e	1476a987-76ad-4963-b64a-01a71eb739ca	\N	geofence	warning	\N	\N	2026-02-07 19:21:30.775808+00	\N	{"zone": "Restricted Area A"}	new	\N	\N	\N	\N	\N	2026-02-07 19:21:30.775808+00	2026-02-07 19:21:30.775808+00
0fa15518-3413-4eb2-b3bf-d58af28c8194	00000000-0000-0000-0000-000000000012	d61fdeee-4e24-4190-bf51-3939e9089f86	overspeed	critical	9826fc4c-375e-47fd-a831-a57c00c3a4ae	\N	2026-02-12 09:31:43.440465+00	{"address": "Hosur Road, Bangalore", "latitude": 12.9716, "longitude": 77.5946}	{"limit": 80, "speed": 85, "message": "Vehicle DLT-001 exceeded speed limit (85 km/h)"}	new	\N	\N	\N	\N	\N	2026-02-12 09:31:43.440465+00	2026-02-12 09:31:43.440465+00
8f7279bb-491f-417c-8d52-d82e7e2f952b	00000000-0000-0000-0000-000000000012	d61fdeee-4e24-4190-bf51-3939e9089f86	overspeed	critical	9826fc4c-375e-47fd-a831-a57c00c3a4ae	\N	2026-02-12 18:37:29.630312+00	{"address": "Hosur Road, Bangalore", "latitude": 12.9716, "longitude": 77.5946}	{"limit": 80, "speed": 85, "message": "Vehicle DLT-001 exceeded speed limit (85 km/h)"}	new	\N	\N	\N	\N	\N	2026-02-12 18:37:29.630312+00	2026-02-12 18:37:29.630312+00
\.


--
-- Data for Name: api_clients; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.api_clients (id, org_id, client_id, client_secret_hash, name, scopes, expiry, status, created_at, updated_at) FROM stdin;
d8d476a9-1d9a-4746-b901-c2f73ee61a37	1476a987-76ad-4963-b64a-01a71eb739ca	cli_19ba1e00ead4451b	$2a$10$RRdEsxZWo0s3cvdRUB/M8eWnQ6TTO77fGPSJCM5IOwazCN6fCdOKq	E2E Test Client	{read:fleet}	\N	active	2026-02-09 14:49:02.536052+00	2026-02-09 14:49:02.536052+00
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.audit_logs (id, user_id, action, resource, details, ip_address, user_agent, created_at, module, entity_id, before_state, after_state, metadata, severity, status, org_id) FROM stdin;
\.


--
-- Data for Name: audit_policies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.audit_policies (id, org_id, retention_years, archive_policy, masking_rules, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.audit_settings (id, org_id, retention_days_online, retention_days_archival, masking_rules, tracked_event_types, alert_on_critical, updated_at) FROM stdin;
\.


--
-- Data for Name: auth_tokens; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.auth_tokens (id, user_id, access_token, refresh_token, device_id, expires_at, created_at, ip_address, user_agent, last_active, is_active) FROM stdin;
286f4a59-1fe5-446f-8dff-58b53487557d	4cb4efd1-0717-41ea-a7c7-c74faa999cbc	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA0NzY0NTAsInVzZXJfaWQiOiI0Y2I0ZWZkMS0wNzE3LTQxZWEtYTdjNy1jNzRmYWE5OTljYmMifQ.SXW5g6ahNNcRc4iSyOUbNKFnkr1MmgiJ8sySlQXmy0E	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwODAzNTAsInVzZXJfaWQiOiI0Y2I0ZWZkMS0wNzE3LTQxZWEtYTdjNy1jNzRmYWE5OTljYmMifQ.HTnecueI8Wa-YIXAW3bc-OCR2EB55kT8fSvzpk8goYM	\N	2026-02-14 14:45:50.70623+00	2026-02-07 14:45:50.707545+00	\N	\N	2026-02-09 14:08:18.096237+00	t
fafad338-6783-4ebf-bd05-e8d71d7b80c3	4cb4efd1-0717-41ea-a7c7-c74faa999cbc	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA0NzcxMTEsInVzZXJfaWQiOiI0Y2I0ZWZkMS0wNzE3LTQxZWEtYTdjNy1jNzRmYWE5OTljYmMifQ.bYQ7Zhfemk3fzHXtAJbzBZLI6gsdRv2q4DiZHBQV7kQ	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwODEwMTEsInVzZXJfaWQiOiI0Y2I0ZWZkMS0wNzE3LTQxZWEtYTdjNy1jNzRmYWE5OTljYmMifQ.LuCTSZxGIHBeLhsn8WZN3r6TAjhyK1a-81ed-aYKw9A	\N	2026-02-14 14:56:51.006107+00	2026-02-07 14:56:51.011212+00	\N	\N	2026-02-09 14:08:18.096237+00	t
371f1b95-ddaf-425e-8e5e-0a679593589a	fab6254c-1fdf-44d5-b323-feda37817aa2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA0OTA3NDUsInVzZXJfaWQiOiJmYWI2MjU0Yy0xZmRmLTQ0ZDUtYjMyMy1mZWRhMzc4MTdhYTIifQ.iFrN0WRSAzsWwycej7ADXGvjTfERXJ1ZxdTZOvEMiEM	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwOTQ2NDUsInVzZXJfaWQiOiJmYWI2MjU0Yy0xZmRmLTQ0ZDUtYjMyMy1mZWRhMzc4MTdhYTIifQ.Vd1gko83974TeOdagdXFbCPQCtcSmLijn5HUZ5k8sqs	\N	2026-02-14 18:44:05.85556+00	2026-02-07 18:44:05.861464+00	\N	\N	2026-02-09 14:08:18.096237+00	t
f34e7bce-f782-4d0d-bd29-273ffad5b264	fab6254c-1fdf-44d5-b323-feda37817aa2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA0OTA4OTEsInVzZXJfaWQiOiJmYWI2MjU0Yy0xZmRmLTQ0ZDUtYjMyMy1mZWRhMzc4MTdhYTIifQ.YLlKgO95MzZgpMBh2jlcwbpmF62zhOqpyWhdiV5BEFQ	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwOTQ3OTEsInVzZXJfaWQiOiJmYWI2MjU0Yy0xZmRmLTQ0ZDUtYjMyMy1mZWRhMzc4MTdhYTIifQ.y-VphkvUj9Ff2vYKzNlHwHWu_Eqs-_H3HyonnHsTRew	\N	2026-02-14 18:46:31.882302+00	2026-02-07 18:46:31.887722+00	\N	\N	2026-02-09 14:08:18.096237+00	t
89bbdcbc-925d-46b2-b98d-840fde9e09c2	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MjIyNzcsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.0NyXvGFZolebH9p6VoyQV6vD8JeKpxmeeyVe3f9Vxvs	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMjYxNzcsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Ro2wzSJiLKxnndDDUHqYVHt7k78-iV2IYHHeWVeaILw	\N	2026-02-17 11:02:57.438935+00	2026-02-10 11:02:57.443938+00	\N	\N	2026-02-10 11:02:57.443938+00	t
f734eb57-2ca0-4aa2-aef6-35a7246e1868	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MjIzNjQsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.QSzO6cHRaQym8cVL8-xqR3MCcrLn-E3-k_XTG26jb9U	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMjYyNjQsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.aA3IQ2bjSqTEFg_UrGYgv1BDjLZQcCbC9kFT5I61r3o	\N	2026-02-17 11:04:24.929905+00	2026-02-10 11:04:24.931059+00	\N	\N	2026-02-10 11:04:24.931059+00	t
4cccadef-062e-4559-872f-3e839e44c64e	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MjI0MDMsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.8B77bykZUdshCrmagVZgc5xsBB6eRX8DtywwdtVtqmY	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMjYzMDMsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.V8QZRCb8tYDHSXmPK4DO4VSQRP8d6Pw3LhIkVe4YMWs	\N	2026-02-17 11:05:03.645332+00	2026-02-10 11:05:03.651364+00	\N	\N	2026-02-10 11:05:03.651364+00	t
c353045b-f82c-4768-b05f-058791836d8d	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MjI0NDYsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Cjz2aCBroxoAP0QG3eE0L88cHPPBieRsRwE8T1qQkyY	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMjYzNDYsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.icbWDkunTuLaGvBwf_7w-IGq4gEUBD3K3HA59dfVK9s	\N	2026-02-17 11:05:46.388073+00	2026-02-10 11:05:46.393427+00	\N	\N	2026-02-10 11:05:46.393427+00	t
ed884b67-e568-4e49-a484-fe2bf038ac63	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MjQ0ODAsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.17Bc82zwD_9sZ_yUm5uUVWfedofieFibkAqO-4MeV-4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMjgzODAsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.f7AibZfwXcOc1KtxpPWg3VEkGz0Dy0c0lomjEIl8nNM	\N	2026-02-17 11:39:40.141347+00	2026-02-10 11:39:40.146706+00	\N	\N	2026-02-10 11:39:40.146706+00	t
c36337d5-49f3-422e-a1df-5358d48d1f27	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MjQ1MTUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.-fmVXf7ljKkGP6l9jSs8B7qRH6Uxf1JSaWmzsl7eqsk	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMjg0MTUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.r6K5bS9dLPp1HjWK070ByPEW8B5o9EuV9p123g9rijw	\N	2026-02-17 11:40:15.874155+00	2026-02-10 11:40:15.878948+00	\N	\N	2026-02-10 11:40:15.878948+00	t
3202291b-8cfb-4c6f-9de5-5177abd20aec	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MjQ4NzYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJPcmcgQWRtaW4iLCJ1c2VyX2lkIjoiMTQ3NmE5ODctNzZhZC00OTYzLWI2NGEtMDFhNzFlYjczOWNhIn0.5bxLdaGzKQPIhSFoaic3LHYFH6eoR7pCr5dF6Zbo9QQ	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMjg3NzYsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.45Olq0-xjz3sMAwdP9Htdq_x3Fhrj46z-NkmxIixfek	\N	2026-02-17 11:46:16.599922+00	2026-02-10 11:46:16.604609+00	\N	\N	2026-02-10 11:46:16.604609+00	t
6908dce7-9991-497f-85db-4764da52bcf9	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MjY3NTQsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJPcmcgQWRtaW4iLCJ1c2VyX2lkIjoiMTQ3NmE5ODctNzZhZC00OTYzLWI2NGEtMDFhNzFlYjczOWNhIn0.AQ5AKqDctsAsSsM11GbyUvgDjaZr8RsHbl-m7hxY1K8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzA2NTQsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.B1cZfyXZtnNPF110Ww9KzmjwONjxCjdNpMFbi9gdPg4	\N	2026-02-17 12:17:34.831827+00	2026-02-10 12:17:34.836831+00	\N	\N	2026-02-10 12:17:34.836831+00	t
0efc09a6-0f15-4dbc-8813-d2c0814b5cd9	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MjcwMjEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJPcmcgQWRtaW4iLCJ1c2VyX2lkIjoiMTQ3NmE5ODctNzZhZC00OTYzLWI2NGEtMDFhNzFlYjczOWNhIn0.dxhqGB9BHvwu21xyQNKuHtX6YrU4w_zKgQRlM24zMEk	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzA5MjEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.nUDOeilLdVBieLGcZolGVJz8L2qigmi9pmAgpqehAIE	\N	2026-02-17 12:22:01.590202+00	2026-02-10 12:22:01.594772+00	\N	\N	2026-02-10 12:22:01.594772+00	t
18c6df54-6033-4ef2-b251-ba9dc825ba1c	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MjcyMjMsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.yt-R2c3GlfXetwrkI7hTo-Gx7xy_1qnrBMqzaNZg79g	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzExMjMsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.gX4uW1u2xKvjMCZp4ypGZJIf5XCdeFO00yW_DvNLi7g	\N	2026-02-17 12:25:23.706397+00	2026-02-10 12:25:23.711018+00	\N	\N	2026-02-10 12:25:23.711018+00	t
885668ee-b7e9-4776-bddd-a28799d40822	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MjcyOTEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.qiAnz0ZAf83fvCmgMA3c04WV_WhDJWHBIYuV-qHYmLU	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzExOTEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.rGmLJqq18IrhXF9WnVMSid_fERYlYkdXknMDc99Ah4A	\N	2026-02-17 12:26:31.859147+00	2026-02-10 12:26:31.86441+00	\N	\N	2026-02-10 12:26:31.86441+00	t
afd1e24a-2a3e-4096-9604-6fcc1f2a8b24	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3Mjc1MjAsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.KOQH2O4cHI3fXhMnK4Y9l248Oqd6bX3o6QGUWRrOdxo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzE0MjAsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.LYvDoz7GdmnQ3-sJz5MFbsR0LxuIDoLSmBuaBHVV4yA	\N	2026-02-17 12:30:20.214722+00	2026-02-10 12:30:20.219445+00	\N	\N	2026-02-10 12:30:20.219445+00	t
02e74af7-90af-421f-bb82-d62f7b110aa7	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3Mjc1NDgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Ydg1SIDqeK3VRx7eNEzt_-ZkjZdpXDloJ6dssPe51hk	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzE0NDgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.0-FDjcV2dKCGmHj4r44FKFcRhFOucY53jPhGAikF4II	\N	2026-02-17 12:30:48.307024+00	2026-02-10 12:30:48.31237+00	\N	\N	2026-02-10 12:30:48.31237+00	t
9b874357-54c0-4d36-90ea-68b52d78433b	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3Mjc1NzgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.vH0MFsV25pZZs0otc0LG3JL6cEmG0DWXdyPkPs9QKUQ	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzE0NzgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.-f1w7JEBTLYP0S8OasF6jyQ_HmxUmQ97avWUfmBTuQY	\N	2026-02-17 12:31:18.073369+00	2026-02-10 12:31:18.07774+00	\N	\N	2026-02-10 12:31:18.07774+00	t
ac45e442-21d5-4aeb-8a48-945d20550b87	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3Mjc3MTcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.kfHJRopzRd-grucPlsvvCEQVmYTzia1ZVrzQrt_vIuo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzE2MTcsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.b1zCInNDIYABxurvFZW3xsTYe1UKMXTFElZZi_4rj30	\N	2026-02-17 12:33:37.564+00	2026-02-10 12:33:37.56909+00	\N	\N	2026-02-10 12:33:37.56909+00	t
3cd3f1f3-bcb1-4683-ae80-56a4c33072fa	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3Mjc3MzEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.9zM0knO0fhAfjcoHvxXm6MHNO-bkVSa9ER0ynv2cGic	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzE2MzEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.BOWbMBn3CXVFBadiAP6olszmcE7ri1o5LJoJnbd3o-I	\N	2026-02-17 12:33:51.88632+00	2026-02-10 12:33:51.890951+00	\N	\N	2026-02-10 12:33:51.890951+00	t
bdf92517-7d15-4328-ae24-3f4437344590	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MjgwMjYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.u8xOFdmILu6oiHk4LSydqi1NEKPSD8bT9T8Alr_qNgY	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzE5MjYsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.cuEkvhGeiWz69r2y59LcCiJjYse85DhFdm4DLEg3TzE	\N	2026-02-17 12:38:46.260023+00	2026-02-10 12:38:46.264854+00	\N	\N	2026-02-10 12:38:46.264854+00	t
3a6f891b-def5-4418-b34f-3febe1f54eb1	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MjgwNzgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.5gQwcr35joj9k8h1qSutWmABM7kc0nqvjIus0kg2mCs	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzE5NzgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.eayGQ8MDyA1JxsoSrCry3QAgCicf5cwq6q__ml50rYE	\N	2026-02-17 12:39:38.46321+00	2026-02-10 12:39:38.467856+00	\N	\N	2026-02-10 12:39:38.467856+00	t
35613f55-959d-4460-89d5-d0466386f0a9	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3Mjg5MDEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Sg-gurDum-TQ4cJ6FJPjs7CkPcCC2EIC6SKVZT7QrR8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzI4MDEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.d0xvwuI0CDPqPfFsqhcgNGDIEhsXYO0hJWyZ0-Ye7FY	\N	2026-02-17 12:53:21.927469+00	2026-02-10 12:53:21.932041+00	\N	\N	2026-02-10 12:53:21.932041+00	t
5083be7e-3fe8-49bb-8ea0-be782f76419e	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3Mjg5MzUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.pUuqnEkpIsMNlpUcvEbx9ew7kWGCJtFoHLj0hZqJbhc	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzI4MzUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.PUyZ4XgUgKt2foTefUMFeZ56LwfNaExsd4Rw3xPukh4	\N	2026-02-17 12:53:55.204386+00	2026-02-10 12:53:55.20877+00	\N	\N	2026-02-10 12:53:55.20877+00	t
3fe3f36d-a6b7-4abe-9ab6-cdc2a2773d32	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MjkxODAsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Sz5ZldRQyGEopju4PZmm7PBggZIZ1u1AiIxMDj_UkcE	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzMwODAsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.-4nSVNilCW1vdBL8JUqur4Poe6gFMTVTuxaLBApX9Qo	\N	2026-02-17 12:58:00.054892+00	2026-02-10 12:58:00.059393+00	\N	\N	2026-02-10 12:58:00.059393+00	t
ea345a26-79c8-48f4-94ae-97e6065e51d2	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MzA3NTUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.uIpjbayKP-Cwm3l7x0Yw-dp4csUCFY1S5k8Big_lt6Q	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzQ2NTUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.pvNuUYk8pyA9KXnJf4sVmNxxWUt95wf_V-z2H-77XZc	\N	2026-02-17 13:24:15.946107+00	2026-02-10 13:24:15.950544+00	\N	\N	2026-02-10 13:24:15.950544+00	t
37945247-0fa0-4a25-9395-7069559eb09e	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MzUwOTQsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.8r6gnB3Vxy_Aojc6MyX0cwyuDE77uRrof1KkGKWG7ns	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzg5OTQsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.5M_BSEHtsNjFaRP-BLFgi5aGZny_F-Ly6vLMxCtsPN4	\N	2026-02-17 14:36:34.790886+00	2026-02-10 14:36:34.795552+00	\N	\N	2026-02-10 14:36:34.795552+00	t
09097e6a-c73f-4398-9d91-db5e42beb6a1	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MzYwMzEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.lfYaAs_x40x5u0sj5WQDouEGS3nZs9nhtAsxU_1w6Zc	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzk5MzEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.qGe_I1LSpXIIwm1mdvUb1xKV5WmalCn_aNfa3U-hlRE	\N	2026-02-17 14:52:11.172303+00	2026-02-10 14:52:11.179249+00	\N	\N	2026-02-10 14:52:11.179249+00	t
775039b4-612a-4858-b45a-ed242b2db5e2	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MzYwODgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.zY2OxC6C0iTSUVpGldHpKvpkvT_3wWfh98BhykSg2Z4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzMzk5ODgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.ssDFd0l-o1Ng_r8MzKodJ3pWvxFJjjE9O1aGrWUQ9GI	\N	2026-02-17 14:53:08.564305+00	2026-02-10 14:53:08.571392+00	\N	\N	2026-02-10 14:53:08.571392+00	t
5254dc7b-37c0-4be1-b23a-862a4bdf2bb4	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3MzkyMzUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.-QdO_caxzWItRPfSojXx3Gxu015l3ct8Hs6_lwNmuQw	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNDMxMzUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.jak1Jw6BbhDu1TH1JON1N3-XRrToqnBk13f0XGQhNAg	\N	2026-02-17 15:45:35.978041+00	2026-02-10 15:45:35.983729+00	\N	\N	2026-02-10 15:45:35.983729+00	t
35ee8758-94bf-45fb-8a26-794aa6e0bb86	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3Mzk3NDUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Ng1-LJskZFqlHm6K5E-0dDm6Dw5eCfCfY8j7S0SzQTs	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNDM2NDUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.C0ldT0IzsJ4fFXJEaOnG-Nw0pc9R3JCp3BH78jDtwCU	\N	2026-02-17 15:54:05.268063+00	2026-02-10 15:54:05.272741+00	\N	\N	2026-02-10 15:54:05.272741+00	t
939ee3ac-b7ba-4c63-b143-e4643123a215	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3Mzk3NTQsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.N5whdpJqF0XygLcG9xTGeI_JYcaCwujYwIPG2tzyARM	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNDM2NTQsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.L27DpSkK5wOw8zilKmbq6695_UO4mLiJT-zGG3-W7B8	\N	2026-02-17 15:54:14.004811+00	2026-02-10 15:54:14.011751+00	\N	\N	2026-02-10 15:54:14.011751+00	t
d7c633e4-1e07-48b6-8b2c-ef1d9d922b7f	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3Mzk5ODAsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.iVjd-tcL_UIt7vCwnL4At3R6q1bWX-0EEdbgSxLn2oE	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNDM4ODAsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.h_CLrktp4iPcM4R3YJ3iQcE0h2K7GkKQ4-pV4rO2F10	\N	2026-02-17 15:58:00.502924+00	2026-02-10 15:58:00.503875+00	\N	\N	2026-02-10 15:58:00.503875+00	t
f14bb1ad-a9a8-4456-8662-5a1778c79f6a	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NDEzMTksIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Z0POFytNm7TR-Biq3X9ffDs-4E_Bf7CXfW2MCF1wzE8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNDUyMTksInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ._29ZT65hmzRYfSrYFzcjINvhCqFkZNp_3GQtO5RZw2o	\N	2026-02-17 16:20:19.219598+00	2026-02-10 16:20:19.223978+00	\N	\N	2026-02-10 16:20:19.223978+00	t
78f381b9-25fa-4c35-889d-9ad9ace6cdd2	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NDI2MDcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.cyqwX63S09UITIxzAplx9ijlJEzQ1H7J1qDeUTplr3U	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNDY1MDcsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.k6V3Y7E45pZhdNvuB8u3VDZGOU8zcEdVRxklAYJRG0s	\N	2026-02-17 16:41:47.937944+00	2026-02-10 16:41:47.942628+00	\N	\N	2026-02-10 16:41:47.942628+00	t
a19677f7-345d-41b9-a5cd-efadcbe0d819	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NDI2NDUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.ximP7qs7hC2piYHMde0H-XlP3f1g5h3J41RmjBTSJCE	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNDY1NDUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.1gOkf5OXVSLuLLgO2W76fz3sppnePPE8RtxSGpLgM24	\N	2026-02-17 16:42:25.433024+00	2026-02-10 16:42:25.43803+00	\N	\N	2026-02-10 16:42:25.43803+00	t
dd36ba1d-a2cf-476d-9087-f9bb4b60ab8b	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NDUzMzEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.U8cxHiC2rJ__m6jmi8Zbcpf9PfUFuPPF2siURkT9JeI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNDkyMzEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.JQKMY6cw4FF7t7JAVqLTVEdwjRE54y6VDPtJAX7LziA	\N	2026-02-17 17:27:11.535084+00	2026-02-10 17:27:11.540162+00	\N	\N	2026-02-10 17:27:11.540162+00	t
3d7f5ec4-cf5f-46db-9795-b68fb131bca4	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NDY1NjMsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.0YaijPDAW3FR-J2_qrCG-WFX-YR6gzBZJoaV1GLS_AU	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTA0NjMsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.ej862YoeVyaoqAgKUWeUye-XbvUsUagOlnPqsC8WdLw	\N	2026-02-17 17:47:43.805145+00	2026-02-10 17:47:43.809491+00	\N	\N	2026-02-10 17:47:43.809491+00	t
4e4e4958-3500-4df2-a260-839e0bdbe594	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTA2MDgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.KlPKxMB7ElVllPd3XQc2t7or6PSf06Q_Vg73NUOiV_k	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTQ1MDgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.xLiUE2BPM5qtXBnVmq9Xb9c8d5SIw-d5mFsktAz5GQE	\N	2026-02-17 18:55:08.836454+00	2026-02-10 18:55:08.841236+00	\N	\N	2026-02-10 18:55:08.841236+00	t
a4822d39-1417-4620-95ec-e12bed7ec8ed	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTA2MjQsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.f_Bb3A7Cu_fgQk2BGXaEJj-p_q5kgdLvqfEXsKaGTeE	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTQ1MjQsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.4ZAFhTdl2bHhUfS0BSmzdrkWXjs6ZLny7rOuN81SqQE	\N	2026-02-17 18:55:24.658913+00	2026-02-10 18:55:24.663494+00	\N	\N	2026-02-10 18:55:24.663494+00	t
28cb0ca7-9460-4e55-b034-3b08fab05e0a	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTEzOTgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.hd5EQrcxF-71WmM5FXYigGg1Tj25M8TKY-d4NRaIscs	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTUyOTgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.5270iTcTONlG8yq8uWTGy1Z9fDbPpAZUUl_qH6PLGg0	\N	2026-02-17 19:08:18.150054+00	2026-02-10 19:08:18.158848+00	\N	\N	2026-02-10 19:08:18.158848+00	t
632734a3-4106-498a-ab76-a9308f416c17	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTE0MzksIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.UL2y0g3iwc2J7xoJ4PQ21ixq6fQ3U2kD2OOAI5pu9EI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTUzMzksInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.ll4Q97p3QZioeK94-82S7cKlpJm546RlR2HCv5tMDnI	\N	2026-02-17 19:08:59.811303+00	2026-02-10 19:08:59.817216+00	\N	\N	2026-02-10 19:08:59.817216+00	t
f02a5a62-f9e0-44d6-b876-aee943813d95	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTIxMjEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.LJ7uWNjAHR3u-ys3JkadTL-9YhdOx4DDw-5f1WJV3Uo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTYwMjEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.MoovYOM2dTh__u8d2x5QDbbFO_CRUJhhuAXXVS63dFg	\N	2026-02-17 19:20:21.948085+00	2026-02-10 19:20:21.953219+00	\N	\N	2026-02-10 19:20:21.953219+00	t
f72e1968-73b9-45d9-bf64-4440d7b6bbf5	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTMyMDIsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.uLZJzHG3Nho7GzoaebVXOUFMmw9waAEDObjz1dam8Dw	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTcxMDIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.JvDpEQr9sHrGoUn97MGPi3k16Jgj0Y7IF9GKC1C23UE	\N	2026-02-17 19:38:22.228411+00	2026-02-10 19:38:22.236727+00	\N	\N	2026-02-10 19:38:22.236727+00	t
479189a5-d3c8-4281-8057-8f66901dcff6	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTM0NTgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Z7uaPkwapNb9Uwmy0RS4F_Q_1sqpRQG66037mYvwywI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTczNTgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.g2NG_bGVt4q7XUdnpbULMf50rihN-IYGY1vQY1N3buE	\N	2026-02-17 19:42:38.848775+00	2026-02-10 19:42:38.854095+00	\N	\N	2026-02-10 19:42:38.854095+00	t
5e967c1c-f4d8-4c13-b6f8-6836cd10b5f4	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTM0NzgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Lo36TEcMcxszABRBTTcA_dQYdBh3n7ufj-NK-_2q4f8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTczNzgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.cOOKLW1_MMFn9cvnenAHfQvMtKH3jfGKrY4zy_cuwG0	\N	2026-02-17 19:42:58.23765+00	2026-02-10 19:42:58.242474+00	\N	\N	2026-02-10 19:42:58.242474+00	t
b90d1877-b46f-412a-a32d-2e632da4cdcc	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTQ0NTgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.26jF4uSwQ4BWfOlYxgXBtgkz9btG_6L2i96c1CGWxK8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTgzNTgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.OJM3bsmkbXZ4JtQIK6c8iPZJRHmzaxf9HoBFhz19hvc	\N	2026-02-17 19:59:18.403537+00	2026-02-10 19:59:18.407818+00	\N	\N	2026-02-10 19:59:18.407818+00	t
1f401f3c-b739-4056-90c5-4280fb209bb2	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTQ1NDgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.f61YnFaEBHr-rFbk2OBshtYShYowkkOXz9KXXE-WVHU	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTg0NDgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.baXE0-O_rpjbH67BbxFoGnP_EKh0elBq18l2pvgEvgU	\N	2026-02-17 20:00:48.804109+00	2026-02-10 20:00:48.809046+00	\N	\N	2026-02-10 20:00:48.809046+00	t
7768f33d-7f15-4dc5-b7d3-53418b90e171	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTQ3NjYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.ahrm6nIr_ZeKqnjBJ2JZgmiSuR8c7fcQ473zF68NP-A	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTg2NjYsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.qPvEuYnYb_SSLvVYd3cZ8NYJmgrJF_uNLYN5R2A64W8	\N	2026-02-17 20:04:26.989233+00	2026-02-10 20:04:26.993308+00	\N	\N	2026-02-10 20:04:26.993308+00	t
270c9e6a-7bf6-4233-890d-a0b8e1a80a61	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTQ5ODUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Uy6wPPUHrtYTxkGRRwKgPlKz-ri1Yx-qHz9zwEwEUCY	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTg4ODUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.GaUHYEBtzWDGtmMZZ2hqpAz_n2Vf8N4azh_zIRHLPt0	\N	2026-02-17 20:08:05.92979+00	2026-02-10 20:08:05.934051+00	\N	\N	2026-02-10 20:08:05.934051+00	t
b21ae2f6-9b62-4f7b-a0dd-3aaf983f3ef1	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTQ5OTcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.y3a0nIF2muAMykyNZ5Voju6SFjqLBVw86CToMyVtnu0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTg4OTcsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.bFpmKNO5whKU5zAsCfVnaPeP-fX-3eQCEvLv9szFyWc	\N	2026-02-17 20:08:17.02428+00	2026-02-10 20:08:17.028244+00	\N	\N	2026-02-10 20:08:17.028244+00	t
df4e200a-e27f-4b1b-8f38-c94e7a357f20	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTUwNDIsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.y24NERMcgzupZ3qNs4uxJgQHDstBBrilFEkPDat9hbU	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTg5NDIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.r_f4QcC5fMM_Ovh3n02GeYj3yjUEGOEz8UkGNUrAOj0	\N	2026-02-17 20:09:02.643037+00	2026-02-10 20:09:02.647741+00	\N	\N	2026-02-10 20:09:02.647741+00	t
012dcbcc-f487-4354-8ef0-f22916d58cdc	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTUxNzEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.av_Hg5WDJtTGWgVCXLc5xmB7nApVeSwON_9ptL-d1ww	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTkwNzEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.swuZ9JsS5KJIncKGdu2se0nQC-yVnJnlK98LZmfrPGI	\N	2026-02-17 20:11:11.566875+00	2026-02-10 20:11:11.571179+00	\N	\N	2026-02-10 20:11:11.571179+00	t
ccada39f-d6f6-4d33-a8d5-cdad062df944	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTUxOTEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.8l795ddOVYuhPLzkl9TZnsa0_MoApYEagtpTVpvbIWM	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTkwOTEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.wexIumciut-wTJiShSw6jSR_7vgKxFmUb-RV-P2x8qI	\N	2026-02-17 20:11:31.441718+00	2026-02-10 20:11:31.445622+00	\N	\N	2026-02-10 20:11:31.445622+00	t
d4f7df4b-ea45-497f-be60-46ae6c278dc4	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTUyNzAsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.5292gUI_oR9ZlwcP-Yg9xEhPBrZv9eglbxMzMxFd4kQ	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTkxNzAsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ._NeCtEXnwvvd3U5Ky5IQNXAK4TgSWweuWywczf7nxzk	\N	2026-02-17 20:12:50.92788+00	2026-02-10 20:12:50.932162+00	\N	\N	2026-02-10 20:12:50.932162+00	t
aeeca5b9-b7c2-4b58-8483-70b7d74de577	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA3NTUzMjAsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.eOrjtJ4ewe7ngsXJ2Gn2l6itzFj6uDXUZr0IIqiZh_w	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEzNTkyMjAsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.8XGgqapNMG20zXRqO1VB5kMSC3FVsfrW-F8iCqdhfAQ	\N	2026-02-17 20:13:40.391504+00	2026-02-10 20:13:40.395967+00	\N	\N	2026-02-10 20:13:40.395967+00	t
88507418-9ff4-4277-a20a-71a2954e228c	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4MTI5MjUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.1osZ9_o2h50_mYHRmYKWlsaS7QNVx63EU1sN6a2pjnI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0MTY4MjUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.QAA4e10zeNd6aUVz_e1kYxn_11X37bcbGsutUHPiMmA	\N	2026-02-18 12:13:45.517309+00	2026-02-11 12:13:45.522309+00	\N	\N	2026-02-11 12:13:45.522309+00	t
f3f84b65-9ab7-4670-8222-d062e6b6f6eb	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4MTQzNTUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.mh148roEbfyQtX9TgbU36zCphJ1-5jZUeg5KiG23xsU	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0MTgyNTUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.AZvhH2wUb5WKh_S5pQcEJsWTBNtLdMrWBX6XTLlKv5k	\N	2026-02-18 12:37:35.858577+00	2026-02-11 12:37:35.862961+00	\N	\N	2026-02-11 12:37:35.862961+00	t
64bbb57b-9bb5-4d28-b3e3-19abe0b019e7	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4MjA2NTUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.WfF54yQb_xa8uALW93vN3N4C9rlvH1YyqwUjMyn7tgQ	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0MjQ1NTUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.7lPc1-bDUwpCx0CTHR7xJ9lZ67nzEmYcQrezekD1tXg	\N	2026-02-18 14:22:35.905506+00	2026-02-11 14:22:35.910301+00	\N	\N	2026-02-11 14:22:35.910301+00	t
68a19af6-1eb3-4dc3-8e67-67d1a67ce8cf	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4MjIzMzUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.RX0srS26BSDdicVLnPkcUYJQs8FvbdKU72xZNdYNAa8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0MjYyMzUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.RTnSpWONUygLsBbpdDltVvb74cnzmoiPpbSIvo28A-c	\N	2026-02-18 14:50:35.194046+00	2026-02-11 14:50:35.199315+00	\N	\N	2026-02-11 14:50:35.199315+00	t
5936db81-548a-4f9b-851c-c241fdf87a48	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4MjM4NDAsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.YTlNBaBL_lXGUFGisHWX-F9I_wRLkWc0xkw0cVbZ05E	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0Mjc3NDAsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.EkCfef8QPHCkmBqPWnEAoTM2YqAjA5aWuChexN73dps	\N	2026-02-18 15:15:40.275878+00	2026-02-11 15:15:40.28075+00	\N	\N	2026-02-11 15:15:40.28075+00	t
ca3da626-884a-48e9-9a01-cc3309ad7820	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4MjUzOTUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.XgLokAnF97X0Ff9WGYWB0pTTgQdSLE_xxNuDxTkiszU	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0MjkyOTUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.yE3Zy8RHOztPhjWbxUSboCAxP6VROBko7RpYFpthi9c	\N	2026-02-18 15:41:35.791112+00	2026-02-11 15:41:35.796215+00	\N	\N	2026-02-11 15:41:35.796215+00	t
d308201b-02ba-4721-8b88-bbd31f82ac1f	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4MjYyOTksIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.83pBLgJOuaAUbN94rGkQUUB2nAw5HeKcEPi_-r7HNLw	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0MzAxOTksInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.r9lqmNmabdYKZl-vrUF_x9PE2N1YjLpCLVNo11l-2sc	\N	2026-02-18 15:56:39.848713+00	2026-02-11 15:56:39.853762+00	\N	\N	2026-02-11 15:56:39.853762+00	t
242ae03c-cab4-4b7a-b0ef-c0f257e4059f	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4MjY0MDcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.bmq3X9tN9pWIY4TVIxzvcXg1nsRzIxHYvXuwz5JKy0M	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0MzAzMDcsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.g-t7ReV2MWDLVIX_XcYKEPwTX-Zac6do9cBRA1L_ESE	\N	2026-02-18 15:58:27.015064+00	2026-02-11 15:58:27.020019+00	\N	\N	2026-02-11 15:58:27.020019+00	t
0fda9d32-1c75-4740-a2a0-4dfd61d132a9	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4MjY2ODUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.gHnlVkv_gtExN2LRHyc5byiERIPkPQJmhVhKm-1z79U	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0MzA1ODUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.FuXQv7QalSZgj5SwCn1rmjy4yLI47sAUZkptwtbK5_8	\N	2026-02-18 16:03:05.36168+00	2026-02-11 16:03:05.366719+00	\N	\N	2026-02-11 16:03:05.366719+00	t
f74001ef-fac2-41ab-a209-ad115a40b4da	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4MjY4MTksIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.PA5I80YZyqjflLL2RieZEi-7_NamktZ2EwGS7SImosA	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0MzA3MTksInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.bYFHRm3ZNzfNqF6gPt4wIlzvZ72eoeqHFGI5h-88A38	\N	2026-02-18 16:05:19.269494+00	2026-02-11 16:05:19.274538+00	\N	\N	2026-02-11 16:05:19.274538+00	t
c2ea4015-2942-4741-b1bc-705bc0374bb7	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4ODMwODEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.AJjeSiB2vEWeHlsseqjl4sQlGpslXV6i5sk5ndMJtFs	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0ODY5ODEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.p4EMiQ60ZzhpexNVCC2ucEpZGyA8wDtPELS6MSPv1Ew	\N	2026-02-19 07:43:01.95978+00	2026-02-12 07:43:01.964591+00	\N	\N	2026-02-12 07:43:01.964591+00	t
cec63970-3f32-45c4-b634-d3a23ab2afa8	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4ODMzNTEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.oomkp0LQi3NrhyWRxVo9Dq2MMf3TbB4_G40DvvbinFM	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0ODcyNTEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.cKRaOIoJQfdKOQFMuOBZoNg2v9e4PzF6tVmvEILTsvE	\N	2026-02-19 07:47:31.369566+00	2026-02-12 07:47:31.374028+00	\N	\N	2026-02-12 07:47:31.374028+00	t
2dc84fa3-65e8-4eab-bddd-93765de3c97b	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4ODQ3NDMsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.YI6sKC7orXIccjRIehLRc4kDklwHW1JkhyGGzMbZLVo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0ODg2NDMsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.SW28-WkYIzpUmUtroDdaa6BXQ86wMezSlVmcD43JWaQ	\N	2026-02-19 08:10:43.707255+00	2026-02-12 08:10:43.711858+00	\N	\N	2026-02-12 08:10:43.711858+00	t
0bccf5af-6294-4a61-8b77-b7e5eafa2052	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4ODY3MjUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.0U3Kwmot2aOLab9Fm-Myxv3GtMEHBifb3OKYLVvLreo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTA2MjUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.lIFXnxk0i2QLvePBxlY6G1936YN9XwTJ6dNUkCTajpM	\N	2026-02-19 08:43:45.328685+00	2026-02-12 08:43:45.3339+00	\N	\N	2026-02-12 08:43:45.3339+00	t
709193fa-7d24-46fb-9fb1-b95579ce25d2	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4ODY3NjYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.iZkrvGgVCTa3_V4udpiCvQLmxwIoHiM2aFrFH8Lq-1s	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTA2NjYsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.hdB04nzDec3cyLjri-CLIc4qE-JF-OXJUxy4hmLf5Bc	\N	2026-02-19 08:44:26.603213+00	2026-02-12 08:44:26.60782+00	\N	\N	2026-02-12 08:44:26.60782+00	t
d6116cf3-c74c-453b-9e1d-bea86bee13f3	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4ODcwNDMsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ._TQi-gV_PB2O-iFyQR8jvrtvuPMq4kExJ-sbxtZiZmE	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTA5NDMsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.OejgkZJelHX1Iyk9Bfe7D7c2Xx72kOtD9lf3xhEXCWw	\N	2026-02-19 08:49:03.169251+00	2026-02-12 08:49:03.170324+00	\N	\N	2026-02-12 08:49:03.170324+00	t
bc6c187b-9639-4b48-9574-2e1efb8ae55f	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4ODg0MDMsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.HCtocfA-d_vpQdsbcTeDmHnmUaypUVx3kVQYj54TB24	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTIzMDMsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.MgugxvJWGh7uolBswK4IJ5C_GmRWSRffFNpX0AhQacI	\N	2026-02-19 09:11:43.72829+00	2026-02-12 09:11:43.733214+00	\N	\N	2026-02-12 09:11:43.733214+00	t
bd4df790-da91-4879-9b88-b673d56992e3	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4ODk2OTEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.PrJu9BIk9M7yu2lRfwVpnv6S8sjBS7wu6gTc4GAj3HU	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTM1OTEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.f7KISly4QqNXEFtHzZdkXuEglABZkJSBCDHIHCsoQYc	\N	2026-02-19 09:33:11.786817+00	2026-02-12 09:33:11.791727+00	\N	\N	2026-02-12 09:33:11.791727+00	t
48a14c71-a810-4c39-a6d5-92304e734675	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTA4MzksIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.su8mzLeUJu0D_HDROrCV0SiNL7VUpSWGt2FSC9lrjTM	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTQ3MzksInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.2FqcsU59KyUMtG45y7oAgblXM-n0dFJOlTNFVVjxb1g	\N	2026-02-19 09:52:19.132401+00	2026-02-12 09:52:19.136803+00	\N	\N	2026-02-12 09:52:19.136803+00	t
5190e108-9ab1-45f2-bc20-7b9e79db5b93	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTA5OTYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.NAqCx-MmmGOgS5R-IT0Dys2cz0EmGmPP-XUaC-FQjfU	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTQ4OTYsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.rstu7WIDknpyGcXUIrEx_P5WAvIsrbQv4zLhsR_NBcQ	\N	2026-02-19 09:54:56.682837+00	2026-02-12 09:54:56.687223+00	\N	\N	2026-02-12 09:54:56.687223+00	t
74d51cf1-9433-40fd-80e8-a0897588b9d6	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTEwMTEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.snDH5kD9y8FoRWOm29DUa1yFTVUXfobmtOQGFBbUO_Q	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTQ5MTEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.mEGKYSsWJ42JYuVVP0RVcJJ6SNawuO_PQHn9hioZGmY	\N	2026-02-19 09:55:11.351485+00	2026-02-12 09:55:11.355407+00	\N	\N	2026-02-12 09:55:11.355407+00	t
972a8597-5651-492c-ab66-9a235c977bcb	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTEwNjEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.brI-NdrgnqvjkdCJNynGxHKzLORF2qqKzssCYsEWpGw	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTQ5NjEsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.MKqXFXYDCVgcLM_YhT4Fjiqld-D0JSelvKSzqUDpbmc	\N	2026-02-19 09:56:01.698698+00	2026-02-12 09:56:01.70322+00	\N	\N	2026-02-12 09:56:01.70322+00	t
dbddd78d-143f-4365-b427-8a7725d5c474	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTExMTYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.XyX5totvUvHuTa6A9l0OauY4pqVbFnjzqMIRdQ-k-WA	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTUwMTYsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.U-zhCpdBlRNQKNxsnNAEX6mQy5srwXpGGld-sr6eruE	\N	2026-02-19 09:56:56.502706+00	2026-02-12 09:56:56.507009+00	\N	\N	2026-02-12 09:56:56.507009+00	t
95683250-7689-4ddf-afda-fa757e545f73	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTExNDksIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.MlGZm6KFinO-VCnAy2O98CWzMjrSYThWeIrxN6wO62E	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTUwNDksInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.EIZpNG9ZS4t3h5FmHRW4hHrn0o73KDnh1eOMyC8Ly6o	\N	2026-02-19 09:57:29.855529+00	2026-02-12 09:57:29.859959+00	\N	\N	2026-02-12 09:57:29.859959+00	t
874112ec-3753-4659-a2f7-d8e80a8bc71e	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTExODQsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.JfDs8_9WlRRVaTOdGnEZhyZ1SSOpJIDSOmEjhdvPSy4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTUwODQsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.3v7yenwZjeHMD300uR9nsFi8ZppVwMYsJBfrqQ43-mE	\N	2026-02-19 09:58:04.312067+00	2026-02-12 09:58:04.316392+00	\N	\N	2026-02-12 09:58:04.316392+00	t
3d969d1c-220b-4add-8af7-73763af14c74	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTEyNjEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.g0qVjTTEH1YrQ5Ty7cR26B8XvzWPdHNb6GMYFKPV420	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTUxNjEsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.4jucMkxE0HzUGBEOF2gulXy6YQV1RJ91_lEK_4q6HLs	\N	2026-02-19 09:59:21.838593+00	2026-02-12 09:59:21.842648+00	\N	\N	2026-02-12 09:59:21.842648+00	t
69575f4a-222b-42a3-95bd-e2b15bcf1e99	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTIxMzksIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.XXNOVXANG_94EaR1JW2k1bVkx_8wH1UHv2Mxlfz4Wh0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTYwMzksInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.LJ6oP4gnS1IPISu9yqiP_IdeemiXHlZj0FT__nkQll0	\N	2026-02-19 10:13:59.86357+00	2026-02-12 10:13:59.867758+00	\N	\N	2026-02-12 10:13:59.867758+00	t
08cc00f4-4a43-44e2-9b12-6ff091ee97ed	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTIzNzYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.snlkwsLt6lMRtnSu4QyxM_KA1alrhbOam8h81Yx2cvI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTYyNzYsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.gh-IXRzcqH_stxPc_N5km69gXtVbzDNDCk22jnrASWk	\N	2026-02-19 10:17:56.872542+00	2026-02-12 10:17:56.877241+00	\N	\N	2026-02-12 10:17:56.877241+00	t
77dfcca3-3a10-422b-b41e-d6e8f1cd44d5	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTI0MTYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.zEbtuuDTcfq9Fy6kFUQPAoVDd7kpjdmjZsL38Xee4DE	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTYzMTYsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.BSg4tC-QZYSq0v9r2ekVJ9zSUkXekQxWkwrQ1SsAGhw	\N	2026-02-19 10:18:36.318248+00	2026-02-12 10:18:36.322329+00	\N	\N	2026-02-12 10:18:36.322329+00	t
f51f1a9a-a348-4445-90be-71b62d52b11d	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTI1NTMsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.dCj938YELSBEntZOMNN41eYlKZTfJVT8XVqIW_3QX8I	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTY0NTMsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.3GVmegNOKgMDPI3rxXO46w3yo3_GXft1S4D4jjrVpzo	\N	2026-02-19 10:20:53.876837+00	2026-02-12 10:20:53.880995+00	\N	\N	2026-02-12 10:20:53.880995+00	t
5c372ec8-82ee-4442-923f-c8ac18666744	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTI3OTYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.ygLWr129sYYva4BOfQcmU11RwZZ_GpOicAU7VvEZPiE	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTY2OTYsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.2XiRo97m6e8MgBXQS-8dTOWY5bzFNX5O17wGA7sZu3c	\N	2026-02-19 10:24:56.285964+00	2026-02-12 10:24:56.289969+00	\N	\N	2026-02-12 10:24:56.289969+00	t
cc661f91-be15-4f9b-bd14-e8d7b1af2af4	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTI5MTAsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.Ci7MsFlcqoAPoqTTbyf8JOgwcxQuGRWGGGq6m4h-5Yo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTY4MTAsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.qcqpbZVSxbSQR6LX0ECEMnjWdRdKJoxSQU6z21tQbKk	\N	2026-02-19 10:26:50.910397+00	2026-02-12 10:26:50.914692+00	\N	\N	2026-02-12 10:26:50.914692+00	t
d6dd0d4c-ae1d-4b0c-9854-779166d39059	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTI5NjgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.DfximwIIUaN5bKfttYJo6RvgO5DiyGVRYFpSLj0tiTU	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTY4NjgsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.8TWCSIQz6zmqb6W-1GYf19lphkiBkmQcMc4ObC4U0HI	\N	2026-02-19 10:27:48.346759+00	2026-02-12 10:27:48.350933+00	\N	\N	2026-02-12 10:27:48.350933+00	t
19aa6a08-9c66-4a40-9c5c-3f3e7f4f126f	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTI5ODcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.uxP5zGkqrUmMV1rCC0pCO2q5lG1to0a63JpSKpsPpFA	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTY4ODcsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.H2Fc7lr5MQrdFhLi6xLtL9eCgXoFGGZsBkp0EEsMSnw	\N	2026-02-19 10:28:07.320715+00	2026-02-12 10:28:07.324881+00	\N	\N	2026-02-12 10:28:07.324881+00	t
76efdab9-c9ef-4145-a388-daaae745750b	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTMwMjgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.j1WUWsiXpLGiZpWjuLCvh7eNQ0alxMk0G0hHyK8Gvq4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTY5MjgsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.5SHv3Nrnca41Oi7nJD0O4ACgQLQuR5XvY3cg19o4Gh4	\N	2026-02-19 10:28:48.892422+00	2026-02-12 10:28:48.896409+00	\N	\N	2026-02-12 10:28:48.896409+00	t
e13091b4-6add-471f-8287-a28eb12469b4	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTMwODYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.GPg-oGsxXCBrjANUzlxOORTO4UINVX_TcmfCCaapYzo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTY5ODYsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.b5_HfU_u0vqoLy-H2rHyvyGZgatHcasZk1U9lVpA1XI	\N	2026-02-19 10:29:46.948356+00	2026-02-12 10:29:46.952476+00	\N	\N	2026-02-12 10:29:46.952476+00	t
fd15a316-57da-4720-888b-bbba157e684c	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTMxMTUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.Cm23dyCt7AVZdF0ONxEcue-ULRMBHkZvBo8auIFdAY4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTcwMTUsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.IYW4xODV8VrJQgLVL1OJDvWP2m3-FWoJFpLzrLoRdDE	\N	2026-02-19 10:30:15.530904+00	2026-02-12 10:30:15.536251+00	\N	\N	2026-02-12 10:30:15.536251+00	t
25cde1bb-f5ab-4c4e-8884-72b431e9e3be	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTMxODgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.6viNoTARhZ6Jzc5FMn6VAwUvavXmavHG0VNzMiG1-EY	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTcwODgsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.m9d0ppNxF1-MKcT1YcAPSzEa2vAgSIE6nNk5sedY9B0	\N	2026-02-19 10:31:28.798256+00	2026-02-12 10:31:28.802096+00	\N	\N	2026-02-12 10:31:28.802096+00	t
db6644a7-b486-42ed-bd35-7eb15aa09a5b	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTMyMDQsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.NdpHfGOUdo2BgCppreBfKNr0Kw3o7Yi6YPlMY5UdjnY	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTcxMDQsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ._VZ2PG2xASqhBvAQ4Bo9DrrYgf2vrDdJRSe5BwONwMY	\N	2026-02-19 10:31:44.586004+00	2026-02-12 10:31:44.589861+00	\N	\N	2026-02-12 10:31:44.589861+00	t
9f62c4c0-dd25-48bc-999f-e8cc9ea923b3	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTM0NDUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.zgdiRx-XA7ce1zmfF5ErI2pMNEPTzegbpu8hidVYuIY	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTczNDUsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.qqhLbVMW0f_5R1nHQ_NCIeaNs39emeSEDpCod00ITmw	\N	2026-02-19 10:35:45.605916+00	2026-02-12 10:35:45.610757+00	\N	\N	2026-02-12 10:35:45.610757+00	t
7b3fce8e-6bc4-4acd-bbfa-81db08d5aa93	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTQxNzgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.I_i-DjBlXyMhPQNw9rttfr6dGV-3D5rzKx8rPIssKrk	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTgwNzgsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.2U8UtMJKwrlTu7mSet2nsf6KK8m5qf2VMEmi0k9E5E4	\N	2026-02-19 10:47:58.421112+00	2026-02-12 10:47:58.425418+00	\N	\N	2026-02-12 10:47:58.425418+00	t
c50aae27-4102-4959-baad-3e319a2ce583	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA4OTQ1MzgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.ItSxstLcM_MNymFPbGASST7_4qCLW1Yeaior556Bj7U	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE0OTg0MzgsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.Q-MeLU5lhZu8bEwvtqA2XGgMzfYHM3ZltKEldLK6QOI	\N	2026-02-19 10:53:58.541565+00	2026-02-12 10:53:58.545828+00	\N	\N	2026-02-12 10:53:58.545828+00	t
3255a06c-7eb9-4530-9a9f-31ea971f6871	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjU4MTQsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.Xm7WQE2bPQkgcZk4P2UGzsLeL22_wYDnH2jf61h5594	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1Mjk3MTQsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.m0Jp3HDr-BBAKTimlcirz2QWU8nUqpgksHQ_vU718Y0	\N	2026-02-19 19:35:14.260189+00	2026-02-12 19:35:14.264576+00	\N	\N	2026-02-12 19:35:14.264576+00	t
2974baee-1850-480c-a90c-ab347c0cd342	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjYwMTcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.i98Miqv4B1_tqWp_JWidwBbgewEv8HT-Q3m7VZCZBpQ	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1Mjk5MTcsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.m7ZyBj1lrecRb8uR4kqTSLe-vBdbVD9tpBO9f-Usiag	\N	2026-02-19 19:38:37.117658+00	2026-02-12 19:38:37.121702+00	\N	\N	2026-02-12 19:38:37.121702+00	t
01fe5939-06ce-4e4a-96a4-5f8745a4b374	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjYyMjgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.aSnwcygdLxfIeCp_wkF3zOKdhK6WYdhJb7eiZWgeAE8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzAxMjgsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.6PJhdQrIecWjs7FfBPNMyz2DT7NORa9pKex54KM9gqo	\N	2026-02-19 19:42:08.930361+00	2026-02-12 19:42:08.935163+00	\N	\N	2026-02-12 19:42:08.935163+00	t
58a29dba-c225-4be0-8000-063f14606f6f	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjYyNjgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.lU5OF6nLvxOnCvaOE2ui8dvpyf6TNoEpiigz6-ifDpo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzAxNjgsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.Lq_E12mpI5CJGq20qh0rHzY9nMjpFJKebsA5bVW_kDY	\N	2026-02-19 19:42:48.871179+00	2026-02-12 19:42:48.875059+00	\N	\N	2026-02-12 19:42:48.875059+00	t
411e2ee4-f72a-400e-bdc2-1a5fd4c2e4ee	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjYzODgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.l1usRQjS1Hk7sm23AVvo_oHMkbNyAOMcdqNtwnoAvM0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzAyODgsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.ZgX9xIw8kxhFYCLNXY_F9NCETs0B186GQqQBXqzI2ZM	\N	2026-02-19 19:44:48.866477+00	2026-02-12 19:44:48.870372+00	\N	\N	2026-02-12 19:44:48.870372+00	t
91f9ff82-0340-4faa-8805-8c031ab06ee1	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjY1NzksIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.XgtyQKWetiybaJ3F5Rylyx57FWEKWE35RuSFMfeohw0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzA0NzksInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.VC0AmpxeZZ-pB2ud8gQGSRdawyeY8XMZeSzRwu5llzE	\N	2026-02-19 19:47:59.763123+00	2026-02-12 19:47:59.767214+00	\N	\N	2026-02-12 19:47:59.767214+00	t
c9a0ab3e-0d49-4069-884b-b3398368cb73	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjY3NTIsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.kEiYpssQV33I2CCPONQsSJKmWUK7_JMxUeq8M6D_Nzk	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzA2NTIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.erfHE6Jl_CU-Q9GGdHOjn7Ma4gcOwsRA3OxA8rkN028	\N	2026-02-19 19:50:52.230581+00	2026-02-12 19:50:52.235041+00	\N	\N	2026-02-12 19:50:52.235041+00	t
4bcd80b6-d71a-4f45-bcaf-70cb9f82fa61	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjY4MjcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.9iqZzpXYsmIrf9zBjdy2La2pX7WULl4R7_y8GlPc69o	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzA3MjcsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.teoM3NdbWR-fNmNW2q3pPZkDJvcJAZ6E9t95OOPDPCw	\N	2026-02-19 19:52:07.45459+00	2026-02-12 19:52:07.459027+00	\N	\N	2026-02-12 19:52:07.459027+00	t
a1980aab-fbdc-4066-9941-d1b1bcf98f68	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjY4NzUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.2LZjfx-uKKjcmZZwMCsXjb80w3yGvji-CYjDZNzw96M	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzA3NzUsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.NWHITH9VieMQ9ImCbU37VURY2RAOfmuM3XHx9LchMOM	\N	2026-02-19 19:52:55.644858+00	2026-02-12 19:52:55.650151+00	\N	\N	2026-02-12 19:52:55.650151+00	t
13638bda-3a7c-4efe-821f-59ce2db220c2	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjY5MTUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.G8UDbZvRBOQLuG5gBBWPxyhAQWKERsARmY2VIuksj7k	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzA4MTUsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.Kmn6r9VcLl1wnM30BlpDkv_SVEtfexLB11_SZmsuVls	\N	2026-02-19 19:53:35.848926+00	2026-02-12 19:53:35.853458+00	\N	\N	2026-02-12 19:53:35.853458+00	t
da51803e-1f23-4d38-9983-c13bbc632abc	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjY5MjYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.DVjWfV0-2f--YrO9DzoNlyQfvGXuWoJPiH-nxM6nao0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzA4MjYsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.MwcLUBlQFEENfe0gKgnaF-xaW3ECbu73cI7LxeScVIk	\N	2026-02-19 19:53:46.519077+00	2026-02-12 19:53:46.523827+00	\N	\N	2026-02-12 19:53:46.523827+00	t
75943a39-fff7-4b82-b95f-587d4e2445b3	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjY5NTUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.d9aQXc5UDo0q77TCiONFkYmS_cfgncNV5ibVxBebQ08	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzA4NTUsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.LaGyrcb552RYYeJyrY0taMnEZbPaIjWPed7EK4eZe3M	\N	2026-02-19 19:54:15.328558+00	2026-02-12 19:54:15.332601+00	\N	\N	2026-02-12 19:54:15.332601+00	t
1ce59005-4194-4bc5-a24f-cdc8c4187cf3	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjY5ODcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.jziOY27-zxTeAHtFQnb1QrWX2-JIJFN5wokarZxxK5c	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzA4ODcsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.WN9HC8fR2LmBULM81IoojDD5PVsmXFkd_HF0_oP_Cl8	\N	2026-02-19 19:54:47.495562+00	2026-02-12 19:54:47.499852+00	\N	\N	2026-02-12 19:54:47.499852+00	t
e67bac7b-7e83-4b81-bc7a-2b9646405eec	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjcxMDAsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.4u8eYX0r9DF53Djv0LzOQ6-PAJoCDJago89dSZNzKAk	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzEwMDAsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.c6Bkf8-b31vgJMr3dLLpLf25jRNO5GDaAYJaTSrR604	\N	2026-02-19 19:56:40.605165+00	2026-02-12 19:56:40.610156+00	\N	\N	2026-02-12 19:56:40.610156+00	t
043b494b-70a4-478c-916e-fad4e716a30a	0f68a2b7-5a20-4a31-aed5-f45361818da1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjcyMTUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAxMiIsInJvbGUiOiJvcmdfYWRtaW4iLCJ1c2VyX2lkIjoiMGY2OGEyYjctNWEyMC00YTMxLWFlZDUtZjQ1MzYxODE4ZGExIn0.DhlIYsFrvHdVbSTJ1v5Fib64e9Ri0GBuJxLE_JOo5Lc	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzExMTUsInVzZXJfaWQiOiIwZjY4YTJiNy01YTIwLTRhMzEtYWVkNS1mNDUzNjE4MThkYTEifQ.mBzVQpK_nPZvpQzlmgPmpVPEJghLU_oRrMzWBJQKAww	\N	2026-02-19 19:58:35.635855+00	2026-02-12 19:58:35.640526+00	\N	\N	2026-02-12 19:58:35.640526+00	t
881b2c33-5a3c-47b4-a392-cf0e05d9d2aa	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjczMDcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.x33PkgcTZNGy1Qwdcl7BXcYrU5S-5OJWZYFL5r31AtU	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzEyMDcsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.KMmjNRp9YdNl2NiEZbaYeQgAuC9LBaKquCQQ-T7BqTY	\N	2026-02-19 20:00:07.253154+00	2026-02-12 20:00:07.25758+00	\N	\N	2026-02-12 20:00:07.25758+00	t
ef02e812-0da1-4d7a-ac86-d321c2ce8a1e	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjgxNjUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.-rs-nbPWlZvbLJ66sZ-GcQuZeQNNeBu8_upxiKYu588	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzIwNjUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.gd5owyE4OfVnfYYPL20iUWj7y72LpxwWuLDQMjLXZpc	\N	2026-02-19 20:14:25.501505+00	2026-02-12 20:14:25.505834+00	\N	\N	2026-02-12 20:14:25.505834+00	t
6552d8f1-c198-4de8-8c9d-6621156fe995	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjgzNzEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.IX8Cr3ED5ZdbO3m47g5AU3Hr9UTkNk0cjdYVdZtVEro	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzIyNzEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Kf68CCmF_r9Ef_8DOqXgDqDucFVPm8Xsy956nEdsFwA	\N	2026-02-19 20:17:51.694912+00	2026-02-12 20:17:51.699223+00	\N	\N	2026-02-12 20:17:51.699223+00	t
f182fa6f-0e6b-4381-812d-eb4301e19a88	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MjkwMzksIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.K-wPtP9A6WVp4Qb1OqukZCmbR1rknU2j2m7H5xjOB9E	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzI5MzksInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.nSkaG55Wxqk4WwiV5dNlqD0eSGOpPq2S-qjhE2K37mw	\N	2026-02-19 20:28:59.904042+00	2026-02-12 20:28:59.907966+00	\N	\N	2026-02-12 20:28:59.907966+00	t
252ad677-585a-4c0f-98dd-0f7f3fe30daf	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5Mjk5MzQsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.3PCRiNAXJH9gyc3xVqydIl5Qj57XPVKw5-MVPPHuLIk	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzM4MzQsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.84CiVr7GHLJ8N2ls_IrCbVIucZwgn2Pnl0LOiHkSFiI	\N	2026-02-19 20:43:54.851438+00	2026-02-12 20:43:54.855434+00	\N	\N	2026-02-12 20:43:54.855434+00	t
4f5aaec6-4534-4f45-b65f-6d725efaabeb	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MzAxMzQsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.r-7UL4CDS2lg5XhVBRev0JExFD1YVKZEsulpTyozwQo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzQwMzQsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.1BJdXlDLIcpG5XaVCmv423-P7G0otKMKS30UPplUbkQ	\N	2026-02-19 20:47:14.174296+00	2026-02-12 20:47:14.178146+00	\N	\N	2026-02-12 20:47:14.178146+00	t
e74446c7-ab32-4ae3-a8a5-93995b6ac120	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MzA5NTAsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.U0KeRQs3oRKiEx4fy7l_F2wDBb8zcgxth4EHud7dNzM	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzQ4NTAsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.pyGmS3TKHrmIt4ELj_IjgHBWR0zt4GuR8mds6YWbNks	\N	2026-02-19 21:00:50.131447+00	2026-02-12 21:00:50.135382+00	\N	\N	2026-02-12 21:00:50.135382+00	t
7ccfe96f-1367-43fe-9f85-db9d6a248930	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MzEwNjMsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.o2kdsdJPB6SLq1cX0Fd9DG-vI6ZTTYwxMRu1qEFZO0A	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzQ5NjMsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.a4C5bhuBy-c_XowYW4Y04fs80cy8Et1_mwvwt5oQ50o	\N	2026-02-19 21:02:43.022696+00	2026-02-12 21:02:43.026552+00	\N	\N	2026-02-12 21:02:43.026552+00	t
ec34bcae-67d8-4c77-af8d-1d42ce027b6a	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MzIxNDYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.DZUs7oDwN6zRuhyokEo6NT3gWKtzbobSpX9jQ_TwTUQ	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzYwNDYsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.cADA60hMBgzTnypYUb-CQYWufwieUYdDg6jvKRsSxQA	\N	2026-02-19 21:20:46.149838+00	2026-02-12 21:20:46.154001+00	\N	\N	2026-02-12 21:20:46.154001+00	t
0ce2ae97-4ec0-4edb-b02b-0bd04d15df04	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MzIzMDgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.rH77SrwovCMMkI6C2RGln_mJrQ4lGnY79dOYtqkarP0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzYyMDgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.5MYzD7wQtsoUEKbjBR_XhBogPw8uQzrC-ZAtZm7wex4	\N	2026-02-19 21:23:28.386205+00	2026-02-12 21:23:28.389874+00	\N	\N	2026-02-12 21:23:28.389874+00	t
caf073d3-b90d-4a47-be95-035de9b29202	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MzIzNDgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.FOGoGTZGqwlkZy2juZ4Sh1gLVxz4ycYI_YSWmerzYUA	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzYyNDgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.9I3miKQycvC5u0A9zyQvdp5R4GTLIgqYpVFWYCt2Hn4	\N	2026-02-19 21:24:08.169699+00	2026-02-12 21:24:08.173545+00	\N	\N	2026-02-12 21:24:08.173545+00	t
9fd3cd2b-f77d-4383-8f07-ff2bb99ab393	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MzI2MDcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.GrYCtevByk2urEtzZ5JCW2ECDpFwfa6YWJ6APn5W9CQ	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzY1MDcsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.DZ24rZhIVA7R63EZWE-S06Pna_SQUNTf07G2oY4i6vY	\N	2026-02-19 21:28:27.503016+00	2026-02-12 21:28:27.508443+00	\N	\N	2026-02-12 21:28:27.508443+00	t
03e42329-b71a-4895-b327-a09159bac20b	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MzMzMjcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.ODuuDZ_Im4d6RG6XN9j1HYEug6gSiP2v6T1QHnq9MUg	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzcyMjcsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.vKhaqnY472zF_h4gsMqnwYMCbcD19a-bd6ViiPrHsrE	\N	2026-02-19 21:40:27.191998+00	2026-02-12 21:40:27.196581+00	\N	\N	2026-02-12 21:40:27.196581+00	t
b4247072-6d7b-48c9-add2-cf9c2aa65514	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MzMzMzYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.q2U5nCVN19lJRdEXVbD3WGMdq97ibZi1_P3jMPmt44Q	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzcyMzYsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.z0oyAzKq6013AaPDqeWNq4XTG3adeUnZjOhN5OjTjTI	\N	2026-02-19 21:40:36.707297+00	2026-02-12 21:40:36.712276+00	\N	\N	2026-02-12 21:40:36.712276+00	t
14204216-219e-4887-938d-d70caef062a0	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MzMzNDcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.4KK5q8CVuRZ1BqmptwF_6olA_RcyKo3TQAuVkPxedpo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzcyNDcsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.FBuA8RLzTswCABpTVhDu7hZzO1RCP0JK6mUVzLDbRQA	\N	2026-02-19 21:40:47.602864+00	2026-02-12 21:40:47.607093+00	\N	\N	2026-02-12 21:40:47.607093+00	t
5b28ebc1-9116-47de-9c54-5bb4ec80631d	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MzMzNjIsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.xvS-YR5gVueT6wOFhp-eOfzymbwFjbjtL6W162G5f9Y	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzcyNjIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.4LuLELLn8T8Ew6xAIBMlvx5DcAXnBCn99K9vslPt074	\N	2026-02-19 21:41:02.365188+00	2026-02-12 21:41:02.366086+00	\N	\N	2026-02-12 21:41:02.366086+00	t
a10379b2-5f9e-4d93-8592-88a2f0f52705	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzA5MzU0NjIsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.FVrGMaMSBHI1LsiK7b0vmZMPdqrxel4uQyHPZf9sE-8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE1MzkzNjIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.ojMTzHV9FPxgnDqNBs-NwZQGAhkQvhJ8fEshJqhY7Wg	\N	2026-02-19 22:16:02.90446+00	2026-02-12 22:16:02.908597+00	\N	\N	2026-02-12 22:16:02.908597+00	t
1f86fa75-c678-44f3-b660-fd89d4087461	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwMDI5ODAsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.pysxZ-f1psLJAi6mOPqeHDqdbe06Jkjcy2-BmDO_N3c	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2MDY4ODAsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Wt8WvJcFJ9sTODjbt61MS0YHHAXLaEoWbJQkkklKhpI	\N	2026-02-20 17:01:20.090583+00	2026-02-13 17:01:20.096302+00	\N	\N	2026-02-13 17:01:20.096302+00	t
6d57a6f4-d8f6-41f2-b0c1-6f6cc8cef9ad	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwMTMxMjQsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.G6sms3e2pRDBiGle029ieM4DvBHEEJ1H9vE20b1bGTk	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2MTcwMjQsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.QyFAE7vZNwz7GEftTmxdFY_KJTNchW70wjoDfCwNdac	\N	2026-02-20 19:50:24.826298+00	2026-02-13 19:50:24.831126+00	\N	\N	2026-02-13 19:50:24.831126+00	t
f4a44741-3b6a-47ee-92c8-a2c8b7dedaaf	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwMTYyMjQsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.MyYQIJh99os_avBt7Nktqk_BvBJAd0PAkxNXEhXl_MI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2MjAxMjQsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Lj5P7q5PAtHX-GJgplNX08o_7QLEXyUYQrI66xIb77I	\N	2026-02-20 20:42:04.270921+00	2026-02-13 20:42:04.275807+00	\N	\N	2026-02-13 20:42:04.275807+00	t
3057bf33-8059-4552-ae5a-7135f8f107f7	1476a987-76ad-4963-b64a-01a71eb739ca	test_access	test_refresh	\N	2026-02-14 20:42:26.269516+00	2026-02-13 20:42:26.269516+00	\N	\N	2026-02-13 20:42:26.269516+00	t
7abe86a8-09cb-48cd-8882-8fd02803bac6	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwMTYzMDMsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.ZHgqwBL5ywdhJvqeLyNXKMwMfy_JbSfW7imbeioOKLE	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2MjAyMDMsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.cGiQBdiFLJSbGk8mqxkaQCVkQFuWF4m-YoabkLKAENA	\N	2026-02-20 20:43:23.495721+00	2026-02-13 20:43:23.500534+00	\N	\N	2026-02-13 20:43:23.500534+00	t
30292bda-c8b8-4196-b0f4-7e040bc8e312	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwMTY1ODYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.GFKPmuE03b09W9wUSDJCH5NMRO8ECZOgiNlkuffKbEs	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2MjA0ODYsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.OrwfEKMWa3UZYzmdgyDN5FogPvssrphniMedaxKMAiA	\N	2026-02-20 20:48:06.454733+00	2026-02-13 20:48:06.460034+00	\N	\N	2026-02-13 20:48:06.460034+00	t
f7c695bd-2d82-4bcf-80de-92f8dc39ef1f	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwMTcwMDYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.59Pv5DI2ao6R1Je6sLzZCQlXDomo6ov0w9JOkIquoWM	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2MjA5MDYsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.j-tZOrUj7PjE_Gg929LJbyg4Yu0w6B3QQmZM8s79WRc	\N	2026-02-20 20:55:06.108235+00	2026-02-13 20:55:06.112952+00	\N	\N	2026-02-13 20:55:06.112952+00	t
ff2dfe04-089f-4419-80b2-9a5e509acf20	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwMTcwODQsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.5kP2GGqVytWq_LZt_K_FzZNZ2Me8SomXaEmd-44Wwuc	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2MjA5ODQsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.9RS1Mpm15Ob0IfVDGO4NIamTOzSQOlbf76qy9ut-bpA	\N	2026-02-20 20:56:24.513818+00	2026-02-13 20:56:24.520363+00	\N	\N	2026-02-13 20:56:24.520363+00	t
4b5e73ed-d821-4fad-9c11-6566657c7d12	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwMTcyMTMsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.ytgbF4PzbwomDx2rvgMfNTREcZEp_om_z9UiMEPWRoA	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2MjExMTMsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.UlKpKsGckKwhZh1W_1muDR0UsQ9BYmRFAtmBMpoik9c	\N	2026-02-20 20:58:33.622311+00	2026-02-13 20:58:33.626988+00	\N	\N	2026-02-13 20:58:33.626988+00	t
30dbe043-7743-44d4-9743-8c66cb33e7d8	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwMTcyMTMsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.ytgbF4PzbwomDx2rvgMfNTREcZEp_om_z9UiMEPWRoA	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2MjExMTMsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.UlKpKsGckKwhZh1W_1muDR0UsQ9BYmRFAtmBMpoik9c	\N	2026-02-20 20:58:33.745269+00	2026-02-13 20:58:33.750699+00	\N	\N	2026-02-13 20:58:33.750699+00	t
aa956248-3743-4ece-b13e-00ff928a21d5	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNTg3NjgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.kDTMrZuV_VgsHiyXX48r_amOmBuxhr2b0KrVQWSxUnE	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjI2NjgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.EmHO-mX74IVsqyP_cKy4uegDTaCD5UpnIt4z9b4wqs8	\N	2026-02-21 08:31:08.236262+00	2026-02-14 08:31:08.241089+00	\N	\N	2026-02-14 08:31:08.241089+00	t
f8fabb48-5ece-4513-a0f3-5c91910e08d0	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNTkxNzgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.f9gvxBI0nnswtCiEVtrtdT7UvsQFP-8KTqpbexGae7A	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjMwNzgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.rQt9C6jAYxH759zDlWFqrYf1e8zoTtSTUGek8Ey-pf8	\N	2026-02-21 08:37:58.133759+00	2026-02-14 08:37:58.140622+00	\N	\N	2026-02-14 08:37:58.140622+00	t
cc97636c-0625-43e3-9a36-ac9cb1f3ff3d	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNTkzOTcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.hbsCsRxfzSm0jhFh84gwhkpR24fRfgEumkhUhJcXum4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjMyOTcsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.uOl-M4S4goFNf8lNcO77OQKmiAzYuYZ1Gx3wLz_CzRU	\N	2026-02-21 08:41:37.611423+00	2026-02-14 08:41:37.611761+00	\N	\N	2026-02-14 08:41:37.611761+00	t
d6a0379d-c1f0-4626-bc06-c21419ec0229	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNTk0OTYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.4yx_eO2tC6OoRByMq9tQrE1G8Gl3pFRCFIxz1XwIsIw	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjMzOTYsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.zHzmYxsKRZGYq9lZGP2-dFLied9Mtm2VdliqqV8ZmMo	\N	2026-02-21 08:43:16.277879+00	2026-02-14 08:43:16.278218+00	\N	\N	2026-02-14 08:43:16.278218+00	t
4532168d-d1cd-4136-a4eb-8d562d707f6f	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNTk2OTEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.tB77gUAlw_UeAJsOC_uDOKkkvidQku0l9iCw3ylV2k4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjM1OTEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.CXZAii-gS66jxIZIGrKX9_YulUq0wsQz1rb0dDb24VY	\N	2026-02-21 08:46:31.800382+00	2026-02-14 08:46:31.800717+00	\N	\N	2026-02-14 08:46:31.800717+00	t
6635642a-db63-4d35-ab99-02035f868d18	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNTk3NzgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.dZTegXUjdFM0T63NgYtZSQ8A5ppgQWJi7Z7pMRVMKss	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjM2NzgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.K4vJYG232FbClcOR8qdFcnnUA9mxl7dB3UasseZ1fmc	\N	2026-02-21 08:47:58.10095+00	2026-02-14 08:47:58.101302+00	\N	\N	2026-02-14 08:47:58.101302+00	t
142b7e17-4511-4259-84b6-d6994bbac26f	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNTk5NTUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.BIFMThfHBhDpzF4OmxP70snF-b-ZzYyBpALjslSkcgI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjM4NTUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.HxQ2l5x7flHaa7-tMka80irrRhHvGuOw_VH6QTGK1G0	\N	2026-02-21 08:50:55.137457+00	2026-02-14 08:50:55.137857+00	\N	\N	2026-02-14 08:50:55.137857+00	t
012864d5-2ac2-44ef-aedb-ea38e8649239	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNTk5OTMsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.biLihklNWWGa-qop1rCi2yD7_8zXG0Wn0UvWByqSj4U	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjM4OTMsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.sOUMmePIOB_vrV6f2_umisvXLKG87o173ljUmVrhl5U	\N	2026-02-21 08:51:33.983747+00	2026-02-14 08:51:33.983915+00	\N	\N	2026-02-14 08:51:33.983915+00	t
fe6935e5-7e85-4e60-9e1c-c069c433a7fe	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjEyOTMsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.FY-g3ff-mIljadAsPFsY_yOkQXq8LGE43Jhw73hfblY	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjUxOTMsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ._qhx5fBjhx6aQ23whungeSMemvhYU_2RBIvKpkUOIrA	\N	2026-02-21 09:13:13.73244+00	2026-02-14 09:13:13.732499+00	\N	\N	2026-02-14 09:13:13.732499+00	t
c6ae0d4f-afd2-41e2-bc6c-b6e79e8038f2	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjEzMzUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.w3EKAfnQntkCss3MUmcAWii4ihpNE-TFvDR7R8kxn1I	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjUyMzUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.2fdHncQtlGkOGCF-lI8HcLqU0otnNvELKxt4ejZtPfo	\N	2026-02-21 09:13:55.57146+00	2026-02-14 09:13:55.571781+00	\N	\N	2026-02-14 09:13:55.571781+00	t
f30df130-a419-44fe-a5c2-7d5f9f23bf3d	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjE1ODMsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.22HAHUNmAoYPs6dNQr8LfBup9lvDUlaBRIwfvjU2HNo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjU0ODMsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Fre5EOFP3AyMBoSdJEdktR3XcAImV7a91SVduta7J1g	\N	2026-02-21 09:18:03.441779+00	2026-02-14 09:18:03.442157+00	\N	\N	2026-02-14 09:18:03.442157+00	t
dcc9b02d-8ac1-4728-81fd-340ae6f63f55	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjE4ODYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.2w7npI4LmIBAIoeIYXzGFRXe_25-DcyQz8clHl8GR9c	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjU3ODYsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.fvBS4APKqohgQ2BaI3NFbGcuY_Dw838dJM2R0wpRLTk	\N	2026-02-21 09:23:06.057633+00	2026-02-14 09:23:06.058068+00	\N	\N	2026-02-14 09:23:06.058068+00	t
b21d5ee6-d48a-4d57-91ae-4df4adba2fe5	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjM0NTUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.ZYYSVh4O6JHaFIo0dqjaMWP4wuXetBMsF_xGey1F0vI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjczNTUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.8NnUCXivlkw8zPxJZC1mgicLWXlOW_MKwj7WffYBDtE	\N	2026-02-21 09:49:15.365048+00	2026-02-14 09:49:15.365128+00	\N	\N	2026-02-14 09:49:15.365128+00	t
b52bc095-b214-48f8-a2b4-16dca84f73c1	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjM1MjksIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.SRi5wahfdo42CdnV6RsPNTOONmoqtYwvCVDPrCQmNVM	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2Njc0MjksInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.6pW_X2OnSUnD2cQW2mBl7tYFAiJSysJIF8XNth-Sgzw	\N	2026-02-21 09:50:29.804065+00	2026-02-14 09:50:29.804174+00	\N	\N	2026-02-14 09:50:29.804174+00	t
204e9acd-a65d-47a1-b0fd-e49636491946	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjM1NDQsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.cAoc62WrSFKFPaD5ku375_Q5V-Zb84tsiahSN6nKeh8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2Njc0NDQsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.uRMkiMKJEFApFw6aFamyd2_KMzvzbZofIJFxouCoMdU	\N	2026-02-21 09:50:44.124813+00	2026-02-14 09:50:44.124904+00	\N	\N	2026-02-14 09:50:44.124904+00	t
ee307592-e4c6-4796-9cb1-0159805eec08	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjQxMzksIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.kREklNp_jRXCm88HYaFDnSMmakLLTgrSBdjbbCONo0s	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjgwMzksInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Az-IlEBPP_zL68sbtXRhiIzdXZFRiyd0x-krcB3BD6E	\N	2026-02-21 10:00:39.39586+00	2026-02-14 10:00:39.395943+00	\N	\N	2026-02-14 10:00:39.395943+00	t
aaf6de49-1876-4247-809a-f9a462798f4d	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjQxNjcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.JSpqSSXU_z5RJwAjovuiB5NLJnZN2Huwhrltq6cnP-8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjgwNjcsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.h-rpEz9e1npW76lv4YH6ekn7dqLTtJVihiSrlHl9lto	\N	2026-02-21 10:01:07.87744+00	2026-02-14 10:01:07.877492+00	\N	\N	2026-02-14 10:01:07.877492+00	t
532db3e2-cbc5-480a-a589-a46acbd2143b	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjQxODEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.Oyck6M4EpwQ-R9ZbTooTCW4oQvRYnndVn7sVVIIpbpM	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjgwODEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.JjmEOIkqGNvkRcki82LHFTrtYbFRg_mHSs9fHtLAOCE	\N	2026-02-21 10:01:21.621752+00	2026-02-14 10:01:21.62187+00	\N	\N	2026-02-14 10:01:21.62187+00	t
19f56a09-591b-405a-a5a6-3307106457fd	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjQzMDYsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.VL3NF4VTEmE-2VCg861htxOCjydhDC86DccLYD5iFcI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjgyMDYsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.b8r4QybdqbSMXVrItqrK5XkQlmRn-Yb7EK9cQojxkSo	\N	2026-02-21 10:03:26.944673+00	2026-02-14 10:03:26.944779+00	\N	\N	2026-02-14 10:03:26.944779+00	t
a9d4cac0-2527-4c3f-9e92-09e87c93719c	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjUzMDEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.n3N8JhNEyxOWtAkD-I_aZwd2eqzDCg3PcM12J6Pp2Ks	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2NjkyMDEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.c-75H1IM4NORsWHxlPHcrNOgYr3h0vW8e0aP2rGskks	\N	2026-02-21 10:20:01.158384+00	2026-02-14 10:20:01.158869+00	\N	\N	2026-02-14 10:20:01.158869+00	t
a87f2e1f-c9b4-4a5c-bbda-4b7345797642	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjU4NDUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.ys39V_wquqApD7A3lDEQeNoAUwn2KGVTyiDBwpVV_LQ	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2Njk3NDUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.e5FHbpFKgz8ZfFbkp5aBg35UkGSuq6uF4eHMJ2cdrEs	\N	2026-02-21 10:29:05.802602+00	2026-02-14 10:29:05.803014+00	\N	\N	2026-02-14 10:29:05.803014+00	t
7b210e87-bffe-4bc8-8938-bd3275e593ca	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjU4NjUsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.pFXAllQnUF7Nd9aW4RtMErGcK81I2mORwsPbC7Ru2mg	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2Njk3NjUsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.PEOG91gXYAgwtMoH0M9Pqhjau5aG6agx85rF7sXbDlk	\N	2026-02-21 10:29:25.671129+00	2026-02-14 10:29:25.671209+00	\N	\N	2026-02-14 10:29:25.671209+00	t
890f58b9-ac09-4527-9661-73bbabb9706c	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjU4OTcsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.O2oGyM_wuLsBO_J1juRliTJBTaaI1M1IvNrGx1ejHqY	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2Njk3OTcsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.UwFVy9CB7yjA6ZSWpcG35cROzxWscgyGlqc4LnI4DAw	\N	2026-02-21 10:29:57.591817+00	2026-02-14 10:29:57.592259+00	\N	\N	2026-02-14 10:29:57.592259+00	t
5864b804-d11d-4c6e-b6ec-e1b348d1f07d	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjU5NTgsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ._XThJd0e2N4X02XqMvEUaPr_fbJzIj01uY_z_mvJGMQ	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2Njk4NTgsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.dwLAhpwxxk4lq9KsMuNVKmvJU25P0izcbE9Q8hk7gO0	\N	2026-02-21 10:30:58.062999+00	2026-02-14 10:30:58.063068+00	\N	\N	2026-02-14 10:30:58.063068+00	t
191d7026-df53-4017-b372-38f76f61b0ef	1476a987-76ad-4963-b64a-01a71eb739ca	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEwNjYwODEsIm9yZ19pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMSIsInJvbGUiOiJzdXBlcl9hZG1pbiIsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.OQAA4sRoxQEkvTmKN5ScAAmimQGBV-A3nNuSFBDX3bI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzE2Njk5ODEsInVzZXJfaWQiOiIxNDc2YTk4Ny03NmFkLTQ5NjMtYjY0YS0wMWE3MWViNzM5Y2EifQ.r1W13ipPYfmT24s7lSMEa-iceK6Kzz4T5Aw2x0F9ma0	\N	2026-02-21 10:33:01.914681+00	2026-02-14 10:33:01.914763+00	\N	\N	2026-02-14 10:33:01.914763+00	t
\.


--
-- Data for Name: backup_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.backup_logs (id, backup_id, action, result, actor, message, "timestamp") FROM stdin;
\.


--
-- Data for Name: backup_storage_pools; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.backup_storage_pools (id, provider, bucket, region, tier, encryption_enabled, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.backups (id, backup_type, status, start_time, end_time, duration_seconds, size_bytes, location, retention_days, checksum, initiated_by, remarks, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bulk_config; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.bulk_config (organization_id, max_records_per_file, concurrent_threads, retention_months, mandatory_fields, updated_at) FROM stdin;
\.


--
-- Data for Name: bulk_job_records; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.bulk_job_records (id, job_id, row_number, record_data, status, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: bulk_jobs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.bulk_jobs (id, organization_id, file_name, status, total_records, success_count, failed_count, created_by, created_at, updated_at, retry_count) FROM stdin;
\.


--
-- Data for Name: device_commands; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_commands (id, device_id, org_id, command, category, params, status, result, error_message, created_by, sent_at, executed_at, created_at) FROM stdin;
\.


--
-- Data for Name: device_diagnostics_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_diagnostics_logs (id, device_id, org_id, log_type, source, message, metadata, "timestamp") FROM stdin;
\.


--
-- Data for Name: device_firmware_status; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_firmware_status (id, device_id, rollout_id, status, progress, error_message, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: device_telemetry; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.device_telemetry (id, device_id, org_id, payload, packet_type, raw_hex, "timestamp") FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.devices (id, org_id, vehicle_id, serial_number, type, status, last_ping_at, is_deleted, created_at, updated_at, firmware_version, battery_level, signal_strength, hardware_revision, last_heartbeat, model, manufacturer) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.documents (id, vehicle_id, type, doc_number, issue_date, expiry_date, file_url, status, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dr_restore_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.dr_restore_logs (id, restore_id, level, module, message, created_at) FROM stdin;
\.


--
-- Data for Name: dr_restores; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.dr_restores (id, backup_id, restore_type, target_env, status, started_at, completed_at, initiated_by, duration_seconds, created_at) FROM stdin;
\.


--
-- Data for Name: driver_behavior; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_behavior (id, driver_id, org_id, period_start, period_end, score, safety_score, efficiency_score, compliance_score, harsh_accelerations, harsh_brakings, harsh_cornerings, speeding_incidents, phone_usage, seatbelt_violations, fuel_consumption, distance_driven, idle_time, eco_driving_score, hours_of_service, rest_periods, document_compliance, maintenance_adherence, night_driving_hours, highway_percentage, city_driving_percentage, risk_level, risk_factors, improvement_areas, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_incidents; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.driver_incidents (id, driver_id, org_id, type, severity, "timestamp", location, speed, details, resolved, resolution_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.drivers (id, org_id, first_name, last_name, email, phone, license_number, license_type, license_expiry, license_authority, date_of_birth, address, emergency_contact, status, current_vehicle_id, current_trip_id, joining_date, resignation_date, experience_years, rating, total_trips, total_distance_km, total_hours_driven, behavior_score, documents, attendance_records, schedules, metadata, created_at, updated_at, deleted_at) FROM stdin;
d1000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	John	Doe	john.doe@test.com	+919999999999	DL-1234567890	\N	\N	\N	\N	\N	\N	active	\N	\N	2026-02-10 19:55:42.212123+00	\N	0	5	0	0	0	100	\N	\N	\N	{}	2026-02-10 19:55:42.212123+00	2026-02-10 19:55:42.212123+00	\N
00000000-0000-0000-0000-000000000003	00000000-0000-0000-0000-000000000001	John	Doe	john.doe@test.com	+919999999999	DL-1234567890	\N	\N	\N	\N	\N	\N	active	\N	\N	2026-02-10 19:57:37.534609+00	\N	0	5	0	0	0	100	\N	\N	\N	{}	2026-02-10 19:57:37.534609+00	2026-02-10 19:57:37.534609+00	\N
3ba00e35-6079-44c7-9f92-657b03c5a7fe	00000000-0000-0000-0000-000000000001	Jane	Smith	jane.smith@test.com	+15550102	DL-88332	\N	\N	\N	\N	\N	\N	active	\N	\N	2026-02-11 12:41:41.318003+00	\N	5	4.9	0	0	0	100	\N	\N	\N	{}	2026-02-11 12:41:41.318003+00	2026-02-11 12:41:41.318003+00	\N
d220ca09-d822-4030-a05e-4e841c746f75	00000000-0000-0000-0000-000000000001	Robert	Brown	bob.brown@test.com	+15550103	DL-99443	\N	\N	\N	\N	\N	\N	active	\N	\N	2026-02-11 12:41:41.32331+00	\N	12	4.5	0	0	0	100	\N	\N	\N	{}	2026-02-11 12:41:41.32331+00	2026-02-11 12:41:41.32331+00	\N
4ebc8d68-9748-40c5-8873-405415fe0a29	00000000-0000-0000-0000-000000000001	Alice	Wilson	alice.w@test.com	+15550104	DL-11554	\N	\N	\N	\N	\N	\N	active	\N	\N	2026-02-11 12:41:41.326013+00	\N	3	5	0	0	0	100	\N	\N	\N	{}	2026-02-11 12:41:41.326013+00	2026-02-11 12:41:41.326013+00	\N
db2fc801-6a1e-4a8a-a661-2f22afc7cf38	00000000-0000-0000-0000-000000000012	Delta	Driver 1	driver1@delta.io	+15550202	DL-DLT-001	LMV	2031-02-12 19:37:29.637078+00	RTO Bangalore	1990-01-01 00:00:00+00	{}	{}	active	\N	\N	2026-02-12 19:37:29.637078+00	\N	5	4.5	0	0	0	100	\N	\N	\N	{}	2026-02-12 19:37:29.637078+00	2026-02-12 19:37:29.637078+00	\N
\.


--
-- Data for Name: entity_audit_history; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.entity_audit_history (id, entity_type, entity_id, change_data, actor, "timestamp") FROM stdin;
\.


--
-- Data for Name: evidence_exports; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.evidence_exports (id, org_id, module, date_range_start, date_range_end, format, status, requested_by, file_url, error_message, created_at) FROM stdin;
8fa406d0-1f24-48f3-a004-37e1595d9bc5	1476a987-76ad-4963-b64a-01a71eb739ca	SECURITY	2026-01-01 00:00:00+00	2026-02-09 00:00:00+00	json	processing	4cb4efd1-0717-41ea-a7c7-c74faa999cbc	\N	\N	2026-02-09 14:14:24.795768+00
\.


--
-- Data for Name: firmware_packages; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.firmware_packages (id, version, hardware_target, file_url, file_size, checksum, release_notes, status, is_critical, released_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: firmware_rollouts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.firmware_rollouts (id, firmware_id, org_id, name, device_group, target_filter, total_devices, completed_devices, failed_devices, status, rollout_strategy, max_concurrent, created_by, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: geofences; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.geofences (id, org_id, name, type, center, radius_meters, coordinates, route_polyline, buffer_meters, entry_alert, exit_alert, speed_limit, vehicles, enabled, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: global_notification_defaults; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.global_notification_defaults (id, email_enabled, sms_enabled, push_enabled, in_app_enabled, updated_by, updated_at) FROM stdin;
1	t	t	t	t	85374bef-c6fd-4a08-bd1d-7ce96e4c14ed	2026-02-08 18:22:23.963271+00
2	t	t	t	t	85374bef-c6fd-4a08-bd1d-7ce96e4c14ed	2026-02-08 18:22:23.963271+00
3	t	t	t	t	85374bef-c6fd-4a08-bd1d-7ce96e4c14ed	2026-02-08 18:22:23.963271+00
\.


--
-- Data for Name: incident_comments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.incident_comments (id, ticket_id, author_id, author_name, comment_type, content, is_private, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: integration_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.integration_logs (id, org_id, integration_id, method, endpoint, request_body, response_body, status_code, status, duration_ms, "timestamp") FROM stdin;
\.


--
-- Data for Name: integrations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.integrations (id, org_id, name, type, provider, status, config, last_sync, created_at, updated_at) FROM stdin;
a1ec9700-3172-47c8-93aa-24b2a6d28fbd	1476a987-76ad-4963-b64a-01a71eb739ca	Twilio E2E Test	SMS	Twilio	active	{"api_key": "test_key"}	\N	2026-02-09 14:47:57.666873+00	2026-02-09 14:47:57.666873+00
\.


--
-- Data for Name: inventory_parts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.inventory_parts (id, organization_id, part_number, name, description, stock_location, quantity_available, reorder_level, unit_cost, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ip_rules; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.ip_rules (id, org_id, cidr, action, description, added_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: login_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.login_events (id, org_id, user_id, email, ip_address, device, browser, location, status, risk_level, created_at) FROM stdin;
602c0a3a-655b-4c66-aa4f-bc67149700da	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:40942	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 11:46:16.57421+00
065281e7-a8c8-4346-9349-d443d7304b02	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:60772	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 12:17:34.807377+00
28f28441-f16f-458b-bf0e-c00054089621	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:49172	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 12:22:01.565975+00
cb8d7873-735d-4265-a771-0d6ddc53a2b7	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:49452	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 12:25:23.681428+00
b58939cf-f349-4ca0-8b9c-aee6f25b80cb	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:49682	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 12:26:31.835743+00
9fa646cf-5937-4429-8a80-95a7fc2981f5	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:35100	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 12:30:20.190836+00
0290134f-a248-4c5a-a317-c74ec99fea9b	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:35100	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 12:30:48.281207+00
3e738ce6-902d-4398-a101-a53a47c6dcce	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:38168	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 12:31:18.049287+00
0f213405-53af-4bdb-adf6-3bcb5d5969dc	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:40788	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 12:33:37.540242+00
a6b4b155-ade8-421f-8141-54081d401856	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:53160	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 12:33:51.862755+00
6f54e405-36f0-404a-961b-fe7b49aca41b	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:58654	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 12:38:46.235864+00
dd139cd8-b914-446f-8bc2-6cf1a23cccc6	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:54948	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 12:39:38.438743+00
ad430b88-c048-47e3-9410-d52330b3c207	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:51046	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 12:53:21.903305+00
93f384df-74b2-48a4-8cac-c5fbd50c06f9	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:37666	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 12:53:55.180108+00
b39342dd-854a-45d3-8c81-1477f7880b2c	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:58908	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 12:58:00.031034+00
3b648436-c0e0-460e-9946-9a885976d827	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:41440	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 13:24:15.922118+00
920e8260-7982-4d9c-bfce-c274ab7ad13a	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:43376	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 14:36:34.76686+00
a2c963c1-75b4-4772-a7d5-bf0540907c18	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:51036	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 14:52:11.133851+00
dea0efbd-3884-4a26-88dc-72b833b7556a	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:49280	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 14:53:08.527403+00
ecab8cf0-148b-4ea4-a4b9-961cb734dfa5	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:42734	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 15:45:35.953982+00
dcb50dfa-b58a-46cd-9c62-9278979393d4	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:37904	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 15:54:05.241838+00
c4df73d2-4065-494d-afd9-260a8a1a41d8	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:37904	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 15:54:13.969857+00
2211fb6e-1a9b-4e66-9fa4-79997047eba8	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:36150	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 15:58:00.480463+00
9600b72b-ddb4-413a-acc5-cc64d325dc0c	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:45814	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 16:20:19.196035+00
9164b683-89c8-42db-b378-2ab429b31baa	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:54308	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Qoder/0.4.5 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36		SUCCESS	low	2026-02-10 16:41:47.913386+00
1ed49b94-a35c-40df-a893-392228ab6b6f	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:55134	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Qoder/0.4.5 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36		SUCCESS	low	2026-02-10 16:42:25.408649+00
326d7846-b604-433a-a05f-ac3aecc7195f	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:35090	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Qoder/0.4.5 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36		FAILED	low	2026-02-10 17:27:06.275833+00
e9f74e90-905a-4041-ae0e-38ee003d6d56	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:40324	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Qoder/0.4.5 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36		SUCCESS	low	2026-02-10 17:27:11.514054+00
3e9bc716-ca2d-4783-a518-38ed4ec5d621	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:35820	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Qoder/0.4.5 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36		SUCCESS	low	2026-02-10 17:47:43.779471+00
b357911b-add3-4adf-9227-e73c0cca8d8f	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:52382	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 18:55:08.810427+00
358c9e90-a4f8-44b9-b4d0-5f126b92c0db	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:52396	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 18:55:24.636207+00
93c83138-188a-4d24-8951-6730e8e9e0f3	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:44124	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 19:08:18.115134+00
eda3ab6e-2999-463f-a77b-2b879424ad0d	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:44146	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 19:08:59.774699+00
aa3ee74f-7960-4ca7-903b-6e6db29599ea	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:40588	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 19:20:21.918029+00
52b1202a-5a7a-4ed3-b557-247495296fad	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:43358	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 19:38:22.19092+00
298c14e1-095f-45a0-9447-fa5a9a8ac051	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:54892	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 19:42:38.821236+00
5b35fbff-0d17-47fe-8fa6-d4a2450de5cf	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:54892	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-10 19:42:58.210432+00
126b0dfd-c141-4222-a309-1eaa69fe3499	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:41660	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 19:59:18.390513+00
16eb7764-ae92-4cfd-85c8-9c55e903d2ee	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:36472	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 20:00:48.78481+00
c3b168c8-4c79-470a-9e49-f847ff9623e2	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:53218	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 20:04:26.966679+00
47aa7093-42c1-4e56-91b3-a9343fdb6edb	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:45830	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 20:08:05.906394+00
b820aca7-f95f-441b-aafd-11ec5b0f2f35	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:45830	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 20:08:17.006062+00
7a7fe953-eee5-4248-b79f-55738589c90e	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:45830	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 20:09:02.619466+00
70ecf9ff-f5f5-45cf-8d19-1bc149541169	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:56606	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 20:11:11.544442+00
f8ae62e8-9127-456a-8320-266d99f291d3	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:56606	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 20:11:31.420069+00
52314881-0dff-4b66-92b1-9ad3b71c9f7e	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:54820	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 20:12:50.904925+00
eba781d9-1e11-44ce-b494-214030ead9d5	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:47386	Unknown	curl/8.5.0		SUCCESS	low	2026-02-10 20:13:40.379301+00
c1fb9534-066c-4d83-8479-c67886c025a2	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:34318	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-11 12:13:45.492791+00
18041ac8-7aec-4184-939e-636e611442c1	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:48162	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-11 12:37:35.83387+00
ec6ac8e2-6632-4b6e-bd0b-67a2938a2e8f	00000000-0000-0000-0000-000000000001	dcc55d56-2e2f-499b-aca8-821e2e10887a	admin@flyfleet.com	127.0.0.1:43920	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		FAILED	low	2026-02-11 12:55:10.17026+00
2208271e-191d-44c6-985b-83effdcff63f	00000000-0000-0000-0000-000000000001	dcc55d56-2e2f-499b-aca8-821e2e10887a	admin@flyfleet.com	127.0.0.1:55442	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		FAILED	low	2026-02-11 12:57:49.445522+00
f305ab28-7804-4066-b1d9-3bfdd98b6dda	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:56242	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		FAILED	low	2026-02-11 14:22:15.958076+00
167e5fa9-c07d-44f3-a341-20838c9b96c0	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:51384	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		FAILED	low	2026-02-11 14:22:27.263535+00
053c84ea-bfca-48cd-8a12-5206fc29db63	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:52726	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-11 14:22:35.876041+00
6f37ffc0-d4ec-4aec-9271-00f9a236023d	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:39782	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		FAILED	low	2026-02-11 14:50:27.808652+00
eb33a67d-5177-4c7a-a220-57a456ef40d9	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:32778	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-11 14:50:35.166258+00
e27bc15b-9ded-483b-b3b2-716f6244a4ea	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:56150	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Qoder/0.4.5 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36		SUCCESS	low	2026-02-11 15:15:40.249085+00
4972bdc9-bc71-4cf6-9d79-3f506bc35cff	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:45010	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Qoder/0.4.5 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36		SUCCESS	low	2026-02-11 15:41:35.776581+00
1f60dbdf-b772-4906-be52-98464ce28dbe	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:35330	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Qoder/0.4.5 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36		SUCCESS	low	2026-02-11 15:56:39.824252+00
ded52802-9032-4101-8859-f471e19bf024	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.1:39748	Unknown	curl/8.5.0		FAILED	low	2026-02-13 20:39:35.137532+00
1ed8a112-f324-405c-93cd-7c4692639d56	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:52846	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Qoder/0.4.5 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36		SUCCESS	low	2026-02-11 15:58:26.990216+00
2e4557a3-c784-4074-aece-3197da154c9f	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:49966	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Qoder/0.4.5 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36		SUCCESS	low	2026-02-11 16:03:05.335624+00
f8f70812-84be-4225-878d-560aae973496	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:44416	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-11 16:05:19.244303+00
60d1b199-f015-4e5b-9d30-6a04b83e23b9	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:56194	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Qoder/0.4.5 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36		SUCCESS	low	2026-02-12 07:43:01.934408+00
13e5e5c5-87ed-46aa-925f-51ea288ec82f	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:32942	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-12 07:47:31.346064+00
26e1e66f-8cfc-4b06-a58e-0e1176e978a8	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:45786	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-12 08:10:43.683442+00
892c49c2-3318-46a7-93a2-558ce418c23f	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:58344	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Qoder/0.4.5 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36		SUCCESS	low	2026-02-12 08:43:45.303484+00
3bfd5035-0a63-4dd9-be6b-aedcd2fe95a0	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:58348	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-12 08:44:26.579058+00
b5c6766d-cacf-4c62-8683-2cb633075014	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:43890	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Qoder/0.4.5 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36		SUCCESS	low	2026-02-12 08:49:03.1463+00
5c0008b3-413f-4437-ae6c-a9671f98c12c	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:41436	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Qoder/0.4.5 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36		SUCCESS	low	2026-02-12 09:11:43.703366+00
010ba2c0-802b-4cec-a3f9-504407dc83b3	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:46208	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		FAILED	low	2026-02-12 09:33:08.039831+00
67799dc5-b06e-4464-b640-94ee54b90cf3	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:43792	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-12 09:33:11.765498+00
aeb7ed9c-11a3-4909-99ed-c81e28445781	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:54706	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36		SUCCESS	low	2026-02-12 09:52:19.108592+00
08ef8626-804e-4db9-af8f-0e0f181fd1f2	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:46548	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 09:54:56.66428+00
54685d69-84f6-4545-baf4-9bef2b5fa241	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:46548	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 09:55:11.329754+00
7f5de9a9-dedf-4949-8072-fb8947f71847	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	127.0.0.1:46548	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 09:56:01.675424+00
d71ad840-5ce0-49ea-b112-145c9dec3b74	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:46548	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 09:56:56.480788+00
129250a6-4103-4b54-8fd2-6adcdb364269	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	127.0.0.1:46548	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 09:57:29.833065+00
baa6422b-e146-4b11-8d06-1c723d6ae100	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	127.0.0.1:46548	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 09:58:04.290252+00
e698602f-e102-4e6e-8b5a-9737ca577816	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	127.0.0.1:46548	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 09:59:21.814349+00
a861083c-5b4b-4c4a-9100-f71174510e13	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.10:36582	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:13:59.839592+00
0d96796c-6d88-478d-ba13-95533120ed46	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.10:46654	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:17:56.851007+00
02363b78-02f2-4cb5-85a0-cf69cfb0e9ea	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.5:39492	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:18:36.293403+00
85190563-3860-4baa-b618-162d1ddfebd1	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.5:37302	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:20:53.857609+00
4dd6df0f-5049-44d8-86f9-00b3ad70e64c	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.5:55414	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:24:56.262986+00
0fe69d33-0a52-46de-a4ad-040fb84ad81a	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.5:59032	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:26:50.887045+00
23fc733a-3b76-4f34-bc96-8474665bcfdc	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.5:59032	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:27:48.322723+00
4cab1491-6c5a-4c90-ae77-5b9997940827	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.5:59032	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:28:07.302243+00
3294671b-6360-4f8b-9b5b-45923fde4368	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.5:59032	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:28:48.869021+00
1796b479-4f68-448c-a98d-0901337eca25	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.5:59032	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:29:46.925789+00
9fe8b937-3595-4369-8180-9a81e501db92	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.5:59032	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:30:15.506702+00
b65df0cc-13da-4eeb-8f70-b3047b4b002e	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.5:59032	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:31:28.777708+00
73ba64d2-1981-4eb9-9d09-9434e5eb0ec2	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.5:59032	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:31:44.56417+00
9c135e92-7fa2-464e-bf37-e2fd55d7eeb2	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.5:38296	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:35:45.583028+00
68af7d8d-90b3-4d86-afc9-80eb6d6123d9	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.12:54728	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:47:58.395092+00
2d5d2066-962e-4b1e-af0e-800ca51715ee	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.11:33810	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 10:53:58.514892+00
ca98f566-957e-4e91-bf20-38dd1c964bd8	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.3:35764	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 19:35:14.23245+00
2a97ab52-3cc8-4db8-8777-fe2032f3676b	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.3:33316	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 19:38:37.093601+00
1a23be4b-a130-41d1-9404-e6676dd1668e	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.3:48364	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 19:42:08.906724+00
0fc6b420-277e-4c2d-a7dd-1360bf98b9bc	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.3:48364	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 19:42:48.848247+00
607b8f33-95da-4c65-bccf-2d35cbc56617	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.3:48364	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 19:44:48.843065+00
95768269-c81a-4e57-b533-03ceac9de73a	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.3:39022	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 19:47:59.74041+00
fa2f59f0-73f1-4601-a835-6d0cdf212d6d	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.3:52478	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-12 19:50:52.207443+00
97c44abf-32c6-4ba3-b590-f57513ecfc2b	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.3:57134	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-12 19:52:07.42662+00
10ea6c20-ed0d-4290-a68b-66bb32cd4cfe	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.3:50152	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 19:52:55.62239+00
69a9df9d-2833-4c29-91f2-16fa5fd368a5	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.3:50152	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 19:53:35.825411+00
d2c82800-6d02-4217-8f15-9e062c90c644	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.3:50152	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 19:53:46.494172+00
b02b7c41-1a2b-4c2c-bb2c-e9391660f1d3	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.3:50152	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 19:54:15.307778+00
d6efa5be-363a-4776-8461-a3185d7f1207	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.3:50152	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 19:54:47.471896+00
fa6d83ad-1057-48b8-82d2-b648801c826c	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.3:37150	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 19:56:40.580806+00
0895cd3a-8fab-4de4-8426-298f20e20c20	00000000-0000-0000-0000-000000000012	0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	172.18.0.3:40102	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 19:58:35.613085+00
7466931e-8a5e-4f86-bb47-7ca3648ce739	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.3:55520	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-12 20:00:07.230494+00
96bbddbe-b509-4845-a9b4-5881dff4b4bb	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.3:57320	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-12 20:14:25.482315+00
2468a019-2d3d-4d4f-adef-35b7ea4239ff	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.3:60720	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-12 20:17:51.672801+00
08a630e6-2c5a-49f7-a274-5b20fcacaf3f	00000000-0000-0000-0000-000000000001	dcc55d56-2e2f-499b-aca8-821e2e10887a	admin@flyfleet.com	172.18.0.3:56758	Unknown	curl/8.5.0		FAILED	low	2026-02-12 20:28:40.508577+00
329502c3-0a98-44ad-a411-6e5a697cd013	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.3:56758	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 20:28:59.885287+00
92acfe58-dda2-4ff2-ab66-0c08a37747ed	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.3:47756	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 20:43:54.829603+00
c6310b9f-0ec5-4804-97a1-1f06b89e5ec6	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.3:33280	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 20:47:14.154418+00
0b63b793-4fa2-4705-86ae-a523a2cb784a	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.3:44874	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-12 21:00:50.110578+00
fcd929b8-e81a-481c-bc03-f895ded4ce88	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.1:50614	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 21:02:43.002539+00
9a54c0d6-58a9-4d3c-bb79-8b1a979148a0	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.1:39856	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 21:20:46.127807+00
fa1a1e37-2c86-478c-8724-207ca4b6ea8c	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.3:40014	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 21:23:28.361413+00
21347c04-3a73-4233-92a2-a436a8713b95	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.3:33084	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 21:24:08.148857+00
0cf55224-a60f-4f3c-a6e7-52c5f8e2bba5	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.3:46782	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-12 21:28:27.479307+00
2fc51977-096d-414b-95c2-2c8130c5b918	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:58260	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 21:40:27.168084+00
b4acc02d-56d4-4ee2-be10-ee498b60d633	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:54140	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 21:40:36.681293+00
d9761857-5789-453c-85c9-b5b91072fc1f	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:47102	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 21:40:47.579333+00
3791db65-6d46-4af6-af9a-303dc732e7ae	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:33196	Unknown	curl/8.5.0		SUCCESS	low	2026-02-12 21:41:02.347853+00
f72c70a4-da75-41b2-8276-f77f478ccf15	00000000-0000-0000-0000-000000000001	dcc55d56-2e2f-499b-aca8-821e2e10887a	admin@flyfleet.com	127.0.0.1:34814	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		CHALLENGED	medium	2026-02-12 22:04:54.012321+00
6a8d76bf-5f5d-41c3-9550-d3983eea929c	00000000-0000-0000-0000-000000000001	dcc55d56-2e2f-499b-aca8-821e2e10887a	admin@flyfleet.com	127.0.0.1:54776	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		CHALLENGED	medium	2026-02-12 22:08:10.300251+00
95c1037d-a6ab-4bb0-bf09-4fd66cf2b4de	00000000-0000-0000-0000-000000000001	dcc55d56-2e2f-499b-aca8-821e2e10887a	admin@flyfleet.com	127.0.0.1:38598	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		CHALLENGED	medium	2026-02-12 22:08:38.439565+00
97b33601-671e-43d0-bdb5-9d95fa23cd25	00000000-0000-0000-0000-000000000001	dcc55d56-2e2f-499b-aca8-821e2e10887a	admin@flyfleet.com	127.0.0.1:54606	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		CHALLENGED	medium	2026-02-12 22:09:14.264399+00
07e1bc87-59b5-4b28-b7e6-44c9d17485b3	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:36600	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-12 22:16:02.8819+00
b8a16cff-56f2-4995-b282-df9a236ac29c	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.12:40812	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-13 17:01:20.062276+00
4a7147be-86a3-42ca-90c0-e2b050a6d6ef	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.12:37070	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-13 19:50:24.801161+00
4289b2fa-ad30-4155-98bb-221400337853	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.1:36422	Unknown	curl/8.5.0		FAILED	low	2026-02-13 20:38:40.180242+00
f414a95d-4cb9-4b8b-a43b-7a34e564910f	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.1:54752	Unknown	curl/8.5.0		FAILED	low	2026-02-13 20:41:05.941793+00
ed9d3b50-f283-4d54-87fb-e5719a3b8976	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.1:54752	Unknown	curl/8.5.0		CHALLENGED	medium	2026-02-13 20:41:20.851333+00
df0d0d23-878e-41c6-92a5-0be027363b67	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.1:54752	Unknown	curl/8.5.0		SUCCESS	low	2026-02-13 20:42:04.245998+00
bb699628-9221-45fb-94f5-ff8544241d75	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.1:35002	Unknown	curl/8.5.0		SUCCESS	low	2026-02-13 20:43:23.470394+00
7f15a79d-f56f-446c-8127-09b0f76c788a	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	172.18.0.1:55244	Unknown	curl/8.5.0		SUCCESS	low	2026-02-13 20:48:06.425794+00
96ad8a9a-87d5-40dc-8fd2-c358ca5031da	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:42024	Unknown	curl/8.5.0		SUCCESS	low	2026-02-13 20:55:06.084094+00
0b213b42-cb5b-458c-a188-c3d09bafcd21	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:42024	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-13 20:56:24.478684+00
0c2947f4-3730-4b0c-8797-61dc59ef5ef1	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:45598	Unknown	curl/8.5.0		SUCCESS	low	2026-02-13 20:58:33.597265+00
393b2fc8-5198-46a8-b9f8-1e520c006763	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:45598	Unknown	curl/8.5.0		SUCCESS	low	2026-02-13 20:58:33.717667+00
09539695-4ae3-4721-b954-7cefad9c1ebc	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:51676	Unknown	curl/8.5.0		SUCCESS	low	2026-02-14 08:31:08.212561+00
f0e3bbcd-bb0d-4cc2-89b7-d0de26949ab8	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:44328	Unknown	curl/8.5.0		SUCCESS	low	2026-02-14 08:37:58.089574+00
b25711fa-8ac8-48e6-aa72-cc97a271f4af	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:54758	Unknown	curl/8.5.0		SUCCESS	low	2026-02-14 08:41:37.606435+00
70c20464-4086-4e82-a62e-84b9cff5ee57	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:49416	Unknown	curl/8.5.0		SUCCESS	low	2026-02-14 08:43:16.273041+00
fc8141e3-71fb-4dc9-a148-520f83387f08	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:58266	Unknown	curl/8.5.0		SUCCESS	low	2026-02-14 08:46:31.795624+00
9a5acef8-1a29-4937-8142-4a0f45dba05f	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:56570	Unknown	curl/8.5.0		SUCCESS	low	2026-02-14 08:47:58.0963+00
32fc5f0f-23cd-40a4-8b37-f25fb9a5b1be	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	[::1]:44768	Unknown	curl/8.5.0		SUCCESS	low	2026-02-14 08:50:55.132276+00
0c812de7-f6f6-48d2-9d2a-b3c915cf50a2	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:33260	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-14 08:51:33.977003+00
4d0b44d2-51a6-4253-85bd-61a847db6bca	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:36546	Unknown	curl/8.5.0		SUCCESS	low	2026-02-14 09:13:13.728813+00
8158f71d-fec4-4229-93e5-1143d8591ca9	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:47904	Unknown	curl/8.5.0		SUCCESS	low	2026-02-14 09:13:55.566579+00
7c50cc8d-8300-47d7-8fb7-58bb0c8af312	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:58294	Unknown	curl/8.5.0		SUCCESS	low	2026-02-14 09:18:03.437115+00
77d169b2-e08c-4e0e-857a-487ae008bf4d	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:58124	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-14 09:23:06.052281+00
64ceff4c-46b6-4807-9153-21e25bdc2f28	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:54716	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-14 09:49:15.36109+00
fd325bbd-9f5e-4e73-afa8-6297996d68fc	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:54716	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-14 09:50:29.799455+00
6c304c61-3772-4bbd-b940-2832015f8107	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:41020	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-14 09:50:44.121212+00
840db198-c854-4a3e-9472-6ffb8757b5da	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:38654	Unknown	curl/8.5.0		SUCCESS	low	2026-02-14 10:00:39.3908+00
e0cb59e9-2be8-4a75-9dc6-283de5ffb9ad	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:38654	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-14 10:01:07.874228+00
882410b5-80f8-4abe-b350-15414e68c4d2	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:60520	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-14 10:01:21.617452+00
ccb18aea-2538-4777-8f34-45dc3200fd54	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:52172	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-14 10:03:26.939446+00
41d4a643-1fa0-4e1b-a3b0-452a78ff5930	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:51556	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-14 10:20:01.151937+00
cf30fb03-f7bf-4df0-b536-02a0081c4a3f	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:50522	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		FAILED	low	2026-02-14 10:28:34.745774+00
0b9441e7-dd06-42c9-b796-a5c40746f526	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:44292	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-14 10:29:05.797522+00
a5834993-9834-4d24-ae73-49d136525444	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:42336	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-14 10:29:25.667464+00
2e3e3848-cb76-4c91-a75b-801766dcc271	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:50440	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-14 10:29:57.587697+00
396a4fa1-22e9-409b-a593-254cd3a483f5	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:54358	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		FAILED	low	2026-02-14 10:30:00.568139+00
4a2bbf6c-536f-4bc4-9d76-44c3986c83d1	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:60600	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-14 10:30:58.059113+00
323921bc-a20e-4915-be06-64ea7f8453f7	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:54614	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		SUCCESS	low	2026-02-14 10:33:01.910891+00
f205d024-2870-4b02-abc7-9da489a6c733	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:38938	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		FAILED	low	2026-02-14 10:44:41.882808+00
fab82857-f4e0-4075-9819-4e07b80754ba	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:42308	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		FAILED	low	2026-02-14 10:44:52.905856+00
f4111119-a05d-48a0-9c49-249fb6dd6007	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:45458	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		FAILED	low	2026-02-14 10:45:37.957602+00
f49b98ce-0fdf-4d2f-a911-18ba9756dd82	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:57312	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		CHALLENGED	medium	2026-02-14 10:46:49.750246+00
3493a468-a6b4-4fdf-b470-80edd8edd62f	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:55146	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		CHALLENGED	medium	2026-02-14 10:48:25.587455+00
b5d1c12c-f3f8-4cf2-abe4-baee71d75599	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:55146	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		CHALLENGED	medium	2026-02-14 10:48:34.70018+00
7a599b65-0b6f-495e-8b5f-1e87ea9af0cd	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:55146	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		CHALLENGED	medium	2026-02-14 10:48:53.546733+00
bbfd84c1-43b8-4f15-89d5-559a9f38e31f	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:38962	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		CHALLENGED	medium	2026-02-14 10:47:26.08665+00
9dc90675-8301-4122-89cc-d55ac134fbfb	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:52166	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		CHALLENGED	medium	2026-02-14 10:49:03.981038+00
e0304be3-4bfa-4998-b6de-abf725d363f4	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:53236	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		CHALLENGED	medium	2026-02-14 10:49:27.31188+00
9090f91b-d509-4905-bac0-03659f215b78	00000000-0000-0000-0000-000000000001	1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	127.0.0.1:53066	Unknown	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36		CHALLENGED	medium	2026-02-14 10:49:37.948924+00
\.


--
-- Data for Name: maintenance_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.maintenance_settings (organization_id, sla_p1_hours, sla_p2_hours, sla_p3_hours, low_stock_threshold, approval_threshold, auto_assign_enabled, notification_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_codes; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_codes (id, user_id, code, method, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_events (id, user_id, org_id, event_type, status, method, ip_address, user_agent, location, details, created_at) FROM stdin;
fa0093bb-288a-41c1-adbf-b65e0232b581	4cb4efd1-0717-41ea-a7c7-c74faa999cbc	1476a987-76ad-4963-b64a-01a71eb739ca	VERIFY_SUCCESS	success	totp	192.168.1.10	\N	Mumbai, IN	\N	2026-02-07 14:17:49.709884+00
3db52134-2250-4feb-911b-0c0ce0a114fc	4cb4efd1-0717-41ea-a7c7-c74faa999cbc	1476a987-76ad-4963-b64a-01a71eb739ca	VERIFY_FAILED	failure	sms	45.12.33.21	\N	London, UK	\N	2026-02-07 14:17:49.709884+00
428a9b70-6481-44a8-8aa5-0a2b97421cdc	4cb4efd1-0717-41ea-a7c7-c74faa999cbc	1476a987-76ad-4963-b64a-01a71eb739ca	CHALLENGE_ISSUED	pending	totp	192.168.1.10	\N	Mumbai, IN	\N	2026-02-07 14:17:49.709884+00
759212fd-1b58-4032-ab7c-b17e554ad74b	4cb4efd1-0717-41ea-a7c7-c74faa999cbc	1476a987-76ad-4963-b64a-01a71eb739ca	VERIFY_SUCCESS	success	totp	192.168.1.10	\N	Mumbai, IN	\N	2026-02-07 14:18:24.030976+00
\.


--
-- Data for Name: mfa_exceptions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_exceptions (id, user_id, org_id, reason, granted_by, expires_at, created_at, start_date) FROM stdin;
\.


--
-- Data for Name: mfa_failures; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_failures (id, user_id, org_id, method, failure_reason, ip_address, location, created_at) FROM stdin;
538373b3-d7c0-4018-b8e4-72ced1669b83	4cb4efd1-0717-41ea-a7c7-c74faa999cbc	1476a987-76ad-4963-b64a-01a71eb739ca	sms	Invalid code	45.12.33.21	London, UK	2026-02-07 14:17:49.714415+00
a69ad2a0-1e5c-423c-bd87-36286c010393	4cb4efd1-0717-41ea-a7c7-c74faa999cbc	1476a987-76ad-4963-b64a-01a71eb739ca	totp	Timeout	14.22.88.102	Shenzhen, CN	2026-02-07 14:17:49.714415+00
d327f3b2-7299-4aad-83e0-f3d3a5779c87	4cb4efd1-0717-41ea-a7c7-c74faa999cbc	1476a987-76ad-4963-b64a-01a71eb739ca	sms	Invalid code	45.12.33.21	London, UK	2026-02-07 14:18:24.824683+00
\.


--
-- Data for Name: mfa_lockouts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_lockouts (id, user_id, org_id, reason, locked_at, expires_at, unlocked_at, unlocked_by) FROM stdin;
d93665d5-5361-4b9f-8b08-b592d5c2aa40	4cb4efd1-0717-41ea-a7c7-c74faa999cbc	1476a987-76ad-4963-b64a-01a71eb739ca	Too many failed attempts	2026-02-07 14:17:49.718198+00	2026-02-07 14:47:49.718198+00	\N	\N
8c65bbc7-ff33-4d37-9c10-e823f0cf5ebf	4cb4efd1-0717-41ea-a7c7-c74faa999cbc	1476a987-76ad-4963-b64a-01a71eb739ca	Too many failed attempts	2026-02-07 14:18:25.851058+00	2026-02-07 14:48:25.851058+00	\N	\N
\.


--
-- Data for Name: mfa_org_overrides; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_org_overrides (id, org_id, enabled, allowed_methods, max_attempts, lockout_minutes, remember_device_days, grace_period_days, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_policies; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_policies (id, org_id, require_mfa, allowed_methods, max_attempts, lockout_minutes, created_at, updated_at, grace_period_days, remember_device_days, enforce_at_login, admin_only_mode, remember_device_allowed, mfa_challenge_timeout, version) FROM stdin;
3bf6879c-812b-4595-9008-b6e1bac82d5d	1476a987-76ad-4963-b64a-01a71eb739ca	t	["totp", "sms"]	5	30	2026-02-07 14:17:49.704788+00	2026-02-07 14:17:49.704788+00	7	30	t	f	t	60	1
\.


--
-- Data for Name: mfa_policy_history; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_policy_history (id, policy_id, org_id, snapshot, changed_by, change_reason, version, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_users; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.mfa_users (user_id, org_id, status, method, trusted_devices_count, last_reset, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.notification_events (id, notification_id, event_type, message, created_at) FROM stdin;
b4004591-759c-4b23-903b-d0e52f2f6de3	9addbff8-22db-4965-95e6-f29cdd0151b1	SENT	Delivered to gateway	2026-02-08 17:36:57.420483+00
2770b930-08d0-4b18-b5fe-86bca1df394a	2a2d7ab6-4bee-4233-9620-38a3de74b2b1	SENT	Delivered to gateway	2026-02-08 17:37:26.686673+00
9f7adb27-c68c-4d9e-a032-0fd6b9e26adb	dbd21456-fb2d-4946-934c-3b8b4b6d8f09	SENT	Delivered to gateway	2026-02-08 17:38:22.479855+00
696ea970-4de2-4f8a-abdf-8a13e58987a9	f46589b3-a764-493b-9543-c10b7a8006a9	SENT	Delivered to gateway	2026-02-08 17:38:22.855672+00
d7b27725-3b4b-436f-a65e-2de8b03c1938	6c7673b6-778c-468d-9605-f125ca565d5a	SENT	Delivered to gateway	2026-02-08 18:20:05.973447+00
b3a0ee16-1564-4cb3-84b8-99411256211a	1b2d13f3-d462-48a3-b101-ac3ef0e32cb6	SENT	Delivered to gateway	2026-02-08 18:22:23.925959+00
\.


--
-- Data for Name: notification_logs; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.notification_logs (id, correlation_id, user_id, user_email, channel, type, subject, body, status, provider, provider_response, retry_count, max_retries, metadata, created_at, updated_at) FROM stdin;
75326652-43da-4e41-b93d-a5a1fbf4e233	test-corr-1	\N	user@example.com	EMAIL	SECURITY	Integrated Test	Hello world	QUEUED		\N	0	3	{"test": true}	2026-02-08 17:36:57.405589+00	2026-02-08 17:36:57.405589+00
9addbff8-22db-4965-95e6-f29cdd0151b1		\N	timeline@example.com	SMS	SYSTEM			SENT		\N	0	0	\N	2026-02-08 17:36:57.416236+00	2026-02-08 17:36:57.416236+00
c275e595-df95-40b4-b194-a09f4095d2eb	test-corr-1	\N	user@example.com	EMAIL	SECURITY	Integrated Test	Hello world	QUEUED		\N	0	3	{"test": true}	2026-02-08 17:37:26.675328+00	2026-02-08 17:37:26.675328+00
2a2d7ab6-4bee-4233-9620-38a3de74b2b1		\N	timeline@example.com	SMS	SYSTEM	Timeline Test	Body	SENT		\N	0	0	\N	2026-02-08 17:37:26.682613+00	2026-02-08 17:37:26.682613+00
d25eaad5-9073-48b9-a1cb-bcf1316d921f	test-corr-1	\N	user@example.com	EMAIL	SECURITY	Integrated Test	Hello world	QUEUED	\N	\N	0	3	{"test": true}	2026-02-08 17:38:22.470673+00	2026-02-08 17:38:22.470673+00
dbd21456-fb2d-4946-934c-3b8b4b6d8f09	\N	\N	timeline@example.com	SMS	SYSTEM	Timeline Test	Body	SENT	\N	\N	0	0	\N	2026-02-08 17:38:22.477493+00	2026-02-08 17:38:22.477493+00
944d4abd-0e05-47f9-b679-555d81d85749	test-corr-1	\N	user@example.com	EMAIL	SECURITY	Integrated Test	Hello world	QUEUED	\N	\N	0	3	{"test": true}	2026-02-08 17:38:22.847821+00	2026-02-08 17:38:22.847821+00
f46589b3-a764-493b-9543-c10b7a8006a9	\N	\N	timeline@example.com	SMS	SYSTEM	Timeline Test	Body	SENT	\N	\N	0	0	\N	2026-02-08 17:38:22.853367+00	2026-02-08 17:38:22.853367+00
2f41f183-7608-4025-a523-904903e65590	test-corr-1	\N	user@example.com	EMAIL	SECURITY	Integrated Test	Hello world	QUEUED	\N	\N	0	3	{"test": true}	2026-02-08 18:20:05.965311+00	2026-02-08 18:20:05.965311+00
6c7673b6-778c-468d-9605-f125ca565d5a	\N	\N	timeline@example.com	SMS	SYSTEM	Timeline Test	Body	SENT	\N	\N	0	0	\N	2026-02-08 18:20:05.970845+00	2026-02-08 18:20:05.970845+00
265415ed-96d5-4f2b-86c7-25e7d0256d36	test-corr-1	\N	user@example.com	EMAIL	SECURITY	Integrated Test	Hello world	QUEUED	\N	\N	0	3	{"test": true}	2026-02-08 18:22:23.916653+00	2026-02-08 18:22:23.916653+00
1b2d13f3-d462-48a3-b101-ac3ef0e32cb6	\N	\N	timeline@example.com	SMS	SYSTEM	Timeline Test	Body	SENT	\N	\N	0	0	\N	2026-02-08 18:22:23.923598+00	2026-02-08 18:22:23.923598+00
e0f2b2c2-d57d-4f54-8d43-a1511c889f2e	\N	\N	filter@example.com	EMAIL	MAINTENANCE	S1		SENT	\N	\N	0	0	\N	2026-02-08 18:22:23.935953+00	2026-02-08 18:22:23.935953+00
17778425-cb41-4583-9b40-f1c5e359e3c2	\N	\N	filter@example.com	SMS	MAINTENANCE	S2		FAILED	\N	\N	0	0	\N	2026-02-08 18:22:23.938111+00	2026-02-08 18:22:23.938111+00
\.


--
-- Data for Name: notification_preference_audit; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.notification_preference_audit (id, user_id, changed_by, old_values, new_values, change_reason, created_at) FROM stdin;
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.notification_settings (id, channel, enabled, max_retries, priority, retention_months, updated_at) FROM stdin;
3a6d847c-1586-402b-97a0-d5c0b71a8cb5	PUSH	t	5	HIGH	12	2026-02-08 18:22:23.929253+00
\.


--
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.notification_templates (id, name, channel, language, subject, body, updated_at) FROM stdin;
\.


--
-- Data for Name: org_support_metrics; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.org_support_metrics (org_id, open_tickets, resolved_tickets, avg_resolution_time, sla_breaches, critical_issues, last_calculated, updated_at) FROM stdin;
1476a987-76ad-4963-b64a-01a71eb739ca	0	0	\N	0	0	2026-02-09 21:05:18.717372+00	2026-02-09 21:05:18.717372+00
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.organizations (id, name, domain, status, created_at, updated_at, default_theme, is_deleted) FROM stdin;
1476a987-76ad-4963-b64a-01a71eb739ca	FlyFleet GSOC	\N	active	2026-02-07 14:17:09.835097+00	2026-02-07 14:17:09.835097+00	light	f
00000000-0000-0000-0000-000000000001	FlyFleet Global	test.com	active	2026-02-10 10:37:48.372044+00	2026-02-10 10:37:48.372044+00	light	f
d6d0bb4a-d189-43c0-8be8-9a94eccb626c	Acme	acme.flyfleet.io	active	2026-02-10 17:31:44.226113+00	2026-02-10 17:31:44.226113+00	dark	f
00000000-0000-0000-0000-000000000003	FastTrack Delivery	fasttrack.com	active	2026-02-12 09:42:35.197913+00	2026-02-12 09:42:35.197913+00	dark	f
00000000-0000-0000-0000-000000000004	Global Freight	globalfreight.net	pending	2026-02-12 09:42:35.202053+00	2026-02-12 09:42:35.202053+00	light	f
00000000-0000-0000-0000-000000000012	Delta Logistics	delta.flyfleet.io	active	2026-02-12 09:43:00.73435+00	2026-02-12 09:43:00.73435+00	light	f
00000000-0000-0000-0000-000000000013	Echo Transport	echo.transport.com	active	2026-02-12 09:43:00.739202+00	2026-02-12 09:43:00.739202+00	dark	f
00000000-0000-0000-0000-000000000014	Foxtrot Systems	foxtrot.systems	pending	2026-02-12 09:43:00.742627+00	2026-02-12 09:43:00.742627+00	light	f
8905c027-5e1d-4b42-a054-6680f4cab7f4	Verification Lab	verify.lab	active	2026-02-12 22:19:40.788298+00	2026-02-12 22:19:40.788298+00	light	f
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.permissions (id, module, action, created_at, description) FROM stdin;
96c0a52f-ce15-428e-9207-03e6fb091006	users	read	2026-02-10 10:41:22.798548+00	View users
4a985b86-d86f-40b1-8f24-ccbddf1c36c0	users	create	2026-02-10 10:41:22.805753+00	Create users
547c2688-864f-45f2-933d-67a52ea2f500	users	update	2026-02-10 10:41:22.816473+00	Update users
8f4eef62-2392-4a8f-aa55-96a75c0f72cc	users	delete	2026-02-10 10:41:22.83199+00	Delete users
c3a9bc32-f533-43db-aeab-5ca63a570c86	roles	read	2026-02-10 10:41:22.846965+00	View roles
5594b6ed-ec45-4da7-b03c-1e329b29816d	roles	create	2026-02-10 10:41:22.860822+00	Create roles
e7b004eb-9698-4ffc-a405-1a77e5e4b21c	roles	update	2026-02-10 10:41:22.874917+00	Update roles
09f0c71b-7a6d-4e62-8c8a-78c1327a1d78	roles	delete	2026-02-10 10:41:22.890224+00	Delete roles
95ee09a9-d824-4586-b365-39a55d6ecd00	vehicles	read	2026-02-10 10:41:22.904835+00	View vehicles
15f61c4b-5dfe-4617-88b6-9a6e743b2c36	vehicles	create	2026-02-10 10:41:22.919946+00	Create vehicles
181473b9-c6b7-4920-866a-6384b9660688	vehicles	update	2026-02-10 10:41:22.93517+00	Update vehicles
a8b149c3-9e58-46fc-8602-7bab6432c822	vehicles	delete	2026-02-10 10:41:22.951288+00	Delete vehicles
252b3dab-cd3a-4452-86e3-320c0942c379	reports	read	2026-02-10 10:41:22.965655+00	View reports
a99e25fb-5184-4a1e-88ea-d70c2caf5d0f	reports	export	2026-02-10 10:41:22.980393+00	Export reports
5dd72439-f292-4359-9692-7f05c3092208	settings	read	2026-02-10 10:41:22.996413+00	View settings
e0d76f16-4720-450a-a79d-15915f10637f	settings	update	2026-02-10 10:41:23.013776+00	Update settings
a4fa456c-2b2c-4a2a-a643-fdc43f34af7b	audit	read	2026-02-10 10:41:23.028492+00	View audit logs
459f13f4-4378-4b6c-92dc-2690b8d2cc9a	user	read	2026-02-10 15:51:08.070372+00	View users
2d1a82ca-b0e8-4041-b2f0-3aa33b644f8b	user	create	2026-02-10 15:51:08.078917+00	Create users
e725b2f3-67ce-4a0d-9b9a-1a7876a40a74	user	update	2026-02-10 15:51:08.087622+00	Update users
a325afa6-a830-496a-ac7f-29e6fc170a31	user	delete	2026-02-10 15:51:08.104014+00	Delete users
cad93b31-309d-45e1-b937-9d596d600344	org	read	2026-02-10 15:51:08.14995+00	View organizations
54ed69a3-1723-4c42-a9b0-830e3d7a5625	org	create	2026-02-10 15:51:08.166008+00	Create organizations
6396f831-6c4e-4137-81ba-ddaf37fe2d0c	org	update	2026-02-10 15:51:08.181845+00	Update organizations
b89913d0-7b5e-462f-b453-5b4e8c6e6c5b	org	delete	2026-02-10 15:51:08.19818+00	Delete organizations
14461d1c-bad8-4c8f-87c9-4246673cdd39	vehicle	read	2026-02-10 15:51:08.21401+00	View vehicles
e5f1fc39-78c5-4898-88ce-4f06df15ec10	vehicle	create	2026-02-10 15:51:08.23052+00	Create vehicles
e0092148-aa18-4892-90f8-a32b8957154a	vehicle	update	2026-02-10 15:51:08.246567+00	Update vehicles
4dc342af-d6ad-4658-ad68-47af1b79d86f	vehicle	delete	2026-02-10 15:51:08.263328+00	Delete vehicles
d5c0cf1b-d17e-48e8-874f-5a1c16891818	trip	read	2026-02-10 15:51:08.279358+00	View trips
f14fcae5-9fe1-4795-8e25-1c2f44fcf80b	driver	read	2026-02-10 15:51:08.295465+00	View drivers
c98c6951-86dd-4bb0-85c9-241154d15c10	device	read	2026-02-10 15:51:08.311129+00	View devices
357c280a-14f8-4055-8d82-1a0eba6c7249	documents	read	2026-02-10 15:51:08.341565+00	View documents
9dc32340-cab9-4419-b82c-d881647dc782	audit_logs	read	2026-02-10 15:51:08.372148+00	View audit logs
ed939356-8353-4792-9033-c4ad793bce65	dashboard	read	2026-02-10 15:51:08.388421+00	View dashboard
04f61a54-67ed-4711-8811-2f8aab2c9b87	fuel	read	2026-02-10 15:51:08.405174+00	Fuel management
41ae030f-5848-4d0a-a10a-521412d0022c	governance	read	2026-02-10 15:51:08.422064+00	Governance
e91961c2-537c-45d0-a3d6-e2fb494ac85e	disaster_recovery	read	2026-02-10 15:51:08.438962+00	DR
3166fc64-1676-4c93-990d-cc38145e2f58	billing	read	2026-02-13 15:34:01.649354+00	View billing
1f49d1d8-12ff-4f60-94c6-a4affdf0c23e	tracking	read	2026-02-13 15:34:01.663284+00	Real-time tracking
\.


--
-- Data for Name: report_executions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.report_executions (id, report_id, started_at, finished_at, duration_seconds, status, error_message, file_url, file_size, created_at) FROM stdin;
\.


--
-- Data for Name: report_global_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.report_global_settings (id, max_concurrent_jobs, max_retry_attempts, retention_days, smtp_host, smtp_port, smtp_user, updated_at) FROM stdin;
\.


--
-- Data for Name: report_recipients; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.report_recipients (id, report_id, email, created_at) FROM stdin;
\.


--
-- Data for Name: review_items; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.review_items (id, review_id, user_id, role_id, current_status, reviewer_id, reviewed_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
53931c9c-f9ba-4c29-872b-b8692d9a184e	ed939356-8353-4792-9033-c4ad793bce65
53931c9c-f9ba-4c29-872b-b8692d9a184e	c3a9bc32-f533-43db-aeab-5ca63a570c86
53931c9c-f9ba-4c29-872b-b8692d9a184e	c98c6951-86dd-4bb0-85c9-241154d15c10
53931c9c-f9ba-4c29-872b-b8692d9a184e	357c280a-14f8-4055-8d82-1a0eba6c7249
53931c9c-f9ba-4c29-872b-b8692d9a184e	e0d76f16-4720-450a-a79d-15915f10637f
53931c9c-f9ba-4c29-872b-b8692d9a184e	41ae030f-5848-4d0a-a10a-521412d0022c
53931c9c-f9ba-4c29-872b-b8692d9a184e	b89913d0-7b5e-462f-b453-5b4e8c6e6c5b
53931c9c-f9ba-4c29-872b-b8692d9a184e	5dd72439-f292-4359-9692-7f05c3092208
53931c9c-f9ba-4c29-872b-b8692d9a184e	9dc32340-cab9-4419-b82c-d881647dc782
53931c9c-f9ba-4c29-872b-b8692d9a184e	e7b004eb-9698-4ffc-a405-1a77e5e4b21c
53931c9c-f9ba-4c29-872b-b8692d9a184e	e5f1fc39-78c5-4898-88ce-4f06df15ec10
53931c9c-f9ba-4c29-872b-b8692d9a184e	e0092148-aa18-4892-90f8-a32b8957154a
53931c9c-f9ba-4c29-872b-b8692d9a184e	4dc342af-d6ad-4658-ad68-47af1b79d86f
53931c9c-f9ba-4c29-872b-b8692d9a184e	09f0c71b-7a6d-4e62-8c8a-78c1327a1d78
53931c9c-f9ba-4c29-872b-b8692d9a184e	cad93b31-309d-45e1-b937-9d596d600344
53931c9c-f9ba-4c29-872b-b8692d9a184e	54ed69a3-1723-4c42-a9b0-830e3d7a5625
53931c9c-f9ba-4c29-872b-b8692d9a184e	d5c0cf1b-d17e-48e8-874f-5a1c16891818
53931c9c-f9ba-4c29-872b-b8692d9a184e	2d1a82ca-b0e8-4041-b2f0-3aa33b644f8b
53931c9c-f9ba-4c29-872b-b8692d9a184e	f14fcae5-9fe1-4795-8e25-1c2f44fcf80b
53931c9c-f9ba-4c29-872b-b8692d9a184e	e91961c2-537c-45d0-a3d6-e2fb494ac85e
53931c9c-f9ba-4c29-872b-b8692d9a184e	04f61a54-67ed-4711-8811-2f8aab2c9b87
53931c9c-f9ba-4c29-872b-b8692d9a184e	3166fc64-1676-4c93-990d-cc38145e2f58
53931c9c-f9ba-4c29-872b-b8692d9a184e	459f13f4-4378-4b6c-92dc-2690b8d2cc9a
53931c9c-f9ba-4c29-872b-b8692d9a184e	e725b2f3-67ce-4a0d-9b9a-1a7876a40a74
53931c9c-f9ba-4c29-872b-b8692d9a184e	5594b6ed-ec45-4da7-b03c-1e329b29816d
53931c9c-f9ba-4c29-872b-b8692d9a184e	14461d1c-bad8-4c8f-87c9-4246673cdd39
53931c9c-f9ba-4c29-872b-b8692d9a184e	252b3dab-cd3a-4452-86e3-320c0942c379
53931c9c-f9ba-4c29-872b-b8692d9a184e	1f49d1d8-12ff-4f60-94c6-a4affdf0c23e
53931c9c-f9ba-4c29-872b-b8692d9a184e	a325afa6-a830-496a-ac7f-29e6fc170a31
53931c9c-f9ba-4c29-872b-b8692d9a184e	6396f831-6c4e-4137-81ba-ddaf37fe2d0c
53931c9c-f9ba-4c29-872b-b8692d9a184e	a99e25fb-5184-4a1e-88ea-d70c2caf5d0f
2ff567aa-47b1-496c-910e-05bf96f795ee	e91961c2-537c-45d0-a3d6-e2fb494ac85e
2ff567aa-47b1-496c-910e-05bf96f795ee	04f61a54-67ed-4711-8811-2f8aab2c9b87
2ff567aa-47b1-496c-910e-05bf96f795ee	3166fc64-1676-4c93-990d-cc38145e2f58
2ff567aa-47b1-496c-910e-05bf96f795ee	459f13f4-4378-4b6c-92dc-2690b8d2cc9a
2ff567aa-47b1-496c-910e-05bf96f795ee	e725b2f3-67ce-4a0d-9b9a-1a7876a40a74
2ff567aa-47b1-496c-910e-05bf96f795ee	5594b6ed-ec45-4da7-b03c-1e329b29816d
2ff567aa-47b1-496c-910e-05bf96f795ee	14461d1c-bad8-4c8f-87c9-4246673cdd39
2ff567aa-47b1-496c-910e-05bf96f795ee	252b3dab-cd3a-4452-86e3-320c0942c379
2ff567aa-47b1-496c-910e-05bf96f795ee	1f49d1d8-12ff-4f60-94c6-a4affdf0c23e
2ff567aa-47b1-496c-910e-05bf96f795ee	a325afa6-a830-496a-ac7f-29e6fc170a31
2ff567aa-47b1-496c-910e-05bf96f795ee	6396f831-6c4e-4137-81ba-ddaf37fe2d0c
2ff567aa-47b1-496c-910e-05bf96f795ee	a99e25fb-5184-4a1e-88ea-d70c2caf5d0f
2ff567aa-47b1-496c-910e-05bf96f795ee	ed939356-8353-4792-9033-c4ad793bce65
2ff567aa-47b1-496c-910e-05bf96f795ee	c3a9bc32-f533-43db-aeab-5ca63a570c86
2ff567aa-47b1-496c-910e-05bf96f795ee	c98c6951-86dd-4bb0-85c9-241154d15c10
2ff567aa-47b1-496c-910e-05bf96f795ee	357c280a-14f8-4055-8d82-1a0eba6c7249
2ff567aa-47b1-496c-910e-05bf96f795ee	e0d76f16-4720-450a-a79d-15915f10637f
2ff567aa-47b1-496c-910e-05bf96f795ee	41ae030f-5848-4d0a-a10a-521412d0022c
2ff567aa-47b1-496c-910e-05bf96f795ee	b89913d0-7b5e-462f-b453-5b4e8c6e6c5b
2ff567aa-47b1-496c-910e-05bf96f795ee	5dd72439-f292-4359-9692-7f05c3092208
2ff567aa-47b1-496c-910e-05bf96f795ee	9dc32340-cab9-4419-b82c-d881647dc782
2ff567aa-47b1-496c-910e-05bf96f795ee	e7b004eb-9698-4ffc-a405-1a77e5e4b21c
2ff567aa-47b1-496c-910e-05bf96f795ee	e5f1fc39-78c5-4898-88ce-4f06df15ec10
2ff567aa-47b1-496c-910e-05bf96f795ee	e0092148-aa18-4892-90f8-a32b8957154a
2ff567aa-47b1-496c-910e-05bf96f795ee	4dc342af-d6ad-4658-ad68-47af1b79d86f
2ff567aa-47b1-496c-910e-05bf96f795ee	09f0c71b-7a6d-4e62-8c8a-78c1327a1d78
2ff567aa-47b1-496c-910e-05bf96f795ee	cad93b31-309d-45e1-b937-9d596d600344
2ff567aa-47b1-496c-910e-05bf96f795ee	54ed69a3-1723-4c42-a9b0-830e3d7a5625
2ff567aa-47b1-496c-910e-05bf96f795ee	d5c0cf1b-d17e-48e8-874f-5a1c16891818
2ff567aa-47b1-496c-910e-05bf96f795ee	2d1a82ca-b0e8-4041-b2f0-3aa33b644f8b
2ff567aa-47b1-496c-910e-05bf96f795ee	f14fcae5-9fe1-4795-8e25-1c2f44fcf80b
5bb5527a-78b6-48ca-9cc6-164c6d2f135e	252b3dab-cd3a-4452-86e3-320c0942c379
5bb5527a-78b6-48ca-9cc6-164c6d2f135e	a99e25fb-5184-4a1e-88ea-d70c2caf5d0f
a70907c4-9e0d-4e4e-b19e-e06de00becca	c3a9bc32-f533-43db-aeab-5ca63a570c86
a70907c4-9e0d-4e4e-b19e-e06de00becca	252b3dab-cd3a-4452-86e3-320c0942c379
a70907c4-9e0d-4e4e-b19e-e06de00becca	5dd72439-f292-4359-9692-7f05c3092208
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.roles (id, name, description, is_system, created_at, updated_at, organization_id) FROM stdin;
8ae52c14-35b6-486f-bd67-44a8006031cd	super_admin	Full platform access	t	2026-02-09 14:08:17.028764+00	2026-02-09 14:08:17.028764+00	\N
338fd1ae-a18b-40d8-9098-f39335f1cbb6	org_admin	Organization level administrator	t	2026-02-09 14:08:17.028764+00	2026-02-09 14:08:17.028764+00	\N
5191451e-44e6-4803-be1a-6a508ca171ec	fleet_manager	Manages vehicles and drivers	t	2026-02-09 14:08:17.028764+00	2026-02-09 14:08:17.028764+00	\N
585bbeaf-54a3-4098-b343-e6410c703f0e	driver	Driver app access only	t	2026-02-09 14:08:17.028764+00	2026-02-09 14:08:17.028764+00	\N
53931c9c-f9ba-4c29-872b-b8692d9a184e	Super Admin	Full access to the entire system	t	2026-02-10 10:42:34.989166+00	2026-02-10 10:42:34.989166+00	\N
2ff567aa-47b1-496c-910e-05bf96f795ee	Org Admin	Full access to organization resources	t	2026-02-10 10:42:35.032661+00	2026-02-10 10:42:35.032661+00	\N
5bb5527a-78b6-48ca-9cc6-164c6d2f135e	Member	Standard member access	t	2026-02-10 10:42:35.075778+00	2026-02-10 10:42:35.075778+00	\N
a70907c4-9e0d-4e4e-b19e-e06de00becca	Viewer	Read-only access	t	2026-02-10 10:42:35.114641+00	2026-02-10 10:42:35.114641+00	\N
\.


--
-- Data for Name: scheduled_reports; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.scheduled_reports (id, organization_id, name, report_type, format, frequency, cron_expression, delivery_time, timezone, filters, status, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: security_events; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.security_events (id, user_id, event_type, ip_address, user_agent, metadata, created_at) FROM stdin;
147a798d-0956-4d6a-865e-47fe669f8e9b	b967246f-4ad3-4d05-9b33-d60fec25e0db	LOGIN_FAILED	[::1]:49152	curl/8.5.0	{"attempt_count": 1}	2026-02-07 18:44:57.648694+00
8de20fcc-ba6b-407b-8b07-fd6bc7a0e6fd	b967246f-4ad3-4d05-9b33-d60fec25e0db	LOGIN_FAILED	127.0.0.1:60858	curl/8.5.0	{"attempt_count": 2}	2026-02-07 18:45:13.48547+00
\.


--
-- Data for Name: support_audit_log; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.support_audit_log (id, ticket_id, user_id, action, old_value, new_value, details, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.support_tickets (id, ticket_id, org_id, title, description, status, priority, category, assigned_to, reporter_id, created_at, updated_at, resolved_at, sla_deadline, tags, metadata) FROM stdin;
0db128bf-5b59-4eda-883d-52e0c6c73f22	INC-1001	1476a987-76ad-4963-b64a-01a71eb739ca	Test Ticket	Test description	OPEN	HIGH	Technical	\N	1476a987-76ad-4963-b64a-01a71eb739ca	2026-02-09 21:11:26.602892+00	2026-02-09 21:11:26.602892+00	\N	\N	[]	{}
\.


--
-- Data for Name: telemetry; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.telemetry (id, trip_id, latitude, longitude, speed, heading, event_type, event_time) FROM stdin;
9e1d83f4-aefb-4ba1-a580-e93dc2eab9a7	00000000-0000-0000-0000-000000000004	19.07600000	72.87770000	60.00	180.00	position	2026-02-10 08:05:00
f0b42262-f336-4f79-9d49-82754faf1fb8	00000000-0000-0000-0000-000000000004	18.97120000	73.01230000	75.00	185.00	position	2026-02-10 09:00:00
dc61fc88-a876-4949-975c-dfa7701d4fdd	00000000-0000-0000-0000-000000000004	18.52040000	73.85670000	0.00	180.00	completed	2026-02-10 12:00:00
\.


--
-- Data for Name: threat_alerts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.threat_alerts (id, org_id, type, severity, ip, user_id, description, status, created_at) FROM stdin;
\.


--
-- Data for Name: trip_settings; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.trip_settings (id, organization_id, retention_period, policies, updated_at) FROM stdin;
\.


--
-- Data for Name: trips; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.trips (id, organization_id, vehicle_id, driver_id, status, title, description, planned_route, actual_route, waypoints, start_location, end_location, estimated_distance_km, distance, estimated_duration_min, actual_duration_min, fuel_consumed_liters, idling_time_minutes, cargo_details, pod_documents, scheduled_start, start_time, end_time, customer_name, customer_phone, customer_email, cancellation_reason, events, is_deleted, created_at, updated_at, trip_id, actual_distance_km, started_at, ended_at) FROM stdin;
00000000-0000-0000-0000-000000000004	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000002	00000000-0000-0000-0000-000000000003	planned	Untitled Trip	Auto-corrected	\N	\N	\N	{"address": "Mumbai, MH", "latitude": 0, "longitude": 0}	{"address": "Pune, MH", "latitude": 0, "longitude": 0}	100.00	150.50	60	\N	0.00	0	\N	\N	2026-02-12 19:54:08.164281+00	2026-02-10 08:00:00+00	2026-02-10 12:00:00+00	Default Customer	555-0100	customer@example.com	\N	\N	f	2026-02-10 19:57:37.537502+00	2026-02-10 19:57:37.537502+00	TR-2026-0001	0	\N	\N
00000000-0000-0000-0000-000000000005	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000002	00000000-0000-0000-0000-000000000003	planned	Untitled Trip	Auto-corrected	\N	\N	\N	{"address": "Pune, MH", "latitude": 0, "longitude": 0}	{"address": "Bangalore, KA", "latitude": 0, "longitude": 0}	100.00	0.00	60	\N	0.00	0	\N	\N	2026-02-12 19:54:08.164281+00	2026-02-11 06:00:00+00	\N	Default Customer	555-0100	customer@example.com	\N	\N	f	2026-02-10 19:57:37.537502+00	2026-02-10 19:57:37.537502+00	TR-2026-0002	0	\N	\N
40b75ff3-725e-43f5-8542-56f9f211cc5d	00000000-0000-0000-0000-000000000012	9826fc4c-375e-47fd-a831-a57c00c3a4ae	6a5d003b-823d-42c8-932e-97b9c5af0c14	in_progress	Bangalore to Mysore Logistics	Auto parts delivery	[{"type": "pickup", "location": {"address": "Bangalore Hub", "latitude": 12.9716, "longitude": 77.5946}, "sequence": 1}, {"type": "dropoff", "location": {"address": "Mysore Factory", "latitude": 12.2958, "longitude": 76.6394}, "sequence": 2}]	[{"type": "pickup", "status": "departed", "location": {"address": "Bangalore Hub", "latitude": 12.9716, "longitude": 77.5946}, "sequence": 1, "arrival_time": "2024-02-12T08:00:00Z"}]	[]	{"address": "Bangalore Hub", "latitude": 12.9716, "longitude": 77.5946}	{"address": "Mysore Factory", "latitude": 12.2958, "longitude": 76.6394}	150.50	\N	180	\N	25.50	10	{"type": "Auto Parts", "fragile": false, "weight_kg": 800}	\N	2026-02-12 08:31:43.451191+00	2026-02-12 08:31:43.451191+00	\N	AutoComponents Inc	+919876543212	\N	\N	\N	f	2026-02-12 07:31:43.451191+00	2026-02-12 10:31:43.451191+00	\N	0	\N	\N
3f453b27-912c-4727-b7c5-9a9db567b60d	00000000-0000-0000-0000-000000000012	71d782b0-0b52-4711-8fc9-577f65f069ba	\N	planned	Inter-city Transfer	Stock transfer	\N	\N	\N	{"address": "Bangalore Hub", "latitude": 12.9716, "longitude": 77.5946}	{"address": "Chennai Hub", "latitude": 13.0827, "longitude": 80.2707}	300.00	\N	300	\N	0.00	0	{"type": "General", "weight_kg": 500}	\N	2026-02-14 10:31:43.454957+00	\N	\N	Internal	+919876543213	\N	\N	\N	f	2026-02-12 10:31:43.454957+00	2026-02-12 10:31:43.454957+00	\N	0	\N	\N
a59aec7e-7c93-4142-84c5-198afe8628ce	00000000-0000-0000-0000-000000000012	9826fc4c-375e-47fd-a831-a57c00c3a4ae	db2fc801-6a1e-4a8a-a661-2f22afc7cf38	in_progress	Bangalore to Mysore Logistics	Auto parts delivery	[{"type": "pickup", "location": {"address": "Bangalore Hub", "latitude": 12.9716, "longitude": 77.5946}, "sequence": 1}, {"type": "dropoff", "location": {"address": "Mysore Factory", "latitude": 12.2958, "longitude": 76.6394}, "sequence": 2}]	[{"type": "pickup", "status": "departed", "location": {"address": "Bangalore Hub", "latitude": 12.9716, "longitude": 77.5946}, "sequence": 1, "arrival_time": "2024-02-12T08:00:00Z"}]	[]	{"address": "Bangalore Hub", "latitude": 12.9716, "longitude": 77.5946}	{"address": "Mysore Factory", "latitude": 12.2958, "longitude": 76.6394}	150.50	\N	180	\N	25.50	10	{"type": "Auto Parts", "fragile": false, "weight_kg": 800}	\N	2026-02-12 17:37:29.641667+00	2026-02-12 17:37:29.641667+00	\N	AutoComponents Inc	+919876543212	\N	\N	\N	f	2026-02-12 16:37:29.641667+00	2026-02-12 19:37:29.641667+00	\N	0	\N	\N
3da67e6f-4c60-4083-9472-f7163a8b92bf	00000000-0000-0000-0000-000000000012	71d782b0-0b52-4711-8fc9-577f65f069ba	\N	planned	Inter-city Transfer	Stock transfer	\N	\N	\N	{"address": "Bangalore Hub", "latitude": 12.9716, "longitude": 77.5946}	{"address": "Chennai Hub", "latitude": 13.0827, "longitude": 80.2707}	300.00	\N	300	\N	0.00	0	{"type": "General", "weight_kg": 500}	\N	2026-02-14 19:37:29.646095+00	\N	\N	Internal	+919876543213	\N	\N	\N	f	2026-02-12 19:37:29.646095+00	2026-02-12 19:37:29.646095+00	\N	0	\N	\N
\.


--
-- Data for Name: user_notification_preferences; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.user_notification_preferences (id, user_id, email_enabled, sms_enabled, push_enabled, in_app_enabled, last_modified_by, last_modified_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_organizations; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.user_organizations (id, user_id, org_id, role, status, created_at) FROM stdin;
8ceac177-cc46-44f4-9aab-89cfbd685e1e	b967246f-4ad3-4d05-9b33-d60fec25e0db	1476a987-76ad-4963-b64a-01a71eb739ca	admin	active	2026-02-07 14:17:38.523153+00
6f113de8-68c3-4072-acc8-4a0f72e4a52a	4cb4efd1-0717-41ea-a7c7-c74faa999cbc	1476a987-76ad-4963-b64a-01a71eb739ca	admin	active	2026-02-07 14:51:30.652496+00
581ef1bc-4c53-4e08-ba0f-f8c8e382f1c9	fab6254c-1fdf-44d5-b323-feda37817aa2	1476a987-76ad-4963-b64a-01a71eb739ca	admin	active	2026-02-07 18:48:34.987288+00
c5771906-33e3-4c7d-a5dd-5ac1a88472b0	1476a987-76ad-4963-b64a-01a71eb739ca	00000000-0000-0000-0000-000000000001	super_admin	active	2026-02-10 11:44:47.571481+00
27483a18-472e-4ed1-9438-b24bdb1a39b6	dcc55d56-2e2f-499b-aca8-821e2e10887a	00000000-0000-0000-0000-000000000001	admin	active	2026-02-11 12:42:33.346427+00
34f6b5a7-d598-43bb-a504-00e06c9ed45f	b967246f-4ad3-4d05-9b33-d60fec25e0db	00000000-0000-0000-0000-000000000001	admin	active	2026-02-11 12:42:33.346427+00
16e34fa1-f4f7-4f70-904b-3614af5e134a	0f68a2b7-5a20-4a31-aed5-f45361818da1	00000000-0000-0000-0000-000000000012	org_admin	active	2026-02-12 09:43:00.750318+00
d6cc28c7-b9b5-48df-946f-7a69303e7991	aa6465bf-5e6d-48a0-8630-15bb7e723d9a	00000000-0000-0000-0000-000000000012	driver	active	2026-02-12 09:43:00.756392+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.user_roles (user_id, role_id, assigned_by, assigned_at) FROM stdin;
1476a987-76ad-4963-b64a-01a71eb739ca	53931c9c-f9ba-4c29-872b-b8692d9a184e	00000000-0000-0000-0000-000000000000	2026-02-10 11:44:47.60358+00
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.user_sessions (id, user_id, session_id, ip_address, user_agent, device_info, login_time, last_activity, logout_time, is_active, location) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.users (id, email, password_hash, name, phone, mfa_enabled, mfa_secret, status, created_at, updated_at, theme, failed_logins, locked_until, verified, theme_updated_at, is_deleted, role_id) FROM stdin;
99b9fe67-b5b1-4fb4-88c5-ad375e586688	newadmin@flyfleet.com	$2a$10$pzDwYBQya5gy5j62/7EdTeoYjUx8m0XP0zQUAP8iWqO8RBDa8QYYi	New Admin		f	\N	active	2026-02-06 20:08:23.750246+00	2026-02-06 20:08:23.750248+00		0	\N	f	\N	f	\N
aa6465bf-5e6d-48a0-8630-15bb7e723d9a	driver1@delta.io	$2a$10$X7.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1	Delta Driver 1	\N	f	\N	active	2026-02-12 09:43:00.746217+00	2026-02-12 09:43:00.746217+00	light	0	\N	t	\N	f	\N
4cb4efd1-0717-41ea-a7c7-c74faa999cbc	test_api_user@example.com	$2a$10$fWejTMGCoX6WRkQ3RXRgR.gAKv9PsniE8zrfKjMmc5qDOifZNatwu	Test API User	\N	f	\N	active	2026-02-07 14:33:45.316705+00	2026-02-07 15:49:08.656375+00	light	0	\N	t	\N	f	\N
c60028d5-cb64-4438-90db-63014d20c679	debug@example.com	$2a$10$4bTJn/eYWfDIkFOeOZOGK.ZI.2sIpIQ7WluiNyi83W3pWusepA/6W	Debug User		f	\N	active	2026-02-07 18:40:32.835583+00	2026-02-07 18:40:32.835586+00		0	\N	f	\N	f	\N
b967246f-4ad3-4d05-9b33-d60fec25e0db	test@example.com	$2a$10$YFv8k8p4k8p4k8p4k8p4k8p4k8p4k8p4k8p4k8p4k8p4k8p4k8p4	Test Admin	\N	t	\N	active	2026-02-07 14:17:30.853247+00	2026-02-07 18:45:13.479313+00	light	2	\N	f	\N	f	\N
fab6254c-1fdf-44d5-b323-feda37817aa2	test_debug@example.com	$2a$10$Dz.MQXYj2YTjcJ5XKXBWgump5ShmCyr5rcdARVLA/2Tr6SYqxXM4q	Test Debug User		f	\N	active	2026-02-07 18:43:52.567316+00	2026-02-07 20:13:47.152441+00		0	\N	f	\N	f	\N
1476a987-76ad-4963-b64a-01a71eb739ca	admin@test.com	$2a$10$Np9NdxAOBmlJJDaONfTWVeIFfwpaLg4qzIny0CWyp1DU/6fiZCwO2	Admin User		f	\N	active	2026-02-09 21:11:26.171806+00	2026-02-14 10:45:37.951757+00	light	3	\N	f	\N	f	\N
0f68a2b7-5a20-4a31-aed5-f45361818da1	admin@delta.io	$2a$10$Np9NdxAOBmlJJDaONfTWVeIFfwpaLg4qzIny0CWyp1DU/6fiZCwO2	Delta Admin	\N	f	\N	active	2026-02-12 09:43:00.746217+00	2026-02-12 19:58:35.604752+00	light	0	\N	t	\N	f	\N
dcc55d56-2e2f-499b-aca8-821e2e10887a	admin@flyfleet.com	$2a$10$wqhgNlg3/ocPHFS7FQZlf.BYmmyp5paVhNK6ebFLfK1WqRu1hsSc6	Admin User		f	\N	active	2026-02-06 20:06:52.152404+00	2026-02-12 20:28:40.501812+00		3	\N	f	\N	f	\N
89786ec8-f39f-45c3-9afe-171820761961	admin@acme.com	$2a$10$X7.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1	Acme Admin	\N	f	\N	active	2026-02-12 09:42:35.204177+00	2026-02-12 09:42:35.204177+00	light	0	\N	t	\N	f	\N
d6d99e59-8014-445d-ae59-2cb9fec03a7b	driver1@acme.com	$2a$10$X7.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1	Acme Driver 1	\N	f	\N	active	2026-02-12 09:42:35.204177+00	2026-02-12 09:42:35.204177+00	light	0	\N	t	\N	f	\N
\.


--
-- Data for Name: vehicle_assignments; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicle_assignments (id, vehicle_id, driver_id, device_id, started_at, ended_at, is_active) FROM stdin;
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.vehicles (id, org_id, license_plate, model, make, year, color, status, capacity, fuel_type, vin, registration, insurance, odometer, last_service, current_driver_id, created_at, updated_at, deleted_at, vehicle_no, service_due, notes) FROM stdin;
00000000-0000-0000-0000-000000000002	00000000-0000-0000-0000-000000000001	MH-01-AB-1234	Prima	Tata	2023	\N	active	10	diesel	\N	\N	\N	0	\N	\N	2026-02-10 19:57:37.528912+00	2026-02-10 19:57:37.528912+00	\N	V-101	\N	\N
90382e9a-7eb7-471d-8de1-2468dbf3a49a	00000000-0000-0000-0000-000000000001	FLD-103	VNL 860	Volvo	2023	\N	maintenance	1	diesel	VNL-860-103	\N	\N	5000	\N	\N	2026-02-11 12:41:08.374454+00	2026-02-11 12:41:08.374454+00	\N	\N	\N	\N
3d3dda22-2099-48de-84c4-ec09d7aeba2f	00000000-0000-0000-0000-000000000001	FLD-104	T680	Kenworth	2022	\N	active	1	diesel	KW-T680-104	\N	\N	89000	\N	\N	2026-02-11 12:41:08.374454+00	2026-02-11 12:41:08.374454+00	\N	\N	\N	\N
394d65af-8f0d-4253-91d0-26655f38fa5b	00000000-0000-0000-0000-000000000001	FLD-105	579	Peterbilt	2022	\N	active	1	diesel	PB-579-105	\N	\N	34200	\N	\N	2026-02-11 12:41:08.374454+00	2026-02-11 12:41:08.374454+00	\N	\N	\N	\N
f53b6e6c-d105-4f09-8b0d-9d3c7e75fc98	00000000-0000-0000-0000-000000000001	FLD-106	Anthem	Mack	2021	\N	inactive	1	diesel	MACK-ANT-106	\N	\N	150000	\N	\N	2026-02-11 12:41:08.374454+00	2026-02-11 12:41:08.374454+00	\N	\N	\N	\N
372d0472-8f6e-4e73-ba69-c1e8fb94c924	00000000-0000-0000-0000-000000000001	FLD-101	Cascadia	Freightliner	2022	\N	active	1	diesel	1F9E-101	\N	\N	45000	\N	d1000000-0000-0000-0000-000000000001	2026-02-11 12:41:08.374454+00	2026-02-11 12:41:08.374454+00	\N	\N	\N	\N
d574861d-cb71-42c9-a3f4-b3e9790b0eef	00000000-0000-0000-0000-000000000001	FLD-102	M2 106	Freightliner	2021	\N	active	1	diesel	1F9E-102	\N	\N	12000	\N	00000000-0000-0000-0000-000000000003	2026-02-11 12:41:08.374454+00	2026-02-11 12:41:08.374454+00	\N	\N	\N	\N
cc54d794-6286-4334-aefb-cd57969a5108	00000000-0000-0000-0000-000000000002	ACME-001	F-150	Ford	2023	\N	active	1	\N	VIN-ACME-001	\N	\N	0	\N	\N	2026-02-12 09:42:35.212744+00	2026-02-12 09:42:35.212744+00	\N	\N	\N	\N
b5ba2f90-a6ab-48dd-941d-15d9255f8567	00000000-0000-0000-0000-000000000002	ACME-002	Transit	Ford	2022	\N	active	1	\N	VIN-ACME-002	\N	\N	0	\N	\N	2026-02-12 09:42:35.212744+00	2026-02-12 09:42:35.212744+00	\N	\N	\N	\N
c58f4c66-08e6-4d03-87e4-055f6f38ad01	00000000-0000-0000-0000-000000000003	FT-101	Sprinter	Mercedes	2024	\N	active	1	\N	VIN-FT-101	\N	\N	0	\N	\N	2026-02-12 09:42:35.218405+00	2026-02-12 09:42:35.218405+00	\N	\N	\N	\N
9826fc4c-375e-47fd-a831-a57c00c3a4ae	00000000-0000-0000-0000-000000000012	DLT-001	Semi	Tesla	2024	\N	active	1	\N	VIN-DLT-001	\N	\N	0	\N	\N	2026-02-12 09:43:00.760042+00	2026-02-12 09:43:00.760042+00	\N	\N	\N	\N
71d782b0-0b52-4711-8fc9-577f65f069ba	00000000-0000-0000-0000-000000000012	DLT-002	Tre	Nikola	2023	\N	maintenance	1	\N	VIN-DLT-002	\N	\N	0	\N	\N	2026-02-12 09:43:00.760042+00	2026-02-12 09:43:00.760042+00	\N	\N	\N	\N
242c25d3-54c0-4481-bb40-c83a35e62434	00000000-0000-0000-0000-000000000013	ECHO-101	EDV	Rivian	2024	\N	active	1	\N	VIN-ECHO-101	\N	\N	0	\N	\N	2026-02-12 09:43:00.763121+00	2026-02-12 09:43:00.763121+00	\N	\N	\N	\N
\.


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.webhooks (id, org_id, url, events, secret, status, created_at, updated_at) FROM stdin;
ae862db1-e179-4e98-8b52-82891abb6701	1476a987-76ad-4963-b64a-01a71eb739ca	https://example.com/webhook	{integration.created}	whsec_e02a782be50874f21c9d8261d7dbe3e9	active	2026-02-09 14:52:33.486975+00	2026-02-09 14:52:33.486975+00
\.


--
-- Data for Name: work_order_parts; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.work_order_parts (id, work_order_id, part_id, quantity, unit_cost, created_at) FROM stdin;
\.


--
-- Data for Name: work_orders; Type: TABLE DATA; Schema: public; Owner: fleet_user
--

COPY public.work_orders (id, organization_id, vehicle_id, title, description, maintenance_type, priority, status, assigned_to, scheduled_date, completed_date, estimated_cost, actual_cost, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Name: backup_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fleet_user
--

SELECT pg_catalog.setval('public.backup_logs_id_seq', 1, false);


--
-- Name: backup_storage_pools_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fleet_user
--

SELECT pg_catalog.setval('public.backup_storage_pools_id_seq', 1, false);


--
-- Name: global_notification_defaults_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fleet_user
--

SELECT pg_catalog.setval('public.global_notification_defaults_id_seq', 3, true);


--
-- Name: report_global_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fleet_user
--

SELECT pg_catalog.setval('public.report_global_settings_id_seq', 1, false);


--
-- Name: access_reviews access_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.access_reviews
    ADD CONSTRAINT access_reviews_pkey PRIMARY KEY (id);


--
-- Name: alert_rules alert_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alert_rules
    ADD CONSTRAINT alert_rules_pkey PRIMARY KEY (id);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: api_clients api_clients_client_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT api_clients_client_id_key UNIQUE (client_id);


--
-- Name: api_clients api_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT api_clients_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: audit_policies audit_policies_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_org_id_key UNIQUE (org_id);


--
-- Name: audit_policies audit_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_pkey PRIMARY KEY (id);


--
-- Name: audit_settings audit_settings_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_settings
    ADD CONSTRAINT audit_settings_org_id_key UNIQUE (org_id);


--
-- Name: audit_settings audit_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_settings
    ADD CONSTRAINT audit_settings_pkey PRIMARY KEY (id);


--
-- Name: auth_tokens auth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_pkey PRIMARY KEY (id);


--
-- Name: backup_logs backup_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_pkey PRIMARY KEY (id);


--
-- Name: backup_storage_pools backup_storage_pools_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backup_storage_pools
    ADD CONSTRAINT backup_storage_pools_pkey PRIMARY KEY (id);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: bulk_config bulk_config_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_config
    ADD CONSTRAINT bulk_config_pkey PRIMARY KEY (organization_id);


--
-- Name: bulk_job_records bulk_job_records_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_job_records
    ADD CONSTRAINT bulk_job_records_pkey PRIMARY KEY (id);


--
-- Name: bulk_jobs bulk_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_jobs
    ADD CONSTRAINT bulk_jobs_pkey PRIMARY KEY (id);


--
-- Name: device_commands device_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_commands
    ADD CONSTRAINT device_commands_pkey PRIMARY KEY (id);


--
-- Name: device_diagnostics_logs device_diagnostics_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_diagnostics_logs
    ADD CONSTRAINT device_diagnostics_logs_pkey PRIMARY KEY (id);


--
-- Name: device_firmware_status device_firmware_status_device_id_rollout_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_firmware_status
    ADD CONSTRAINT device_firmware_status_device_id_rollout_id_key UNIQUE (device_id, rollout_id);


--
-- Name: device_firmware_status device_firmware_status_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_firmware_status
    ADD CONSTRAINT device_firmware_status_pkey PRIMARY KEY (id);


--
-- Name: device_telemetry device_telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_telemetry
    ADD CONSTRAINT device_telemetry_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: devices devices_serial_number_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_serial_number_key UNIQUE (serial_number);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: dr_restore_logs dr_restore_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_restore_logs
    ADD CONSTRAINT dr_restore_logs_pkey PRIMARY KEY (id);


--
-- Name: dr_restores dr_restores_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_restores
    ADD CONSTRAINT dr_restores_pkey PRIMARY KEY (id);


--
-- Name: driver_behavior driver_behavior_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_behavior
    ADD CONSTRAINT driver_behavior_pkey PRIMARY KEY (id);


--
-- Name: driver_incidents driver_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.driver_incidents
    ADD CONSTRAINT driver_incidents_pkey PRIMARY KEY (id);


--
-- Name: drivers drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pkey PRIMARY KEY (id);


--
-- Name: entity_audit_history entity_audit_history_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.entity_audit_history
    ADD CONSTRAINT entity_audit_history_pkey PRIMARY KEY (id);


--
-- Name: evidence_exports evidence_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.evidence_exports
    ADD CONSTRAINT evidence_exports_pkey PRIMARY KEY (id);


--
-- Name: firmware_packages firmware_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_packages
    ADD CONSTRAINT firmware_packages_pkey PRIMARY KEY (id);


--
-- Name: firmware_rollouts firmware_rollouts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_pkey PRIMARY KEY (id);


--
-- Name: geofences geofences_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofences
    ADD CONSTRAINT geofences_pkey PRIMARY KEY (id);


--
-- Name: global_notification_defaults global_notification_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.global_notification_defaults
    ADD CONSTRAINT global_notification_defaults_pkey PRIMARY KEY (id);


--
-- Name: incident_comments incident_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_comments
    ADD CONSTRAINT incident_comments_pkey PRIMARY KEY (id);


--
-- Name: integration_logs integration_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);


--
-- Name: inventory_parts inventory_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.inventory_parts
    ADD CONSTRAINT inventory_parts_pkey PRIMARY KEY (id);


--
-- Name: ip_rules ip_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.ip_rules
    ADD CONSTRAINT ip_rules_pkey PRIMARY KEY (id);


--
-- Name: login_events login_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.login_events
    ADD CONSTRAINT login_events_pkey PRIMARY KEY (id);


--
-- Name: maintenance_settings maintenance_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.maintenance_settings
    ADD CONSTRAINT maintenance_settings_pkey PRIMARY KEY (organization_id);


--
-- Name: mfa_codes mfa_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_codes
    ADD CONSTRAINT mfa_codes_pkey PRIMARY KEY (id);


--
-- Name: mfa_events mfa_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_events
    ADD CONSTRAINT mfa_events_pkey PRIMARY KEY (id);


--
-- Name: mfa_exceptions mfa_exceptions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_pkey PRIMARY KEY (id);


--
-- Name: mfa_failures mfa_failures_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_failures
    ADD CONSTRAINT mfa_failures_pkey PRIMARY KEY (id);


--
-- Name: mfa_lockouts mfa_lockouts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_pkey PRIMARY KEY (id);


--
-- Name: mfa_org_overrides mfa_org_overrides_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_org_overrides
    ADD CONSTRAINT mfa_org_overrides_org_id_key UNIQUE (org_id);


--
-- Name: mfa_org_overrides mfa_org_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_org_overrides
    ADD CONSTRAINT mfa_org_overrides_pkey PRIMARY KEY (id);


--
-- Name: mfa_policies mfa_policies_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policies
    ADD CONSTRAINT mfa_policies_org_id_key UNIQUE (org_id);


--
-- Name: mfa_policies mfa_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policies
    ADD CONSTRAINT mfa_policies_pkey PRIMARY KEY (id);


--
-- Name: mfa_policy_history mfa_policy_history_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policy_history
    ADD CONSTRAINT mfa_policy_history_pkey PRIMARY KEY (id);


--
-- Name: mfa_users mfa_users_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_users
    ADD CONSTRAINT mfa_users_pkey PRIMARY KEY (user_id);


--
-- Name: notification_events notification_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_events
    ADD CONSTRAINT notification_events_pkey PRIMARY KEY (id);


--
-- Name: notification_logs notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_pkey PRIMARY KEY (id);


--
-- Name: notification_preference_audit notification_preference_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_preference_audit
    ADD CONSTRAINT notification_preference_audit_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_channel_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_channel_key UNIQUE (channel);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_name_channel_language_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_name_channel_language_key UNIQUE (name, channel, language);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: org_support_metrics org_support_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.org_support_metrics
    ADD CONSTRAINT org_support_metrics_pkey PRIMARY KEY (org_id);


--
-- Name: organizations organizations_domain_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_domain_key UNIQUE (domain);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_module_action_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_module_action_key UNIQUE (module, action);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: report_executions report_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.report_executions
    ADD CONSTRAINT report_executions_pkey PRIMARY KEY (id);


--
-- Name: report_global_settings report_global_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.report_global_settings
    ADD CONSTRAINT report_global_settings_pkey PRIMARY KEY (id);


--
-- Name: report_recipients report_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.report_recipients
    ADD CONSTRAINT report_recipients_pkey PRIMARY KEY (id);


--
-- Name: review_items review_items_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: scheduled_reports scheduled_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.scheduled_reports
    ADD CONSTRAINT scheduled_reports_pkey PRIMARY KEY (id);


--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);


--
-- Name: support_audit_log support_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_audit_log
    ADD CONSTRAINT support_audit_log_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_ticket_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_ticket_id_key UNIQUE (ticket_id);


--
-- Name: telemetry telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry
    ADD CONSTRAINT telemetry_pkey PRIMARY KEY (id);


--
-- Name: threat_alerts threat_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.threat_alerts
    ADD CONSTRAINT threat_alerts_pkey PRIMARY KEY (id);


--
-- Name: trip_settings trip_settings_organization_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trip_settings
    ADD CONSTRAINT trip_settings_organization_id_key UNIQUE (organization_id);


--
-- Name: trip_settings trip_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trip_settings
    ADD CONSTRAINT trip_settings_pkey PRIMARY KEY (id);


--
-- Name: trips trips_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_pkey PRIMARY KEY (id);


--
-- Name: work_order_parts unique_part_per_order; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.work_order_parts
    ADD CONSTRAINT unique_part_per_order UNIQUE (work_order_id, part_id);


--
-- Name: inventory_parts unique_part_per_org; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.inventory_parts
    ADD CONSTRAINT unique_part_per_org UNIQUE (organization_id, part_number);


--
-- Name: user_notification_preferences user_notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_notification_preferences user_notification_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_user_id_key UNIQUE (user_id);


--
-- Name: user_organizations user_organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_pkey PRIMARY KEY (id);


--
-- Name: user_organizations user_organizations_user_id_org_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_user_id_org_id_key UNIQUE (user_id, org_id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_session_id_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_session_id_key UNIQUE (session_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vehicle_assignments vehicle_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_assignments
    ADD CONSTRAINT vehicle_assignments_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_license_plate_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_license_plate_key UNIQUE (license_plate);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_vehicle_no_key; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_vehicle_no_key UNIQUE (vehicle_no);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: work_order_parts work_order_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.work_order_parts
    ADD CONSTRAINT work_order_parts_pkey PRIMARY KEY (id);


--
-- Name: work_orders work_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT work_orders_pkey PRIMARY KEY (id);


--
-- Name: idx_access_reviews_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_access_reviews_org ON public.access_reviews USING btree (org_id);


--
-- Name: idx_access_reviews_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_access_reviews_status ON public.access_reviews USING btree (org_id, status);


--
-- Name: idx_alerts_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_org_id ON public.alerts USING btree (org_id);


--
-- Name: idx_alerts_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_status ON public.alerts USING btree (status);


--
-- Name: idx_alerts_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_timestamp ON public.alerts USING btree ("timestamp");


--
-- Name: idx_alerts_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_alerts_vehicle_id ON public.alerts USING btree (vehicle_id);


--
-- Name: idx_api_clients_client_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_api_clients_client_id ON public.api_clients USING btree (client_id);


--
-- Name: idx_api_clients_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_api_clients_org ON public.api_clients USING btree (org_id);


--
-- Name: idx_assignments_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_assignments_vehicle ON public.vehicle_assignments USING btree (vehicle_id);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: idx_audit_logs_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_org_id ON public.audit_logs USING btree (org_id);


--
-- Name: idx_audit_logs_severity; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_severity ON public.audit_logs USING btree (severity);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_auth_tokens_refresh_token; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_auth_tokens_refresh_token ON public.auth_tokens USING btree (refresh_token);


--
-- Name: idx_auth_tokens_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_auth_tokens_user_id ON public.auth_tokens USING btree (user_id);


--
-- Name: idx_backup_logs_backup_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_backup_logs_backup_id ON public.backup_logs USING btree (backup_id);


--
-- Name: idx_backups_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_backups_created_at ON public.backups USING btree (created_at);


--
-- Name: idx_backups_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_backups_status ON public.backups USING btree (status);


--
-- Name: idx_behavior_driver_period; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_behavior_driver_period ON public.driver_behavior USING btree (driver_id, period_start);


--
-- Name: idx_bulk_job_records_job_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_bulk_job_records_job_id ON public.bulk_job_records USING btree (job_id);


--
-- Name: idx_bulk_jobs_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_bulk_jobs_org ON public.bulk_jobs USING btree (organization_id);


--
-- Name: idx_bulk_jobs_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_bulk_jobs_status ON public.bulk_jobs USING btree (status);


--
-- Name: idx_device_commands_device; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_commands_device ON public.device_commands USING btree (device_id);


--
-- Name: idx_device_commands_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_commands_status ON public.device_commands USING btree (status);


--
-- Name: idx_device_diagnostics_logs_device; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_diagnostics_logs_device ON public.device_diagnostics_logs USING btree (device_id);


--
-- Name: idx_device_diagnostics_logs_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_diagnostics_logs_timestamp ON public.device_diagnostics_logs USING btree ("timestamp" DESC);


--
-- Name: idx_device_firmware_status_rollout; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_firmware_status_rollout ON public.device_firmware_status USING btree (rollout_id);


--
-- Name: idx_device_telemetry_device; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_telemetry_device ON public.device_telemetry USING btree (device_id);


--
-- Name: idx_device_telemetry_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_device_telemetry_timestamp ON public.device_telemetry USING btree ("timestamp" DESC);


--
-- Name: idx_devices_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_devices_org ON public.devices USING btree (org_id);


--
-- Name: idx_documents_expiry_date; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_expiry_date ON public.documents USING btree (expiry_date);


--
-- Name: idx_documents_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_status ON public.documents USING btree (status);


--
-- Name: idx_documents_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_type ON public.documents USING btree (type);


--
-- Name: idx_documents_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_documents_vehicle_id ON public.documents USING btree (vehicle_id);


--
-- Name: idx_dr_restore_logs_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dr_restore_logs_created_at ON public.dr_restore_logs USING btree (created_at);


--
-- Name: idx_dr_restore_logs_restore_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dr_restore_logs_restore_id ON public.dr_restore_logs USING btree (restore_id);


--
-- Name: idx_dr_restores_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_dr_restores_created_at ON public.dr_restores USING btree (created_at);


--
-- Name: idx_drivers_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_org_id ON public.drivers USING btree (org_id);


--
-- Name: idx_drivers_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_status ON public.drivers USING btree (status);


--
-- Name: idx_drivers_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_drivers_vehicle ON public.drivers USING btree (current_vehicle_id);


--
-- Name: idx_entity_history_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_entity_history_id ON public.entity_audit_history USING btree (entity_id);


--
-- Name: idx_entity_history_type; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_entity_history_type ON public.entity_audit_history USING btree (entity_type);


--
-- Name: idx_firmware_rollouts_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_firmware_rollouts_org ON public.firmware_rollouts USING btree (org_id);


--
-- Name: idx_firmware_rollouts_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_firmware_rollouts_status ON public.firmware_rollouts USING btree (status);


--
-- Name: idx_incident_comments_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_incident_comments_created_at ON public.incident_comments USING btree (created_at);


--
-- Name: idx_incident_comments_ticket_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_incident_comments_ticket_id ON public.incident_comments USING btree (ticket_id);


--
-- Name: idx_incidents_driver; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_incidents_driver ON public.driver_incidents USING btree (driver_id);


--
-- Name: idx_integration_logs_integration; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_logs_integration ON public.integration_logs USING btree (integration_id);


--
-- Name: idx_integration_logs_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_logs_org ON public.integration_logs USING btree (org_id);


--
-- Name: idx_integration_logs_timestamp; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integration_logs_timestamp ON public.integration_logs USING btree ("timestamp" DESC);


--
-- Name: idx_integrations_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integrations_org ON public.integrations USING btree (org_id);


--
-- Name: idx_integrations_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_integrations_status ON public.integrations USING btree (status);


--
-- Name: idx_inventory_low_stock; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_inventory_low_stock ON public.inventory_parts USING btree (organization_id, quantity_available) WHERE (quantity_available <= reorder_level);


--
-- Name: idx_inventory_organization; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_inventory_organization ON public.inventory_parts USING btree (organization_id);


--
-- Name: idx_inventory_part_number; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_inventory_part_number ON public.inventory_parts USING btree (part_number);


--
-- Name: idx_ip_rules_action; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_ip_rules_action ON public.ip_rules USING btree (org_id, action);


--
-- Name: idx_ip_rules_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_ip_rules_org ON public.ip_rules USING btree (org_id);


--
-- Name: idx_login_events_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_login_events_created_at ON public.login_events USING btree (created_at);


--
-- Name: idx_login_events_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_login_events_org_id ON public.login_events USING btree (org_id);


--
-- Name: idx_login_events_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_login_events_status ON public.login_events USING btree (status);


--
-- Name: idx_login_events_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_login_events_user_id ON public.login_events USING btree (user_id);


--
-- Name: idx_mfa_codes_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_codes_user_id ON public.mfa_codes USING btree (user_id);


--
-- Name: idx_mfa_events_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_events_created_at ON public.mfa_events USING btree (created_at);


--
-- Name: idx_mfa_events_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_events_org_id ON public.mfa_events USING btree (org_id);


--
-- Name: idx_mfa_events_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_events_user_id ON public.mfa_events USING btree (user_id);


--
-- Name: idx_mfa_exceptions_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_exceptions_user_id ON public.mfa_exceptions USING btree (user_id);


--
-- Name: idx_mfa_failures_location; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_failures_location ON public.mfa_failures USING btree (location);


--
-- Name: idx_mfa_failures_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_failures_user_id ON public.mfa_failures USING btree (user_id);


--
-- Name: idx_mfa_lockouts_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_lockouts_user_id ON public.mfa_lockouts USING btree (user_id);


--
-- Name: idx_mfa_org_overrides_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_org_overrides_org_id ON public.mfa_org_overrides USING btree (org_id);


--
-- Name: idx_mfa_policy_history_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_mfa_policy_history_org_id ON public.mfa_policy_history USING btree (org_id);


--
-- Name: idx_notif_channel; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_notif_channel ON public.notification_logs USING btree (channel);


--
-- Name: idx_notif_created; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_notif_created ON public.notification_logs USING btree (created_at);


--
-- Name: idx_notif_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_notif_status ON public.notification_logs USING btree (status);


--
-- Name: idx_notif_user; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_notif_user ON public.notification_logs USING btree (user_id);


--
-- Name: idx_notification_preference_audit_user; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_notification_preference_audit_user ON public.notification_preference_audit USING btree (user_id);


--
-- Name: idx_review_items_review; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_review_items_review ON public.review_items USING btree (review_id);


--
-- Name: idx_review_items_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_review_items_status ON public.review_items USING btree (review_id, current_status);


--
-- Name: idx_review_items_user; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_review_items_user ON public.review_items USING btree (user_id);


--
-- Name: idx_support_audit_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_audit_created_at ON public.support_audit_log USING btree (created_at);


--
-- Name: idx_support_audit_ticket_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_audit_ticket_id ON public.support_audit_log USING btree (ticket_id);


--
-- Name: idx_support_tickets_assigned_to; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_assigned_to ON public.support_tickets USING btree (assigned_to);


--
-- Name: idx_support_tickets_created_at; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_created_at ON public.support_tickets USING btree (created_at);


--
-- Name: idx_support_tickets_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_org_id ON public.support_tickets USING btree (org_id);


--
-- Name: idx_support_tickets_priority; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_priority ON public.support_tickets USING btree (priority);


--
-- Name: idx_support_tickets_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_support_tickets_status ON public.support_tickets USING btree (status);


--
-- Name: idx_telemetry_event_time; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_event_time ON public.telemetry USING btree (event_time);


--
-- Name: idx_telemetry_trip_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_telemetry_trip_id ON public.telemetry USING btree (trip_id);


--
-- Name: idx_threat_alerts_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_threat_alerts_org_id ON public.threat_alerts USING btree (org_id);


--
-- Name: idx_threat_alerts_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_threat_alerts_status ON public.threat_alerts USING btree (status);


--
-- Name: idx_trips_driver_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_driver_id ON public.trips USING btree (driver_id);


--
-- Name: idx_trips_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_org_id ON public.trips USING btree (organization_id);


--
-- Name: idx_trips_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_status ON public.trips USING btree (status);


--
-- Name: idx_trips_vehicle_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_trips_vehicle_id ON public.trips USING btree (vehicle_id);


--
-- Name: idx_user_notification_preferences_user; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_notification_preferences_user ON public.user_notification_preferences USING btree (user_id);


--
-- Name: idx_user_org_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_org_org_id ON public.user_organizations USING btree (org_id);


--
-- Name: idx_user_org_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_org_user_id ON public.user_organizations USING btree (user_id);


--
-- Name: idx_user_sessions_is_active; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_sessions_is_active ON public.user_sessions USING btree (is_active);


--
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: idx_users_role_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_users_role_id ON public.users USING btree (role_id);


--
-- Name: idx_vehicles_license; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_license ON public.vehicles USING btree (license_plate);


--
-- Name: idx_vehicles_org_id; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_org_id ON public.vehicles USING btree (org_id);


--
-- Name: idx_vehicles_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_status ON public.vehicles USING btree (status);


--
-- Name: idx_vehicles_vehicle_no; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_vehicle_no ON public.vehicles USING btree (vehicle_no);


--
-- Name: idx_vehicles_vin; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_vehicles_vin ON public.vehicles USING btree (vin);


--
-- Name: idx_webhooks_org; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_webhooks_org ON public.webhooks USING btree (org_id);


--
-- Name: idx_work_order_parts_order; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_order_parts_order ON public.work_order_parts USING btree (work_order_id);


--
-- Name: idx_work_order_parts_part; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_order_parts_part ON public.work_order_parts USING btree (part_id);


--
-- Name: idx_work_orders_assigned; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_assigned ON public.work_orders USING btree (assigned_to);


--
-- Name: idx_work_orders_organization; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_organization ON public.work_orders USING btree (organization_id);


--
-- Name: idx_work_orders_priority; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_priority ON public.work_orders USING btree (priority);


--
-- Name: idx_work_orders_scheduled; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_scheduled ON public.work_orders USING btree (scheduled_date);


--
-- Name: idx_work_orders_status; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_status ON public.work_orders USING btree (status);


--
-- Name: idx_work_orders_vehicle; Type: INDEX; Schema: public; Owner: fleet_user
--

CREATE INDEX idx_work_orders_vehicle ON public.work_orders USING btree (vehicle_id);


--
-- Name: inventory_parts trigger_inventory_parts_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trigger_inventory_parts_updated_at BEFORE UPDATE ON public.inventory_parts FOR EACH ROW EXECUTE FUNCTION public.update_work_orders_updated_at();


--
-- Name: maintenance_settings trigger_maintenance_settings_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trigger_maintenance_settings_updated_at BEFORE UPDATE ON public.maintenance_settings FOR EACH ROW EXECUTE FUNCTION public.update_work_orders_updated_at();


--
-- Name: work_orders trigger_work_orders_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER trigger_work_orders_updated_at BEFORE UPDATE ON public.work_orders FOR EACH ROW EXECUTE FUNCTION public.update_work_orders_updated_at();


--
-- Name: incident_comments update_incident_comments_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_incident_comments_updated_at BEFORE UPDATE ON public.incident_comments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: org_support_metrics update_org_support_metrics_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_org_support_metrics_updated_at BEFORE UPDATE ON public.org_support_metrics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: support_tickets update_support_tickets_updated_at; Type: TRIGGER; Schema: public; Owner: fleet_user
--

CREATE TRIGGER update_support_tickets_updated_at BEFORE UPDATE ON public.support_tickets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: access_reviews access_reviews_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.access_reviews
    ADD CONSTRAINT access_reviews_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: access_reviews access_reviews_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.access_reviews
    ADD CONSTRAINT access_reviews_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: alert_rules alert_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alert_rules
    ADD CONSTRAINT alert_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: alert_rules alert_rules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alert_rules
    ADD CONSTRAINT alert_rules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: alerts alerts_acknowledged_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_acknowledged_by_fkey FOREIGN KEY (acknowledged_by) REFERENCES public.users(id);


--
-- Name: alerts alerts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: alerts alerts_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: alerts alerts_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.alert_rules(id);


--
-- Name: api_clients api_clients_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT api_clients_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: audit_logs audit_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_policies audit_policies_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_policies audit_policies_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_policies
    ADD CONSTRAINT audit_policies_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_settings audit_settings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.audit_settings
    ADD CONSTRAINT audit_settings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: auth_tokens auth_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: backup_logs backup_logs_backup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_backup_id_fkey FOREIGN KEY (backup_id) REFERENCES public.backups(id) ON DELETE CASCADE;


--
-- Name: bulk_job_records bulk_job_records_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.bulk_job_records
    ADD CONSTRAINT bulk_job_records_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.bulk_jobs(id) ON DELETE CASCADE;


--
-- Name: device_commands device_commands_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_commands
    ADD CONSTRAINT device_commands_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: device_commands device_commands_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_commands
    ADD CONSTRAINT device_commands_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: device_commands device_commands_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_commands
    ADD CONSTRAINT device_commands_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: device_diagnostics_logs device_diagnostics_logs_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_diagnostics_logs
    ADD CONSTRAINT device_diagnostics_logs_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: device_diagnostics_logs device_diagnostics_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_diagnostics_logs
    ADD CONSTRAINT device_diagnostics_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: device_firmware_status device_firmware_status_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_firmware_status
    ADD CONSTRAINT device_firmware_status_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: device_firmware_status device_firmware_status_rollout_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_firmware_status
    ADD CONSTRAINT device_firmware_status_rollout_id_fkey FOREIGN KEY (rollout_id) REFERENCES public.firmware_rollouts(id) ON DELETE CASCADE;


--
-- Name: device_telemetry device_telemetry_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_telemetry
    ADD CONSTRAINT device_telemetry_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: device_telemetry device_telemetry_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.device_telemetry
    ADD CONSTRAINT device_telemetry_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: devices devices_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: dr_restore_logs dr_restore_logs_restore_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.dr_restore_logs
    ADD CONSTRAINT dr_restore_logs_restore_id_fkey FOREIGN KEY (restore_id) REFERENCES public.dr_restores(id);


--
-- Name: drivers drivers_current_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_current_vehicle_id_fkey FOREIGN KEY (current_vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: entity_audit_history entity_audit_history_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.entity_audit_history
    ADD CONSTRAINT entity_audit_history_actor_fkey FOREIGN KEY (actor) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: evidence_exports evidence_exports_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.evidence_exports
    ADD CONSTRAINT evidence_exports_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: evidence_exports evidence_exports_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.evidence_exports
    ADD CONSTRAINT evidence_exports_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: firmware_rollouts firmware_rollouts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: firmware_rollouts firmware_rollouts_firmware_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_firmware_id_fkey FOREIGN KEY (firmware_id) REFERENCES public.firmware_packages(id) ON DELETE CASCADE;


--
-- Name: firmware_rollouts firmware_rollouts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.firmware_rollouts
    ADD CONSTRAINT firmware_rollouts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: geofences geofences_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofences
    ADD CONSTRAINT geofences_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: geofences geofences_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.geofences
    ADD CONSTRAINT geofences_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: incident_comments incident_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_comments
    ADD CONSTRAINT incident_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: incident_comments incident_comments_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.incident_comments
    ADD CONSTRAINT incident_comments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: integration_logs integration_logs_integration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_integration_id_fkey FOREIGN KEY (integration_id) REFERENCES public.integrations(id) ON DELETE SET NULL;


--
-- Name: integration_logs integration_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: integrations integrations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: ip_rules ip_rules_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.ip_rules
    ADD CONSTRAINT ip_rules_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id);


--
-- Name: ip_rules ip_rules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.ip_rules
    ADD CONSTRAINT ip_rules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: login_events login_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.login_events
    ADD CONSTRAINT login_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: login_events login_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.login_events
    ADD CONSTRAINT login_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: mfa_codes mfa_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_codes
    ADD CONSTRAINT mfa_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_events mfa_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_events
    ADD CONSTRAINT mfa_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_events mfa_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_events
    ADD CONSTRAINT mfa_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_exceptions mfa_exceptions_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.users(id);


--
-- Name: mfa_exceptions mfa_exceptions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_exceptions mfa_exceptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_exceptions
    ADD CONSTRAINT mfa_exceptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_failures mfa_failures_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_failures
    ADD CONSTRAINT mfa_failures_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_failures mfa_failures_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_failures
    ADD CONSTRAINT mfa_failures_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_lockouts mfa_lockouts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_lockouts mfa_lockouts_unlocked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_unlocked_by_fkey FOREIGN KEY (unlocked_by) REFERENCES public.users(id);


--
-- Name: mfa_lockouts mfa_lockouts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_lockouts
    ADD CONSTRAINT mfa_lockouts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mfa_org_overrides mfa_org_overrides_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_org_overrides
    ADD CONSTRAINT mfa_org_overrides_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_policies mfa_policies_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policies
    ADD CONSTRAINT mfa_policies_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_policy_history mfa_policy_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policy_history
    ADD CONSTRAINT mfa_policy_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: mfa_policy_history mfa_policy_history_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_policy_history
    ADD CONSTRAINT mfa_policy_history_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: mfa_users mfa_users_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_users
    ADD CONSTRAINT mfa_users_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: mfa_users mfa_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.mfa_users
    ADD CONSTRAINT mfa_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notification_events notification_events_notification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.notification_events
    ADD CONSTRAINT notification_events_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES public.notification_logs(id) ON DELETE CASCADE;


--
-- Name: org_support_metrics org_support_metrics_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.org_support_metrics
    ADD CONSTRAINT org_support_metrics_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: report_executions report_executions_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.report_executions
    ADD CONSTRAINT report_executions_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.scheduled_reports(id);


--
-- Name: report_recipients report_recipients_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.report_recipients
    ADD CONSTRAINT report_recipients_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.scheduled_reports(id) ON DELETE CASCADE;


--
-- Name: review_items review_items_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.access_reviews(id) ON DELETE CASCADE;


--
-- Name: review_items review_items_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id);


--
-- Name: review_items review_items_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: review_items review_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: roles roles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: security_events security_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: support_audit_log support_audit_log_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_audit_log
    ADD CONSTRAINT support_audit_log_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id);


--
-- Name: support_audit_log support_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_audit_log
    ADD CONSTRAINT support_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: support_tickets support_tickets_reporter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_reporter_id_fkey FOREIGN KEY (reporter_id) REFERENCES public.users(id);


--
-- Name: telemetry telemetry_trip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.telemetry
    ADD CONSTRAINT telemetry_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES public.trips(id) ON DELETE CASCADE;


--
-- Name: threat_alerts threat_alerts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.threat_alerts
    ADD CONSTRAINT threat_alerts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: threat_alerts threat_alerts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.threat_alerts
    ADD CONSTRAINT threat_alerts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: trips trips_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_org_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: user_organizations user_organizations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: user_organizations user_organizations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: vehicle_assignments vehicle_assignments_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.vehicle_assignments
    ADD CONSTRAINT vehicle_assignments_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE SET NULL;


--
-- Name: webhooks webhooks_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: work_order_parts work_order_parts_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.work_order_parts
    ADD CONSTRAINT work_order_parts_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.inventory_parts(id) ON DELETE RESTRICT;


--
-- Name: work_order_parts work_order_parts_work_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fleet_user
--

ALTER TABLE ONLY public.work_order_parts
    ADD CONSTRAINT work_order_parts_work_order_id_fkey FOREIGN KEY (work_order_id) REFERENCES public.work_orders(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 41FY1SYLeJ9IvyyK4XRikSz4PFAjxd0ASrC4C7ZukZ0s2RYxjk9BP5fVrtGx5BZ

